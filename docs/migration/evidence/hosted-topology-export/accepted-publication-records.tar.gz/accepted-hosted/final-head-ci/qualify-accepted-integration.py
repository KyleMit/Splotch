import datetime,hashlib,json,pathlib,stat,subprocess
root=pathlib.Path('/private/tmp/splotch-resume-01a111b0/hosted-export/final-head-ci')
repo=pathlib.Path('/Users/kylemit/.codex/worktrees/migration-neutral-react/Splotch')
def read(name):return json.loads((root/name).read_bytes())
head='34dc4650bf43a9fb12e7378bf4d73b6bc68ebb70';base='709fadd68ecb802aa2c9daa3fc197ce8d072b23c';merge='78d844ce36845e13690e2ca4ee7fcd645eb128d0';tree='ae69ebf1849dd6cfab317b4da7123e037fc0fb3a'
def git(*args):return subprocess.check_output(['/usr/bin/git',*args],cwd=repo).decode().strip()
ci=read('check-runs.json');checks=ci['check_runs']
success=['Release build smoke','Quality','Browserless tests','Page-load performance',*[f'Tests ({i}/8)' for i in range(1,9)],'Firefox smoke','WebKit smoke','Retained web host control','Android release Java compile','iOS release simulator compile','ADR numbers, headings, and index entries agree']
skips=['WebKit commit gate (fast)','WebKit commit gate (fast, fresh-runner retry)','WebKit commit gate (failure report)','WebKit commit gate (full)','Exact topology proof inputs']
assert len(success)==18 and len(checks)==23 and ci['total_count']==23
assert sorted(c['name'] for c in checks)==sorted(success+skips)
assert all(c['head_sha']==head and c['status']=='completed' and c['conclusion']==('success' if c['name'] in success else 'skipped') for c in checks)
pr=read('pr-after-merge.json');actual=read('git-commit-after-merge.json');checked=read('checked-git-commit.json')
assert pr['merged'] and pr['merge_commit_sha']==merge and pr['head']['sha']==head
assert actual['sha']==merge and actual['tree']['sha']==tree and [p['sha'] for p in actual['parents']]==[base,head]
assert checked['sha']=='dcdec1d040446fae924d29ded16ff172b1d84dad' and checked['tree']['sha']==tree and [p['sha'] for p in checked['parents']]==[base,head]
assert read('git-ref-after-merge.json')['object']['sha']==merge
assert git('rev-parse','origin/codex/native-migration')==merge and git('rev-parse',merge+'^{tree}')==tree
assert git('diff','--name-only',head,merge)=='' and git('status','--porcelain=v1')==''
q=read('retained-source-qualification-34dc.json.txt');assert q['conclusion']['acceptanceBlockingIssue'] is None and q['job']['durationSeconds']==1288 and q['workflow']['deadlineSeconds']==2100
workflows=[]
for path in ['.github/workflows/test.yml','.github/workflows/native-compile.yml','.github/workflows/adr-integrity.yml','.github/workflows/native-topology-proof.yml']:
 b=subprocess.check_output(['/usr/bin/git','show',head+':'+path],cwd=repo)
 workflows.append({'path':path,'source':head,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
for name in ['ruleset-main.json','ruleset-pr-assets.json']:
 assert all(x in ['~DEFAULT_BRANCH','refs/heads/pr-assets'] for x in read(name)['conditions']['ref_name']['include'])
receipt={'observedAtUtc':datetime.datetime.now(datetime.UTC).isoformat(),'unit':'PR2707 complete nonproduction topology export','base':base,'reviewedHead':head,'actualCICheckout':checked['sha'],'acceptedMerge':merge,'sameTree':tree,'nativeAndLocalAttributionVerified':True,'checkSet':{'testsWorkflow':{'successfulJobs':15,'excludedJobs':4},'nativeCompileWorkflow':{'successfulJobs':2,'trigger':'changed package.json'},'adrWorkflow':{'successfulJobs':1},'topologyProofWorkflow':{'skippedJobs':1,'condition':'hosted-export head is not an allowed exact-proof ref'},'success':18,'skipped':5,'unfinished':0,'failures':0,'expectedNames':success,'excludedNames':skips},'workflows':workflows,'rival':{'originalConversation':'029bce38-e7e6-4c21-98ac-035278e7f05f','wrapperSession':'59a88b12-e4d7-4180-9f95-fa47bf5e2382','roundsUsed':3,'remaining':0,'actualResumed':True,'findings':0,'unverified':0,'postedReview':'https://github.com/KyleMit/Splotch/pull/2707#pullrequestreview-5435088421','previousThreadsResolved':4},'retainedJob':{'id':112517565587,'durationSeconds':1288,'deadlineSeconds':2100,'sourceQualification':'retained-source-qualification-34dc.json.txt'},'acceptance':'Narrow hosted structured export/reader unit accepted and integrated. Actual cloud observer444locations443keys95resolutions complete at observation; only observed443 subset of542 possible production keys, intentional optional/platform pruning. Operator-attested transport/deployment provenance limitations remain. SW literal absent only precache claim.','limits':['No complete cloud build/install logs','Shipping Capacitor compilation is not ReactNative proof','No replacement UI, native/runtime, continuity, signed upgrade, physical improvement, architecture selection or release cutover acceptance','Later fullrootmanifest/config/lock/source changes invalidate live contract receipts and need existing generator/requalification;39a2 hosted census stays immutable historical evidence'],'postmerge':'Integration branch has no main/tag release-event gates; final main/release obligations remain separate','policyReads':'Two live rulesets apply only defaultMain/pr-assets. Encoded branches URL refused by native tool; supported exact Gitref succeeded. No unavailable branch-protection response is represented as an inspected configuration.','transitions':'Ready/update/merge native API sequential; expectedhead guard; native/local finalcommit/tree/readback exact.'}
p=root/'accepted-integration-78d.json.txt';p.write_text(json.dumps(receipt,indent=2)+'\n');p.chmod(0o444)
print(json.dumps({'receipt':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'integration':merge,'acceptedScope':'hosted export only'}))
