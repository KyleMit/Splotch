from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, io, json, os, stat, tarfile

ROOT = Path(__file__).parent
REPO = Path('/Users/kylemit/.codex/worktrees/migration-neutral-react/Splotch')
PUBLIC = REPO / 'docs/migration/evidence/hosted-topology-export'
REVIEW = Path('/Users/kylemit/Code/Splotch/logs/migration-resumption-01a111b0/hosted-export/original-round2')
sha = lambda data: hashlib.sha256(data).hexdigest()
old = json.loads((PUBLIC / 'manifest.json').read_bytes())
assert sha((PUBLIC / old['archive']['path']).read_bytes()) == old['archive']['sha256']
assert old['archive']['sha256'] == 'b2b4deb92b748f879dfdc316bbd19d74af94998e7f33b8128991504307375a29'
full = json.loads((ROOT / 'full-gates-02/complete.json').read_bytes())
floor = json.loads((ROOT / 'floor-scoped-02/complete.json').read_bytes())
assert full['allCommandsPassed'] and full['allOwnedGroupsGone']
assert floor['allOwnedGroupsGone']
for name, record in [('full-gates-02', full), ('floor-scoped-02', floor)]:
    for row in record['commands']:
        assert row['exitCode'] == 0 and row['groupGone']
        for channel in ('stdout', 'stderr'):
            raw = (ROOT / name / row[channel]['path']).read_bytes()
            assert len(raw) == row[channel]['bytes'] and sha(raw) == row[channel]['sha256']
        try: os.killpg(row['pgid'], 0)
        except ProcessLookupError: pass
        else: raise ValueError('Actual recorded group remains')
for relative, expected in floor['sourceBeforeAndAfter'].items():
    assert sha((REPO / relative).read_bytes()) == expected
sources = []
for name in ('review-repairs-02', 'review-scoped-02', 'review-scoped-03', 'review-scoped-04', 'full-gates-02', 'floor-scoped-02'):
    for source in sorted((ROOT / name).rglob('*')):
        if source.is_dir(): continue
        assert source.is_file() and not source.is_symlink()
        sources.append((source, name + '/' + source.relative_to(ROOT / name).as_posix()))
for name in ('run-review-scoped-02.py', 'run-review-scoped-03.py', 'run-review-scoped-04.py', 'run-full-gates-02.py', 'run-floor-scoped-02.py', 'current-source-paths.json', Path(__file__).name):
    sources.append((ROOT / name, 'producers/' + name))
review_manifest = json.loads((REVIEW / 'manifest.json').read_bytes())
assert review_manifest['original'] == '029bce38-e7e6-4c21-98ac-035278e7f05f'
assert review_manifest['reviewId'] == 5434468134
for row in review_manifest['rows']:
    source = REVIEW / row['path']; raw = source.read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    sources.append((source, 'original-round2/' + row['path']))
sources.append((REVIEW / 'manifest.json', 'original-round2/manifest.json'))
assert len({name for _, name in sources}) == len(sources)
archive = PUBLIC / 'review-repairs.tar.gz'
manifest_path = PUBLIC / 'review-repairs-manifest.json'
assert not archive.exists() and not manifest_path.exists()
rows = []
with archive.open('xb') as output, gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as stored:
    for source, relative in sources:
        assert stat.S_ISREG(source.lstat().st_mode) and not source.is_symlink()
        raw = source.read_bytes(); info = tarfile.TarInfo(relative)
        info.size = len(raw); info.mode = 0o444; info.mtime = 0
        stored.addfile(info, io.BytesIO(raw))
        rows.append({'path': relative, 'bytes': len(raw), 'sha256': sha(raw), 'mode': '0444'})
with tarfile.open(archive, 'r:gz') as stored:
    members = stored.getmembers(); assert len(members) == len(rows)
    for member, row in zip(members, rows):
        relative = Path(member.name)
        assert member.isreg() and not member.linkname and not relative.is_absolute() and '..' not in relative.parts
        assert member.name == row['path'] and member.mode == 0o444 and member.size == row['bytes']
        raw = stored.extractfile(member).read(); assert sha(raw) == row['sha256']
manifest = {'schemaVersion': 1, 'createdAtUtc': datetime.now(timezone.utc).isoformat(), 'sourceBase': full['sourceBase'], 'acceptedIntegration': '709fadd68ecb802aa2c9daa3fc197ce8d072b23c', 'scope': 'Complete original Claude round2 selected technical provenance, failed and passed repaired-source local/scoped/floor channels and exact producers; no raw provider conversations/authentication, hosted census, native app, physical comparison or product acceptance.', 'archive': {'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes())}, 'sourceInputs': floor['sourceBeforeAndAfter'], 'rows': rows}
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
assert sha((PUBLIC / old['archive']['path']).read_bytes()) == old['archive']['sha256']
print(json.dumps({'safeMembers': len(rows), 'logicalBytes': sum(row['bytes'] for row in rows), 'archive': manifest['archive'], 'oldArchiveUnchanged': True}))
