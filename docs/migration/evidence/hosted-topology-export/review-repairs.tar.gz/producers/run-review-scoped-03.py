from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import runpy
import shutil
import signal
import subprocess
import threading
import time

START=time.monotonic()
DEADLINE_SECONDS=480
REPO=Path('/Users/kylemit/.codex/worktrees/migration-neutral-react/Splotch')
OUT=Path(__file__).parent/'review-scoped-03'
OUT.mkdir(exist_ok=False)
RECORDER=Path('/private/tmp/splotch-resume-01a111b0/native/android-qualification/execution/record-python-children.py')
digest=lambda raw:hashlib.sha256(raw).hexdigest()
assert digest(RECORDER.read_bytes())=='c79525316e2fd35d6b7617c281105a15c9df8b2ecb74542a68d7ce743bc466d3'
identity=runpy.run_path(str(RECORDER),run_name='owned_identity_reader')['query_identity']
state={'child':None,'identity':None}

def expired():
    value={'timedOut':True,'elapsedSeconds':time.monotonic()-START,'deadlineSeconds':DEADLINE_SECONDS}
    child=state['child']
    if child is not None and child.poll() is None:
        current=identity(child.pid,OUT)
        if current==state['identity'] and current is not None and current['ppid']==os.getpid() and current['pgid']==child.pid:
            os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=10);value['ownedTerminationIdentity']=current
        else:value['unresolvedOwnership']={'expected':state['identity'],'current':current}
    (OUT/'expired.json').write_text(json.dumps(value,indent=2)+'\n')
    os._exit(124)

timer=threading.Timer(max(0,DEADLINE_SECONDS-(time.monotonic()-START)),expired);timer.daemon=True;timer.start()
paths=json.loads((OUT.parent/'current-source-paths.json').read_text())+['docs/migration/evidence/netlify-install/production-install-contract.json']
source=lambda:{path:digest((REPO/path).read_bytes()) for path in paths}
pre_format=source();before=pre_format
base=subprocess.run(['git','rev-parse','HEAD'],cwd=REPO,capture_output=True,text=True,check=True,timeout=5).stdout.strip()
assert base=='15ee75b85f4903a78567bf6b759204d8bff28b5d'
index_path=Path(subprocess.run(['git','rev-parse','--git-path','index'],cwd=REPO,capture_output=True,text=True,check=True,timeout=5).stdout.strip())
if not index_path.is_absolute():index_path=REPO/index_path
index_before=digest(index_path.read_bytes())
(OUT/'index-before.bin').write_bytes(index_path.read_bytes())
semantic_before=subprocess.run(['git','ls-files','--stage','-z'],cwd=REPO,capture_output=True,check=True,timeout=5).stdout
(OUT/'semantic-index-before.bin').write_bytes(semantic_before)
node_path=Path(shutil.which('node')).resolve(strict=True)
runtime_inputs={str(path):digest(path.read_bytes()) for path in [node_path,(REPO/'node_modules/dprint/bin.cjs').resolve(strict=True),(REPO/'node_modules/dprint/dprint').resolve(strict=True)]}
old_contract=json.loads((REPO/'docs/migration/evidence/netlify-install/production-install-contract.json').read_bytes())
exclusive_path=REPO/'docs/migration/evidence/native-topology-05/candidate-exclusive-artifacts.json'
exclusive_before=digest(exclusive_path.read_bytes())
commands=[
    ['node','node_modules/prettier/bin/prettier.cjs','--write','tools/migration/tests/hosted-topology.test.mjs'],
    ['npm','run','test:tools','--','tools/migration/tests/hosted-topology.test.mjs','tools/migration/tests/netlify-topology-witness.test.mjs'],
    ['node','node_modules/eslint/bin/eslint.js','tools/netlify-topology-witness.mjs','tools/migration/lib/netlify-topology-report.mjs','tools/migration/gen-hosted-topology.mjs','tools/migration/check-hosted-topology.mjs','tools/migration/tests/hosted-topology.test.mjs'],
    ['npm','run','check'],
    ['npm','run','lint'],
]
rows=[]
for index,argv in enumerate(commands):
    at=time.monotonic();started=datetime.now(timezone.utc).isoformat()
    with (OUT/(str(index)+'.stdout.txt')).open('xb') as out,(OUT/(str(index)+'.stderr.txt')).open('xb') as err:
        child=subprocess.Popen(argv,cwd=REPO,stdout=out,stderr=err,start_new_session=True)
        state['child']=child;state['identity']=identity(child.pid,OUT)
        assert state['identity'] and state['identity']['ppid']==os.getpid() and state['identity']['pgid']==child.pid
        row={'argv':argv,'pid':child.pid,'pgid':child.pid,'actualOSIdentity':state['identity'],'startedAt':started}
        (OUT/(str(index)+'.running.json')).write_text(json.dumps(row,indent=2)+'\n')
        child.wait(timeout=max(0,DEADLINE_SECONDS-(time.monotonic()-START)))
    try:os.killpg(child.pid,0);gone=False
    except ProcessLookupError:gone=True
    row.update(exitCode=child.returncode,groupGone=gone,elapsedSeconds=time.monotonic()-at,finishedAt=datetime.now(timezone.utc).isoformat())
    for ch in ['stdout','stderr']:
        file=OUT/(str(index)+'.'+ch+'.txt');raw=file.read_bytes();row[ch]={'path':file.name,'bytes':len(raw),'sha256':digest(raw)}
    rows.append(row)
    (OUT/(str(index)+'.complete.json')).write_text(json.dumps(row,indent=2)+'\n')
    assert gone
    assert row['exitCode']==0
    if index==0: before=source()
    assert before==source()
(OUT/'index-after.bin').write_bytes(index_path.read_bytes())
semantic_after=subprocess.run(['git','ls-files','--stage','-z'],cwd=REPO,capture_output=True,check=True,timeout=5).stdout
(OUT/'semantic-index-after.bin').write_bytes(semantic_after)
assert semantic_before==semantic_after
assert exclusive_before==digest(exclusive_path.read_bytes())
assert all(digest(Path(path).read_bytes())==value for path,value in runtime_inputs.items())
assert subprocess.run(['git','rev-parse','HEAD'],cwd=REPO,capture_output=True,text=True,check=True,timeout=5).stdout.strip()==base
receipt={'owner':'/root','scope':'four original review fixes: format/regenerate, actual locale and umask controls, transport rejecting/restored controls, scoped tools/focused lint/check/lint; no build/hosted/native acceptance',
         'deadlineSeconds':DEADLINE_SECONDS,'elapsedSeconds':time.monotonic()-START,'producerSha256':digest(Path(__file__).read_bytes()),
         'identityReaderSha256':digest(RECORDER.read_bytes()),'sourceBase':base,'indexBeforeSha256':index_before,'indexAfterSha256':digest(index_path.read_bytes()),'semanticIndexBeforeAndAfterSha256':digest(semantic_before),'runtimeInputsBeforeAndAfter':runtime_inputs,'preFormatSource':pre_format,'sourceBefore':before,'sourceAfter':source(),'candidateExclusiveSha256':exclusive_before,'contractRootManifestMatchesCurrentSource':json.loads((REPO/'docs/migration/evidence/netlify-install/production-install-contract.json').read_bytes())['rootManifestSha256']==digest((REPO/'package.json').read_bytes()),'commands':rows,
         'allOwnedGroupsGone':all(row['groupGone'] for row in rows),'allCommandsPassed':all(row['exitCode']==0 for row in rows),
         'finishedAt':datetime.now(timezone.utc).isoformat()}
(OUT/'complete.json').write_text(json.dumps(receipt,indent=2)+'\n');timer.cancel()
print(json.dumps({'allCommandsPassed':receipt['allCommandsPassed'],'elapsedSeconds':receipt['elapsedSeconds'],
                 'allOwnedGroupsGone':receipt['allOwnedGroupsGone'],'sourceUnchanged':before==receipt['sourceAfter'],
                 'exits':[row['exitCode'] for row in rows]}))
assert before==receipt['sourceAfter'] and receipt['elapsedSeconds']<DEADLINE_SECONDS
assert receipt['allCommandsPassed']
