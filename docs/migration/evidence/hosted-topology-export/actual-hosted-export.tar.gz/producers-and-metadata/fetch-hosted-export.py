from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, runpy, signal, subprocess, time

START = time.monotonic()
DEADLINE_SECONDS = 180
ROOT = Path(__file__).parent
OUT = ROOT / 'actual-hosted-01'
PRIVATE = Path('/private/tmp/splotch-resume-01a111b0/host-local/hosted-response-01')
OUT.mkdir(exist_ok=False); PRIVATE.mkdir(mode=0o700, exist_ok=False)
REPO = Path('/Users/kylemit/.codex/worktrees/migration-neutral-react/Splotch')
SOURCE = '39a2cbc8371645687f475b02fb1ebb7ae55820cc'
CURL = Path('/usr/bin/curl')
RECORDER = Path('/private/tmp/splotch-resume-01a111b0/native/android-qualification/execution/record-python-children.py')
sha = lambda data: hashlib.sha256(data).hexdigest()
assert sha(RECORDER.read_bytes()) == 'c79525316e2fd35d6b7617c281105a15c9df8b2ecb74542a68d7ce743bc466d3'
identity = runpy.run_path(str(RECORDER), run_name='owned_identity_reader')['query_identity']
assert subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=REPO, capture_output=True, text=True, check=True, timeout=5).stdout.strip() == SOURCE
api = json.loads((ROOT / 'deploy-meta-01.json').read_bytes())
metadata = api['selectedDeployments'][0]
assert metadata['state'] == 'ready' and metadata['published_at'] is None and metadata['commit_ref'] == SOURCE
assert metadata['id'] == '6ac566ac46de700008f09313' and metadata['site_id'] == '8804b246-aa43-44dc-b997-4dc452079910' and metadata['name'] == 'splotchy'
base = 'https://' + metadata['id'] + '--' + metadata['name'] + '.netlify.app'
selected = {key: metadata[key] for key in ['id', 'build_id', 'site_id', 'commit_ref', 'branch', 'context', 'state']}
(OUT / 'deploy-metadata.json').write_text(json.dumps(selected, indent=2) + '\n')
curl_before = sha(CURL.read_bytes())
rows = []
for label, path in [('artifact', '/migration-install-topology.json'), ('service-worker', '/sw.js'), ('real-missing', '/migration-install-topology-missing.json')]:
    url = base + path
    body = OUT / (label + '.body')
    headers = PRIVATE / (label + '.headers.private.txt')
    output = OUT / (label + '.curl.stdout.json')
    error = OUT / (label + '.curl.stderr.txt')
    argv = [str(CURL), '-q', '--silent', '--show-error', '--proto', '=https', '--connect-timeout', '10', '--max-time', '30', '--header', 'Accept-Encoding: identity', '--header', 'Accept: application/json', '--dump-header', str(headers), '--output', str(body), '--write-out', '%{json}', url]
    with output.open('xb') as stdout, error.open('xb') as stderr:
        child = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, start_new_session=True)
        current = identity(child.pid, OUT)
        assert current and current['ppid'] == os.getpid() and current['pgid'] == child.pid
        row = {'label': label, 'argv': argv, 'url': url, 'pid': child.pid, 'pgid': child.pid, 'actualOSIdentity': current, 'startedAtUtc': datetime.now(timezone.utc).isoformat()}
        (OUT / (label + '.running.json')).write_text(json.dumps(row, indent=2) + '\n')
        try: code = child.wait(timeout=max(0, DEADLINE_SECONDS - (time.monotonic() - START)))
        except subprocess.TimeoutExpired:
            actual = identity(child.pid, OUT)
            assert actual == current and actual['ppid'] == os.getpid() and actual['pgid'] == child.pid, 'Decline unproved timeout signal'
            os.killpg(child.pid, signal.SIGKILL); child.wait(timeout=5); raise
    try: os.killpg(child.pid, 0); gone = False
    except ProcessLookupError: gone = True
    assert gone and code == 0
    transport = json.loads(output.read_bytes())
    assert transport['url_effective'] == url and transport['num_redirects'] == 0
    raw = body.read_bytes(); assert len(raw) == int(transport['size_download'])
    header_data = headers.read_text().split('\r\n\r\n')[-1]
    pairs = {}
    for line in headers.read_text().splitlines():
        if ':' in line:
            key, value = line.split(':', 1); pairs[key.lower()] = value.strip()
    assert pairs.get('content-encoding', 'identity') == 'identity', 'Unexpected compressed body'
    if 'content-length' in pairs: assert int(pairs['content-length']) == len(raw)
    receipt = {'url': url, 'status': transport['http_code'], 'contentType': transport['content_type'], 'bytes': len(raw), 'sha256': sha(raw)}
    (OUT / (label + '.transport.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    headers.chmod(0o600)
    row.update(exitCode=code, groupGone=gone, transport=receipt, selectedHeaders={key: pairs.get(key) for key in ['content-type', 'content-length', 'content-encoding', 'etag', 'cache-control']}, headerBytes=headers.stat().st_size, headerSha256=sha(headers.read_bytes()))
    rows.append(row)
    (OUT / (label + '.complete.json')).write_text(json.dumps(row, indent=2) + '\n')
assert sha(CURL.read_bytes()) == curl_before
assert rows[0]['transport']['status'] == 200 and rows[0]['transport']['contentType'].split(';', 1)[0].lower() == 'application/json'
assert rows[1]['transport']['status'] == 200
assert b'migration-install-topology.json' not in (OUT / 'service-worker.body').read_bytes()
assert rows[2]['transport']['contentType'].split(';', 1)[0].lower() == 'text/html', 'Real missing response is not the preregistered HTML control'
receipt = {'owner': '/root', 'source': SOURCE, 'selectedDeployment': metadata, 'apiMetadataReceiptSha256': sha((ROOT / 'deploy-meta-01.json').read_bytes()), 'producerSha256': sha(Path(__file__).read_bytes()), 'curlSha256BeforeAndAfter': curl_before, 'commands': rows, 'serviceWorkerExportLiteralAbsent': True, 'deadlineSeconds': DEADLINE_SECONDS, 'elapsedSeconds': time.monotonic() - START, 'finishedAtUtc': datetime.now(timezone.utc).isoformat(), 'claim': 'Complete immutable public body transport bound to exact ready nonproduction API deployment/source; strict offline consumption and independent original review remain required. SW literal absence is precache evidence, not a claim about every runtime cache route. Headers/raw API auth/skew state stay host-local.'}
(OUT / 'complete.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'responses': [row['transport'] for row in rows], 'serviceWorkerExportLiteralAbsent': True, 'elapsedSeconds': receipt['elapsedSeconds'], 'allGroupsGone': True}))
