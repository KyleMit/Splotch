from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
import stat
import tarfile

ROOT = Path(__file__).parent
REPO = Path('/Users/kylemit/.codex/worktrees/migration-neutral-react/Splotch')
PUBLIC = REPO / 'docs/migration/evidence/hosted-topology-export'
DURABLE = Path('/Users/kylemit/Code/Splotch/logs/migration-resumption-01a111b0/hosted-export/actual-hosted-export')
SOURCE = '39a2cbc8371645687f475b02fb1ebb7ae55820cc'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
preserved = {}
for name, expected in [('validation.tar.gz', 'b2b4deb92b748f879dfdc316bbd19d74af94998e7f33b8128991504307375a29'), ('review-repairs.tar.gz', '8aeca969c5a29936881b2c41123f241bd17279c30e83af40c913d1ac80aa6e13')]:
    assert sha((PUBLIC / name).read_bytes()) == expected
    preserved[name] = expected
consumption = json.loads((ROOT / 'actual-consumption-02/complete.json').read_bytes())
assert consumption['source'] == SOURCE and consumption['allOwnedGroupsGone']
for index, row in enumerate(consumption['commands']):
    assert row['exitCode'] == (1 if index % 2 == 0 else 0) and row['groupGone']
    for channel in ['stdout', 'stderr']:
        raw = (ROOT / 'actual-consumption-02' / row[channel]['path']).read_bytes()
        assert len(raw) == row[channel]['bytes'] and sha(raw) == row[channel]['sha256']
for path, expected in consumption['sourceBeforeAndAfter'].items():
    assert sha((REPO / path).read_bytes()) == expected
assert json.loads((ROOT / 'actual-consumption-02/parent-qualification.json').read_bytes())['correctNegativeReasonsAndEachExactActualPositive']
assert json.loads((ROOT / 'actual-hosted-01/parent-qualification.json').read_bytes())['all3ActualHttpBodiesAndTransportSizeHashStatusMediaUrlNoRedirectVerified']
sources = []
omitted = []
for directory in ['actual-hosted-01', 'actual-consumption-01', 'actual-consumption-02']:
    for path in sorted((ROOT / directory).iterdir()):
        assert stat.S_ISREG(path.lstat().st_mode) and not path.is_symlink()
        if path.name.endswith('.curl.stdout.json'):
            data = json.loads(path.read_bytes())
            for key in ['url.user', 'url.password', 'url.query', 'url.fragment', 'urle.user', 'urle.password', 'urle.query', 'urle.fragment']:
                assert data[key] is None or data[key] == ''
            omitted.append({'path': directory + '/' + path.name, 'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes()), 'reason': 'Full curl diagnostic certificate/network metadata remains host-local; complete public body and exact selected transport fields are exported, not clipped body data.'})
        else:
            sources.append((path, directory + '/' + path.name))
for name in ['read-proof-deploys.py', 'read-proof-deploy.py', 'fetch-hosted-export.py', 'consume-actual-hosted.py', 'consume-actual-hosted-02.py', 'actual-consumption-preregistration.json', 'actual-consumption-preregistration-02.json', 'deploy-meta-01.json', 'proof-ref-current.json', Path(__file__).name]:
    sources.append((ROOT / name, 'producers-and-metadata/' + name))
recorder = Path('/private/tmp/splotch-resume-01a111b0/native/android-qualification/execution/record-python-children.py')
assert sha(recorder.read_bytes()) == 'c79525316e2fd35d6b7617c281105a15c9df8b2ecb74542a68d7ce743bc466d3'
sources.append((recorder, 'producers-and-metadata/record-python-children.py'))
for path in consumption['sourceBeforeAndAfter']:
    sources.append((REPO / path, 'tested-source/' + path))
assert len(sources) == len({relative for _, relative in sources})
archive = PUBLIC / 'actual-hosted-export.tar.gz'
manifest_path = PUBLIC / 'actual-hosted-export-manifest.json'
assert not archive.exists() and not manifest_path.exists() and not DURABLE.exists()
DURABLE.mkdir(parents=True, mode=0o755)
rows = []
with archive.open('xb') as stream, gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as stored:
    for source, relative in sources:
        assert stat.S_ISREG(source.lstat().st_mode) and not source.is_symlink()
        relative_path = Path(relative)
        assert not relative_path.is_absolute() and '..' not in relative_path.parts
        raw = source.read_bytes()
        item = tarfile.TarInfo(relative)
        item.size = len(raw)
        item.mode = 0o444
        item.mtime = 0
        stored.addfile(item, io.BytesIO(raw))
        target = DURABLE / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as output:
            output.write(raw)
        target.chmod(0o444)
        assert target.read_bytes() == raw
        assert (source.stat().st_dev, source.stat().st_ino) != (target.stat().st_dev, target.stat().st_ino)
        assert target.stat().st_nlink == 1 and stat.S_IMODE(target.stat().st_mode) == 0o444
        rows.append({'path': relative, 'bytes': len(raw), 'sha256': sha(raw), 'mode': '0444'})
with tarfile.open(archive, 'r:gz') as stored:
    members = stored.getmembers()
    assert len(members) == len(rows)
    for member, row in zip(members, rows):
        path = Path(member.name)
        assert member.isreg() and not member.linkname and not path.is_absolute() and '..' not in path.parts
        assert member.name == row['path'] and member.size == row['bytes'] and member.mode == 0o444
        assert sha(stored.extractfile(member).read()) == row['sha256']
manifest = {'schemaVersion': 1, 'createdAtUtc': datetime.now(timezone.utc).isoformat(), 'testedSource': SOURCE, 'acceptedIntegration': '709fadd68ecb802aa2c9daa3fc197ce8d072b23c', 'scope': 'Complete actual immutable nonproduction hosted census/body, selected transport/deploy attribution, full strict-consumer rejecting/restored channels and failed setup record; no raw API skew tokens, headers, provider conversations or authentication state.', 'archive': {'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes())}, 'originalSourceInputs': consumption['sourceBeforeAndAfter'], 'artifact': json.loads((ROOT / 'actual-hosted-01/artifact.transport.json').read_bytes()), 'deployment': json.loads((ROOT / 'actual-hosted-01/deploy-metadata.json').read_bytes()), 'omittedHostLocalDiagnostics': omitted, 'rows': rows, 'preservedArchives': preserved, 'claimLimits': ['Actual artifact export is complete; selected public transport and deployment metadata are operator-attested and distinct from supplied-record invariants.', 'SW export-literal absence is a precache observation, not a whole runtime-cache claim.', 'No complete cloud build/install log export, RN/native/UI, continuity, physical performance, signed upgrade, production or final architecture acceptance.']}
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
(DURABLE / 'manifest.json').write_bytes(manifest_path.read_bytes())
(DURABLE / 'manifest.json').chmod(0o444)
for name, expected in preserved.items():
    assert sha((PUBLIC / name).read_bytes()) == expected
print(json.dumps({'members': len(rows), 'logicalBytes': sum(row['bytes'] for row in rows), 'archive': manifest['archive'], 'durableIndependentFiles': len(rows) + 1, 'preservedArchivesUnchanged': True}))
