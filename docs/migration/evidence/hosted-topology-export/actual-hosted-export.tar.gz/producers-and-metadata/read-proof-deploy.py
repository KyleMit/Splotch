from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, runpy, signal, subprocess, sys, time

START = time.monotonic()
DEADLINE_SECONDS = 60
ROOT = Path(__file__).parent
SOURCE = '39a2cbc8371645687f475b02fb1ebb7ae55820cc'
SITE = '8804b246-aa43-44dc-b997-4dc452079910'
BRANCH = 'feature/netlify-migration-topology-05'
NODE = Path('/Users/kylemit/.nvm/versions/node/v24.16.0/bin/node')
CLI = Path('/Users/kylemit/.nvm/versions/node/v24.16.0/lib/node_modules/netlify-cli')
RECORDER = Path('/private/tmp/splotch-resume-01a111b0/native/android-qualification/execution/record-python-children.py')
sha = lambda data: hashlib.sha256(data).hexdigest()
assert sha(RECORDER.read_bytes()) == 'c79525316e2fd35d6b7617c281105a15c9df8b2ecb74542a68d7ce743bc466d3'
assert json.loads((CLI / 'package.json').read_bytes())['version'] == '26.1.0'
DEPLOY = '6ac566ac46de700008f09313'
assert re.fullmatch(r'deploy-meta-[0-9]{2}', sys.argv[1])
PRIVATE = Path('/private/tmp/splotch-resume-01a111b0/host-local') / sys.argv[1]
PRIVATE.mkdir(mode=0o700, exist_ok=False)
identity = runpy.run_path(str(RECORDER), run_name='owned_identity_reader')['query_identity']
owner_paths = [NODE] + [CLI / name for name in ['package.json', 'bin/run.js', 'dist/commands/api/index.js', 'dist/commands/api/api.js', 'node_modules/@netlify/open-api/dist/swagger.json']]
owners = lambda: {str(path): {'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())} for path in owner_paths}
before = owners()
env = dict(os.environ)
env.update(CI='true', NETLIFY_SITE_ID=SITE, DEBUG='', NO_COLOR='1', NETLIFY_TELEMETRY_DISABLED='true', NETLIFY_UPDATE_NOTIFIER_DISABLED='true')
argv = [str(NODE), str(CLI / 'bin/run.js'), 'api', 'getDeploy', '--data', json.dumps({'deploy_id': DEPLOY}, separators=(',', ':'))]
row = {'owner': '/root', 'operation': 'supported exact getDeploy', 'expectedSource': SOURCE, 'site': SITE, 'branch': BRANCH, 'argv': argv, 'producerSha256': sha(Path(__file__).read_bytes()), 'ownerInputsBefore': before, 'startedAtUtc': datetime.now(timezone.utc).isoformat(), 'deadlineSeconds': DEADLINE_SECONDS, 'scope': 'Read-only complete supported deploy-list response. Raw response may contain skew tokens and stays host-local0600; selected deployment metadata plus raw byte counts/digests only. No production/settings/build/ref/auth/install mutation or installed-graph claim.'}
with (PRIVATE / 'response.private.json').open('xb') as output, (PRIVATE / 'stderr.private.txt').open('xb') as error:
    child = subprocess.Popen(argv, cwd=PRIVATE, stdin=subprocess.DEVNULL, stdout=output, stderr=error, env=env, start_new_session=True)
    observed = identity(child.pid, PRIVATE)
    assert observed and observed['ppid'] == os.getpid() and observed['pgid'] == child.pid
    row.update(pid=child.pid, producerPid=os.getpid(), actualOSIdentity=observed)
    (PRIVATE / 'started.private.json').write_text(json.dumps(row, indent=2) + '\n')
    try:
        row['exitCode'] = child.wait(timeout=max(0, DEADLINE_SECONDS - (time.monotonic() - START)))
    except subprocess.TimeoutExpired:
        current = identity(child.pid, PRIVATE)
        assert current == observed and current['ppid'] == os.getpid() and current['pgid'] == child.pid, 'Decline unproved timeout signal'
        os.killpg(child.pid, signal.SIGKILL); child.wait(timeout=5); row['timedOut'] = True; row['terminationIdentity'] = current
        row['exitCode'] = child.returncode
for path in PRIVATE.iterdir():
    if path.is_file(): path.chmod(0o600)
try: os.killpg(child.pid, 0); gone = False
except ProcessLookupError: gone = True
row['groupGone'] = gone
assert gone and row['exitCode'] == 0
raw = (PRIVATE / 'response.private.json').read_bytes()
record = json.loads(raw)
assert isinstance(record, dict)
assert record['id'] == DEPLOY and record['site_id'] == SITE and record['commit_ref'] == SOURCE and record['branch'] == BRANCH and record['context'] == 'branch-deploy' and record['published_at'] is None
records = [record]
fields = ['id', 'build_id', 'site_id', 'commit_ref', 'branch', 'context', 'state', 'created_at', 'updated_at', 'published_at', 'name', 'deploy_ssl_url', 'deploy_url', 'ssl_url']
row['selectedDeployments'] = [{key: record.get(key) for key in fields}]
row['completeResponseRows'] = 1
row['stdout'] = {'bytes': len(raw), 'sha256': sha(raw)}
stderr = (PRIVATE / 'stderr.private.txt').read_bytes()
row['stderr'] = {'bytes': len(stderr), 'sha256': sha(stderr)}
row['ownerInputsAfter'] = owners(); assert before == row['ownerInputsAfter']
row['elapsedSeconds'] = time.monotonic() - START
row['finishedAtUtc'] = datetime.now(timezone.utc).isoformat()
(ROOT / (sys.argv[1] + '.json')).write_text(json.dumps(row, indent=2) + '\n')
print(json.dumps({'exitCode': row['exitCode'], 'groupGone': gone, 'completeResponseRows': len(records), 'selectedDeployments': row['selectedDeployments'], 'elapsedSeconds': row['elapsedSeconds']}))
