from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import runpy
import signal
import subprocess
import threading
import time

START = time.monotonic()
DEADLINE_SECONDS = 120
ROOT = Path(__file__).parent
REPO = Path('/Users/kylemit/.codex/worktrees/migration-neutral-react/Splotch')
SOURCE = '39a2cbc8371645687f475b02fb1ebb7ae55820cc'
ACTUAL = ROOT / 'actual-hosted-01'
OUT = ROOT / 'actual-consumption-02'
NODE = Path('/Users/kylemit/.nvm/versions/node/v24.16.0/bin/node')
RECORDER = Path('/private/tmp/splotch-resume-01a111b0/native/android-qualification/execution/record-python-children.py')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert sha(NODE.read_bytes()) == '1ee75375e33b94fc34b3b19aede049e11dae90efb63b374dc96d6bdace70c4b8'
assert sha(RECORDER.read_bytes()) == 'c79525316e2fd35d6b7617c281105a15c9df8b2ecb74542a68d7ce743bc466d3'
OUT.mkdir(exist_ok=False)
identity = runpy.run_path(str(RECORDER), run_name='owned_identity_reader')['query_identity']
state = {'child': None, 'identity': None}


def expired():
    receipt = {'timedOut': True, 'elapsedSeconds': time.monotonic() - START}
    child = state['child']
    if child is not None and child.poll() is None:
        current = identity(child.pid, OUT)
        if current == state['identity'] and current is not None and current['ppid'] == os.getpid() and current['pgid'] == child.pid:
            os.killpg(child.pid, signal.SIGKILL)
            child.wait(timeout=5)
            receipt['ownedTerminationIdentity'] = current
        else:
            receipt['unresolvedOwnership'] = {'expected': state['identity'], 'current': current}
    (OUT / 'expired.json').write_text(json.dumps(receipt, indent=2) + '\n')
    os._exit(124)


timer = threading.Timer(max(0, DEADLINE_SECONDS - (time.monotonic() - START)), expired)
timer.daemon = True
timer.start()
git = lambda *argv: subprocess.run(['git', *argv], cwd=REPO, capture_output=True, check=True, timeout=10).stdout
assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert git('status', '--porcelain') == b''
source_paths = [
    'tools/migration/check-hosted-topology.mjs', 'tools/migration/lib/netlify-topology-report.mjs',
    'tools/lib/netlify-runtime.mjs', 'tools/lib/proc.mjs', 'tools/lib/native-candidate.mjs',
    'docs/migration/evidence/netlify-install/production-install-contract.json',
    'pnpm-lock.yaml', 'package.json', 'experiments/native-architecture/package.json',
    'pnpm-workspace.yaml', 'netlify.toml',
]
source = lambda: {path: sha((REPO / path).read_bytes()) for path in source_paths}
before = source()
for path in source_paths:
    assert (REPO / path).read_bytes() == git('show', SOURCE + ':' + path)
index_before = git('ls-files', '--stage', '-z')
(OUT / 'semantic-index.before.bin.txt').write_bytes(index_before)
artifact = ACTUAL / 'artifact.body'
metadata = ACTUAL / 'deploy-metadata.json'
transport = ACTUAL / 'artifact.transport.json'
missing = ACTUAL / 'real-missing.body'
actual_paths = [artifact, metadata, transport, missing, ACTUAL / 'real-missing.transport.json', ACTUAL / 'complete.json']
actual_before = {str(path.relative_to(ROOT)): sha(path.read_bytes()) for path in actual_paths}
raw = artifact.read_bytes()
assert len(raw) == 65935 and sha(raw) == '3766cfe95ee457e5e57dbe3414b70a73ff65d52afc7f5727e5b99d5dad7f8564'
assert len(missing.read_bytes()) == 81575 and sha(missing.read_bytes()) == '29a68de5b2e1c9d79aaaafecdf3c8c86aae4690ee51e6ef2dd7e80f50cfe064f'
(OUT / 'truncated-json.body').write_bytes(raw[:-20])
(OUT / 'fatal-utf8.body').write_bytes(raw + b'\xc3')
wrong_metadata = json.loads(metadata.read_bytes())
wrong_metadata['commit_ref'] = '0' * 40
(OUT / 'wrong-metadata.json').write_text(json.dumps(wrong_metadata, indent=2) + '\n')
wrong_transport = json.loads(transport.read_bytes())
wrong_transport['sha256'] = '0' * 64
(OUT / 'wrong-transport.json').write_text(json.dumps(wrong_transport, indent=2) + '\n')
cases = [
    ('real-missing-html', missing, metadata, ACTUAL / 'real-missing.transport.json', 'Hosted file is HTML, not a topology export'),
    ('truncated-json', OUT / 'truncated-json.body', metadata, transport, 'SyntaxError:'),
    ('fatal-utf8', OUT / 'fatal-utf8.body', metadata, transport, 'TypeError: The encoded data was not valid for encoding utf-8'),
    ('wrong-metadata', artifact, OUT / 'wrong-metadata.json', transport, 'Deploy commit differs from expected source'),
    ('changed-transport-digest', artifact, metadata, OUT / 'wrong-transport.json', 'Hosted transport bytes differ'),
]
rows = []


def consume(label, body, meta, receipt, expected_error):
    at = time.monotonic()
    argv = [str(NODE), 'tools/migration/check-hosted-topology.mjs', '--artifact', str(body), '--commit', SOURCE, '--metadata', str(meta), '--transport', str(receipt)]
    with (OUT / (label + '.stdout.txt')).open('xb') as output, (OUT / (label + '.stderr.txt')).open('xb') as error:
        child = subprocess.Popen(argv, cwd=REPO, stdout=output, stderr=error, stdin=subprocess.DEVNULL, start_new_session=True)
        state['child'] = child
        state['identity'] = identity(child.pid, OUT)
        assert state['identity'] and state['identity']['ppid'] == os.getpid() and state['identity']['pgid'] == child.pid
        row = {'label': label, 'argv': argv, 'pid': child.pid, 'pgid': child.pid, 'actualOSIdentity': state['identity'], 'startedAtUtc': datetime.now(timezone.utc).isoformat(), 'expectedError': expected_error}
        (OUT / (label + '.running.json')).write_text(json.dumps(row, indent=2) + '\n')
        child.wait(timeout=max(0, DEADLINE_SECONDS - (time.monotonic() - START)))
    try:
        os.killpg(child.pid, 0)
        gone = False
    except ProcessLookupError:
        gone = True
    row.update(exitCode=child.returncode, groupGone=gone, elapsedSeconds=time.monotonic() - at)
    for channel in ['stdout', 'stderr']:
        path = OUT / (label + '.' + channel + '.txt')
        channel_raw = path.read_bytes()
        row[channel] = {'path': path.name, 'bytes': len(channel_raw), 'sha256': sha(channel_raw)}
    rows.append(row)
    (OUT / (label + '.complete.json')).write_text(json.dumps(row, indent=2) + '\n')
    assert gone and source() == before
    if expected_error is not None:
        assert child.returncode == 1 and row['stdout']['bytes'] == 0
        stderr = (OUT / (label + '.stderr.txt')).read_text()
        assert expected_error in stderr and 'check-hosted-topology.mjs' in stderr
        if label in ['truncated-json', 'fatal-utf8']:
            assert 'parseTopologyJson' in stderr
    else:
        assert child.returncode == 0 and row['stderr']['bytes'] == 0
        result = json.loads((OUT / (label + '.stdout.txt')).read_bytes())
        assert result == {'disposition': 'hosted-topology-invariants-verified', 'commit': SOURCE, 'deploy': {'id': '6ac566ac46de700008f09313', 'buildId': '6ac566ac46de700008f09311', 'siteId': '8804b246-aa43-44dc-b997-4dc452079910'}, 'bytes': 65935, 'sha256': sha(raw), 'contractSha256': '87b8dbf9832b8cc7caf40ba7d4a0a7761e433fe91005e8bf477ecbb10c398720', 'installedPackageCount': 444, 'resolutionCount': 95}


for label, body, meta, receipt, expected_error in cases:
    consume(label, body, meta, receipt, expected_error)
    consume(label + '-restored', artifact, metadata, transport, None)
index_after = git('ls-files', '--stage', '-z')
(OUT / 'semantic-index.after.bin.txt').write_bytes(index_after)
assert index_before == index_after and git('status', '--porcelain') == b''
assert actual_before == {str(path.relative_to(ROOT)): sha(path.read_bytes()) for path in actual_paths}
assert sha(NODE.read_bytes()) == '1ee75375e33b94fc34b3b19aede049e11dae90efb63b374dc96d6bdace70c4b8'
receipt = {'owner': '/root', 'source': SOURCE, 'sourceBeforeAndAfter': before, 'originalActualInputsBeforeAndAfter': actual_before, 'commands': rows, 'producerSha256': sha(Path(__file__).read_bytes()), 'recorderSha256': sha(RECORDER.read_bytes()), 'nodeSha256BeforeAndAfter': sha(NODE.read_bytes()), 'semanticIndexBeforeAndAfterSha256': sha(index_before), 'deadlineSeconds': DEADLINE_SECONDS, 'elapsedSeconds': time.monotonic() - START, 'allOwnedGroupsGone': True, 'finishedAtUtc': datetime.now(timezone.utc).isoformat(), 'claim': 'Strict current CLI consumption of the complete actual immutable hosted export, actual missing-file HTML refusal, and distinct derived JSON/UTF/metadata/digest refusals with unchanged exact-body restoration. Operator transport/API attestation is separate from artifact invariants. No candidate/native/UI, physical performance, release or complete build-log acceptance.'}
(OUT / 'complete.json').write_text(json.dumps(receipt, indent=2) + '\n')
timer.cancel()
print(json.dumps({'exitCodes': [row['exitCode'] for row in rows], 'actualBodyBytes': len(raw), 'installedPackages': 444, 'resolutions': 95, 'elapsedSeconds': receipt['elapsedSeconds'], 'allGroupsGone': True}))
