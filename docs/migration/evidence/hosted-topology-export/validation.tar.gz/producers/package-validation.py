from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
import shutil
import tarfile

ROOT = Path(__file__).parent
REPO = Path('/Users/kylemit/.codex/worktrees/migration-neutral-react/Splotch')
DURABLE = Path('/Users/kylemit/Code/Splotch/logs/migration-resumption-01a111b0')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
floor = ROOT / 'floor-scoped-01'
receipt = json.loads((floor / 'complete.json').read_bytes())
for row in receipt['commands']:
    assert row['exitCode'] == 0 and row['groupGone']
    for channel in ['stdout', 'stderr']:
        raw = (floor / row[channel]['path']).read_bytes()
        assert len(raw) == row[channel]['bytes'] and sha(raw) == row[channel]['sha256']
    try:
        os.killpg(row['pgid'], 0)
    except ProcessLookupError:
        pass
    else:
        raise ValueError('Owned floor group remains')
producer_pid = receipt['commands'][0]['actualOSIdentity']['ppid']
try:
    os.kill(producer_pid, 0)
except ProcessLookupError:
    pass
else:
    raise ValueError('Floor producer remains')
for relative, expected in receipt['sourceBeforeAndAfter'].items():
    assert sha((REPO / relative).read_bytes()) == expected
now = datetime.now(timezone.utc).isoformat()
(floor / 'release.json').write_text(json.dumps({'owner': '/root', 'releasedAtUtc': now, 'allThreeActualGroupsAbsent': [row['pgid'] for row in receipt['commands']], 'producerPidAbsent': producer_pid, 'completeSha256': sha((floor / 'complete.json').read_bytes())}, indent=2) + '\n')
mirror = DURABLE / 'hosted-export/floor-scoped-01'
mirror.mkdir(exist_ok=False)
for source in floor.iterdir():
    assert source.is_file() and not source.is_symlink()
    target = mirror / source.name
    shutil.copyfile(source, target)
    target.chmod(0o444)
    assert source.read_bytes() == target.read_bytes() and source.stat().st_ino != target.stat().st_ino
sources = []
for name in ['scoped-composed-04', 'full-gates-01', 'floor-scoped-01']:
    for source in sorted((ROOT / name).iterdir()):
        assert source.is_file() and not source.is_symlink()
        sources.append((source, name + '/' + source.name))
for source in [ROOT / 'run-full-gates.py', ROOT / 'qualify-full-gates.py', ROOT / 'run-floor-scoped.py', Path(__file__)]:
    sources.append((source, 'producers/' + source.name))
target_root = REPO / 'docs/migration/evidence/hosted-topology-export'
target_root.mkdir(exist_ok=False)
archive_path = target_root / 'validation.tar.gz'
rows = []
with archive_path.open('xb') as output, gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as archived:
    for source, relative in sources:
        raw = source.read_bytes()
        info = tarfile.TarInfo(relative)
        info.size = len(raw)
        info.mode = 0o444
        info.mtime = 0
        archived.addfile(info, io.BytesIO(raw))
        rows.append({'path': relative, 'bytes': len(raw), 'sha256': sha(raw), 'mode': '0444'})
with tarfile.open(archive_path, 'r:gz') as archived:
    assert [member.name for member in archived.getmembers()] == [row['path'] for row in rows]
    for member, row in zip(archived.getmembers(), rows):
        assert member.isfile() and member.mode == 0o444 and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        raw = archived.extractfile(member).read()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
manifest = {'schemaVersion': 1, 'sourceBase': receipt['sourceBase'], 'scope': 'Complete local scoped/floor/full-command channels and recorder failure qualification; not complete hosted installed graph or native product acceptance.', 'archive': {'path': archive_path.name, 'bytes': archive_path.stat().st_size, 'sha256': sha(archive_path.read_bytes())}, 'rows': rows}
(target_root / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
live_path = DURABLE / 'LIVE-UNITS.json'
live = json.loads(live_path.read_bytes())
assert live['leases']['exclusiveHost']['producerSha256'] == receipt['producerSha256']
live['leases']['exclusiveHost'].update(state='released', releasedAtUtc=now, receipt='hosted-export/floor-scoped-01/release.json')
live['updatedAtUtc'] = now
unit = next(unit for unit in live['units'] if unit['unit'] == 'complete hosted topology artifact export')
unit['states']['floorExecution'] = 'Actual Node22.13 version/path/ARM64, ordinary export loader no-op and three scoped suites passed; same11source/semanticindex/floorbinary; all3groups and producer absent.'
unit['states']['publicationPreparation'] = 'Complete local validation capsule with each safe member and byte/hash verified; source review and hosted evidence remain pending.'
live_path.write_text(json.dumps(live, indent=2) + '\n')
print(json.dumps({'floorReleasedAtUtc': now, 'safeVerifiedMembers': len(rows), 'capsuleBytes': manifest['archive']['bytes'], 'capsuleSha256': manifest['archive']['sha256']}))
