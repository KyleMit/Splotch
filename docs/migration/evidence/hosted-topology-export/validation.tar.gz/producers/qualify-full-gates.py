from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import subprocess

ROOT = Path(__file__).parent
OUT = ROOT / 'full-gates-01'
REPO = Path('/Users/kylemit/.codex/worktrees/migration-neutral-react/Splotch')
DURABLE = Path('/Users/kylemit/Code/Splotch/logs/migration-resumption-01a111b0')
BASE = '709fadd68ecb802aa2c9daa3fc197ce8d072b23c'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def git(*argv):
    return subprocess.run(['git', *argv], cwd=REPO, check=True, capture_output=True, timeout=15).stdout

def index_entries(raw):
    result = {}
    for record in raw.split(b'\0'):
        if not record:
            continue
        header, relative = record.split(b'\t', 1)
        mode, object_id, stage = header.decode().split()
        assert stage == '0'
        result[relative.decode()] = [mode, object_id, stage]
    return result

def absent(identifier, group=False):
    try:
        (os.killpg if group else os.kill)(identifier, 0)
    except ProcessLookupError:
        return True
    return False

assert git('rev-parse', 'HEAD').decode().strip() == BASE
scoped = json.loads((ROOT / 'scoped-composed-04/complete.json').read_bytes())
assert sha((ROOT / 'scoped-composed-04/complete.json').read_bytes()) == 'f22a3166253fd3f3402f25d2c070e72cdc100f1a1082f882597e124639689081'
for relative, expected in scoped['sourceAfter'].items():
    assert sha((REPO / relative).read_bytes()) == expected, relative
for absolute, expected in scoped['runtimeInputsBeforeAndAfter'].items():
    assert sha(Path(absolute).read_bytes()) == expected, absolute
assert sha((REPO / 'docs/migration/evidence/native-topology-05/candidate-exclusive-artifacts.json').read_bytes()) == scoped['candidateExclusiveSha256']
baseline = {}
for record in git('ls-tree', '-r', '-z', 'HEAD').split(b'\0'):
    if record:
        header, relative = record.split(b'\t', 1)
        mode, kind, object_id = header.decode().split()
        baseline[relative.decode()] = [mode, object_id, '0']
current_raw = git('ls-files', '--stage', '-z')
current = index_entries(current_raw)
saved_positive = index_entries((OUT / 'semantic-index-current.bin.txt').read_bytes())
saved_negative = index_entries((OUT / 'semantic-index-rejecting.bin.txt').read_bytes())
assert current == baseline == saved_positive
assert current.keys() == saved_negative.keys()
changed = [relative for relative in current if current[relative] != saved_negative[relative]]
assert changed == ['tools/netlify-topology-witness.mjs']
relative = changed[0]
assert current[relative][0] == '100644'
assert saved_negative[relative] == ['100755', *current[relative][1:]]
alternate_env = dict(os.environ, GIT_INDEX_FILE=str(OUT / 'counterfactual.index'))
restored = subprocess.run(['git', 'ls-files', '--stage', '-z'], cwd=REPO, env=alternate_env, capture_output=True, check=True, timeout=15).stdout
assert index_entries(restored) == baseline
rows = [json.loads((OUT / f'{number}.complete.json').read_bytes()) for number in range(5)]
for row in rows:
    assert row['exitCode'] == 0 and row['groupGone'] and absent(row['pgid'], group=True)
    for channel in ['stdout', 'stderr']:
        evidence = row[channel]
        raw = (OUT / evidence['path']).read_bytes()
        assert len(raw) == evidence['bytes'] and sha(raw) == evidence['sha256']
parent_pid = rows[0]['actualOSIdentity']['ppid']
assert all(row['actualOSIdentity']['ppid'] == parent_pid for row in rows)
assert absent(parent_pid)
elapsed = sum(row['elapsedSeconds'] for row in rows)
assert elapsed < 900
port = (OUT / '0.stdout.txt').read_text().strip()
assert port.isdecimal() and 1024 < int(port) < 65536
for relative in ['web/build/migration-install-topology.json', 'web/static/migration-install-topology.json']:
    target = REPO / relative
    assert not target.exists() and not target.is_symlink()
now = datetime.now(timezone.utc).isoformat()
receipt = {'owner': '/root', 'sourceBase': BASE, 'sourceBeforeAndAfter': scoped['sourceAfter'],
           'runtimeInputsBeforeAndAfter': scoped['runtimeInputsBeforeAndAfter'], 'commands': rows,
           'actualCommandElapsedSumSeconds': elapsed, 'smokePort': port, 'producerSha256': sha((ROOT / 'run-full-gates.py').read_bytes()),
           'qualifierSha256': sha(Path(__file__).read_bytes()), 'semanticIndexEqualsAcceptedBase': True,
           'semanticIndexRejectingControl': {'changedPath': changed[0], 'actualPositiveMode': '100644', 'actualRejectingMode': '100755', 'sameObjectAndStage': True, 'alternateRestored': True, 'realIndexUnmodified': True},
           'rawIndexFailure': {'predicate': 'index_before == digest(index_path.read_bytes())', 'originalRecorderExit': 1,
                               'limit': 'Original raw index bytes were not saved. The exact cache/extension field change cannot be attributed; raw equality did not pass.'},
           'parentQualifierSetupFailure': {'error': "AttributeError: 'str' object has no attribute 'decode'", 'scope': 'One-off parent receipt construction after actual alternate-index negative/restoration; no product source or real index mutation.'},
           'claim': 'Five actual commands returned zero, each source check completed before the raw-index failure. Current eleven source hashes and three runtime hashes match prior frozen source; current semantic index equals accepted base. Ordinary export absent. No hosted, RN app, native app, physical performance or cutover acceptance.',
           'allOwnedGroupsGone': True, 'actualProducerGone': parent_pid, 'qualifiedAtUtc': now}
(OUT / 'postqualification.json').write_text(json.dumps(receipt, indent=2) + '\n')
(OUT / 'release.json').write_text(json.dumps({'owner': '/root', 'releasedAtUtc': now, 'producerPidAbsent': parent_pid, 'allFiveGroupsAbsent': [row['pgid'] for row in rows], 'postqualificationSha256': sha((OUT / 'postqualification.json').read_bytes())}, indent=2) + '\n')
target_root = DURABLE / 'hosted-export/full-gates-01'
target_root.mkdir(parents=True, exist_ok=False)
mirror_rows = []
for source in sorted(OUT.iterdir()):
    assert source.is_file() and not source.is_symlink()
    target = target_root / source.name
    shutil.copyfile(source, target)
    target.chmod(0o444)
    raw = source.read_bytes()
    assert target.read_bytes() == raw and source.stat().st_ino != target.stat().st_ino
    mirror_rows.append({'source': str(source), 'target': str(target), 'bytes': len(raw), 'sha256': sha(raw), 'targetMode': '0444'})
for source in [ROOT / 'run-full-gates.py', Path(__file__)]:
    target = target_root / source.name
    shutil.copyfile(source, target)
    target.chmod(0o444)
    raw = source.read_bytes()
    assert target.read_bytes() == raw
    mirror_rows.append({'source': str(source), 'target': str(target), 'bytes': len(raw), 'sha256': sha(raw), 'targetMode': '0444'})
(ROOT / 'full-gates-durable-mirror.json').write_text(json.dumps({'rows': mirror_rows, 'allQualified': True}, indent=2) + '\n')
live_path = DURABLE / 'LIVE-UNITS.json'
live = json.loads(live_path.read_bytes())
assert live['leases']['exclusiveHost']['producerSha256'] == receipt['producerSha256']
live['updatedAtUtc'] = now
live['leases']['exclusiveHost'].update(state='released', releasedAtUtc=now, receipt='hosted-export/full-gates-01/release.json', limit=receipt['rawIndexFailure']['limit'])
unit = next(unit for unit in live['units'] if unit['unit'] == 'complete hosted topology artifact export')
unit['states']['fullExecution'] = 'Quality15/Browserless5/ordinary web and Capacitor static build all exit0; actual source/runtime unchanged and semantic index equal accepted base. Raw index byte recorder failed; parent postqualification preserves scope and original failure. All five groups and producer absent.'
unit['receipt'] = 'hosted-export/full-gates-01/postqualification.json'
unit['nextGate'] = 'actual Node22.13 export floor controls, reviewable PR/original029b round2 source review; immutable hosted body/round3 and final-head CI'
live_path.write_text(json.dumps(live, indent=2) + '\n')
print(json.dumps({'qualified': True, 'fiveExitCodes': [row['exitCode'] for row in rows], 'sourceFiles': len(scoped['sourceAfter']), 'semanticIndexRows': len(current), 'durableRows': len(mirror_rows), 'releasedAtUtc': now}))
