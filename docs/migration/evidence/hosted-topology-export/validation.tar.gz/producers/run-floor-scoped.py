from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import runpy
import signal
import subprocess
import threading
import time

START = time.monotonic()
DEADLINE_SECONDS = 120
ROOT = Path(__file__).parent
REPO = Path('/Users/kylemit/.codex/worktrees/migration-neutral-react/Splotch')
OUT = ROOT / 'floor-scoped-01'
OUT.mkdir(exist_ok=False)
NODE = Path('/private/tmp/splotch-resume-01a111b0/retained/node-floor/attempt-2/toolchain/node-v22.13.0-darwin-arm64/bin/node')
RECORDER = Path('/private/tmp/splotch-resume-01a111b0/native/android-qualification/execution/record-python-children.py')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert sha(NODE.read_bytes()) == '5c79f8e198fd2456ea6660aaa6be218f9f44747f2306c7d0f5f97b087b2f2dfc'
assert sha(RECORDER.read_bytes()) == 'c79525316e2fd35d6b7617c281105a15c9df8b2ecb74542a68d7ce743bc466d3'
identity = runpy.run_path(str(RECORDER), run_name='owned_identity_reader')['query_identity']
state = {'child': None, 'identity': None}

def expired():
    receipt = {'timedOut': True, 'elapsedSeconds': time.monotonic() - START}
    child = state['child']
    if child is not None and child.poll() is None:
        current = identity(child.pid, OUT)
        if current == state['identity'] and current is not None and current['ppid'] == os.getpid() and current['pgid'] == child.pid:
            os.killpg(child.pid, signal.SIGKILL)
            child.wait(timeout=10)
            receipt['ownedTerminationIdentity'] = current
        else:
            receipt['unresolvedOwnership'] = {'expected': state['identity'], 'current': current}
    (OUT / 'expired.json').write_text(json.dumps(receipt, indent=2) + '\n')
    os._exit(124)

timer = threading.Timer(max(0, DEADLINE_SECONDS - (time.monotonic() - START)), expired)
timer.daemon = True
timer.start()
frozen = json.loads((ROOT / 'scoped-composed-04/complete.json').read_bytes())
source = lambda: {relative: sha((REPO / relative).read_bytes()) for relative in frozen['sourceAfter']}
before = source()
assert before == frozen['sourceAfter']
git = lambda *argv: subprocess.run(['git', *argv], cwd=REPO, capture_output=True, check=True, timeout=15).stdout
assert git('rev-parse', 'HEAD').decode().strip() == frozen['sourceBase']
index_before = git('ls-files', '--stage', '-z')
(OUT / 'semantic-index.before.bin.txt').write_bytes(index_before)
index_path = Path(git('rev-parse', '--git-path', 'index').decode().strip())
if not index_path.is_absolute():
    index_path = REPO / index_path
(OUT / 'raw-index.before.bin.txt').write_bytes(index_path.read_bytes())
environment = dict(os.environ)
environment['PATH'] = str(NODE.parent) + os.pathsep + environment['PATH']
assert environment.get('CAPACITOR') not in ['true', '1'] and environment.get('PERF_MARKS') not in ['true', '1']
assert not environment.get('SPLOTCH_NETLIFY_TOPOLOGY_PROOF')
commands = [
    [str(NODE), '-p', 'JSON.stringify({version:process.version,execPath:process.execPath,arch:process.arch})'],
    [str(NODE), 'tools/migration/gen-hosted-topology.mjs'],
    [str(NODE), '--experimental-strip-types', '--disable-warning=ExperimentalWarning', 'node_modules/vitest/vitest.mjs', 'run', '--config', 'tools/vitest.config.mjs', 'tools/migration/tests/hosted-topology.test.mjs', 'tools/migration/tests/netlify-topology-witness.test.mjs', 'tools/tests/enumerated-build-paths.test.mjs'],
]
rows = []
for number, argv in enumerate(commands):
    at = time.monotonic()
    with (OUT / f'{number}.stdout.txt').open('xb') as output, (OUT / f'{number}.stderr.txt').open('xb') as error:
        child = subprocess.Popen(argv, cwd=REPO, env=environment, stdout=output, stderr=error, start_new_session=True)
        state['child'] = child
        state['identity'] = identity(child.pid, OUT)
        assert state['identity'] and state['identity']['ppid'] == os.getpid() and state['identity']['pgid'] == child.pid
        row = {'argv': argv, 'pid': child.pid, 'pgid': child.pid, 'actualOSIdentity': state['identity'], 'startedAtUtc': datetime.now(timezone.utc).isoformat()}
        (OUT / f'{number}.running.json').write_text(json.dumps(row, indent=2) + '\n')
        child.wait(timeout=max(0, DEADLINE_SECONDS - (time.monotonic() - START)))
    try:
        os.killpg(child.pid, 0)
        gone = False
    except ProcessLookupError:
        gone = True
    row.update(exitCode=child.returncode, groupGone=gone, elapsedSeconds=time.monotonic() - at)
    for channel in ['stdout', 'stderr']:
        path = OUT / f'{number}.{channel}.txt'
        raw = path.read_bytes()
        row[channel] = {'path': path.name, 'bytes': len(raw), 'sha256': sha(raw)}
    rows.append(row)
    (OUT / f'{number}.complete.json').write_text(json.dumps(row, indent=2) + '\n')
    assert child.returncode == 0 and gone and source() == before
assert json.loads((OUT / '0.stdout.txt').read_bytes()) == {'version': 'v22.13.0', 'execPath': str(NODE), 'arch': 'arm64'}
assert json.loads((OUT / '1.stdout.txt').read_bytes()) == {'disposition': 'not-the-selected-proof-ref'}
index_after = git('ls-files', '--stage', '-z')
assert index_before == index_after
(OUT / 'semantic-index.after.bin.txt').write_bytes(index_after)
(OUT / 'raw-index.after.bin.txt').write_bytes(index_path.read_bytes())
assert sha(NODE.read_bytes()) == '5c79f8e198fd2456ea6660aaa6be218f9f44747f2306c7d0f5f97b087b2f2dfc'
receipt = {'owner': '/root', 'sourceBase': frozen['sourceBase'], 'sourceBeforeAndAfter': before,
           'producerSha256': sha(Path(__file__).read_bytes()), 'floorNodeSha256BeforeAndAfter': sha(NODE.read_bytes()),
           'priorQualifiedRuntimeReceipt': '/private/tmp/splotch-resume-01a111b0/retained/node-floor/full-postbuild/condition.json',
           'commands': rows, 'semanticIndexBeforeAndAfterSha256': sha(index_before), 'deadlineSeconds': DEADLINE_SECONDS,
           'deadlineReason': 'Actual declared-floor export loader, three existing scoped suites and source/binary hashing; previous same suites finished0.51s, full ownership finishing included.',
           'elapsedSeconds': time.monotonic() - START, 'allOwnedGroupsGone': True, 'finishedAtUtc': datetime.now(timezone.utc).isoformat(),
           'claim': 'Actual Node22.13 binary runs ordinary no-op producer and scoped export/observer/deploy-watch controls. No whole new install graph, hosted build, RN/native app, physical performance or release claim.'}
(OUT / 'complete.json').write_text(json.dumps(receipt, indent=2) + '\n')
timer.cancel()
print(json.dumps({'exitCodes': [row['exitCode'] for row in rows], 'actualFloor': 'v22.13.0', 'elapsedSeconds': receipt['elapsedSeconds'], 'sourceUnchanged': True, 'allOwnedGroupsGone': True}))
