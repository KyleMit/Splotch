# Provisional native Settings and drawing audio source

This feature is based on20b51012a9bb3daa1314cab1d8c276cc9eb8a977 in the isolated
`codex/native-audio-settings` branch. It is an unaccepted provisional source unit. No framework is
selected. Shipping web and Capacitor trees are unchanged.

The candidate adds an accessible Settings entry with one Sound switch. The new sound-v1 snapshot
contains exactly a version and boolean; canonical JSON, finite size and version are validated before
use. Failed reads start muted and expose recovery. Failed writes preserve the session choice and
provide Retry saving. Native writes a checked pending snapshot to a fresh committed revision,
awaits the move and confirms readback before pruning older revisions. It retains the immediately
prior revision. Browser localStorage has its own candidate-owned key and verifies readback. No
legacy settings or credential migration is added.

Drawing gesture samples feed a speed-scaled scratch loop. The copied MP3 and portable gain mapping
are drift-guarded against their shipping owners without importing the shipping browser/rune source.
The native adapter uses the released Expo Audio binding; the browser adapter uses Web Audio. Native
gain interpolation approximates the shipping envelope through wall-clock timers. Lift mutes and
pauses; mute, background, inactive and unmount abort pending initialization and remove/release
players. Late completion cannot start a departed stroke. A stationary held finger becomes quiet.
Load failures leave drawing usable and offer a sound retry through the switch.

The one clip currently reused is pencil-1.mp3. This source slice does not claim full audio parity:
clear-gesture bubbles/page-turn feedback, pencil recording variations, real speaker timbre and latency,
full drawing fidelity, long-session resource use and performance acceptance remain later gates.

## Fresh package inspection

[package-provenance.json](package-provenance.json) records the exact candidate-only dependency
delta and both official registry archives. `expo-audio`57.0.5 is the one new artifact; its peers use
already locked packages. `expo-asset`57.0.18 is an actual new browser root for `Asset.fromModule`,
while its artifact is already in the Expo closure. Both versions match the current released
Expo57.0.26 SDK map. The official metadata, complete tarballs, extracted manifests and per-member
hash inventories are retained in `package-provenance/`. Neither artifact has lifecycle install or
prepare scripts, root hooks or root binding.gyp. No package scripts were executed by this inspection.

The optional audio config plugin is omitted from the maintained native projects: its recording and
background defaults are unused. The library's Android manifest contains only MODIFY_AUDIO_SETTINGS;
there is no microphone permission, recording service or iOS microphone purpose string in this
feature's source. Actual merged permission and native dependency graphs still need build inspection.

The accepted baseline and N1 archive/Forge inputs and F1 scanner/refusal implementation remain
unchanged. This feature's genuine new modules extend only the scanner test's expected inventory,
with direct new-module refusal controls. Exact lock/closure qualification will be composed under
this feature after the execution window opens; no old lock or proof is copied as new acceptance.

## Validation state

Source and regression tests are prepared. The root coordinator has reserved the active build/device
window for N1 qualification. This owner has not installed packages, built, started a server, used a
device or played audio. No browser/native playback or product result is claimed. Formatting,
TypeScript/check/lint, focused tests, full applicable tier, real browser output and native output
will be recorded after the appropriate bounded leases. Formal review and publication are owned by
the root coordinator and have not started for this unit.
