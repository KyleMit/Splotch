from pathlib import Path
import json,tarfile,hashlib,stat,datetime,io
SOURCE=Path('/private/tmp/splotch-l0-native-execution-202610070306')
REPO=Path('/Users/kylemit/.codex/worktrees/migration-legacy-continuity/Splotch')
TARGET=REPO/'docs/migration/evidence/legacy-continuity/hosted-portability'
required=['hosted-linux-portability','portable-receipt-pre-fix','portable-receipt-restored','portable-scoped','portable-final-scoped','portable-quality','portable-browserless','materialize-portable-released','materialize-portable-reader','materialize-portable-held','portable-publication-format','portable-publication-docrefs','portable-publication-docrefs-restored','portable-publication-markdown','portable-publication-format-final','portable-publication-docrefs-final','portable-publication-markdown-final']
files=[]
for directory in required:
 path=SOURCE/directory
 assert path.is_dir(),('L0_INCOMPLETE_PORTABILITY_EVIDENCE',directory)
 for p in sorted(path.rglob('*')):
  if p.is_file():files.append((p,'controls/'+p.relative_to(SOURCE).as_posix()))
for name in ['prepare-owned.py','prepare-owned.pure-before-full.py','source-gate-lease.json.txt','original-review-capacity-map.portable.json.txt','producer-requalification.json.txt','prepared-source-summary.portable.json.txt','released-portable-materialized-baseline.json.txt','reader-portable-materialized-baseline.json.txt','held-portable-materialized-baseline.json.txt','portable-gate-summary.json.txt','portable-publication-summary.json.txt','build-portability-capsule.py']:
 p=SOURCE/name;assert p.is_file(),name;files.append((p,'qualification/'+name))
for name in ['command-evidence.mjs','run-fixture.mjs','tests/ios-command-outcome.test.mjs','README.md']:
 files.append((REPO/'tools/migration/legacy-continuity'/name,'maintained/'+name))
TARGET.mkdir(parents=True,exist_ok=True)
archive=TARGET/'receipts.tar.gz';members=[];seen=set()
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as tar:
 for path,name in sorted(files,key=lambda x:x[1]):
  assert name not in seen and not path.is_symlink();seen.add(name)
  data=path.read_bytes();mode=stat.S_IMODE(path.stat().st_mode)
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=mode;info.mtime=int(path.stat().st_mtime);tar.addfile(info,io.BytesIO(data))
  members.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'mode':oct(mode)})
with tarfile.open(archive,'r:gz') as tar:
 actual=tar.getmembers();assert len(actual)==len(members)
 for item,expected in zip(actual,members):
  assert item.isfile() and item.name==expected['path'] and item.mode==int(expected['mode'],8)
  data=tar.extractfile(item).read();assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
body={'owner':'L0','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':'5d739c9921a9c011a594eba9139eb1ea34538a36','qualifiedSourceTree':json.loads((SOURCE/'portable-gate-summary.json.txt').read_text())['qualifiedSourceTree'],'scope':'true hosted Linux failure, separate deliberate rejection/restoration, exact passing repaired-source gates, fresh source-only producer requalification; no native execution or final acceptance','archive':{'path':'receipts.tar.gz','bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'memberCount':len(members),'members':members,'readback':'Every member byte/mode and full membership verified'}
(TARGET/'manifest.json.txt').write_text(json.dumps(body,indent=2)+'\n')
print(json.dumps({'archive':str(archive),'members':len(members),'bytes':archive.stat().st_size}))
