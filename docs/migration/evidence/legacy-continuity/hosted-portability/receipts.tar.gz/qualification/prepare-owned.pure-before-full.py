from pathlib import Path
import subprocess,datetime,json,hashlib,os,re,sys,time,signal,socket
REPO=Path('/Users/kylemit/.codex/worktrees/migration-legacy-continuity/Splotch')
ROOT=Path('/private/tmp/splotch-l0-native-execution-202610070306')
NODE=Path('/Users/kylemit/.nvm/versions/node/v24.16.0/bin/node')
NPM=NODE.parent.parent/'lib/node_modules/npm/bin/npm-cli.js'
PROFILE=Path('/private/tmp/splotch-resume-01a111b0/legacy-continuity-source/accepted-composition-78d/install-reuse/qualification.json.txt')
ENV={**os.environ,'PATH':str(NODE.parent)+':'+os.environ['PATH'],'LC_ALL':'C'}
IDENTITY_SECONDS=2
DRAIN_SECONDS=3
POLL_SECONDS=.1
label=sys.argv[1];budget=int(sys.argv[2]);command=sys.argv[3:]
assert re.fullmatch('[a-z0-9-]+',label)
root=ROOT/label;root.mkdir()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def file(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'realpath':str(p.resolve()),'bytes':len(b),'sha256':sha(b),'mode':oct(p.stat().st_mode&0o777)}
def write(name,value):(root/name).write_text(json.dumps(value,indent=2)+'\n')
def git(args):return subprocess.check_output(['git',*args],cwd=REPO,timeout=15)
def source():
 paths=git(['ls-files','-z','tools/migration/legacy-continuity']).decode().split('\0')
 paths+=git(['ls-files','--others','--exclude-standard','-z','tools/migration/legacy-continuity']).decode().split('\0')
 return {'head':git(['rev-parse','HEAD']).decode().strip(),'mergeHead':git(['rev-parse','--verify','--quiet','MERGE_HEAD']).decode().strip() if (REPO/'.git').exists() and subprocess.run(['git','rev-parse','--verify','--quiet','MERGE_HEAD'],cwd=REPO,capture_output=True).returncode==0 else None,'status':git(['status','--porcelain=v1']).decode(),'indexSha256':sha(git(['ls-files','--stage','-z'])),'files':[file(REPO/p) for p in sorted(set(paths)) if p]}
def reuse():
 j=json.loads(PROFILE.read_text());assert sha(PROFILE.read_bytes())=='b9ad160661fa428d4539ccbdf127790c967e2b6287108ef879b2c324475afeb6'
 actual=[]
 for k in ['runtime','locksAndWorkspace','installedMetadata','installedLockAndLinker']:
  for expected in j[k]:
   a=file(expected['path']);assert all(a[x]==expected[x] for x in ['realpath','bytes','sha256','mode']),('L0_REUSE_CHANGED',expected['path']);actual.append(a)
 return {'profile':file(PROFILE),'checked':actual,'scope':'limited inherited JavaScript installed metadata/runtime/lock reuse; no exhaustive source or compiled association'}
def identity(pid):
 p=subprocess.run(['/bin/ps','-ww','-p',str(pid),'-o','pid=','-o','ppid=','-o','pgid=','-o','lstart=','-o','args='],capture_output=True,timeout=IDENTITY_SECONDS,env=ENV)
 raw=p.stdout.decode();m=re.fullmatch(r'\s*(\d+)\s+(\d+)\s+(\d+)\s+(\w{3}\s+\w{3}\s+\d+\s+\d{2}:\d{2}:\d{2}\s+\d{4})\s+([\s\S]+?)\s*',raw)
 if p.returncode or not m:return {'status':'unavailable','code':p.returncode,'raw':raw,'stderr':p.stderr.decode()}
 return {'status':'observed','pid':int(m[1]),'ppid':int(m[2]),'pgid':int(m[3]),'birth':m[4],'argv':m[5],'raw':raw}
def group(pid):
 try:
  p=subprocess.run(['/bin/ps','-axo','pid=,pgid='],capture_output=True,timeout=IDENTITY_SECONDS,env=ENV)
  assert p.returncode==0
  rows=[re.fullmatch(r'\s*(\d+)\s+(\d+)\s*',s) for s in p.stdout.decode().strip().split('\n')];assert all(rows) and any(int(m[1])==os.getpid() for m in rows)
  members=[int(m[1]) for m in rows if int(m[2])==pid];return {'status':'present' if members else 'absent','members':members,'tableSha256':sha(p.stdout)}
 except Exception as e:return {'status':'indeterminate','error':str(e)}
def port_available(port):
 with socket.socket() as probe:
  try:probe.bind(('127.0.0.1',port));return True
  except OSError:return False
def signal_owned(row,sig):
 live=identity(row['pid']);row.setdefault('signalChecks',[]).append({'at':now(),'signal':signal.Signals(sig).name,'live':live})
 initial=row['identity'];assert initial['status']==live['status']=='observed' and all(initial[k]==live[k] for k in ['pid','ppid','pgid','birth','argv']) and live['ppid']==os.getpid() and live['pgid']==row['pid'],'L0_TOOL_OWNERSHIP_UNRESOLVED_NO_SIGNAL'
 os.killpg(row['pid'],sig)
row={'owner':'L0','label':label,'argv':command,'cwd':str(REPO),'startedAt':now(),'deadlineSeconds':budget,'releaseCondition':'target exit, actual group absence, closed raw destinations and finalized before/after/source/reuse receipts','scope':'pure fresh source preparation authorized during neutral full-gate lease; install/build/server/native/device excluded'}
if 'SMOKE_PORT' in ENV:
 row['smokePort']=int(ENV['SMOKE_PORT']);row['portFreeBefore']=port_available(row['smokePort']);assert row['portFreeBefore'],'L0_SELECTED_PORT_OCCUPIED'
assert group(os.getpid())['status']!='indeterminate','L0_PROCESS_INVENTORY_UNAVAILABLE_BEFORE_TARGET'
write('lease.started.json.txt',row);write('source.before.json.txt',source());write('reuse.before.json.txt',reuse())
for name,args in [('status.before.txt',['status','--short','--branch']),('staged.before.diff.txt',['diff','--cached','--binary']),('unstaged.before.diff.txt',['diff','--binary'])]:(root/name).write_bytes(git(args))
p=None;failure=None
try:
 with (root/'stdout.raw.txt').open('wb') as out,(root/'stderr.raw.txt').open('wb') as err:
  p=subprocess.Popen(command,cwd=REPO,stdout=out,stderr=err,env=ENV,start_new_session=True);row['pid']=p.pid;row['identity']=identity(p.pid);write('lease.running.json.txt',row)
  try:row['exitCode']=p.wait(timeout=budget)
  except subprocess.TimeoutExpired:
   row['deadlineExceeded']=True;signal_owned(row,signal.SIGTERM)
   try:row['exitCode']=p.wait(timeout=DRAIN_SECONDS)
   except subprocess.TimeoutExpired:signal_owned(row,signal.SIGKILL);row['exitCode']=p.wait(timeout=DRAIN_SECONDS)
  deadline=time.monotonic()+DRAIN_SECONDS
  observation=group(p.pid)
  while observation['status']=='present' and time.monotonic()<deadline:time.sleep(POLL_SECONDS);observation=group(p.pid)
  row['groupObservation']=observation
  assert observation['status']=='absent','L0_TOOL_GROUP_UNRESOLVED_NO_SIGNAL'
except Exception as e:failure=str(e);row['failure']=failure
finally:
 if 'smokePort' in row:
  row['portFreeAfter']=port_available(row['smokePort'])
  if not row['portFreeAfter']:failure='L0_SELECTED_PORT_UNRELEASED';row['portFailure']=failure
 row['endedAt']=now();row['stdout']=file(root/'stdout.raw.txt');row['stderr']=file(root/'stderr.raw.txt')
 try:
  after=source();write('source.after.json.txt',after);write('reuse.after.json.txt',reuse())
  if command[0]!='git':assert json.loads((root/'source.before.json.txt').read_text())==after,'L0_SOURCE_CHANGED_DURING_GATE'
 except Exception as e:row['afterFailure']=str(e);failure=str(e)
 row['controller']=file(Path(__file__));write('receipt.json.txt',row);write('lease.released.json.txt',{'at':now(),'groupObservation':row.get('groupObservation'),'unresolvedOwnership':failure,'exitCode':row.get('exitCode')})
 print(json.dumps({'root':str(root),'exitCode':row.get('exitCode'),'failure':failure,'groupObservation':row.get('groupObservation')}))
 print((root/'stdout.raw.txt').read_text(errors='replace')[-1800:]);print((root/'stderr.raw.txt').read_text(errors='replace')[-2800:])
sys.exit(1 if failure else row['exitCode'])
