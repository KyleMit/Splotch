# L0 pre-freeze source repairs

This packet records implemented source over accepted 794448fbf76276b76a910c167b5c2e0c4e1ea538. It
contains source hashes, exact source/root diffs, the bounded scoped-tools supervisor and finite
copy/repair producers. No install, scoped suite, native build/run, profile survival or upgrade
acceptance has occurred at this transition.

The CLI parses only in exported `runLegacyContinuity(argv)` and runs only under the accepted
`isMain`/`runMain` owner. Unknown flags refuse; importing the entry executes no CLI. All ADB calls
have a fixed named per-call deadline. Each spawned command records actual OS PID, direct PPID,
process group, birth and full argv. Every teardown signal requires an unchanged live identity;
missing/reused/unavailable leaders with a surviving group preserve unresolved ownership. Complete
command files survive failures. The proposed whole tools lease remains separate from per-call and
teardown deadlines.

ADB cleanup re-enumerates the exact serial/port/socket mapping before removal and refuses a changed
owner. PID-filtered native logs are captured even after command failure; log collection failure
still reaches guarded forward cleanup. A native app crash or CDP timeout is a failed command, never
an intended passing refusal. Actual native logs/row/restoration remain later execution requirements.

The raw preimage now includes the actual hint-independent held-record reader before commands can
mutate settings, vault or held state. Host transport verification checks every encoded held type,
complete buffer bytes/length/hash, get/count/getKey existence, recognized-entry cardinality and
claimed recognized picture bytes. Lost tags or bytes refuse. Native IndexedDB absence/crypto and
persistent-profile behavior remain unexecuted. The nine earlier source-only composition calls keep
their exact earlier overlays; their roots cannot authorize execution of these changed inputs.

The root package change is one public script plus its matching description. Knip adds only the exact
nested CLI and test entries; existing project and Vitest discovery already cover them. The bounded
L0 CAMPAIGN row and dated observation preserve older transitions. Parent reconciles the common live
register across units.

Original Claude identity 1b406e61-641e-4cf8-86fb-2b1cd7548469 retains one used round and two
remaining. Round two challenges this implemented observer/route/configuration/read shape and trust
before native execution. Round three covers executed evidence/final unit. No new/adopted/fallback
review or budget reset occurred here.

`source-manifest.json.txt` binds the 25 tool/test/template files, three bounded root changes and
accepted read-only process/lock/workspace owners. `review-request.json.txt` binds exact diff and
supervisor bytes. The supervisor proposes a 600-second whole lease for a fresh own frozen
ignored-script install, complete recursive installed graph, scoped guards/check/lint and final
finite source/flag controls. Source/index/runtime identity and group absence must remain proven. It
neither compiles nor executes native apps. Its planned execution is separate from this source
preparation packet.
