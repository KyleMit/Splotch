# L0 repaired full-gate source freeze

This additive freeze binds 475 actual source/evidence/execution-owner files and 25,994,268 bytes on
accepted base 709fadd68ecb802aa2c9daa3fc197ce8d072b23c. Complete prior manifests and actual failed
Quality receipts remain immutable. Only six existing input paths change: two module export surfaces,
one redundant Knip entry, the unit's current register/readme and the exact historical raw proposal
representation. Every other previously selected owner byte/mode is unchanged; additional files
preserve the actual failure, its release and the finite source/projection repair.

The original 1,055-byte proposal has a named raw .md.txt projection. Its unit inode/mode/hash are
identical, the canonical original remains at its historical Markdown name, both manifests remain
unchanged, and the explicit projected-member inventory binds all 53 original members. The fresh
freeze uses the actual projected path. No formatting rule is excluded and no raw byte is rewritten.

The role Git/source/configuration declarations and 56 stored source blobs retain their exact profile
identities. The inspector/contract ownership bytes changed to make genuine internal owners private;
`role-profile-inputs.json.txt` records that changed input rather than promoting an old
implementation receipt. Three actual bounded CLI role positives must compare complete output with
earlier executed positives, without normalization. Native/effective origin/profile/compiled SDK
association remains separate.

`run-final-source-gates-retry.py.txt` proposes one 900-second whole lease: Quality 300 seconds,
first Browserless 480 seconds, three role commands up to 60 seconds each and port probes up to 30
seconds each. Every call is capped by actual whole remaining time after a 60-second finalization
reserve; individual maximums cannot all exhaust simultaneously. The same-host measured Quality and
Browserless harness costs plus the actual 52.842-second failed fifteen-step Quality invocation
justify the whole deadline and headroom. None measures app latency.

The full source is truly staged only after this preparation packet is copied. Exact semantic index,
staged tree/status/owned diff and no unstaged/untracked source govern before/after acceptance; raw
index changes are diagnostic. Prior complete own installation/JS graph is input-qualified again,
without install/list/catalog repetition. Signals require actual unchanged live PID/birth/argv and
direct parent/group; lost ownership or a surviving group cannot be release. The actual net owner
rechecks unreserved SMOKE_PORT 5386 before/after; no foreign listener is stopped. Accidental
failures, wrong refusals or stale inputs halt later acceptance and retain complete raw channels.

No full/scoped/native/rival rerun has occurred on these repaired inputs. Original Claude
1b406e61-641e-4cf8-86fb-2b1cd7548469 remains one used/two remaining, with actual PR-keyed adoption
and original round two after a reviewable PR. No candidate/static/native build, device, signing,
channel, physical comparison or whole-campaign acceptance follows this preparation.
