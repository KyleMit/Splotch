# L0 additive process-boundary repair and follow-up plan

The parent read and accepted the complete two-file proposal
8872eb474a2921e371d4a2b95d6a590944b4b15d27974925f8cd21526fee772b before source application. Exactly
that command/guard repair was applied and formatted. The actual command output, primary command
error and lost-ownership error propagate after the original cleanup/evidence block; simultaneous
errors retain both actual objects in AggregateError. The ownership predicate, signal proof, teardown
and raw evidence remain unchanged. No lint suppression or ownership relaxation was introduced. The
new actual production-function guard checks nonzero-only propagation, simultaneous
command/lost-leader refusal, saved failure fields, finite natural group drain and restored owned
success. Eleven scoped guards are prepared; none has been rerun yet.

The first [tools lease](../tools-gates-20261006200650/README.md) and its exact `receipt.json.txt`
bf6bf2ccc51b4b1435ae0d56061d274d6adf8274e713cc82106420fd1b77a765 remain immutable. Own
ignored-script frozen installation, complete 2,063,317-byte JS graph, ten prior guards and composed
check passed; one accidental `no-unsafe-finally` lint failure stopped all later role/flag commands.
The actual release proof and full44-file failure mirror remain intact. Successful scopes are not
renamed final-source acceptance.

The new additive `source-manifest.json.txt` binds126 current source/evidence inputs and3,155,521
bytes. Compared with the unchanged original69-input source manifest
002767256119ce8e817f5acfb7e88a14f054971e07e14f93cac8540caea3a222, only the two authorized sources
and the L0 current register row/dated transition changed. Other owners and historical observations
remain intact. The actual source/profile owners remain
reader709fadd68ecb802aa2c9daa3fc197ce8d072b23c, releasedd8b86469f63c57a06a9de45664a42eea15b99eb0 and
heldef3d1eb2070c1bd0dee620ed42a2b14201c2a9b4. The new manifest also binds the previously qualified
complete profile and56 source blobs by exact immutable references; no unchanged source probe is
rerun. `profile-reuse.json.txt` gives the exact matching finite selection and its limits.

`run-scoped-tools-followup.py.txt` is proposed, not executed or leased. Its whole600-second alarm
covers prep, input hashing and complete final receipt hashing; it keeps finite per-call/Git/teardown
deadlines and the finalization reserve. It first qualifies the original complete install/graph
receipt, successful install/list execution, actual recorded dependency inputs, runtime
identities/inodes, eleven direct installed package metadata bytes/inodes and installed lock/linker
bytes. The complete stored graph is verified without invoking install/list/catalog again.
Qualification runs before and after the new commands and refuses any changed input. This reuses the
complete JS resolution/installation receipt within its scope; it does not establish the bytes of
every installed library, native compiled/resolved graph or SDK source-to-binary association.

Only changed11guards, composed check/lint and previously unexecuted three role inspections plus
unknown-flag intended refusal/restored positive are proposed. An accidental failure or a wrong
refusal reason stops later commands, preserves all complete outputs and refuses acceptance. Owned
process signals still require exact live birth/argv/direct parent/group; unresolved ownership cannot
become release. No native/static build, full suite, browser/performance workload or rival execution
is authorized by this plan. The parent's next separate lease is required.

The corrected source-only `round2-prompt.md` records the first tools failure and actual source
repair without promoting unexecuted checks. Original Claude
conversation1b406e61-641e-4cf8-86fb-2b1cd7548469 remains1used/2remaining; no PR, ledger adoption or
new review round occurred. Actual precompiled SDK declarations, effective origin/profile/runtime,
signing/channel upgrade and physical gates retain their existing claim limits. New evidence is
additive; no old receipt bytes were rewritten.
