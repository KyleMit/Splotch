# L0 repaired execution plan

L0 is one owned sequence: core seed/read mechanics first (L0a), then applicable pack/job observation
and hazard controls (L0b). This plan replaces the proposed execution instructions; the original
plan, seed modules, reader and original Claude report remain immutable. No fixture implementation,
fixture install, native build or native run is accepted by this document.

The original Claude conversation is 1b406e61-641e-4cf8-86fb-2b1cd7548469. Its first substantive
round reviewed f14966ee98563e3c569fbcb90beea6d9c684614a and the exact owned source/provider packet.
One round is used; two remain. The complete report has eight blocking findings and four suggestions.
Question mode created no ledger: actual PR-keyed adoption must preserve that original identity and
the consumed round. Source challenge of the implemented native observer/configuration precedes trust
execution; final executed evidence receives the remaining independent review.

## Exact sources and claims

| Role                      | Exact source                                                                                | Native labels  | Claim                                                                            |
| ------------------------- | ------------------------------------------------------------------------------------------- | -------------- | -------------------------------------------------------------------------------- |
| Released previous fixture | v1.6.0, d8b86469f63c57a06a9de45664a42eea15b99eb0                                            | 1.6.0 / code 8 | Source-built released-format mechanics; attached binary association remains open |
| Unreleased held fixture   | main snapshot ef3d1eb2070c1bd0dee620ed42a2b14201c2a9b4                                      | 1.6.0 / code 8 | Source-built later held/pending-removal format feasibility                       |
| Reader fixture            | accepted integration 794448fbf76276b76a910c167b5c2e0c4e1ea538 plus a frozen fixture overlay | 1.6.0 / code 8 | Same-version in-place reinstall, identified by source and artifact digest        |

The implementation worktree composed the accepted records-only PR2706 frontier by fast-forward. The
released/main/root lock and production source changes are not inferred from version labels. The
selected reader and main held fixture have identical Git blobs for storage.ts,
ColoringPacksPlugin.swift, ColoringPackWorker.java and capacitor.config.json; the actual comparison
is in review-validation/reader-contrast.json. Each other reused input needs its own complete scope
match. The original question's f149 scope remains unchanged.

A real version-change scenario belongs to the existing version owner. L0 does not manually bump
Gradle/Xcode/package versions or exercise a mismatch by inventing native job JSON. Same-version
reinstall cannot prove the released appVersion mismatch path. RN read, destination transactions,
source retirement, atomic iOS hardening, signed channels, physical lock/accessibility, performance
and power-loss durability remain downstream.

## L0a eligibility, seed and persistence cuts

Use only a newly owned emulator and a newly created simulator. Never reuse a user install, copy a
host .env/local.xcconfig/keystore.properties, or use real signing credentials. Android fixtures use
one newly generated owned nonproduction key for both artifacts. Simulator builds use an observed
local simulator signing scope without team/provisioning credentials. Compare artifact certificate or
entitlements and actual installed effective identity before any in-place operation.

Before every launch, enumerate the owned app's coloring root offline. L0a requires no pack files, no
job and no preexisting fixture sentinel/vault entries. On iOS the normal no-job launch reaches
rootDirectory, which creates Application Support/coloring and sets its backup-exclusion attribute;
record that expected empty-root effect. A nonempty job/pack precondition is a refusal, not absence.
L0b owns those scenarios. Require the same OS/runtime and Android WebView provider across stages.

Generate a new run nonce. The source writes a unique sentinel and unique dummy secret values to the
actual released fixed logical secret keys; the reader must never seed before reading. Constant dummy
bytes cannot be evidence of survival. Core settings use valid non-default source values: false
sound, volume 37, dark theme, released advancedControls false or main toolDrawer false, coloring
false and AI true. drawerOpen false is its default and is not the positive. AI true is only an inert
persisted value in the isolated fixture route; no normal drawing/credential boot or API caller runs.
First capture raw values, then compare actual source parser results. Raw storage writers are
acceptable only for these validated values; importing the full settings module before the raw
snapshot would add its module-initialization reads. Retain night as an explicitly invalid theme
control with the real isThemePreference/readTheme fallback predicate. Preserve raw forms such as
37abc separately from their actual lenient readInt result; never call them canonical integers.

The route uses the source's real storage/secure writer modules, not mocks. It is the literal
prerendered /legacy-continuity.html route outside /dev, which native builds strip. A fixture-only
server.appStartPath of /legacy-continuity.html reaches that exact packaged HTML. The pinned
Capacitor 8.5.1 and 8.5.2 local servers route extensionless paths to root index.html; such a path is
refused. iOS also requires the corresponding packaged appStartFileURL to exist. Require that output
file, the actual initial URL and no drawing-root/earlyBoot entry before capture. The source
appStartPath owners append a path without changing hostname or scheme. SDK sources construct the
normal web view without a nonpersistent-data-store/profile override; actual profile continuity
remains an execution gate. Qualify the complete inherited app.html and root layout at each source:
the template reads storage and may clean shallow history, but does not seed storage. Every inherited
effect and any unexpected history navigation is recorded. Both source and reader need an explicit
audited initial route to avoid normal boot before capture. The reviewer summary's suggestion to
require no appStartPath in the reader is not adopted: a path differs from an origin, and
unconditionally loading the normal root would violate RAW_SNAPSHOT. The actual packaged config,
initial URL, persistent profile and unique sentinel determine acceptance; unexpected
host/scheme/profile or normal-boot entry refuses the run.

A Preferences.get immediately after a setter is only an in-memory observation. Observe the
independent durable storage before termination, with the named 5,000 ms observation deadline and its
failed stage retained. Android reads the two exact shared_prefs XML files through run-as, including
the secure row XML, without parsing browser databases. A missing file, malformed XML or wrong native
type is distinct from an absent key. Observe the alias in-process independently. iOS uses the actual
container Preferences/cfprefsd boundary and then a source relaunch read; no cfprefsd kill or
arbitrary host defaults access is allowed. Record exact rows/types and unchanged unrelated owned
sentinel.

After acknowledgement, terminate only the owned app process and relaunch the source before
reinstalling. Read back localStorage, sentinel, native mirrors and vault values without reseeding or
hydration. This attributes a lost batched WebView write to the source persistence cut rather than to
the later reinstall. Android uses an owned-process kill rather than force-stop for the preservation
cut. A deliberate force-stop is a separately labelled scheduler hazard control. The fresh core
precondition excludes jobs, but the same stop convention remains explicit.

## Native observation and return contract

Register each fixture observer beside the source's actual local plugin registrations. No generic
import/storage framework or replacement destination service is part of L0. Native command sets are
finite and source-bound; host input is validated before use and cannot supply arbitrary JS, paths,
account names or keychain queries. All mutations require the nonce and exact owned-key allowlist.
Never use Preferences.clear, secure clear, delete-all Keychain or IDB database deletion.

Android CDP selects the actual owned PID and observed origin at an explicitly unused forward port.
The host captures raw page/native results before actual hydration. Native Preferences XML and
Keystore alias checks distinguish memory acknowledgement from disk and null from inconsistency.
Record per-key results and the actual hydrate completion: v1.6 swallows a rejected Promise.all and
skips all restores/backups; main additionally excludes the union of pending removals. A delivered JS
rejection would skip the whole restore, but the Android native wrong-type path is not that proof:
Preferences.getString throws, PluginHandle invokes reflectively, and Bridge rethrows a
RuntimeException on its task handler. Capture the actual native exception/process outcome as a
separately named type-error hazard. A timeout or setup fault with no attributable native exception
does not satisfy that control. The fixture route never automatically hydrates; after that disposable
failure a gated relaunch can observe the raw row and restore it through the real string writer
before any get/hydrate. Preserve and re-observe both wrong-typed and restored disk rows. Do not
fabricate a provider rejection to make this path pass. iOS numeric coercion is a separate actual
parser control. Neither one substitutes for native availability.

iOS receives a finite command and nonce via simctl launch arguments. After capacitorDidLoad and
fixture-page readiness, callAsyncJavaScript in the page content world awaits the actual seed/read
promise. Do not use evaluateJavaScript to assume Promise completion. Results use a framed, hashed
output or an exact owned app tmp report path; never write into coloring, Preferences or WebKit
evidence areas. The observer never touches ColoringPackDownloadCoordinator.shared. Bind complete
command/result bytes, command identity, error/status and readiness to the source.

The iOS raw query follows the qualified KeychainSwift getter: generic password; account
capacitor-storage_<logical name>; no explicit service/access-group; default non-sync query attribute
omission. Add return-data/attributes to observe local OSStatus and accessibility. Each query owns
its status variable. Do not reuse the provider's nil-conflating get or a mutable last status.
Compare effective access-group attributes plus artifact application-identifier/keychain entitlements
before and after. The qualified provider default is whenUnlocked; the stricter
whenUnlockedThisDeviceOnly prose in MOBILE/native is not a source or runtime fact for these locked
fixtures. Record actual returned accessibility and leave owner correction to integration. A changed
query/scope is refused before claiming source absence.

Vault outcomes are present, confirmed absent, inconsistent namespace, corrupt, unavailable or setup
refusal. Android confirmed absence requires both durable row absence and alias absence; provider
remove alone cannot prove it. Orphan row/alias, malformed separator, authenticated-cipher failure
and non-string/Date/invalid JSON remain separately named. iOS item-not-found requires the qualified
query and identity; nonzero other statuses are unavailable and retain source; successful raw data
with invalid UTF-8/JSON is corrupt. A deliberate malformed query can test actual Security API
refusal and loss-free retry, but does not prove a correctly configured item physically locked.
Binding failures are setup failures. Physical inaccessible/locked-item acceptance remains open.

## Held records

Seed held records only in the exact main fixture through its actual createUnsavedPictureStore
writer, with a known owned PNG blob, metadata, nonce signature and acknowledged write. Never seed
that format into the released fixture. After source relaunch, the reader uses actual same-origin
IndexedDB APIs without depending on either hint. Missing/stale false hints are real owned-key
operations. Main's stock read short-circuit and filtering are not continuity oracles.

The page encodes raw values before transport. A record envelope preserves raw shape/type tags, own
fields, single-object or array form, every entry and complete bytes. Use count/getKey/cursor in the
same readonly transaction to distinguish an absent key from a present undefined value.
Unknown/malformed entries remain invalid source, never a filtered complete migration or absence.
Encode buffers as explicit base64 and byte length with a digest, and independently recompute the
host digest against the exact source fixture bytes. Empty/extra/unknown forms are handled according
to the actual owner scope rather than invented validity rules. Any unsupported digest/bridge or {}
byte representation refuses acceptance. Confirm abort-on-upgrade leaves no database per actual
engine; actual native origin/profile and writer remain separate gates.

The later independent old-helper mechanism executed the exact preserved source bytes. Both installed
Chromium and WebKit left no DB after the abort, misclassified a present undefined-value record as
absent, and lost ArrayBuffer bytes through JSON; Chromium CDP by-value did too. This confirms
defects; it does not accept the reader or a native fixture. Original request 1 stays declined and
the original report's unverified statement stays immutable. The repaired reader needs its own
rejecting controls and restored positives at final relevant source.

## L0b source and scheduler controls

L0b starts only after core source/identity mechanics and a separately reviewed native lease. Seed
completed packs and a pending job through the real released facade, exact build descriptors and
verified bytes. Use a reviewed fixture define for the compiled asset base plus owned transport
trust. Serve that build's coloring bytes at /coloring at a controlled HTTPS origin root; Android
concatenates URLs while iOS resolves absolute paths. Do not silently retain the production base,
manually create job/marker JSON, change the WebView origin or change native version owners.

The controlled server logs request arrival separately from job persistence and never finishes the
held response. The real job is persisted before network; lack of request arrival on discretionary
iOS is not absence. Android's 30 s timeout/retry/deferredAfterAttempt remains a distinct source
outcome. Keep server resources leased until the snapshot/hazard findings are safe. Transport trust
is limited to the owned emulator/simulator and fixture; no host trust-store mutation or real TLS
credential is allowed.

Enumerate offline and preserve full paths, modes, hashes, job bytes, source job schema and complete
OS scheduler receipt before every stop/update/launch. Android WorkManager starts in the provider
phase before an Activity; an Activity-only gate is too late. Establish and observe unmet network
constraints before preservation cuts, record dumpsys jobscheduler for this package, and avoid
emulator reboots. No raw WorkManager database parsing is needed or permitted. Record force-stop
rescheduling only as its own hazard control. Main's worker rejects old jobs lacking resolution and
marker and deletes them; background eligibility cannot be inferred from an inactive Activity.

On iOS, do in-process observations during the seeding session before termination. Same-version
resume can start work; malformed decode and version mismatch remove jobs/cancel tasks; main cannot
decode v1.6 jobs; status/reconcile deletes or adopts files and drains old namespaces. AppDelegate
launch and background events plus sessionSendsLaunchEvents can start the process outside the
harness. Any unexpected background relaunch contaminates the run. Offline file enumeration is
required; background task/session state that cannot be observed without creating the session is
reported unobservable, not preserved. A scheduler/transport gate that cannot actually be established
halts that dependent scenario while core work continues. Displayed simulator network bars are not a
networking gate. Any later session attachment must be independently challenged with its actual side
effects before ownership acceptance.

Reader launch/status hooks stay gated until source enumeration. L0b can qualify real raw snapshot
and demonstrate source hazards on preserved disposable data. It does not pass pending-job ownership
transfer: that needs a real later implementation. Even matching-file adoption does not accept all
job/files/continuity obligations. Real version-mismatch execution remains under the version owner.

## Install, execution, review and delivery gates

Before each fixture install/build, freeze the exact overlay and read its source scripts/lifecycle
owners. Use its own frozen pnpm lock/workspace and complete captured install stdout; no borrowing
review node_modules. Verify the root cap binary is the actual pinned CLI (8.5.1 for v1.6 despite the
transitive 5.7.8); inspect allowed build scripts and all-false allowBuilds policy before
installation. Check generated Capacitor config/registration/topology and guard expected source
changes after prebuild:cap/cap sync. Fixture changes are explicitly allowed; unrelated
Package.swift, capacitor.settings.gradle or package/registration drift fails. Lock iOS SPM
resolution and compare Package.resolved. Record resolved Android dependencies, exact
environment/runtime/WebView version, artifacts and local identity. Source labels/installed directory
alone cannot accept a graph.

Implement only tools/migration/legacy-continuity and its owned evidence directory. Fixture source
copies/overlays stay in owned roots. Coordinate necessary root entry/knip/script catalog changes and
the parent-supplied CAMPAIGN update before source/gate freeze. Format maintained source; raw
captured bytes use .txt suffixes. Independent implemented-source challenge precedes trust runs;
scoped actual execution, intended failures, restored positives and final-head CI precede parent
integration. No fourth review/reset is available. Material findings or stale inputs halt dependent
acceptance. Existing reusable receipts remain bound to their full input/scope identity.
