# L0 original round-one dispositions

The immutable original report is `plan-review/findings.json.txt`, conversation
1b406e61-641e-4cf8-86fb-2b1cd7548469, one substantive round used and two remaining. The 12 rows
below retain original order and severity. A plan disposition authorizes the stated source
implementation; it does not accept an implementation, device result or continuity claim. The
original unexecuted request and report remain unchanged.

## Blocking findings

1. **iOS launch and reconciliation owners — confirmed.** Released
   `ios/App/App/AppDelegate.swift:10,14–23` reaches resume and background-event attachment. Released
   `ColoringPacksPlugin.swift:81–99,146–155,167–183,242–254` covers no-job root creation,
   same-version resume, session launch events and completion mutations. Main's required job schema
   at `:20–29` rejects released jobs at `:97`; reconciliation at `:140–170` deletes mismatched files
   and drains namespaces. L0a refuses any offline pack/job precondition, expects empty coloring-root
   creation, and never calls status or the coordinator from its observer. L0b observes the seed
   session before termination, snapshots offline before every launch/status, never completes the
   held response, and rejects unexpected background launches. A scheduler gate that cannot be
   established halts that scenario. Pending-job transfer remains a later real owner.

2. **Android worker/stop hazards — confirmed with a scope limit.** Released
   `android/app/build.gradle:60` and manifest register WorkManager through its dependency; released
   `ColoringPackWorker.java:55,93` and main `:39,65–67` contain job-removal paths. Activity
   registration cannot gate provider-phase work. Core runs require no job/pack; pack runs establish
   and observe unmet constraints before preservation cuts. Capture package-scoped
   `dumpsys jobscheduler`, process identities and offline files. Kill only the owned PID; a
   force-stop is a separately labelled mutation/hazard, never preservation evidence. No reboot or
   raw WorkManager database parsing. Actual scheduler/provider graph remains an installed-input
   execution gate, not inferred from this source inventory.

3. **Acknowledgement and persistence cut — confirmed.** Released `storage.ts:85–101,205–228`
   asynchronously mirrors and hydrates. Qualified Preferences `Preferences.java:43` and secure
   provider `SecureStorage.java:129` use apply. Require the actual two Android XML files plus
   independently observed alias, or iOS defaults/container evidence and source-side relaunch. Use a
   unique nonce and a named 5,000 ms disk-observation deadline. Read source local/sentinel/vault
   after owned termination and before reinstall; reader never seeds. Preserve the failed stage and
   distinguish in-memory get, disk acknowledgement, source relaunch and reinstall observations. A
   timeout is not absence.

4. **Theme and non-default values — confirmed.** Released theme accepts light/dark/system;
   `settings.svelte.ts:37–60,125–129` binds defaults and theme parsing. Valid positive values are
   sound false, volume 37, theme dark, released advancedControls false or main toolDrawer false,
   coloring false and AI true. drawerOpen false and AI false are defaults, not positives. Seed valid
   values through the real storage writer; import the actual settings parser only after raw capture.
   Invalid night and noncanonical volume strings are distinct real-owner controls; fresh
   document/module state is required for a claimed default fallback. AI is an inert dummy fixture
   setting with no boot/API caller. Restore dark/non-default positives through the real writer.

5. **Held record serialization and absence — confirmed, later mechanism evidence qualified.** The
   original helper is not reused as an accepted reader. Both installed desktop engines empirically
   returned empty serialized ArrayBuffer objects and classified a present undefined record as
   absent; the original helper's absent-DB abort left no DB. The complete later `helper-mechanism`
   receipt is separate from the declined original request. Implement explicit page-side
   base64/length/digest envelopes, preserve every raw entry/field/type and single-object versus
   array form, and use count/getKey in the same readonly transaction. Unknown/malformed source
   remains invalid source. Main seeds via its actual held writer; reader bypasses hint
   short-circuits. Verify exact fixture bytes/digest independently on host. Reject empty byte
   serialization, malformed-present records, stale hints or unsupported transport; restore exact
   positives. Native WKWebView/profile/writer behavior still requires actual execution. iOS uses
   callAsyncJavaScript in page world, not Promise-assuming evaluateJavaScript.

6. **Controlled pack source — confirmed.** Released `nativeStore.ts:31`, `vite.config.ts:47` and
   `securityPolicy.ts:40,92–94` bind production by default. L0a has no pack download. L0b freezes an
   explicit fixture asset-base define and narrowly owned transport trust; compiled output must prove
   the controlled root origin. Serve exact build descriptor bytes at `/coloring`, preserving iOS
   relative-URL versus Android concatenation behavior. Record job persistence separately from
   request arrival. Never complete the held response; capture Android
   timeout/retry/deferredAfterAttempt and iOS discretionary non-arrival as distinct outcomes. A
   transport or network constraint that fails setup cannot be a rejecting control.

7. **Source/version identity — confirmed.** Released d8b86469f63c57a06a9de45664a42eea15b99eb0, main
   held snapshot ef3d1eb2070c1bd0dee620ed42a2b14201c2a9b4, and reader
   794448fbf76276b76a910c167b5c2e0c4e1ea538 all label 1.6.0/code 8. Freeze each exact Git source,
   overlay, graph, compiled artifact digest and effective installed identity. Call the operation
   same-version in-place reinstall. Do not fabricate native version changes or appVersion job JSON.
   Source-built fixtures do not accept published-binary association or signed upgrades.

8. **iOS command/result/query boundary — confirmed.** Register the finite observer beside actual
   MainViewController registrations after capacitorDidLoad. Use finite simctl launch arguments,
   explicit fixture readiness and page-world callAsyncJavaScript. Results leave through a hashed
   framed channel or fixed owned app tmp report outside observed coloring/Preferences/WebKit. The
   observer never references the coloring coordinator. Raw keychain query follows pinned
   KeychainSwift: generic-password, account capacitor-storage_<owned logical name>, no explicit
   service/group and synchronization attribute omitted. Return separate OSStatus/data/attributes per
   query; compare entitlements/effective groups. App null is not absence. Query/identity mismatch
   refuses acceptance. Physical locked/unavailable semantics remain downstream.

## Suggestions

9. **Split core and pack/job — adopted.** L0a is executable core first with no-job/no-pack
   precondition; L0b owns scheduler/transport/hazard requirements. One owner and original review
   budget continue. Earlier tags remain in the supported-source matrix; this pilot is not their
   execution acceptance.

10. **Parser/rejection controls — adopted with an actual bridge contrast.** Preserve per-key raw and
    parsed outcomes plus hydrate completion and main pending-removal union behavior. A delivered
    rejected Promise causes whole-restore skip in the app source. However, the actual Android
    wrong-native-type path throws from Preferences.getString, through reflected PluginHandle
    invocation; pinned Bridge.java:846–857 rethrows RuntimeException on taskHandler. It is not
    guaranteed to become a JS rejection. Preregister this as a type-error/native-process hazard,
    require the attributable native exception, and retain wrong-typed disk rows before loss-free
    fixture-route restoration. Do not substitute a synthetic rejection. iOS numeric coercion is
    tested separately. Ordinary timeout/setup failure is not a negative control.

11. **Confirmed Android vault absence — adopted.** Qualified provider `SecureStorage.java:157–166`
    removes the row only when the alias exists. Observe both durable row and alias after exact
    owned-key removal; classify row-only/alias-only states as inconsistency. Invalid JSON, Date
    conversion, non-string JSON and app catch-null remain separate from confirmed absence. Cleanup
    never calls provider clear or all-item deletion. Restore through the real string setter and
    verify persistence cut again.

12. **Graph/toolchain qualification — adopted.** Capture each source's own complete frozen install
    and resolved graph under its later lease; borrowed reviewer node_modules is not an input.
    Confirm root CLI 8.5.1 for released and 8.5.2 for main/reader despite transitive CLI 5.7.8.
    Inspect lifecycle owners/all-false allowBuilds; check generators and sync against exact expected
    overlay, including Package.swift, capacitor.settings.gradle and registrations. Lock/compare
    Package.resolved and actual Android resolution, runtime/WebView identities and artifacts.
    Unexpected native/package/config drift refuses execution. Floors and signed channels remain
    their own gates.

## Additional route and policy contrasts

The original report's summary both recommends fixture appStartPath and requires no reader
appStartPath. The latter is rejected by source evidence: normal-root boot would precede raw capture.
Pinned SDK owners append a path without changing scheme/hostname. Both native asset routers send
extensionless paths to root index.html; use literal `/legacy-continuity.html` instead. iOS requires
that packaged file to exist. Exact HTML output, inherited template/layout, actual URL and no
root-page/earlyBoot entry are gates. The template reads storage and cleans shallow history; it does
not seed storage. Source route qualification cannot prove persistent-profile survival.

Qualified secure provider default access zero maps to whenUnlocked. The stricter
whenUnlockedThisDeviceOnly mobile prose is not projected onto these fixtures. Observe actual
accessibility/entitlements, preserve the discrepancy and hand policy correction to the parent.

The original report's single unverified entry remains immutable. Its later old-helper desktop
mechanism claim is now separately executed and bounded. Actual source writer, native return
transport, same-ID profile and upgrade claims remain unaccepted. Round two will challenge the
implemented observer/route/config/read shape before native trust; round three reviews executed
revision/evidence and final unit acceptance. No new planning round or reset is used.
