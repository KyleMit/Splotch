# Locked Capacitor route and bridge owners

Four public npm archives were read without installation or execution. Android and iOS 8.5.1 match
v1.6.0 d8b86469f63c57a06a9de45664a42eea15b99eb0's actual lock; 8.5.2 match accepted reader
794448fbf76276b76a910c167b5c2e0c4e1ea538. The exact registry responses, locks, archive bytes, 358
safe unique regular source files and original modes are bound in manifest.json. Both locked SHA-512
integrity and registry SHA-1 match each archive. Source copies are stored read-only. This proves
selected public source inputs, not an installed/compiled/deployed graph.

owner-boundaries.json binds 34 actual line/byte anchors across nine finite owner files and both
versions, plus the complete 358-file literal search set. Eight owner files are identical across
versions. Bridge.java differs as a whole; its anchored URL, DOM-storage and exception ranges were
read independently for each version. The source predicates show:

* Android CapConfig reads server.appStartPath separately from hostname/scheme. Bridge forms the
  local origin, then appends that path. DOM storage is enabled. Its local server serves root
  index.html for extensionless HTML5 paths, and extensionful HTML through the file path.
* iOS InstanceConfiguration constructs localURL from scheme/hostname, then appStartServerURL appends
  the path. CAPBridgeViewController requires appStartFileURL to exist before loading the matching
  server URL. CapacitorRouter serves root index.html for extensionless paths; .html paths select
  their actual file. The controller creates WKWebViewConfiguration without an explicit
  websiteDataStore override and registers plugins before web loading.
* None of the complete four archives contains the literal profile override predicates nonPersistent,
  websiteDataStore =, setDataDirectorySuffix or dataDirectorySuffix. This finite spelling search
  excludes neither app overrides nor external/deployed input. Actual persistent profile survival is
  a native execution gate.
* Android PluginHandle invokes plugin methods reflectively. Bridge's posted task catches a general
  exception and rethrows RuntimeException. A wrong-type Preferences get is therefore not guaranteed
  to deliver the JavaScript rejection needed for an app Promise.all skip control.

The planned fixture path is literal /legacy-continuity.html on source and reader. Require its exact
built file, initial URL and audited route/template/layout, with no drawing-root/earlyBoot before raw
capture. Do not treat an extensionless route, normal root index or merely successful navigation as
that predicate. Source-level path/origin reasoning is separate from sentinel/profile execution.

The intake verifier's locked positive, actual wrong-version archive, one appended source byte and
restored positive were executed. Both deliberate mismatches returned
LOCKED_ARCHIVE_INTEGRITY_MISMATCH; restored exact bytes passed. These are source-integrity controls,
not runtime storage or crypto controls. The sandbox DNS setup failure before response bytes is
retained separately under capacitor-route-attempts and is not a rejecting control. Producers and
complete command logs remain adjacent in the parent preflight directory.
