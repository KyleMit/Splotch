# Repaired Quality pass and first Browserless failure

The exact reviewed retry ran at staged tree 1acae1d1600798e298f5e5dda6be138bf8445284 on
709fadd68ecb802aa2c9daa3fc197ce8d072b23c, with the granted 900-second whole deadline. Quality
reached all fifteen stages and exited zero in 46.629 seconds. Browserless reached all five stages
and exited one in 77.839 seconds. Only test:tools failed, with 7,693 passing and two failing tests:
the document scanner treated a historical copied CAMPAIGN snapshot's fifteen relative links as
current documentation; the tool path guard classified a capability-relative test anchor as a
repository-root walk. Unit coverage, asset generator, store-drawings and all 42 API smoke assertions
passed. Source-role positives were halted before execution.

The actual original receipt is f5f69179abec6746093a7636f6b62962a94fa910126f77b209814d8efbb64cd9.
Complete final hashing finished within 125.116304 seconds. Source byte/modes, semantic
index/tree/status, runtime and qualified own installation/complete graph reuse stayed unchanged.
Complete raw stdout/stderr retains the exact two test reasons and all job channels. These are
accidental source/packaging findings, not intended rejecting controls or native continuity
acceptance.

`lease.released.json.txt` independently proves four command groups 94494, 94496, 95760 and 71700 and
producer 94478 absent through actual OS process/group inspection. No signal was sent. Both actual
net-owner port probes exited zero and SMOKE_PORT 5386 was free after the jobs. There was no
install/list/catalog repeat, unleased retry, extension, native/browser/performance or rival stage.
Original Claude conversation 1b406e61-641e-4cf8-86fb-2b1cd7548469 remains one used/two remaining.

The source owner will give the capability path its actual anchor and consolidate historical raw
records in one complete safe capsule while preserving canonical original copies/manifests. The next
full-source gates require new input binding and a parent lease. No PR/CI/native/effective
profile/signed-channel/physical or whole campaign acceptance is established by this invocation.
