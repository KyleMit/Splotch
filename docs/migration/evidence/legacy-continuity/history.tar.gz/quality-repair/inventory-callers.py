from pathlib import Path
import subprocess,json,hashlib,datetime
R=Path('/Users/kylemit/.codex/worktrees/migration-legacy-continuity/Splotch');P=Path('/private/tmp/splotch-resume-01a111b0/legacy-continuity-source/quality-repair-proposal')
roots=['tools','web','netlify','android','ios','.ruler','.github','migration','experiments']
globs=['*.mjs','*.cjs','*.js','*.ts','*.tsx','*.svelte','*.template','*.json','*.java','*.swift','*.kt']
args=['rg','--files','--hidden',*[v for g in globs for v in ['-g',g]],*roots];p=subprocess.run(args,cwd=R,capture_output=True,timeout=15);assert p.returncode==0 and not p.stderr
names=sorted(set(p.stdout.decode().splitlines()+['package.json','knip.json','eslint.config.js','knip.production.json']))
pattern=r'FIXTURE_OWNER_KEY|UNRELATED_SENTINEL_KEY|NATIVE_SECURE_PREFIX|NATIVE_PREFERENCES_GROUP|NATIVE_VAULT_PREFERENCES|\bgitBytes\b';q=subprocess.run(['rg','-n',pattern,'--',*names],cwd=R,capture_output=True,timeout=15);assert q.returncode==0 and not q.stderr
(P/'callers.stdout.raw.txt').write_bytes(q.stdout);(P/'callers.stderr.raw.txt').write_bytes(q.stderr)
matched={line.split(':',1)[0] for line in q.stdout.decode().splitlines()};assert matched=={'tools/migration/legacy-continuity/contract.mjs','tools/migration/legacy-continuity/source-inputs.mjs'}
rows=[]
for name in names:
 b=(R/name).read_bytes();rows.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
v={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'selectionArgv':args,'selectionExitCode':p.returncode,'searchPattern':pattern,'searchArgvPrefix':['rg','-n',pattern,'--'],'actualFiniteSearchFiles':rows,'searchExitCode':q.returncode,'matchedOwnerPaths':sorted(matched),'stdoutBytes':len(q.stdout),'stdoutSha256':hashlib.sha256(q.stdout).hexdigest(),'scope':'actual maintained source/config/template caller inventory across actual repository roots, including candidate/native and co-located tests; generated/ignored outputs, docs historicalrawrecords and hostprivatepaths excluded; everymatchedname is internal to itsdefiningmodule; values/helpersremain genuine productionowners, remove onlyexternal exportsurface'}
(P/'callers-manifest.json.txt').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps({'files':len(rows),'selectedBytes':sum(x['bytes'] for x in rows),'matchedPaths':sorted(matched),'manifestSha256':hashlib.sha256((P/'callers-manifest.json.txt').read_bytes()).hexdigest()}))
