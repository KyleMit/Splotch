from pathlib import Path
import json,hashlib,stat,datetime,os
R=Path('/Users/kylemit/.codex/worktrees/migration-legacy-continuity/Splotch');S=Path('/private/tmp/splotch-resume-01a111b0/legacy-continuity-source/quality-repair-proposal');U=R/'docs/migration/evidence/legacy-continuity/source-composition';D=Path('/Users/kylemit/Code/Splotch/logs/migration-resumption-01a111b0/legacy-continuity/source-composition')
def h(b):return hashlib.sha256(b).hexdigest()
def file_identity(p):
 b=p.read_bytes();st=p.stat();assert stat.S_ISREG(p.lstat().st_mode);return {'path':str(p),'bytes':len(b),'sha256':h(b),'mode':oct(stat.S_IMODE(st.st_mode)),'inode':[st.st_dev,st.st_ino]}
proposal=json.loads((S/'projection-proposal.json.txt').read_bytes());old=proposal['oldRelativePath'];new=proposal['rawProjectionRelativePath']
assert old=='integration-proposal/CAMPAIGN-L0-row-proposal.md' and new==old+'.txt'
assert h((U/'manifest.json.txt').read_bytes())==proposal['originalManifestSha256'] and h((U/'integration-proposal/receipt.json.txt').read_bytes())==proposal['secondaryReceiptSha256']
m=json.loads((U/'manifest.json.txt').read_bytes());e=next(row for row in m['files'] if row['path']==old)
assert next(row for row in json.loads((U/'integration-proposal/receipt.json.txt').read_bytes())['proposed'] if row['path']==Path(old).name)['sha256']==proposal['sha256']
for root in [U,D]:
 for row in m['files']:
  p=root/row['path'];v=file_identity(p);mirror=next(x for x in row['mirrors'] if x['root']==str(root))
  assert v['bytes']==row['bytes'] and v['sha256']==row['sha256'] and v['mode']=='0o444' and v['inode']==mirror['inode'],('L0_HISTORICAL_MEMBER_CHANGED',str(p))
assert not (U/new).exists() and (U/old).resolve()==U/old
old_identity=file_identity(U/old);canonical_identity=file_identity(D/old);assert old_identity['inode']==proposal['unitOriginalInode'];assert old_identity['inode']!=canonical_identity['inode']
for row in proposal['sourceChanges']:
 assert h((R/row['path']).read_bytes())==row['beforeSha256'];assert h((S/row['path']).read_bytes())==row['afterSha256']
for root in [U,D]:assert not (root/'raw-markdown-projection.json.txt').exists() and not (root/'projected-members.json.txt').exists()
# All fixed inputs and outputs are qualified before any mutation.
for row in proposal['sourceChanges']:(R/row['path']).write_bytes((S/row['path']).read_bytes())
(U/old).rename(U/new);new_identity=file_identity(U/new);assert {k:new_identity[k] for k in ['bytes','sha256','mode','inode']}=={k:old_identity[k] for k in ['bytes','sha256','mode','inode']};assert file_identity(D/old)==canonical_identity
mapped=[]
for row in m['files']:
 actual=new if row['path']==old else row['path'];unit=file_identity(U/actual);canonical=file_identity(D/row['path'])
 assert unit['bytes']==canonical['bytes']==row['bytes'] and unit['sha256']==canonical['sha256']==row['sha256'] and unit['mode']==canonical['mode']=='0o444' and unit['inode']!=canonical['inode']
 mapped.append({'historicalRelativePath':row['path'],'currentUnitRelativePath':actual,'bytes':row['bytes'],'sha256':row['sha256'],'unit':unit,'canonicalHistoricalCopy':canonical})
value={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'one historical rawMarkdown current-unit packaging projection; no reformatting, chmod relaxation, loss ofbytes, formatter exclusions or controlacceptance; original manifests/canonical filenames remain immutable historical evidence','originalManifestSha256':proposal['originalManifestSha256'],'secondaryReceiptSha256':proposal['secondaryReceiptSha256'],'historicalRelativePath':old,'currentUnitRawProjectionPath':new,'beforeUnit':old_identity,'afterUnit':new_identity,'canonicalOriginal':canonical_identity,'producerSha256':h(Path(__file__).read_bytes()),'sourceChangeProposalSha256':h((S/'maintained-source.diff.txt').read_bytes()),'sourceChanges':proposal['sourceChanges'],'manifestResolutionRule':'resolve only the one named historicalpath to current rawprojection for unitmembers; canonical original path stays exact; every other historicalpath must resolve unchanged; projected-members.json.txt verifies complete originalfinite set'}
for leaf,v in [('raw-markdown-projection.json.txt',value),('projected-members.json.txt',{'at':value['at'],'originalManifestSha256':proposal['originalManifestSha256'],'count':len(mapped),'files':mapped,'scope':'complete original53payload preservation at currentmappedunitpaths and unchangedcanonical originalpaths; additive amendment/inventory are notoriginalmembers'})]:
 b=(json.dumps(v,indent=2)+'\n').encode();inodes=[]
 for root in [U,D]:
  p=root/leaf;p.write_bytes(b);p.chmod(0o444);assert p.read_bytes()==b and stat.S_IMODE(p.stat().st_mode)==0o444;inodes.append([p.stat().st_dev,p.stat().st_ino])
 assert inodes[0]!=inodes[1]
print(json.dumps({'projectedMembers':len(mapped),'old':old,'new':new,'bytes':new_identity['bytes'],'sha256':new_identity['sha256'],'sameUnitInode':new_identity['inode']==old_identity['inode'],'canonicalOriginalUnchanged':True,'projectionSha256':h((U/'raw-markdown-projection.json.txt').read_bytes()),'membersSha256':h((U/'projected-members.json.txt').read_bytes())}))
