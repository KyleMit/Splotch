# L0 full-Quality finding repair

The [first full Quality invocation](../full-final-gates-20261006204640/README.md) reached all
fifteen steps and failed three. Browserless was not run. Complete actual channels,
source/semantic-index, qualified installed-graph reuse and independent owned-process/port release
remain immutable. An additive amendment corrects the failure-mirror helper's inherited scope label;
actual invocation receipts govern claims.

The maintained-source diff internalizes five genuine owning constants and the Git reader function. A
complete actual caller inventory covers 2,120 maintained code/config/template files and finds those
names only in their two defining modules. Their production consumers and values remain unchanged.
The redundant executable Knip entry is removed; the root public script already owns its entry
discovery, while the nested test entry remains. No suppression, allowlist, cap change or speculative
consumer is introduced.

The one 1,055-byte historical proposal row is represented as a raw .md.txt member at the current
unit path. Its exact SHA, 0444 mode and original inode survive the rename; the original canonical
Markdown copy remains unchanged. Both original manifests remain at exact unit/canonical filenames,
bytes/modes and independent inodes. The explicit source-composition projection receipt maps only
that one historical name; its complete projected-member inventory checks all 53 original members,
including all other untouched paths. A historical manifest continues to describe its captured
layout; current unit readers must apply the named projection rather than assume the old path exists.
There is no formatter configuration exclusion or reformatted raw receipt.

`applied-repair.json.txt` records actual source/packaging composition only. The old source manifests
and failed-source receipt are not rewritten. The prepared retry controller retains the original
whole 900-second bound, Quality 300/Browserless 480 deadlines, actual signal ownership, smoke-port
owner and existing installation/graph reuse. Three bounded role CLI inspections will qualify the
changed inspector/contract ownership bytes and compare complete output with earlier executed
positives without normalization. Their individual deadlines are capped by whole remaining time, with
60 seconds reserved for finalization. No install/list/catalog repeat or new materialization is
needed.

Fresh source/profile/producer and complete semantic-stage binding precedes a new parent-granted
exclusive lease. Original Claude conversation 1b406e61-641e-4cf8-86fb-2b1cd7548469 remains one
used/two remaining; no PR, ledger adoption, new round or native/SDK/profile/channel/physical
acceptance follows the source repair. The standalone scope is source-built fixture tooling; app
source and linked precompiled SDK association remain distinct gates.
