# L0 pinned iOS SDK owner amendment

Recorded 2026-10-06 after the original L0 round-one challenge and before round two, installation or
native execution. This amends the trust-plan owner description; the original PLAN and nine earlier
source-only materializations remain immutable.

The actual released v1.6.0 source d8b86469f63c57a06a9de45664a42eea15b99eb0 pins capacitor-swift-pm
8.5.1 at 6afa7424fd2fcd8ca1e577478e8a00af284b7e82. Held main
ef3d1eb2070c1bd0dee620ed42a2b14201c2a9b4 and the current accepted reader
794448fbf76276b76a910c167b5c2e0c4e1ea538 pin 8.5.2 at 0b6882e9a3288342aacf36348e5a94e4f1dd7b13.
Their actual role Package.resolved and CapApp-SPM/Package.swift bytes are included.

Both pinned upstream Package.swift owners declare exactly two `.binaryTarget` entries at lines
19–27: Capacitor and Cordova XCFramework ZIPs. Lines 21–22 and 26–27 own their exact version-bound
URLs and SHA-256 archive checksums. The source manifest has no source targets. A fixture app source
build therefore links pinned precompiled SDKs; it does not compile this SDK from the npm archive.
The qualified npm source is useful for source-owner hypotheses, but equal version labels do not
establish association with compiled SDK bytes or runtime behavior.

The complete primary GitHub MCP commit and base64 file responses are preserved, with both decoded
904-byte Package.swift files. The source identity verifier checked repository, exact commit/ref and
the decoded Git blob, byte hash and finite binary-target URL/checksum declarations. It refused each
wrong actual commit identity and changed actual source bytes for the intended reason, then restored
both original positives. These six source-intake controls qualify the manifest identity only. The
first incorrect MCP argument schema is separately preserved as a setup failure.

Before any iOS trust execution, the later permitted install/build must bind the exact SPM checkout
and resolved graph; verify all downloaded SDK ZIP checksums and safe members; preserve actual
selected XCFramework slice, framework/interface/module metadata and library byte identities; bind
the app's link/load composition and installed/runtime SDK identities; and exercise the real bridge,
route, native observer and storage controls. The app artifact must record the SDK binaries
separately from source-built app/overlay inputs. Compiled-source association remains unresolved
unless complete qualified provenance actually establishes it. Archive contents, header versions,
compilation success and reviewer agreement alone cannot establish that association or storage
continuity.

This intake downloaded only public structured metadata and manifest source. No binary ZIP, SDK
execution, source/base modification, package installation, review round or ledger adoption occurred.
The actual L0 round-two prompt now names this owner boundary; the eventual PR description and new
final source/artifact manifest must preserve it. Previous released binary/signing/channel
association, physical protection and performance gates remain open. Upcoming accepted-base
composition must rebind only changed reader inputs after the parent verifies the real merge, keeping
released and held identities fixed.

Complete machine-readable inputs, qualified source hashes and binary checksums are in
`spm-owner-inputs/primary-manifest-qualification.json.txt`; the finite verifier is
`spm-owner-inputs/qualify-primary-manifests.py.txt`. The mirrored packet manifest verifies byte,
mode and independent inode identity without rerunning unchanged empirical controls.
