# L0 minimal accepted-base composition preparation

This is read-only preparation against published Retained source
0c56e26309198082dfe76c99231fab24b23117cd over current L0 base
794448fbf76276b76a910c167b5c2e0c4e1ea538. It is not an acceptance, merge, source change or executed
gate. Actual accepted integration must come from the parent and be verified before applying. Current
25 fixtures/tools and all historical receipts remain preserved.

The incoming public diff changes package check to include retained-host TypeScript, adds the
retained script catalog and knip entries, qualifies the Node-floor PWA postbuild flag and adds
`web/appShellBuildNonce.ts` plus its Vite owner. Sixteen directly read existing persistence,
origin/configuration, native registration/launch/SPM/lock/process owners have byte-identical source.
The attempted app-local `CapacitorBridgeViewController.swift` lookup is unavailable on both sources;
that guessed path is not an owner or a positive assertion. Actual app ownership is the observed
`MainViewController.swift`, while CAPBridgeViewController belongs to the separate pinned SDK.
`published-source-contrast.json.txt` preserves the complete actual contrast and that setup lookup.
No SDK checkout/installed/compiled identity is promoted.

After the parent supplies the actual accepted merge:

1. Re-verify all current source-manifest rows, exact unit base/index and saved root bytes. Refuse
   any changed/unowned source. Verify actual incoming ancestry and complete changed-path set,
   including no collision with the 25 owned tools or evidence directory.
2. Preserve exact owned package/knip/CAMPAIGN bytes and the surgical source/root patch. Remove only
   known owned intent-to-add entries from the index while retaining every source file. Restore only
   the three root owners to their known base after their byte/mode preservation is proven. Do not
   apply stale whole root files over incoming owners.
3. Fast-forward the isolated L0 branch to the exact accepted integration. Keep the 25 untracked
   owned tools and all evidence bytes in place; verify them again afterward. A conflict, unexpected
   path or hash change halts this composition, with the preserved frontier available.
4. Compose the one L0 script/description and exact nested knip entries over the actual accepted JSON
   owners, preserving all incoming check/postbuild/retained changes. Parent owns common-register
   reconciliation; add only the bounded L0 row and a dated composition transition while preserving
   prior dated observations.
5. Compare exact new accepted reader owners, then rebind the reader source/configuration to that
   actual source after the parent confirms the scope. Released and held roles keep their exact tag
   and main-snapshot identities. The new reader's Vite nonce helper/source linkage must join its
   finite explicit intake. Current shipping source storage/native/SPM equality can narrow the review
   delta; changed base, script/check/Vite/reader/overlay identities still invalidate relevant prior
   preparation/runtime receipts. Retain the old 794 reader and frozen PLAN as history and preserve
   the exact dated replacement input/disposition.
6. Freeze the composed source manifest, exact root/tool/reader-source diffs, complete source-owner
   contrasts and a rebound scoped supervisor before requesting execution. The supervisor checks the
   exact actual new base and source manifest. Its 600-second whole deadline covers preparation and
   final complete hashing, with the same live signal proof and expiry/ownership refusal behavior.
7. On the parent's transferred lease, perform the own frozen ignored-script install, complete graph,
   ten scoped guards, actual composed check/lint and final source/flag controls. No prior old-base
   gates or borrowed graph are reused. Native/full/browser/performance execution remains excluded.
   Preserve source/index/runtime identity, all output bytes and actual group release.
8. Open/review the small source unit only after applicable full gates and the original-identity
   adoption requirements are satisfied. Original Claude round two challenges implemented source and
   changed inputs before native trust. One used/two remaining persists; no fresh/reset/ledger launch
   has occurred in this preparation.

Own source fixtures still require later exact static output, frozen role-specific installation, SPM
checkout/resolved native graph, owned nonproduction signing identity, artifact/runtime/origin
qualification and fresh owned simulator/emulator leases. The composition does not accept those,
source-built local continuity, signed-channel upgrades or comparative physical performance.
