# L0 frozen source and bounded tools lease plan

This final source snapshot replaces the unexecuted supervisor and CLI filename in the earlier
[source preparation](../source-repairs/README.md) packet. The earlier packet and nine historical
materialization receipts remain unchanged. No own install, scoped suite, native build/run,
profile-survival or upgrade acceptance has occurred.

The executable is `tools/migration/legacy-continuity/run-fixture.mjs`, following the owning tools
instruction's verb-filename rule. Its guarded named entry remains `runLegacyContinuity(argv)`. Only
its package/knip/test callers changed. The surgical diff compares the six repaired files to all 25
byte-verified earlier source files; it preserves the old and current identities separately. The full
source manifest also binds accepted process/lock/workspace owners. The package diff changes one
public script and matching description; knip adds exactly the nested entry and tests. Parent owns
live-register integration.

The scoped supervisor's 600-second SIGALRM starts before preparation and hashing. All file hashes
are checked against the remaining deadline, Git queries have finite 15-second timeouts, and calls
reserve 60 seconds for final complete input/receipt hashing. Final actual elapsed time must be below
600 seconds. Expiry or unresolved process ownership preserves failure evidence and refuses complete
gate acceptance. Per-call deadlines and teardown limits remain distinct.

Requested execution is an own frozen ignored-script pnpm install, complete recursive installed
JavaScript graph, ten scoped host guards, check/lint and finite final inspect/unknown/restored flag
controls. No full suite, native/static build, device, browser or performance execution is requested.
Every command group signal re-proves full unchanged PID/birth/argv plus direct PPID and group
ownership. A missing or reused leader with surviving descendants preserves unresolved ownership. The
source/index/runtime snapshot and all owned command groups must remain valid at completion.

The actual raw held-record read is included before any command mutation. Complete encoded types and
buffer bytes/length/SHA plus held presence/count/recognition cardinality are checked on the host.
These are transport guards. Native engine/profile continuity remains unexecuted, and original Claude
round two must challenge the implemented route/observer/configuration/read shape and trust before
native boundary execution. Original identity 1b406e61-641e-4cf8-86fb-2b1cd7548469 retains one used
round and two remaining; this snapshot spent no substantive round.
