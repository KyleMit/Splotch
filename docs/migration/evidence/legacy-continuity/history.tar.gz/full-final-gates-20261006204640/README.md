# First full L0 local gates failure

The exact parent-reviewed final-source runner ran on a granted 900-second exclusive lease at staged
tree 1d2e0277c1e370cac3e1e340621e42641517fbf4 and accepted base
709fadd68ecb802aa2c9daa3fc197ce8d072b23c. Complete final hashing finished in 52.841748 seconds.
Quality reached all fifteen actual job steps and exited one. Exactly three steps failed:
format:check identified one unformatted historical raw Markdown proposal; ruler:check then refused
to rewrite that immutable read-only receipt; lint:dead identified six internal exports and a
redundant executable entry. Browserless was not executed. These are accidental findings, not
rejecting controls or continuity acceptance.

The exact original `receipt.json.txt` is
f69f8065e5bb22df9c3131f6cdbb8a82c8cf459f6499e8cdc93a8bebfa9f38fc. Every selected source byte/mode,
semantic index/tree/status and runtime stayed qualified. Before/after reuse of the own complete JS
installation/graph receipt is equal; there was no install/list/catalog repeat. The before/after port
probes used the actual accepted net owner, both exited zero and reported SMOKE_PORT 5386 free.
Complete Quality stdout/stderr, all command raw channels, staged-source snapshots and the exact
producer remain separate files without normalization or clipping.

`lease.released.json.txt` independently proves all three command groups 81595, 81597 and 83200, plus
supervisor 81579, absent through actual OS process/group queries. No signal was sent. A first
read-only process query was denied by the default sandbox before mutation; the authorized escalated
query succeeded. Its setup failure is preserved separately and is not a native refusal. The actual
supervisor executable identity is recorded after execution without claiming all interpreter
libraries.

The current repair boundary is historical raw receipt packaging plus internal export/Knip surface.
No immutable receipt was reformatted, chmod-relaxed or dropped, and no formatter/dead-code rule was
suppressed. Proposed repairs require fresh exact source/semantic-index binding and a new parent
lease before appropriate reruns. Original Claude conversation 1b406e61-641e-4cf8-86fb-2b1cd7548469
remains one used/two remaining. No PR, rival round, compiled
SDK/native/device/profile/channel/physical or full campaign acceptance follows this failure.
