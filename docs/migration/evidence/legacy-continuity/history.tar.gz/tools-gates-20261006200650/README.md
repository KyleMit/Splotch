# L0 tools lease: first accidental failure

The parent granted one frozen 600-second tools-only lease at accepted source
709fadd68ecb802aa2c9daa3fc197ce8d072b23c. The actual supervisor was `run-scoped-tools.py`, SHA
4b8b32c12d7c74c8a7c487fc0e9e308850a4e178a13d07a5a491c63a5de9ba3e. Tool handle 7885 started at
2026-10-06 20:06:50 UTC and exited 1 after the first accidental failure. Final hashing completed
within 32.134834375 seconds; this duration measures harness execution, not app performance.

`receipt.json.txt` is the exact complete supervisor outcome, SHA
bf6bf2ccc51b4b1435ae0d56061d274d6adf8274e713cc82106420fd1b77a765. It preserves actual command
PID/birth/argv/direct parent/group identities, complete source/runtime/index snapshots and output
byte/hash records. Source/runtime/index stayed unchanged. The seven owned command groups were
absent; the separate actual `lease.released.json.txt`, SHA
b4bb9ebf393478ddf7fdc1cf06366e4ac2e9b414dd270448e1a8ab37e0642c67, re-proves their absence and
records release. Original filenames and immutable bytes are preserved.

The ignored-script frozen pnpm install passed in 4.3 seconds. Its full output reports 1,419
packages, reused cache inputs, no downloaded packages and pnpm 11.22.0. The complete recursive
depth-Infinity installed JS graph is 2,063,317 bytes and is preserved without clipping. Actual
installed package/module/lock metadata are included. This qualifies the own installed JS graph only;
native resolved/compiled/loaded SDKs remain open. Catalog, all ten scoped guard tests and the
composed check command exited 0. Complete stdout/stderr are included, including check stderr; exit
codes determine their disposition.

Lint exited 1 with exactly one `no-unsafe-finally` error at
`tools/migration/legacy-continuity/command-evidence.mjs:258:7`. This is an accidental implementation
failure, not a rejecting control. The supervisor stopped later work immediately. Final role
inspections and unknown-flag/restored controls did not run. The failure does not invalidate the
completed scopes whose relevant source/graph/runtime inputs still match, but it prevents this unit's
final local-gate acceptance. A process-boundary source repair and scoped follow-up require parent
disposition; no install repeat is proposed.

No native/static build, device, browser/performance suite, rival review, PR or ledger adoption
occurred. Original L0 conversation 1b406e61-641e-4cf8-86fb-2b1cd7548469 remains one used/two
remaining. No intended negative is accepted from a wrong cause. The copy manifest verifies complete
file bytes, mode0444 and independent unit/canonical durable inodes, including the exact original
supervisor manifest plus the subsequent release record.
