from pathlib import Path
import subprocess,json,hashlib,datetime,time,os,signal,re,sys

REPO=Path('/Users/kylemit/.codex/worktrees/migration-legacy-continuity/Splotch')
SOURCE=Path('/private/tmp/splotch-resume-01a111b0/legacy-continuity-source')
MANIFEST=SOURCE/'integration-final/source-manifest.json.txt'
NODE=Path('/Users/kylemit/.nvm/versions/node/v24.16.0/bin/node')
PNPM=Path('/Users/kylemit/.nvm/versions/node/v24.16.0/lib/node_modules/corepack/dist/pnpm.js')
NPM=Path('/Users/kylemit/.nvm/versions/node/v24.16.0/lib/node_modules/npm/bin/npm-cli.js')
WHOLE_DEADLINE_SECONDS=600
TEARDOWN_SECONDS=2
IDENTITY_SECONDS=2
GIT_QUERY_SECONDS=15
FINALIZATION_RESERVE_SECONDS=60
POLL_SECONDS=.1
ART=SOURCE/('tools-gates-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S'))
ENV={**os.environ,'PATH':str(NODE.parent)+':'+os.environ['PATH'],'LC_ALL':'C'}
rows=[]
whole_start=time.monotonic()

def whole_remaining():
 remaining=WHOLE_DEADLINE_SECONDS-(time.monotonic()-whole_start)
 if remaining<=0:raise TimeoutError('L0_WHOLE_TOOLS_DEADLINE')
 return remaining

def whole_alarm(signum,frame):raise TimeoutError('L0_WHOLE_TOOLS_DEADLINE')
signal.signal(signal.SIGALRM,whole_alarm)
signal.setitimer(signal.ITIMER_REAL,WHOLE_DEADLINE_SECONDS)

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(data):
 whole_remaining();value=hashlib.sha256(data).hexdigest();whole_remaining();return value
def write(name,value):
 whole_remaining();(ART/name).write_text(json.dumps(value,indent=2)+'\n');whole_remaining()
def file_identity(path):
 whole_remaining();b=path.read_bytes();st=path.stat();whole_remaining()
 return {'path':str(path),'realpath':str(path.resolve()),'bytes':len(b),'sha256':sha(b),'mode':oct(st.st_mode&0o777),'inode':[st.st_dev,st.st_ino]}
def observe(pid):
 try:
  p=subprocess.run(['/bin/ps','-ww','-p',str(pid),'-o','pid=','-o','ppid=','-o','pgid=','-o','lstart=','-o','args='],capture_output=True,timeout=IDENTITY_SECONDS,env=ENV)
  raw=p.stdout.decode();m=re.fullmatch(r'\s*(\d+)\s+(\d+)\s+(\d+)\s+(\w{3}\s+\w{3}\s+\d+\s+\d{2}:\d{2}:\d{2}\s+\d{4})\s+([\s\S]+?)\s*',raw)
  value={'exitCode':p.returncode,'stdout':raw,'stderr':p.stderr.decode()}
  if not m or p.returncode: return {'status':'unavailable',**value}
  return {'status':'observed','pid':int(m[1]),'ppid':int(m[2]),'pgid':int(m[3]),'birth':m[4],'argv':m[5],**value}
 except Exception as e:return {'status':'unavailable','error':str(e)}
def exists(pid):
 try:os.killpg(pid,0);return True
 except ProcessLookupError:return False

def signal_owned(row,sig):
 live=observe(row['pid']);row.setdefault('signalChecks',[]).append({'at':now(),'live':live,'signal':signal.Signals(sig).name})
 initial=row['identity']
 assert live['status']=='observed' and initial['status']=='observed', 'L0_TOOL_LEADER_UNAVAILABLE_NO_SIGNAL'
 assert all(live[k]==initial[k] for k in ['pid','ppid','pgid','birth','argv']) and live['ppid']==os.getpid() and live['pgid']==row['pid'], 'L0_TOOL_OWNERSHIP_CHANGED_NO_SIGNAL'
 os.killpg(row['pid'],sig)

def release(row):
 if not exists(row['pid']):return
 signal_owned(row,signal.SIGTERM)
 deadline=time.monotonic()+TEARDOWN_SECONDS
 while exists(row['pid']) and time.monotonic()<deadline:time.sleep(POLL_SECONDS)
 if exists(row['pid']):signal_owned(row,signal.SIGKILL)
 deadline=time.monotonic()+TEARDOWN_SECONDS
 while exists(row['pid']) and time.monotonic()<deadline:time.sleep(POLL_SECONDS)
 assert not exists(row['pid']),'L0_TOOL_GROUP_REMAINS'

def run(label,argv,call_seconds=60,expected=0,reason=None):
 remaining=whole_remaining()-FINALIZATION_RESERVE_SECONDS
 assert remaining>0,'L0_WHOLE_TOOLS_DEADLINE'
 timeout=min(call_seconds,remaining)
 row={'label':label,'argv':argv,'cwd':str(REPO),'startedAt':now(),'perCallDeadlineSeconds':call_seconds,'effectiveDeadlineSeconds':timeout,'expectedExit':expected,'expectedReason':reason}
 rows.append(row)
 with (ART/(label+'.stdout.raw.txt')).open('wb') as out,(ART/(label+'.stderr.raw.txt')).open('wb') as err:
  p=subprocess.Popen(argv,cwd=REPO,env=ENV,stdout=out,stderr=err,start_new_session=True)
  row['pid']=p.pid;row['identity']=observe(p.pid)
  write('commands.json.txt',rows)
  try:
   assert row['identity']['status']=='observed' and row['identity']['ppid']==os.getpid() and row['identity']['pgid']==p.pid, 'L0_TOOL_SPAWN_IDENTITY_UNQUALIFIED'
   row['exitCode']=p.wait(timeout=timeout)
  except Exception as e:row['failure']=str(e);raise
  finally:
   try:release(row)
   except Exception as e:row['unresolvedOwnership']=str(e);raise
   finally:
    row['groupAbsent']=not exists(p.pid);row['endedAt']=now();write('commands.json.txt',rows)
 stdout=(ART/(label+'.stdout.raw.txt')).read_bytes();stderr=(ART/(label+'.stderr.raw.txt')).read_bytes()
 row['stdout']={'bytes':len(stdout),'sha256':sha(stdout)};row['stderr']={'bytes':len(stderr),'sha256':sha(stderr)}
 write('commands.json.txt',rows)
 assert row['exitCode']==expected,(label,'L0_UNEXPECTED_EXIT',row['exitCode'])
 if reason:assert reason.encode() in stderr,(label,'L0_WRONG_FAILURE_REASON')
 print(json.dumps({'label':label,'exitCode':row['exitCode'],'groupAbsent':row['groupAbsent'],'stdoutBytes':len(stdout),'stderrBytes':len(stderr)}),flush=True)
 return stdout

def source_snapshot(label):
 manifest=json.loads(MANIFEST.read_bytes())
 current=[file_identity(REPO/r['path']) for r in manifest['files']]
 for expected,actual in zip(manifest['files'],current):
  assert expected['sha256']==actual['sha256'] and expected['bytes']==actual['bytes'] and expected['mode']==actual['mode'], ('L0_SOURCE_INPUT_CHANGED',expected['path'])
 index=Path(subprocess.check_output(['git','rev-parse','--git-path','index'],cwd=REPO,text=True,timeout=min(GIT_QUERY_SECONDS,whole_remaining())).strip())
 if not index.is_absolute():index=REPO/index
 diff=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=REPO,timeout=min(GIT_QUERY_SECONDS,whole_remaining()))
 status=subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=REPO,timeout=min(GIT_QUERY_SECONDS,whole_remaining()))
 (ART/(label+'.diff.txt')).write_bytes(diff);(ART/(label+'.status.bin.txt')).write_bytes(status)
 return {'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True,timeout=min(GIT_QUERY_SECONDS,whole_remaining())).strip(),'manifest':file_identity(MANIFEST),'selected':current,'index':file_identity(index),'diffSha256':sha(diff),'statusSha256':sha(status),'runtime':[file_identity(p) for p in [NODE,PNPM,NPM,Path('/bin/ps')]]}

ART.mkdir(exist_ok=False)
write('lease.started.json.txt',{'owner':'L0','scope':'own frozen ignored-script install, complete installed graph and scoped guards/check/lint; no full suites/build/native/device/browser/performance','startedAt':now(),'wholeDeadlineSeconds':WHOLE_DEADLINE_SECONDS,'finalizationReserveSeconds':FINALIZATION_RESERVE_SECONDS,'gitQueryDeadlineSeconds':GIT_QUERY_SECONDS,'teardownPerSignalSeconds':TEARDOWN_SECONDS,'supervisor':observe(os.getpid()),'sourceManifest':file_identity(MANIFEST),'producer':file_identity(Path(__file__))})
print(json.dumps({'artifactRoot':str(ART),'leaseSeconds':WHOLE_DEADLINE_SECONDS}),flush=True)
failure=None;before=None;after=None
try:
 before=source_snapshot('before');write('before.json.txt',before)
 assert before['base']=='794448fbf76276b76a910c167b5c2e0c4e1ea538','L0_IMPLEMENTATION_BASE_CHANGED'
 run('pnpm-version',[str(NODE),str(PNPM),'--version'],30)
 run('frozen-ignored-install',[str(NODE),str(PNPM),'install','--frozen-lockfile','--ignore-scripts','--reporter=append-only'],300)
 graph=run('complete-installed-graph',[str(NODE),str(PNPM),'list','--recursive','--depth','Infinity','--json'],60)
 parsed=json.loads(graph);assert isinstance(parsed,list) and parsed,'L0_INSTALLED_GRAPH_INCOMPLETE'
 metadata=[]
 for name in ['@capacitor/core','@capacitor/cli','@capacitor/android','@capacitor/ios','@capacitor/preferences','@aparajita/capacitor-secure-storage','@sveltejs/kit','svelte','vite','vitest','eslint']:
  path=REPO/'node_modules'/name/'package.json';b=path.read_bytes();pkg=json.loads(b);metadata.append({**file_identity(path),'name':pkg['name'],'version':pkg['version']});(ART/(name.replace('/','_').replace('@','')+'.package.json.txt')).write_bytes(b)
 for label,path in [('installed.modules.yaml.txt',REPO/'node_modules/.modules.yaml'),('installed.pnpm-lock.yaml.txt',REPO/'node_modules/.pnpm/lock.yaml'),('source.pnpm-lock.yaml.txt',REPO/'pnpm-lock.yaml'),('source.pnpm-workspace.yaml.txt',REPO/'pnpm-workspace.yaml')]:
  (ART/label).write_bytes(path.read_bytes())
 write('installed-metadata.json.txt',{'packages':metadata,'completeGraphBytes':len(graph),'completeGraphSha256':sha(graph),'scope':'installed JS graph only; no native resolved/compiled graph or SDK execution qualified'})
 run('script-catalog',[str(NODE),str(NPM),'run','info'],30)
 run('scoped-guards',[str(NODE),str(NPM),'run','test:tools','--','migration/legacy-continuity/tests/guards.test.mjs'],120)
 run('check',[str(NODE),str(NPM),'run','check'],180)
 run('lint',[str(NODE),str(NPM),'run','lint'],120)
 for role in ['released','held','reader']:
  run('final-inspect-'+role,[str(NODE),str(NPM),'run','--silent','migration:legacy-continuity','--','inspect','--source',role],60)
 run('unknown-flag',[str(NODE),str(NPM),'run','--silent','migration:legacy-continuity','--','inspect','--source','reader','--unexpected'],60,1,'Unknown option')
 run('restored-flags',[str(NODE),str(NPM),'run','--silent','migration:legacy-continuity','--','inspect','--source','reader'],60)
except Exception as e:
 failure=str(e);print(json.dumps({'failure':failure}),flush=True)
finally:
 try:
  after=source_snapshot('after');write('after.json.txt',after)
  if before:
   assert before['base']==after['base'] and before['diffSha256']==after['diffSha256'] and before['statusSha256']==after['statusSha256'] and before['index']['sha256']==after['index']['sha256'],'L0_SOURCE_INDEX_CHANGED'
   assert [(r['path'],r['sha256']) for r in before['runtime']]==[(r['path'],r['sha256']) for r in after['runtime']],'L0_RUNTIME_CHANGED'
 except Exception as e:failure=(failure+'; ' if failure else '')+str(e)
 unresolved=[r for r in rows if not r.get('groupAbsent')]
 receipt={'completedAt':now(),'elapsedSeconds':time.monotonic()-whole_start,'scope':'own installed JS graph and scoped local tool gates only; native/source-built continuity acceptance remains open','failure':failure,'unresolvedOwnership':unresolved,'commands':rows,'before':before,'after':after,'sourceAndIndexUnchanged':bool(before and after and before['diffSha256']==after['diffSha256'] and before['statusSha256']==after['statusSha256'] and before['index']['sha256']==after['index']['sha256']),'ownedCommandGroupsAbsent':not unresolved}
 try:
  write('receipt.json.txt',receipt)
  write('manifest.json.txt',{'files':[{**file_identity(p),'path':str(p.relative_to(ART))} for p in sorted(ART.rglob('*')) if p.is_file()]})
  receipt_sha=sha((ART/'receipt.json.txt').read_bytes());final_elapsed=time.monotonic()-whole_start
  assert final_elapsed<WHOLE_DEADLINE_SECONDS,'L0_FINALIZATION_EXCEEDED_WHOLE_DEADLINE'
  whole_remaining();signal.setitimer(signal.ITIMER_REAL,0)
  print(json.dumps({'artifactRoot':str(ART),'failure':failure,'unresolvedCount':len(unresolved),'receiptSha256':receipt_sha,'finalElapsedSeconds':final_elapsed,'wholeDeadlineSatisfied':True}),flush=True)
 except Exception as e:
  signal.setitimer(signal.ITIMER_REAL,0)
  failure=(failure+'; ' if failure else '')+str(e)
  emergency={'at':now(),'failure':failure,'elapsedSeconds':time.monotonic()-whole_start,'scope':'expiry/finalization failure only; no complete gate acceptance','commands':rows,'unresolvedOwnership':unresolved}
  (ART/'expiry-or-finalization-failure.json.txt').write_text(json.dumps(emergency,indent=2)+'\n')
  print(json.dumps({'artifactRoot':str(ART),'failure':failure,'wholeDeadlineSatisfied':False,'unresolvedCount':len(unresolved)}),flush=True)
if failure:sys.exit(1)

