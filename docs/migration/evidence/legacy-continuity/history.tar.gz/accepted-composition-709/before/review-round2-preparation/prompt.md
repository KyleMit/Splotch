Resume the original L0 conversation 1b406e61-641e-4cf8-86fb-2b1cd7548469 for substantive round two.
This unit has one round used and two remaining. The original question reviewed actual f149 source,
70 selected source/13 lock/102 provider inputs; its complete findings and one declined/unexecuted
broker request are preserved. That first question did not create an automatic ledger. The actual
PR-keyed adoption must preserve the original identity and consumed round. A fresh fallback or a
reset is not the requested continuation. No new generic orchestration or architecture selection is
part of L0.

First verify all twelve original findings against the frozen PLAN, finding-dispositions and actual
implemented source. Read the actual reviewed PR's complete source/evidence, its executed scoped
receipts and final input identities; do not infer execution from preparation. Then challenge the
implemented observer/route/configuration/read shape and trust plan before any native boundary run.
Round three is reserved for executed native evidence and final-unit acceptance. The PR's bounded
root script/knip/live-register edits do not accept this fixture or select an architecture.

The exact source roles are released v1.6.0 d8b86469f63c57a06a9de45664a42eea15b99eb0, later held main
ef3d1eb2070c1bd0dee620ed42a2b14201c2a9b4, and accepted reader
794448fbf76276b76a910c167b5c2e0c4e1ea538. All declare version 1.6.0/code 8. These are source-built
same-version mechanics, not proof of published binaries, installed native graph, signing, supported
channel upgrade, physical protection or comparative performance. Released Cap/SPM is 8.5.1 with
revision 6afa7424fd2fcd8ca1e577478e8a00af284b7e82; later/reader Cap/SPM is 8.5.2 with revision
0b6882e9a3288342aacf36348e5a94e4f1dd7b13. The actual locked SPM manifests declare precompiled
Capacitor and Cordova XCFramework binary targets. An app source build links those SDK binaries.
Public npm iOS source and version labels do not prove their compiled-source association. Read the
complete pinned commit/manifest responses, decoded Git blobs and all four binary-target
URLs/checksums in the SDK-owner amendment. Exact SDK binary/interface/resolved/loader/runtime
identities and real owner controls remain later gates, alongside the generated export, app artifact,
native dependencies and installation. No SDK binary has been downloaded or executed under this
source-only qualification.

Focus on concrete false passes and false rejections, and challenge smaller eligible alternatives:

* Exact literal `/legacy-continuity.html`, compiled output filename, effective origin and persistent
  profile: pinned Capacitor extensionless fallback sends the root index and cannot be accepted.
  Confirm inherited root/template reads/history cleanup do not seed or start drawing/earlyBoot
  before the raw snapshot. iOS static route requires actual later build/URL qualification.
* Released iOS AppDelegate launch resume, mismatched-job entire-version deletion, same-version
  resume/publish and current-main decode/cancel hazards precede JS. Android WorkManager starts
  before Activity. L0a must contain no job/pack before every launch; expected no-job directory
  creation remains explicit. No normal status/launch is safe merely because JS avoided status. L0b
  remains separately gated on offline enumeration and controlled job constraints/response.
* Use real source writers, non-default settings including dark/sound false/volume 37/role-specific
  drawer key, finite owned sentinel/nonce and exactly two logical secrets. Memory acknowledgment
  does not establish disk durability; independent native XML/cfprefs + source relaunch precede
  reinstall. Actual default Keychain whenUnlocked versus stricter mobile prose stays a discrepancy,
  not inferred stricter protection. Android vault row+alias outcomes and iOS raw
  OSStatus/attrs/query semantics must distinguish confirmed absence, unavailable and corrupt from
  nullable app getters. Owned-key-only cleanup never calls clear or deletes foreign/held/legacy
  keys.
* The raw snapshot includes the hint-independent held read before mutations. get/count/getKey share
  one readonly transaction and completion is awaited. Stored undefined differs from missing. Every
  supported own field/type remains transported; ArrayBuffer has exact base64/length/SHA and host
  recomputation. Unsupported/cyclic/symbol-bearing data refuses completeness; unknown entries are
  not silently filtered. Host checks encoded tags, recognized-entry cardinality and recognized
  buffer presence. Actual native absence-abort and crypto/profile behavior are still unexecuted. The
  separate desktop-engine receipt qualifies only the old reader's empirical defects and cannot
  execute or accept the declined original broker request retroactively.
* iOS driver must attach after real capacitorDidLoad, await ready/JS in the actual page content
  world, retain its lifecycle, write/hash the raw receipt before command mutation and preserve
  separate command receipt/PID/persistent store/URL. Console/hash frame completeness is not runtime
  provenance or upgrade acceptance. Android can attach only to a qualified owned fresh emulator,
  installed single APK identity, exact PID/start ticks/WebView socket and unused exact forward.
  Re-prove the serial/port/socket map before removal; retain ownership changes. Native Preferences
  wrong-type crashes need actual native exception/PID/raw row and restored source writer; a CDP
  timeout alone is a failed command, not a passing rejecting control.
* CLI import safety, finite flag refusals, source/tree/blob/mode overlays and receipt preservation
  must remain source-bound. Earlier nine materializations retain old overlays after held snapshot,
  transport/command/entry changes; do not promote them to final-source execution. Own full frozen
  ignored-script install/complete graph must not borrow another worktree's modules or imply a
  compiled/resolved native graph. Appropriate final-source local/hosted gates remain required.
* `capturedCommand` proves actual full PID/birth/argv and direct PPID/PGID at spawn and again before
  each group signal. A very fast actual ADB command may exit before ps observes it: this is a
  plausible false rejection. Preserve actual setup failures separately, and do not weaken cleanup
  ownership without executable evidence. Lost/reused/unavailable leaders with surviving groups
  refuse release and preserve unresolved ownership. Per-call, whole host lease and teardown
  deadlines differ. The scoped supervisor's 600-second alarm starts before prep/hashing, bounds
  metadata queries and final complete input/receipt hashing; expiry cannot be a passing gate.

State which smaller alternative, if any, provides the same real owner/native boundary with less
risk. Keep L0a and L0b source-built scope distinct from RN in-place reads, replacement ordered
transactions, channel upgrades and physical calibration. No app/native build or device execution is
currently implied by the source unit. Request only scoped commands that materially resolve a source
question; native/device/full/browser/performance or provisioning requests require an explicit parent
lease and may be declined. Preserve the actual reason for unexecuted claims. Evidence resolves
empirical disagreements; reviewer agreement alone cannot establish native continuity or performance.
