# L0 accepted-base source composition

The parent supplied accepted PR2702 merge 709fadd68ecb802aa2c9daa3fc197ce8d072b23c, tree
265b8a70228d97b46682804d31ac2c513de1535f, parents 794448fbf76276b76a910c167b5c2e0c4e1ea538 and
0c56e26309198082dfe76c99231fab24b23117cd. The isolated L0 source composition verified those actual
Git identities and the complete 60 changed paths before fast-forwarding with hooks disabled. All 25
existing tool/template bytes survived that operation. Only the tool README, reader constant and
finite reader build-owner intake changed afterward; the complete surgical diff is included. The old
f935 source manifest and 60df unexecuted supervisor remain preserved in the earlier evidence packet.

The bounded root diff adds one legacy script and description, two exact knip entries and the L0
current row/dating. Semantic JSON comparisons preserve every accepted owner outside those entries.
Historical L0 dated observations remain unchanged. Other current campaign rows remain the parent
integrator's reconciliation responsibility.

`source-manifest.json.txt` binds 69 current tool/root/read-only/immutable SDK evidence inputs,
1,113,159 bytes. `source-profile-inputs.json.txt` binds 25 released, 26 held and 29 reader actual
Git owner/picture records, with 56 unique complete source blobs preserved by byte SHA. It records
mode, Git blob, revision, tree, source declaration and exact previous-reader comparison. Released
d8b86469f63c57a06a9de45664a42eea15b99eb0 and held ef3d1eb2070c1bd0dee620ed42a2b14201c2a9b4 remain
fixed. Reader now names the accepted merge. The new reader intake explicitly includes
`web/appShellBuildNonce.ts` and its actual ownership/contract imports. This is finite source
metadata, not an executed tool inspection, native graph, effective origin or persistent-profile
survival assertion.

The [immutable SDK owner packet](../sdk-binary-owner/manifest.json.txt) preserves 31
source/metadata/preparation files and matching independent durable copies. Its
[trust amendment](../sdk-binary-owner/sdk-binary-owner-amendment/TRUST-PLAN-AMENDMENT.md) identifies
both pinned SPM Package.swift binary-target owners. Their complete primary commit/file responses,
decoded Git blobs, archive URLs/checksums and six correct-reason identity/refusal/restored controls
remain unchanged. Its older reader declaration describes the prior 794 scope; the new accepted
reader's actual SPM lock/manifest bytes are identical and rebound in this source profile. A
source-built fixture app links pinned precompiled Capacitor and Cordova XCFrameworks. npm
source/version labels do not establish their compiled-source association. Actual SDK
ZIP/member/interface/resolved/link/load/runtime identity and real owner controls remain
prerequisites, with no binary download or execution implied here.

`round2-prompt.md` and its changed-input diff preserve the original L0 conversation
1b406e61-641e-4cf8-86fb-2b1cd7548469, one used and two remaining substantive rounds. The adoption
template is preparation only; no PR, ledger adoption or round-two launch occurred. The next original
round challenges implemented observer/route/configuration/read shape and trust before native
execution. Round three remains for executed native evidence and final-unit acceptance. The old
thirteen finding/plan-repair receipts and declined original request stay historical, with no
retroactive execution.

`run-scoped-tools.py.txt` is the rebound 600-second supervisor. Its diff changes only
source-manifest selection and the actual base assertion. The finite alarm begins before
preparation/hashing, Git metadata calls are bounded and a 60-second finalization reserve protects
complete final hashing. Actual PID/birth/argv/PPID/PGID proof precedes each group signal; lost
ownership or expiry refuses acceptance. It has not run. The requested lease covers one own
ignored-script frozen pnpm install, complete installed JS graph, ten scoped guards, composed
check/lint and final role/flag controls. Full/native/device/browser/performance execution needs
separate authorization. No own node_modules, compiled SDK association, fixture continuity,
signed-channel upgrade or physical claim is accepted by this packet.

All metadata commands and complete selected source bytes are preserved. A source-only knip lookup
initially projected `entry` at the root instead of the actual dot workspace; it failed before any
mutation and is a setup failure, not a rejecting control. The packet copy producer and manifest bind
complete byte/hash/mode identities and independent durable inodes; immutable historical packets are
not rewritten.
