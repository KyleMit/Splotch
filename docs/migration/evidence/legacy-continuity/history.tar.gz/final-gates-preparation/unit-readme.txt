# Source-built legacy continuity unit

L0 owns finite disposable Capacitor source-fixture preparation and observation tools. It preserves
exact released v1.6.0, later held-picture and accepted-reader source/configuration owners, then
composes a literal raw-observation route and registered native observers in owned copies. It does
not implement replacement services or transactions. Native
build/install/effective-origin/profile/runtime and signed-channel continuity remain later gates.

The implemented tools are in `tools/migration/legacy-continuity/`. The original Claude conversation
is 1b406e61-641e-4cf8-86fb-2b1cd7548469, one used/two remaining substantive rounds. The
[repaired plan and twelve finding dispositions](plan-repairs/PLAN.md) control the source unit;
original raw question/review identity is retained in `plan-review/`. The source-built app links
pinned precompiled Capacitor/Cordova SDKs, whose public
[binary-target manifest owner amendment](sdk-binary-owner/sdk-binary-owner-amendment/TRUST-PLAN-AMENDMENT.md)
keeps compiled-source association open.

The [accepted-reader composition](accepted-composition-709/README.md) preserves all 25 tools through
the verified PR2702 fast-forward, actual source/profile declarations and complete source Git blobs.
Earlier nine source-only materialization/control receipts retain their original tool/overlay
identities. The [first tools lease](tools-gates-20261006200650/README.md) preserves complete own
frozen installation and the 2,063,317-byte JS graph plus the one accidental lint failure. The
[exact two-file repair](source-followup-plan/README.md) changes process error propagation and adds a
real aggregate-error/ownership guard. The
[later scoped follow-up](tools-followup-20261006203134/README.md) passes 11 guards/checklint/role
and intended-flag/restored controls at its exact recorded source, with equal input-qualified install
reuse and actual group/producer release.

These immutable packets retain exact raw output filenames and byte/mode/hash/independent-inode
manifests. Parent-verified source/root changes are bounded to L0 tools/templates, one root
script/description, two knip entries and this unit's current register row/dated transitions. The
next gates are full staged Quality/Browserless, commit/push/PR/CI and original round-two
implemented-source challenge. Round three remains for executed native evidence and final acceptance.
No native/device/physical performance, effective persistent-profile survival, replacement
transaction, deployed-binary association, signed upgrade or final campaign completion is established
here.
