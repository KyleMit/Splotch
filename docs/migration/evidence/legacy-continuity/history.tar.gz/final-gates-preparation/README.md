# L0 final local gates preparation

This additive packet freezes the implemented L0 sources, the existing immutable receipts and the
actual accepted Quality/Browserless execution owners on 709fadd68ecb802aa2c9daa3fc197ce8d072b23c.
The earlier scoped follow-up passed eleven guards, check/lint, three real role inspections and
intended unknown-flag refusal/restored positive. Its complete original receipt and installed-graph
qualification remain unchanged. This packet prepares full final-source gates; it contains no new
test, native or rival execution result.

`source-manifest.json.txt` binds 395 selected files and 21,381,388 bytes, including every existing
own tool/evidence input and the finite actual gate/configuration owners. The source-built role
profiles and 56 exact stored Git blobs retain their earlier qualified identities.
`profile-reuse.json.txt` and `scoped-receipt-reuse.json.txt` state the relevant reuse predicates and
limits. A preparation attempt used an incorrect test-owner path and refused before freezing any
inputs; `accidental-missing-owner.json.txt` preserves that setup failure. The corrected paths are
actual capability-owned tests. This is not an intended rejecting control.

`run-final-source-gates.py.txt` proposes one 900-second whole lease. The alarm starts before
preparation/hashing, Git queries have finite 15-second timeouts, and final complete input/receipt
hashing must finish within the whole deadline. Quality has 300 seconds, Browserless 480 seconds,
with 60 seconds reserved for finalization and 60 seconds for overhead/headroom. Historical same-host
Quality 44.704 seconds and Browserless 75.735 seconds justify these limits; they measure harness
cost rather than app latency. The existing mirrors own their actual fifteen/five job steps and
continue collecting step failures; a failed Quality job halts the outer runner before Browserless.
Complete output channels and actual exit reasons remain evidence.

A real staged freeze is prepared after this packet is copied. It binds the complete semantic Git
index, staged tree, owned source diff, current status and absence of unstaged/untracked source.
Before/after snapshots verify selected source byte/mode identities and that complete staged scope.
Raw index bytes/inodes remain diagnostic because Git can refresh cached filesystem metadata without
changing staged content. Strict runtime and installed-receipt reuse predicates remain unchanged. No
install, list or catalog command is repeated. The reused complete 2,063,317-byte JS resolution
receipt does not prove every installed library byte, a native resolved graph or compiled SDK source
association.

SMOKE_PORT 5386 had no passive listener during preparation and is not reserved. The actual accepted
`tools/lib/net.mjs` owner must requalify it before and after the full jobs. API smoke owns its
disposable test server; no foreign listener may be stopped. Outer process signals require the exact
live PID/birth/argv and direct parent/process group before every signal. Lost ownership, timeout,
wrong refusal reason, source change or a surviving owned group refuses acceptance and remains a
separate failure. No Playwright, candidate/static/native build, device, physical performance,
signing/channel, rival or architecture acceptance is authorized by this proposed runner.

The prepared original round-two prompt is additive. Claude conversation
1b406e61-641e-4cf8-86fb-2b1cd7548469 remains one used/two remaining; actual PR-keyed adoption and
original resumed round two happen only after a reviewable PR exists. Round three remains for actual
native evidence and final unit acceptance. The pinned SPM binary-target owner amendment continues to
distinguish source-built app code from precompiled Capacitor/Cordova SDKs.
