# L0a source composition

Observed on isolated accepted base 794448fbf76276b76a910c167b5c2e0c4e1ea538. The maintained tool
implementation is in tools/migration/legacy-continuity. This receipt accepts only finite source
input inspection, Git-blob/mode materialization and fixture overlay composition. No fixture graph,
web/native compile, mounted page, persistence, channel upgrade or comparative timing was executed.
The authored six Vitest guard tests and applicable check/lint/full gates remain unexecuted pending
this unit's own qualified install and a parent lease.

The complete implemented-source manifest contains 25 files and 109,625 bytes. The actual nine calls
preserve full stdout/stderr, argv, source identity, actual process start observations and verified
owned group absence. Wrong-role refuses before Git reads for L0_SOURCE_ROLE_INVALID. Existing-root
refuses for L0_EXISTING_ROOT_REFUSED and leaves its source receipt unchanged. The three actual roles
then materialize successfully and a fresh reader composition restores the positive.

| Role     | Source                                   | Original blobs | Exact Git-source bytes | Owned overlays |
| -------- | ---------------------------------------- | -------------: | ---------------------: | -------------: |
| released | d8b86469f63c57a06a9de45664a42eea15b99eb0 |          6,124 |            724,252,330 |             15 |
| held     | ef3d1eb2070c1bd0dee620ed42a2b14201c2a9b4 |          7,821 |          1,105,262,789 |             15 |
| reader   | 794448fbf76276b76a910c167b5c2e0c4e1ea538 |          8,330 |          1,152,566,097 |             15 |

The restored reader has the same source and input/overlay rules at a separate owned root. These four
full source copies remain scratch preparation; only finite complete evidence is mirrored here.
Output JSON lists every source blob/mode/length and every actual overlay digest. Version labels
remain 1.6.0/code8, so this is a source-built same-version mechanism preparation.

Two accidental setup failures remain separate. The initial controller's ps call was denied by the
sandbox before complete command/group validation. The first host attempt successfully validated the
wrong-role control but then failed a positive released inspection because the producer wrongly
projected HEAD's ColoringPackStorage.java into v1.6. The actual released plugin owns the
noBackup/coloring paths inline; main/reader have the extracted owner. The corrected finite owner
list reads the actual tagged plugin and selects the extracted file only for main/reader. The old
producer file was recovered exactly against its original source-copy digest. Neither accidental
failure qualifies a native or planned negative control.

Original Claude conversation 1b406e61-641e-4cf8-86fb-2b1cd7548469 remains one used/two remaining.
The complete original findings and corrected all-twelve dispositions remain in plan-review and
plan-repairs. Implemented observer/route/configuration/read shape and trust prerequisites receive
actual original round two before native boundary execution; round three remains for executed results
and final-unit acceptance. No new review identity, budget adoption/reset, PR, commit, push, CI or
merge occurred in this transition.
