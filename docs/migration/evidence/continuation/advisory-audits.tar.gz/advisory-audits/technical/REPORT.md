# Independent review of the Splotch migration through the October 6 pause

## Verdict

**Continue with specified corrections, preserving the campaign's conditional architecture
decision.** The work so far is technically sound foundation work with unusually substantive review
and evidence discipline. It has improved the migration's reasoning and preserved the shipping
product while making experiments possible. It has not established that React Native is the right
final architecture, that a replacement native application works, or that changing rendering
frameworks improves the motivating workloads.

The strongest result is the decision process at the pause: RN, a Capacitor/native-paper hybrid, and
retention remain eligible outcomes; RNW versus React Strict DOM remains open; product fidelity,
continuity and measured mechanisms constrain selection. The initial categorical RN/RNW
recommendation exceeded the evidence, but later reviewed contracts correct that problem. I would not
restart the architectural investigation or discard the accepted foundations. I would fix the
candidate import guard before growing its source graph, finish the explicitly pending local units,
and preserve the current causal, host, continuity and final-product gates before moving substantial
product ownership.

No shipping-product correctness defect was established by this audit. One reproducible correctness
defect exists in an assurance guard: its fixed source list misses an undeclared dependency through a
new local module. The most important remaining risks are acknowledged but unproved assumptions,
rather than concealed implementation failures.

Confidence is **high** in the progress classification, accepted source boundaries, historical
baseline arithmetic and current contract reasoning; **moderate** in preservation of existing
behavior, supported by meaningful local/CI checks and representative code inspection; and **low by
design** in candidate runtime, performance and upgrade viability, because those experiments have not
occurred. Original system traces behind some historical attribution figures are absent locally. No
new physical measurement, native build, installation, hosted deployment or full suite was performed
for this audit.

The migration remains paused. This report authorizes no implementation or external action.

## Scope, provenance and method

The cutoff includes the actual terminal pause summary at parent raw record **L17527,
2026-10-06T12:40:02.782Z**. The goal-pause tool call/result are L17520/L17522 at 12:39:45; the
checkpoint observedAt is 12:39:27. Later audit-prompt preparation is excluded. The parent file's
full end time, 13:00:20, therefore does not describe the reviewed campaign interval.

The principal records are:

* Parent `Native Arch`, session 01a10e92-a1ac-7610-a4f0-3769ecfd495c:
  `/Users/kylemit/.codex/sessions/2026/10/05/rollout-2026-10-05T20-17-33-01a10e92-a1ac-7610-a4f0-3769ecfd495c.jsonl`.
* Pause checkpoint and preserved evidence:
  `/Users/kylemit/Code/Splotch/logs/migration-pause-2026-10-06/`.
* Accepted integration: **dc08a90abc67b53124146bf288c80de0f9ffd1dd**.
* Retained-web local source: **8ddfc04053ccdf285c2f6fd7c2b75e745a9d2fc6**, in
  `/Users/kylemit/.codex/worktrees/migration-retained-web/Splotch`.
* Native-source local work: uncommitted changes on dc08a90abc67b53124146bf288c80de0f9ffd1dd, copied
  at the pause and separately inspected in
  `/Users/kylemit/.codex/worktrees/migration-native-source/Splotch`.
* Private React host preparation: `/private/tmp/splotch-react-web30-merge-tieo7hhj`, with 53
  prepared source files and separately frozen inputs; no source commit or execution. This audit
  preserves its exact local files in `private-react-source-snapshot/`; it was not included in the
  campaign pause packet.

Repository instructions and the Codex transcript-analysis skill were read first. The prescribed
Codex skeleton extractor produced `parent-skeleton.md`; factual extraction reads the complete
skeleton in sections and drills raw records, including nested results and pre-compaction history.
Actual parent references, retained rival streams and recorded spawn relationships locate linked
sessions: 48 retained rival runs identify 39 actual Claude session IDs; 34 official transcript paths
are present, and five sessions lack an official file but retain their referenced rival streams.
Claude records use the separate Claude skeleton reader. The inventory is complete for discovered
links; detailed semantic review focuses on consequential records and does not claim an end-to-end
read of every Claude session. Factual extraction is separate from this report's judgments. Generated
skeletons and inventory are retrieval aids, not substitutes for consequential raw evidence.

Fresh architecture, implementation and validation specialists inspected primary evidence
independently. Their reports accompany this one. The root reviewer reconciled their conclusions with
contract/source inspection, exact PR/CI metadata from native GitHub tools, and targeted raw review
records. Agreement is not treated as empirical validation. Differences in scope are preserved: a
source-only GO, a local build, a hosted install, a native compilation and a physical outcome are
different claims.

The native-source child records confirm authenticated intake plus Git/byte/mode/hash checks, with no
native checker, installer, test, compilation or mount invoked. Its delegated task and two message
bodies are encrypted in that rollout; attribution uses its readable tool calls/results and final
delivery, rather than inferring their unavailable text.

The audit consulted architecture, ADR, mobile, testing and profiling skills; all seven requested
migration documents; relevant ADRs, diffs, boundary implementations, tests and artifacts. Focused
execution used isolated fixtures or pure in-memory analysis. The candidate-import probe borrowed an
existing full dependency tree and ran on Node 24; it is a guard/type-resolution counterexample, not
a supported-floor native execution result. The native-source audit borrowed parsers/installed Expo
sources and validates source/provenance only.

The evidence inventory includes `github-pr-metadata.json` and `github-ci-and-reviews.json`; the
final
[linked-session inventory](/Users/kylemit/Code/Splotch/logs/migration-progress-review-01a10e92/2026-10-05-01a10e92-linked-session-inventory.md);
the
[parent factual report](/Users/kylemit/Code/Splotch/logs/migration-progress-review-01a10e92/2026-10-05-01a10e92-parent-facts.md)
with separate
[verbatim scripts](/Users/kylemit/Code/Splotch/logs/migration-progress-review-01a10e92/2026-10-05-01a10e92-parent-one-off-scripts.md)
and
[failed outcomes](/Users/kylemit/Code/Splotch/logs/migration-progress-review-01a10e92/2026-10-05-01a10e92-parent-failures.md);
and the
[native-source child factual report](/Users/kylemit/Code/Splotch/logs/migration-progress-review-01a10e92/linked-codex/2026-10-06-01a11129-native-static-implementation.md).
The specialist judgments are
[architecture-review.md](/Users/kylemit/Code/Splotch/logs/migration-progress-review-01a10e92/architecture-review.md),
[implementation-review.md](/Users/kylemit/Code/Splotch/logs/migration-progress-review-01a10e92/implementation-review.md)
and
[validation-review.md](/Users/kylemit/Code/Splotch/logs/migration-progress-review-01a10e92/validation-review.md),
with the
[prepared React source addendum](/Users/kylemit/Code/Splotch/logs/migration-progress-review-01a10e92/implementation-react-preparation-addendum.md).
Throughout the code references below, paths are relative to `/Users/kylemit/Code/Splotch` unless a
different checkout is named, and refer to the stated revision, not a future branch head.

## Verified progress

### Accepted units

“Accepted” below means independently reviewed, tested, pushed and merged into the migration
integration branch. It does not mean merged into main, deployed to production, accepted as a native
replacement, or accepted as a phase exit.

| Requirement/unit                              | Actual state                                                                                      | Supporting evidence                                                                                                                                                                                                                                  | Remaining acceptance condition                                                                                                     |
| --------------------------------------------- | ------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------- |
| Migration, web, parity and upgrade contracts  | Implemented as documents; reviewed and accepted into integration                                  | [PR 2691](https://github.com/KyleMit/Splotch/pull/2691), head a8f15f6cdbc429e7c2d3900eb549a3f6bb21fee4, merge d3d4203539143584bc1af96e7652fc7f39f3382b; two Claude rounds and 13 resolved findings                                                   | Requirements need actual candidate/target evidence; Phase 0 physical controls and observer mapping remain open                     |
| External source-map-js security repair        | Implemented, tested, reviewed, pushed, merged                                                     | [PR 2692](https://github.com/KyleMit/Splotch/pull/2692), head 05e9f3d4b58159649be3b8042cd11b3662601b60, merge 1ceb97338eced2b280964a5a2257ce4933c489d6; scoped lock repair and successful exact-head Tests/Native compile                            | Separately documented embedded-code residual is not declared repaired by this unit                                                 |
| Portable drawing defaults                     | Implemented with real existing callers; accepted                                                  | [PR 2693](https://github.com/KyleMit/Splotch/pull/2693), head e06807cf612e44fe58ac75bd205ef5bd3bd8e7d4, merge d2e77431c4a06bcdea7fe33611a28edd43e8ada2; two reviews, full tests, final CI                                                            | This is not a portable engine or shared-state package; further extraction needs actual consumers                                   |
| Refined Phase 1 sequence and selection rules  | Reviewed plan accepted                                                                            | [PR 2694](https://github.com/KyleMit/Splotch/pull/2694), head 228e3d2e239ccbc92c8ae84e1e7080c0cda84859, merge d1402f6b2bedd2c30cbc88d30597466855b33874; two plan reviews and documented dispositions                                                 | Calibration, candidates, matched comparisons and foundation selection pending                                                      |
| A0 Magic work witness                         | Implemented, tested, reviewed and merged; diagnostic observer only                                | [PR 2695](https://github.com/KyleMit/Splotch/pull/2695), head bbe36ed22442b32b1e552aeb2e37061223807f2d, merge e5ab28af553a55841aac35c938fc7b0e19ec9ba7; release guards, owner/counter/action tests and final CI                                      | Fresh physical attribution and observer overhead; any A1 suppression/remedy is a separate unit                                     |
| Private Expo/RN candidate topology            | Implemented, structurally checked, reviewed, pushed, merged                                       | [PR 2697](https://github.com/KyleMit/Splotch/pull/2697), final head 9442b27817a61486750b070ff07c880d124571a6, merge dc08a90abc67b53124146bf288c80de0f9ffd1dd; three Claude rounds, final 18 successful applicable CI jobs, hosted proof incorporated | Fix guard finding F1; candidate native projects, optimized compilation, mount, floor/runtime and graphics/service proof are absent |
| Build-version ownership repair                | Implemented, tested, independently reviewed, merged                                               | [PR 2698](https://github.com/KyleMit/Splotch/pull/2698), head 7f090b6fccafdc9d383e2cab8f97c5492c496a60, merge 5ccf8cb1475ba945235bada82c96458a223ccc06; six-file source fix and final Tests CI                                                       | Future candidate artifact versions must still use existing release owner and reservation/channel policy                            |
| Cached Netlify production installation repair | Implemented, fixture-tested, reviewed, actually exercised on a nonproduction hosted build, merged | [PR 2699](https://github.com/KyleMit/Splotch/pull/2699), head 53135ad5e9fd93e4f0c4a65bd74108b7fda1690e, merge cbb104976d0840611dff7f5188b9b8712050fe6a into topology unit; deploy 6ac4dd381d311b0008210aa1; final combined topology-head CI          | This proves the repaired install/build boundary, not deployed React-host/PWA behavior or native product acceptance                 |

All eight PR merge states and identities were checked against GitHub, rather than inferred from the
checkpoint. PR 2691's exact-head Tests run failed only in Quality's dependency audit; the other
applicable jobs passed. Its inherited source-map-js failure was preserved and repaired in 2692. It
is inaccurate to call that first head wholly green, and equally inaccurate to classify the entire
accepted foundation as still failing that repaired advisory.

At the final topology head, successful jobs were ADR consistency, exact topology proof, two shipping
native compilations, and fourteen Tests-workflow jobs: Quality, browserless, release build,
Lighthouse, eight Chromium shards, Firefox smoke and WebKit smoke. Four WebKit commit-gate jobs were
event-inapplicable skips. The successful runs include
[Tests 37460369874](https://github.com/KyleMit/Splotch/actions/runs/37460369874),
[Native compile 37460369826](https://github.com/KyleMit/Splotch/actions/runs/37460369826) and
[topology 37460369695](https://github.com/KyleMit/Splotch/actions/runs/37460369695).

Final green checks do not prove every earlier intermittent failure was fixed. A complete local
browser tier first passed 1,169 cases and failed one compact-picker case; five isolated repeats
passed, then the full normal-worker tier passed all 1,170 (parent L12301, 09:25:49.638; L12379,
09:27:44.060; L12646, 09:36:04.076). Browserless CI also had a temporary Git-fixture cleanup failure
and an unchanged Android signal-cleanup timeout before successful reruns (L10525/L10643/L11675). The
complete rerun is meaningful integration evidence, but the record does not establish these failures’
causes or a reliability repair. I do not assume host load explains them. Preserve them for
recurrence investigation rather than reporting their earlier heads as clean.

**The native CI jobs compile the shipping Capacitor application.**
`.github/workflows/native-compile.yml:79–95` invokes `android:compile` and `ios:build:release`, with
the existing native trees and Capacitor assets. `tools/migration/check-native-topology.mjs:65–80`
runs candidate TypeScript/Babel checks and explicitly says “no native compile, mount, performance or
upgrade result.” Neither job proves an RN application mounted or ran.

### Local work and phase exits

| Requirement/unit                                           | Actual state                                                                                                                                                              | Supporting evidence                                                                                                                                                                 | Remaining acceptance condition                                                                                                                                                                              |
| ---------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Historical baseline inventory                              | Implemented and arithmetic independently reproduced                                                                                                                       | BASELINE.md; 48 native manifest references resolved to 40 raw artifacts; 32 drawing and eight undo passes, 25 iPad/four Android action failures reproduced                          | Current exact-source physical control and causal attribution; historical trace calculations could not be independently replayed                                                                             |
| Retained Svelte web control                                | Prepared, implemented and tested locally; earlier source-only review found issues; current source not independently accepted, pushed or merged                            | Source 8ddfc04053ccdf285c2f6fd7c2b75e745a9d2fc6; seven public calls exited zero; release and mechanism builds/browser runs; nine negative-control categories and restored positives | Measured numeric CI timeout, workflow integration, applicable final-source Quality/full tier, PR/push, resume original Claude review, final-head CI and acceptance                                          |
| Retained browser smoke                                     | Locally tested: real ink, early input before delayed Svelte hydration, same input-canvas identity and nonempty ink after hydration; repeated mechanism evidence preserved | `migration/probes/web-host/tests/control.spec.ts`, paused release and two mechanism runs                                                                                            | Exact full pixel/tile/history oracle and actual React recovery belong to the following host slice; no RNW/RSD result exists                                                                                 |
| Native template intake/source                              | Prepared and uncommitted at pause (intake receipt testsRun=false); source/provenance replay performed only by this audit                                                  | Pause's 70 intake rows; copied snapshot; audit replays 45 maintained native files and Expo scene sources                                                                            | Finish registration/current-topology composition; reviewed source unit/materialization and installed-tree validation; actual native compilation and mount                                                   |
| Static native graphics, runtime/input mechanics            | Proposed; not implemented/accepted as a running candidate                                                                                                                 | PHASE-1 unit 5; minimum source groundwork only                                                                                                                                      | Optimized Android/iOS candidate binaries, static output, actual Hermes flags/runtime, floor/module/permission audits and native input mechanics                                                             |
| Common observable/calibration and A1 remedy                | Specified; A0 observation code exists; current physical results pending                                                                                                   | CONTRACT/PHASE-1, MAGIC-WITNESS.md                                                                                                                                                  | Validated whole-screen visible/readiness observer, negative controls and fresh matched shipping captures before suppression or comparative claims                                                           |
| Same-ID local continuity                                   | Contract/inventory prepared; no accepted reader/import experiment                                                                                                         | UPGRADES.md, PHASE-1 unit 6                                                                                                                                                         | Real setters/locks, legacy origin/profile, localStorage plus independent Preferences, secure entries, applicable held pictures and download jobs in disposable in-place updates                             |
| Signed source/channel upgrades                             | Contract prepared; no accepted result                                                                                                                                     | UPGRADES source/channel matrix                                                                                                                                                      | Supported source artifacts/distribution inventory, exact signed candidate artifacts, real in-place channel checks and transactional import/recovery                                                         |
| React web host and RNW/RSD vocabulary                      | Concrete React sources prepared privately and source-reviewed; no integrated host execution/acceptance; RNW/RSD consumers remain proposed                                 | Parent L9995/L10076/L12729; private 53-file packet; separate runtime-only bundle experiment L5227/L5367; WEB-CONTRACT, PHASE-1 units 7–8                                            | Compose accepted current base, execute actual React consumer/recovery and host scenarios, resolve startup/lazy budget disposition with full cost evidence; real native builds for each surviving vocabulary |
| Complete native paper and matched full-screen alternatives | Proposed                                                                                                                                                                  | PHASE-1 units 9–10; ACCEPTANCE.md                                                                                                                                                   | Crayon/Magic/history/export/audio fidelity, transaction/coherence and native binding proof, then matched physical mechanisms                                                                                |
| Phase 0 exit                                               | Partial: requirements and historical baseline accepted; exit not complete                                                                                                 | CONTRACT:38–56, live ledger                                                                                                                                                         | Current controls, validated measurement mapping and remaining concrete plans                                                                                                                                |
| Phase 1 exit/foundation choice                             | Not complete; current direction is conditional                                                                                                                            | CONTRACT:69 onward                                                                                                                                                                  | Expensive assumptions tested fairly; calibrated comparisons and registered burden policy applied                                                                                                            |
| Phase 2 runnable foundation                                | Not complete                                                                                                                                                              | CONTRACT phase requirements, pause checkpoint                                                                                                                                       | Accepted runnable selected builds, actual behavior/service boundaries, test/capture entries and CI                                                                                                          |
| Phases 3–6 product, tuning and cutover/retention           | Pending                                                                                                                                                                   | CONTRACT/ACCEPTANCE/WEB-CONTRACT/UPGRADES                                                                                                                                           | Complete product evidence, physical release gates, continuity, signed artifacts/deployed host and final review; retirement of replaced owners                                                               |

The pause classification is substantially accurate. Its “controls pass locally” does not convert
those controls into accepted host integration. The integration was clean and pushed; retained source
was a clean local commit without upstream; native intake was explicitly uncommitted. The retained
source bundle has an explicit dc08 prerequisite, and copied local evidence is gitignored and not
pushed. That is honest local preservation, not a remote handoff.

## Architectural reasoning and alternatives

### What changed, and why the current reasoning is stronger

The initial response at parent **L321, 01:58:44.509Z** endorsed a full RN/RNW destination more
firmly than the then-available evidence supported. The user's preceding **L298, 01:57:15.497Z** had
rejected judging a replacement by a naive prototype. Both concerns matter: a rough demo cannot
settle a complete-product verdict, and a mandate to investigate migration cannot establish a
renderer's causal benefit.

The accepted plan resolves this tension appropriately. It tests structural viability and faithful
mechanisms early, permits bounded tuning, and reserves final performance judgment for the integrated
complete product. It does not require a prototype already to satisfy every release gate, but neither
lets compilation or framework identity select RN. CONTRACT:84–121 requires matched mechanism checks
and explicit pivot rules for both native arms; PHASE-1:158–179 requires complete applicable screen
state and the actual production vocabulary.

The reported motivation needs precise qualification. Historical draw-call JS can be short; that does
not mean all application JS is short. ADR-0085's original draw-call evidence reports at-most-2-ms
work, while its gesture-start amendment also records 123–127-ms work associated with suspended audio
resume. The 9.5–14.7-ms Android style work comes from Android **web**, and the iPad page-selection
attribution is physical **Safari**. Neither is a fresh native-WebView causal map.

Independently recomputed native evidence shows drawing and undo pass their banked gates while
discrete actions retain 25 iPad and four Android failing cells. This supports investigating action
costs. It does not establish that the failures still exist at the campaign head, that browser
composition dominates them, or that a native paper alone removes surrounding UI costs.
BASELINE:120–150 and PHASE-1:32–34 correctly state those limits. Some original system traces are
unavailable, so this audit verified artifact/runtime provenance and scoring, not every historical
trace attribution. Raw payloads do not uniformly contain a product SHA themselves; source manifests
and unique retained indexes provide that binding. A generated advisory label does not override the
per-run native scoreability or release policy.

Changing from WebView rendering to native views/graphics is a credible mechanism hypothesis. Native
still has layout, rasterization, uploads, GPU memory, synchronization and compositing costs. RNW
also renders through React DOM on web. A useful experiment therefore holds visible content, paper
backend/input where appropriate, prior journey and outcome constant, then locates the removed cost.
The current plan does this; it does not currently claim a causal benefit from the name “React
Native.”

### Disposition of the alternatives

| Alternative                                            | What it can plausibly improve                                    | What remains to prove                                                                      | Fairness of treatment at the pause                                                                                                                             |
| ------------------------------------------------------ | ---------------------------------------------------------------- | ------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Retain Svelte/Capacitor with bounded in-place remedies | Preserves a working single UI, native services, data and tuning  | Current residual failures and final physical release readiness                             | Explicit valid outcome, including no-residual-cost branch; repaired cells cannot be credited to migration                                                      |
| Svelte/Capacitor with native paper                     | Bypasses some paper/surface costs while retaining surrounding UI | Native input/placement/transactions/coherence and whether surrounding WebView cost remains | Serious symmetric competitor; strongest viable mechanism is required                                                                                           |
| RN mobile with retained Svelte web                     | Native mobile UI/paper while retaining browser investment        | Two UI implementations and recurring synchronization cost                                  | Viable fallback/interim arrangement; duplication is an explicit burden                                                                                         |
| RN mobile plus RNW                                     | Shared RN-oriented product vocabulary                            | Web semantics/SSR/CSP/startup/PWA adapters and actual native paper/services                | Leading candidate, unselected; actual hosted and native vocabulary required                                                                                    |
| RN mobile plus RSD                                     | Shared constrained HTML/CSS vocabulary over native views         | Native API/layout gaps, theme/compiler costs and required adapters                         | Real candidate, unselected; cannot inherit raw-RN fixture timings                                                                                              |
| Flutter or separate Swift/Kotlin UIs                   | Alternative non-WebView pipelines/platform control               | Additional language/UI ownership and continuity/renderer effort                            | Conditional fallback for structural failure, a demonstrated failed mechanism, or dominant recurring burden; requires a concrete feasible bypass and continuity |

I found no neglected alternative that materially changes the present decision. Different ways to
implement native paper in Capacitor remain relevant within that arm; an RN/Skia island is a causal
control, not the only production hybrid permitted. CONTRACT:123–158 expressly separates paper
evidence, host glue and intended production burden. A changed backend cannot inherit identical-paper
evidence.

The current primary RSD documentation confirms material native compatibility gaps, including dialog,
form, checkbox/select and SVG support, and limited native layout. These are concrete reasons to
exercise adapters, not reasons to reject RSD categorically. RNW's official documentation describes
it as a React DOM compatibility layer. Neither establishes a maintenance win over the present
already-shared Svelte UI. See
[RSD HTML compatibility](https://react.github.io/react-strict-dom/api/html/) and
[RNW introduction](https://necolas.github.io/react-native-web/docs/). These current sources inform
the next experiment; they are not retroactively imposed as facts known at the campaign's first
recommendation.

Final at the pause: preserving the product and continuity obligations, one shipping version/identity
owner, current hosted API ownership, and fair phase gates. Provisional: RN mobile as leading
direction, embedded SvelteKit host as lower-change first experiment, released Expo alignment as
candidate tooling. Unresolved: architecture winner, web vocabulary, renderer/backend, production
hybrid bindings, actual observer, audio backend, continuity implementation and final host/cutover.

## Strongest implementation and evidence decisions

### Small shared owners rather than a speculative platform framework

`web/src/lib/drawing/strokeSettings.ts` owns the finite width vocabulary, its mapping and defaults.
Existing Svelte facades retain persistence/restoration and actual callers; Node tools import the
same owner rather than copy a table. Color default uses the palette owner. The unit removes two
direct rune edges without pretending the engine's transitive Kit/rune graph is portable.
`engine.ts:15–21` still has those dependencies, and RENDERER-DEFAULTS explicitly limits the claim.

This is a clean responsibility boundary: plain policy is portable; state/persistence remains with
the existing writer. A future engineer can extend the policy without synchronizing hidden tool
copies. Browser replay tests also check actual serialized execution rather than assuming imported
module closures survive `page.evaluate`. The share-card producer-input digest failure was caught by
the broader suite and repaired with the real generator; rendered PNG bytes stayed unchanged. This is
valuable enabling work with concrete callers, not an invented cross-platform API.

### A0 observes work without changing the scored activity

The Magic witness separates owner outcomes, requests/publication, worker construction and recoding
from browser diagnostics. `web/src/lib/drawing/magicWorkDebug.ts` supplies fresh counter factories
and read-only copies; release has no active PERF counter instance. The witness reads existing state
and does not prepare/acquire work. Action reads freeze finish/frame boundaries before diagnostic
collection and keep the new spans out of scored activity. Unavailable/invalid observations are not
zeros. Guard, publication, disposal and worker lifetimes are separately represented.

That design makes later causal controls possible while preserving diagnostic classification and
owner behavior. Runtime observer overhead remains unmeasured and must be reported before causal
comparisons. Release-stripping and rejecting controls matter more than the raw number of tests.
Inclusive synchronous spans can overlap and do not measure asynchronous worker CPU or sum to a
total; the code/docs recognize this. Counter deltas begin when the action is armed, before
activation, so a delta alone does not locate work inside the measured action interval
(`tools/perf/probes/action-probe.js:262–299,383–400`). Physical traces must align actual spans and
outcomes. A0 is no measured improvement and no A1 suppression has been accepted.

### Candidate isolation is measured, not inferred from a folder name

The private Expo member has exact released Expo57/RN0.86.3/React19.2.3 alignment, one root lock,
declared direct packages and real topology consumers. Guards examine installed React/RN/Metro
identities, native scanner/autolinking paths, archive hooks and production closure. New web
vocabulary/compiler/native peers are deferred until actual callers exist. Existing Capacitor
realpaths and production graphs are protected.

Hoisted pnpm forfeits strict dependency isolation; ADR-0119 says so. The chosen boundary is a
guarded coexistence experiment, not two hermetic package installations. This is proportionate to
retaining the existing shipping toolchain. The defect in F1 shows why the compensating guard must
cover the growing source graph, but does not erase the useful installed-tree and production-boundary
evidence.

### Live invariants and exact historical proofs have different owners

Claude caught that early live Quality froze unrelated root package/lock/Capacitor bytes. The
corrected live checker tests present ownership invariants; the historical evidence checker binds the
exact proof. Subsequent shared transitive security bumps do not become “candidate leaks” solely
because a version changed, while candidate-only names still fail shipping closure. Changed candidate
archives still require inspection.

This distinction has practical maintenance value. Otherwise every ordinary security update or
unrelated script edit would require rewriting a historical experiment or fighting its hash fence.
`tools/migration/README.md:3–20` and `check-native-topology.mjs` make the division understandable.

### Native data and service continuity are treated as architecture constraints

UPGRADES uses actual source classes rather than projecting HEAD backward. Live localStorage wins
over stale Preferences; released Keychain accessibility differs from HEAD's new writer; held-picture
and tombstone stores apply only to sources that have them. Existing app IDs, signing lineage,
version writer, installation pseudonym, coloring directories and background job/session identities
remain owners.

The early read-only same-ID experiment is correctly before deep renderer investment. It is
deliberately distinct from transactional import and real signed-channel upgrades. Matching app IDs,
probe installs and simulator mechanics cannot establish legacy origin/profile or Play/TestFlight
lineage. Reusing native service cores is plausible, with bindings and persistent identities
separately verified. This avoids a gratuitous simultaneous service rewrite.

### Failures and review corrections remain inspectable

The retained controls preserve two failed inversion attempts and the later successful attempt rather
than relabeling an earlier result. The final guard controls reject real mutations, restore source
and rerun positives. All 230 rows in the pause packet's three preservation manifests were
independently checked for file presence, byte size and SHA256; none differed. The initial Netlify
failures remain beside source-qualified dispositions; the successful deployment's clipped witness
and null publication field are stated honestly. Local source receipts do not become runtime evidence
simply by being written.

These are substantive correctness improvements. Lengthy investigation, repeated reviews and
expensive tests were often necessary to expose faulty premises or real environment behavior. Their
cost is not counted against this campaign's quality.

## Prioritized findings

### F1 — P2 correctness of an assurance guard: new local modules bypass declared-import enforcement

**Challenged implementation:** the claim that `check:migration:native-topology` validates the
candidate's declared imports as it grows.

**Exact anchors:** dc08a90abc67b53124146bf288c80de0f9ffd1dd,
`tools/migration/lib/native-identity.mjs:8–14,82–94`;
`tools/migration/check-native-topology.mjs:39,65–72`; candidate `tsconfig.json:7`. The scanner
enumerates five fixed files and skips relative imports without traversing their targets. Audit
artifacts `implementation-import-boundary.mjs` and `.json` record source hash,
original/direct/reachable controls and compiler result.

**Established:** all five original scanner inputs pass. Adding a direct undeclared `yaml` import in
real `src/index.ts` fails with the intended error. Restoring that entry and importing `./Extra`,
where `Extra.ts` imports `yaml`, passes the same real guard. The actual candidate TypeScript
configuration also passes, using the already-hoisted full dependency tree. No current phantom import
was found. The full mutated Quality/topology command was not rerun; its source calls this scanner
and typecheck, and its Babel smoke transforms only ProbeApp.

**Why it matters:** hoisted installation intentionally lacks strict package isolation. This guard is
its compensating boundary. A normal next source split can silently consume a root-only package,
creating hidden dependency direction and failing a future isolated/candidate installation or
obscuring the intended SDK graph. Positive direct-import controls do not prove reachability
coverage.

**Correction:** before growing candidate code, discover every candidate-owned compilable
source/config entry or traverse the real entry graph, rejecting escaped relative imports and
undeclared package references. Add the demonstrated reachable-module mutation alongside the
direct-import control, with restored positives. Keep the fix focused; a generic multi-platform
import framework is unnecessary.

### F2 — Selection-blocking unresolved assumption: present native costs and a common observer are still unproved

**Challenged inference:** fast draw-call JS plus historical browser layout/compositing work
establishes that RN will improve the current native failures.

**Anchors:** parent L321/L298 above; dc08 CONTRACT:54–67,84–121; PHASE-1:17,32–47,96–109; historical
native/raw provenance in `architecture-review.md`.

**Established:** banked native drawing/undo pass and action reds reproduce. The cited Android style
figure is web, iPad attribution is Safari, and original traces are missing locally. No campaign-head
physical control, calibrated whole-screen candidate observer or matched native result exists. The
current contract acknowledges all of this. **Inference only:** RN/native paper can remove a relevant
mechanism.

**Why it matters:** a replacement could remove a browser layer yet retain the dominant cost, or
appear faster because it omits output, mounted state, required motion or late work. Conversely, an
invalid observer could reject a viable native design. Window frame issuance, scheduled rAF and one
drawable presentation are not equivalent whole-screen content outcomes.

**Next verification:** preserve unit 4's calibration and negative controls, refresh the motivating
native action families, correlate A0 work with actual windows, and register materiality before
interventions/results. Use matched complete applicable screens and a common within-OS observable.
Hardware absence permits isolated source/toolchain work, not a selection or phase-exit waiver. This
is an open gate, not an observed defect in the accepted observer code.

### F3 — Selection-blocking unresolved assumption: the promised shared UI and host have not been exercised

**Challenged inference:** shared RNW/RSD components automatically lower ownership or fit the
retained host without material runtime/adaptation costs.

**Anchors:** dc08 CONTRACT:100–102,130–162; WEB-CONTRACT's structural proof; PHASE-1:132–148;
accepted ProbeApp contains View/Text only; retained 8dd control uses the existing SvelteKit host.

**Established:** no accepted or executed React host, RNW/RSD consumer or vocabulary-specific native
build exists. Private React sources do exist: an initial nine-file UI packet received source-only
review/corrections, and a later 53-file semantic merge prepared its caller chain without importing,
installing, testing, building or running it (parent L9995, 07:58:59.153; L10076, 08:02:43.480,
runtimeVerified=false; L12729, 09:38:47.887). The retained local experiment verifies a Svelte
control. Its browser test preserves input-canvas identity and nonempty ink, not complete accepted
pixels/history or React recovery. Current documentation does not falsely claim otherwise.
**Inference only:** adapters plus sharing will retire enough recurring work to justify added owners.

There is a useful early cost experiment, not an empty budget question. Claude bundled exact
React/ReactDOM 19.2.3 runtime exports with esbuild 0.25.12 into 193,523 minified raw bytes (60,333
gzip), exceeding the existing 75,000-byte lazy ceiling; recorded startup headroom was 51,648 bytes
(parent L5227, 05:06:45.987; L5367, 05:11:10.349). The command/output survive, but the cleaned-up
bundle bytes do not. This is runtime-only evidence, not a complete current Kit graph or proof that
every React-host strategy fails. ReactDOM cost is shared by embedded and standalone React hosts; the
remaining retained-runtime overlap and activation path must be measured before ranking those
arrangements. The plan explicitly expects deferred placement to fail, retains the shipping guards
and requires actual full costs plus a reviewed causal budget disposition before host/foundation
eligibility.

**Why it matters:** web already shares one Svelte UI with Capacitor. Modal/focus/Back, palette
gestures, Settings enlargement, theme seeding, CSP/PWA and early ink expose platform semantics and
dual-runtime startup costs. A simple common button or raw-RN fixture cannot resolve those costs.

**Next verification:** finish acceptance of the retained unit, then integrate and execute the
prepared embedded host and deliberately trigger unrelated React recovery. Require all relevant
input/tile identities, exact accepted output and history to survive. Exercise a real dialog,
palette/selection and Settings behavior in both surviving web vocabularies and each vocabulary's
native build. Record adapters and complete deployed startup/host deltas. Resolve the known runtime
ceiling through actual artifact evidence and an explicit reviewed cost/ownership decision; do not
count deferral, compression or a diagnostic build as release acceptance. Consider the separate
same-origin document only on a required-contract or measured retained-runtime reason.

### F4 — Selection-blocking unresolved assumption: legacy data/services need real same-ID feasibility before renderer commitment

**Challenged inference:** prepared native sources, matching identity declarations or a clean
candidate installation establishes installed-user continuity.

**Anchors:** dc08 UPGRADES:14–23, supported source matrix and early local continuity section;
PHASE-1:120–131; no accepted candidate reader/import implementation in the source tree.
Contract-review stream 8c3447d3 records L71 at 02:51:19, L172 at 02:54:06 and L332/L382 at
02:56:40/02:57:13, establishing released Keychain defaults and live reconciliation.

**Established:** the source-specific inventory is strong and corrected. There is no actual
replacement read/import result, native lock/entitlement test or signed upgrade proof. **Inference
only:** narrow WebView readers and reused native service cores will remain accessible under the
chosen host.

**Why it matters:** Preferences-only import can revert live parent choices; wrong Keychain
attributes or origin/profile can make existing records inaccessible; altered worker/session
identities can orphan background downloads; a new random installation ID can reset allowance
identity. These problems are independent of rendering speed.

**Next verification:** execute the already planned disposable same-ID read-only experiment
immediately after minimum compilation/mount, using released setters/locks and the actual legacy
origins. Include newer held-picture feasibility and pack/job ownership where applicable. Prove
failed read is not treated as absent. Then implement ordered transactions and later the full
supported-source/signed-channel matrix. Do not silently narrow the supported source set because
artifacts or distribution details are inconvenient.

### F5 — P3 maintainability and auditability: explicitly inventory surviving experimental/tooling owners

**Challenged assumption:** experiment tooling is temporary, or a lower framework/dependency count
demonstrates reduced recurring burden.

**Anchors:** dc08 ADR-0119's candidate amendment; `tools/netlify-production-install.mjs:345–407`;
`netlify.toml:16`; Forge mitigation and live topology/evidence checker split; CONTRACT:130–152 and
PHASE-1:55–56. The live README ledger currently omits accepted topology/version/install units even
though PRs and pause checkpoint record them. At retained 8dd,
`migration/probes/web-host/README.md:11–12,34–38` also still says runs/discovery are unexercised,
contradicting the local executable records; it understates progress rather than inflating
acceptance.

**Established:** the accepted work adds SDK/manual alignment policy, archive/security guards,
installed-tree/host qualification and a production build installer. The installer runs on actual
Netlify builds, so it is already an operational owner rather than disposable scratch. The
live-versus-historical checker separation is a good maintenance correction. Concrete comparative
burden ranges are not yet registered; no remedy/comparison result has occurred, so the
preregistration requirement is not yet violated. **Inference only:** some owners can later be
retired or simplified.

**Why it matters:** a final design may retain SDK, compiler, native service, two-runtime host and
release/security obligations whose recurring cost offsets shared-component gains. Stale live status
increases the risk of confusing prepared/accepted work, while historical evidence packets should
remain unchanged.

**Correction:** when resuming, update the live work ledger and register the required coarse
common-horizon ranges before comparative results. List each surviving owner, update/failure trigger
and retirement condition. Include the production installer and guarded dependency repair; credit
retirement only when an owner actually disappears. Keep measured runtime/resource gates separate.
This recommends explicit ownership, not removing useful checks to save execution time.

### F6 — P3 evidence limitation: hosted installed-tree arrays are not fully preserved

**Challenged claim:** the successful hosted record is a complete independently replayable inventory
of every installed identity/resolution.

**Anchors:** dc08
`docs/migration/evidence/netlify-install/hosted-home-store-success/README.md:12–23,25–38`; source
53135ad5e9fd93e4f0c4a65bd74108b7fda1690e and deploy 6ac4dd381d311b0008210aa1.

**Established:** actual pnpm production install, final source assertions, five-context
installed-tree witness, release guards, ready state and HTTP version were observed. The witness
emits its passing disposition after its assertions. Its rendered JSON line was clipped at 32768
characters; complete hosted arrays and raw full build log were not captured. The packet explicitly
says so. **Not established:** an independently rehashable complete remote graph from that capture
alone.

**Why it matters:** source-qualified pass evidence is sufficient for the narrow observed install
conclusion, but later reviewers cannot enumerate every remote array entry from this packet.
UI-clipped logs should not become the default evidence transport for a selected production host.

**Next verification:** future host evidence should preserve complete structured witness/log
artifacts through an actual supported export/artifact path, plus hashes and exact source/deploy
binding. Preserve this packet's limitation; do not relabel a later run as the same deployment or
invalidate the accepted narrow result without contrary evidence.

## Review quality: what was caught and what remains blind

The reviews resolved important problems, not merely formatting or convention violations:

| Source of finding                             | Problem caught                                                                                                                                                | Verified disposition and significance                                                                                                                                       |
| --------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| User and architecture/contract reviews        | Early recommendation too categorical; naive demo could mislead in either direction                                                                            | Conditional selection, symmetric RN/hybrid mechanisms and later whole-product tuning are explicit                                                                           |
| Claude contract review                        | Preferences presented as native settings authority; HEAD Keychain class projected onto installed releases; source set undefined                               | Live origin/localStorage and independent fallback, released accessibility/transaction policy, source/channel matrix added; actual raw plugin/tag checks support corrections |
| Claude contract/plan reviews                  | Real SvelteKit host absent from structural proof; RN given weaker bar; memory process accounting and behavior families omitted                                | Actual host/CSP/history/worker requirements, equal mechanism bar, renderer/GPU accounting and additional product families added                                             |
| CI/full local suite on defaults               | Share-card producer provenance digest stale after extraction                                                                                                  | Real generator repaired provenance; unchanged image bytes and repeated review establish scope                                                                               |
| Claude A0 review                              | Exception counter fabricated attribution; superseded brush work confused with orphan client bitmap results                                                    | Counter semantics separated and exception path corrected; no physical causal verdict manufactured                                                                           |
| Claude topology reviews                       | Live gate over-froze historical inputs; hook metadata assumed false instead of null; wiring lacked actual executable/process-exit checks                      | Live versus exact history split, archive-authoritative hook inspection, AST invocation/main/exit negative controls                                                          |
| Claude topology resumed review                | Shared transitive security updates wrongly treated as candidate leakage                                                                                       | Real shared-package mutation exposed false positive; production fence now distinguishes package names/ownership while preserving candidate archive review                   |
| Claude retained-control source review         | Duplicate Kit version stamping; detached preview/interrupt orphaning; unwitnessed hydration hold; overwritten rerun evidence; ignored equal-byte mode changes | Current 8dd source corrects these boundaries and actual mutations reject them; resumed final-source review and CI remain pending                                            |
| Parent, hosted runs and Claude Netlify review | Cached residue/config assumptions contradicted by real builds; 37-byte config misclassified; home-store owner needed qualification                            | Failed deployments preserved, real pnpm writer and Netlify image source inspected, finite allowed family qualified, final actual hosted build succeeds                      |
| Parent/independent passive review             | Non-null published_at registration was over-specified                                                                                                         | Additive ready-state correction preserves null and uses documented readiness plus actual version response, without inventing a publication time                             |
| This implementation audit                     | Fixed candidate source list does not cover reachable new modules                                                                                              | F1 remains an unimplemented audit recommendation; no campaign code changed                                                                                                  |

Consequential Claude raw checks include topology session 0dd8610b-d754-48da-b56a-84aee2f32db9,
L111/L133 (06:59:44/07:00:38) for wiring and Forge controls, L273 (07:47:10) for the shared-update
false positive, and L340/L348 (08:12:27/08:12:39) for corrected shared-update/leak controls and
manifest checks. A temporary manifest path-prefix mistake produced missing-file output at L289 and
was corrected at L296; it is not evidence that the real packet lacks those files.

Netlify reviewer session 208bf809-0151-4898-8051-807bccc81365, L275/L282 (10:37:53/10:37:57), used
real pnpm to establish the 37-byte home-store file; L326 (11:17:18) verified image-owner
restore/write behavior; L351 (11:18:26) reproduced a diagnostic-label nit. Its GO allowed the next
hosted validation and explicitly retained actual hosted acceptance as a prerequisite. It was not
proof that a hosted build would pass. The final diagnostic fix is separately recorded; no fourth
formal whole-unit round is claimed. Current
[Netlify API documentation](https://docs.netlify.com/api-and-cli-guides/api-guides/get-started-with-api/#poll-for-deploy-state)
also supports the ready-state interpretation; it does not explain this deployment's null publication
field.

The reviewers were fallible. Initial plans favored RN too strongly; one review's historical key
inference needed correction; tests and actual hosts found issues after source-only agreement. These
are reasons to retain empirical gates, not to privilege either vendor. Review scopes were often
deliberately narrow. The original retained Claude conversation is not reset to erase findings; its
current unit still needs resumed final-source review. The novel F1 blind spot is a useful warning
that several passing synthetic/direct controls can share the same fixed-file assumption.

The retained reviewer b5bb0824-3f7a-4ad7-9e05-4e8e9af77333 returned source-only NO-GO at raw L303,
08:16:39.283Z (parent launch L10262, 08:07:52.349Z). That review used focused process reproductions,
not candidate build/browser execution. Its findings are not erased by later local success; the
original conversation must review the corrected final source.

No unresolved material architectural disagreement was found in the accepted contract. There is
unresolved feasibility, which remains explicitly open. The principal shared blind spot that could
become dangerous is letting accepted topology/control evidence drift into implied native product
acceptance; the pause summary and current contracts mostly avoid that drift.

## Quality of the increments and unfinished work

The accepted increments have understandable semantic boundaries. Contract work defines acceptance;
defaults establish a small real behavior owner; A0 supplies observation; topology proves
package/build coexistence; version and hosting repairs close failures exposed by the experiment.
Their production or experimental consumers are concrete. Large evidence directories are not
intrinsically poor reviewability: the meaningful source changes and evidence obligations can be
separated, and manifest/provenance tests bind the latter. PR count and file count do not determine
design quality.

The native topology is enabling work rather than a runnable foundation. Its release/alignment and
scanner checks have value even before a native executable exists, provided that boundary stays
explicit. The retained host wrapper also has value as a calibrated Svelte control and evidence
runner. It is not wasted because it does not yet contain React; neither can it be accepted as the
planned React-host unit. The source receipt's eligibility for review is not a passing runtime or
acceptance verdict.

Unfinished work is incorporated cleanly in principle: retained changes have a source commit and
bundle; native source has a copied snapshot and provenance. The private React packet has concrete
sources, dispositions and semantic composition records, but still needs integration onto the
accepted topology/Netlify/version base. Its separate temporary-directory preservation is weaker than
the committed/bundled retained unit; this audit copied it without changing the original. Authored
controls in that packet remain unrun. There are concrete remaining obligations, not a vague “finish
migration.” The private retained CI proposal has no numeric timeout and authored-but-unexecuted
fixtures; it should stay pending. The native registration/current checker must be composed and
actually tested before claiming its next unit. Source validation borrowed from another checkout
cannot substitute for validating that unit's own installed SDK graph.

The prepared React sources also show concrete ownership choices: captured/cancelled asynchronous
island mounting, React confined to an inner boundary without the drawing canvas, per-binding
bridge/modal/refusal lifetimes, and reuse of existing modal/Settings owners. Independent passive
inspection found all 53 prepared files consistent with their receipt and the nine UI files equal to
the selected latest packet. Nested disposal and failed-artifact refusal address real review
findings. These are strong source decisions, with hydration, recovery, route and dialog behavior
still awaiting execution; the addendum gives exact private-file locations.

Maintainability is generally good in the inspected product changes: finite types, small policy
owners, existing state writers, fresh counter factories, contained errors, truthful names,
diagnostic scope and dependency direction. Tooling is more substantial and version-specific,
reflecting real platform/install hazards. That is justified assurance until shown otherwise, but it
needs the ownership/retirement treatment in F5. Convention compliance supports these choices; the
practical benefit is avoiding duplicated policy, accidental side effects and future update traps.

## Recommended next increments, upon separate authorization to resume

1. **Close the current local controls and candidate-source boundary.** Fix F1 with the
   reachable-module negative control. Finish retained CI integration, final-source checks and
   original-review continuation; update the live ledger. Keep the whole-output comparison's narrow
   normalization and source/run bindings. This resolves whether the present control/tooling unit is
   safely extensible and independently accepted.
2. **Accept the minimum native source/toolchain unit, then compile and mount both optimized
   candidates.** Compose actual registration and topology, materialize from reviewed sources, verify
   installed SDK identities/locks/floors/permissions and actual runtime flags. Use static graphics
   only for geometry/output and mechanics. This resolves whether the released native stack is
   operable; it confers no fidelity or performance verdict.
3. **Refresh shipping attribution and calibrate the common outcome, with ranges registered first.**
   Use ordinary PERF_MARKS/A0 controls, observer negative controls and exact-source physical
   captures. Record coarse maintenance ranges and uncertainty before remedies/comparisons. If
   hardware is unavailable, continue only the allowed isolated mechanics; do not replace this with
   simulator timing. This resolves whether the motivating costs remain, which mechanisms matter, and
   whether comparative evidence can be trusted.
4. **Prove early continuity, service feasibility and command ordering before deep renderer work.**
   Same-ID legacy reads, applicable held pictures/pack jobs, minimal audio and one delayed export
   plus page/undo transaction should be separately reviewable slices. This resolves whether a fast
   renderer could still preserve the installed product and its transactional behavior.
5. **Exercise the real React host and shared vocabularies, then faithful native paper/screen
   mechanisms.** Use consequential interaction/adaptation cases and actual native vocabulary builds.
   Witness React recovery while exact paper output/history survives; validate deployed
   host/security/PWA ownership and resolve the actual release-budget disposition before eligibility.
   Preserve complete crayon/Magic/history/audio requirements before matched RN-versus-hybrid
   mechanisms. This resolves ownership/adapter burden and the causal architecture question without
   substituting a minimal graphics demo for fidelity.

These recommendations reinforce the existing sequence, with the new guard correction and explicit
tooling ownership. They are optimized for correctness and a maintainable final product, not fewer
reviews or cheaper validation. The next architectural decision should remain conditional until those
uncertainties are resolved. If the calibrated evidence favors retention or a production hybrid,
choose it without treating prior migration effort as a reason to proceed.

**Recommendation: continue the current investigation with the specified corrections; do not yet
select RN, RNW/RSD or a cutover. Leave the migration paused pending the user's separate
instruction.**
