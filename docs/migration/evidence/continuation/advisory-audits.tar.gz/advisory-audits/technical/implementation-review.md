# Migration implementation review at the pause

Cutoff: 2026-10-06 12:39 UTC. This is an independent read-only review of implementation and maintained proof machinery. It does not reopen campaign execution or certify the proposed architecture.

## Assessment

The merged units and retained local slice are credible enabling work. They generally give each owner a real caller, preserve the existing product, reject ambiguous inputs, and distinguish source/topology/build observations from acceptance. I found no established current shipping behavior regression in the inspected changes. One dependency guard has a verified latent coverage hole; a smaller progress-documentation inconsistency should be corrected before resumption. The many unexecuted native, continuity, platform, and physical-performance gates remain validation gaps, not demonstrated implementation defects.

The code has accumulated substantial maintenance machinery, particularly around Netlify production installation, exact package/source qualification, and isolated retained builds. Much of that complexity is justified by observed failures and strict evidence requirements. Its future upgrade and retirement cost should remain explicit; passing the current fixtures does not make these permanent platform contracts.

## Revisions and method

- Integration was clean at dc08a90abc67b53124146bf288c80de0f9ffd1dd in `/Users/kylemit/Code/Splotch`.
- Retained local worktree was clean at 8ddfc04053ccdf285c2f6fd7c2b75e745a9d2fc6 in `/Users/kylemit/.codex/worktrees/migration-retained-web/Splotch`.
- Native local worktree has base dc08a90abc67b53124146bf288c80de0f9ffd1dd plus the preserved uncommitted source slice. All 70 preserved files under `logs/migration-pause-2026-10-06/native/uncommitted-source` matched the inspected worktree byte for byte. Findings about that work use the paused file paths, not an invented source commit.

I read root agent instructions; architecture, ADR, testing and mobile skills; the migration README, CONTRACT, PHASE-1, ACCEPTANCE, WEB-CONTRACT, UPGRADES and BASELINE; and the defaults, Magic witness, dependency-health, topology and candidate-source records. I inspected representative unit diffs and all designated implementation boundaries: portable defaults/facades; native topology/import ownership; package and bundler configuration; installed/archive qualification and Forge mitigation; production installation/runtime configuration; retained copying, ownership, child execution, emitted comparison, receipts and browser controls; native template intake, transformations, provenance, identity, signing and Apple scene ownership.

I ran only small isolated Node/type-check counterexamples and read-only source/provenance checks. I did not run host suites, builds, native devices, installs, Git mutations, deployment or GitHub writes. The root review separately owns exact-head CI and transcript verification. Statements below about recorded campaign execution are bounded by the pause packet and source records, not a fresh rerun of the campaign.

## Material findings

### F1 — Candidate dependency guard misses local modules reached from the real entry

Priority: P2 before expanding native candidate source. Classification: established guard defect, latent product consequence.

**Challenged implementation:** `assertDeclaredCandidateImports` is used as a candidate declaration boundary, but only scans five fixed files. It discards local specifiers without traversing them. At integration dc08a90abc67b53124146bf288c80de0f9ffd1dd, the list is `tools/migration/lib/native-identity.mjs:8-14`, the loop is `:82-94`, and `check-native-topology.mjs:39` invokes it. The actual topology checker also runs candidate TypeScript at `:65-70`, but type checking resolves undeclared packages available in the root hoisted installation.

**Counterexample:** Preserve all five existing scanner inputs and the real candidate package/TypeScript config in a temporary fixture. The unmodified guard passes. An entry-file `import { parse } from 'yaml'` is rejected with `src/index.ts imports undeclared yaml`. Replace that direct import with `import './Extra'`; let `src/Extra.ts` contain `import { parse } from 'yaml'; parse('x: 1');`. The real guard passes although the candidate manifest does not declare `yaml`. The actual candidate `tsc --project ... --noEmit`, using the retained installed dependency tree, also exits 0. The root declares `yaml` for its own tooling, so that borrowed availability is the mechanism, not a hypothetical missing package.

The exact reproducer and output are preserved in [implementation-import-boundary.mjs](implementation-import-boundary.mjs) and [implementation-import-boundary.json](implementation-import-boundary.json). The result records both tested HEADs and scanner SHA256 `2a591f2c8ca45be03a06c31a3c379ff74a87cb20195eddb4992ce52e58295825`. No campaign source was changed. Audit fixtures were moved into `implementation-scratch/` after execution; the JSON keeps the original execution path and separately records the preserved path. Future reproducer runs create scratch directly in this audit directory.

**Consequence and uncertainty:** A new native-owned helper can use a root-only package while this declaration check and TypeScript remain green. Future source expansion can therefore become dependent on hoisting or a development-only package without an explicit candidate owner. This is not evidence that the current two application sources already contain an undeclared dependency, nor that a current native build leaks one. I did not rerun the whole topology checker or full Quality suite against a mutated repository; the established result is the real declaration guard plus the actual type checker. Source tracing shows that other topology checks focus on manifests, lock artifacts, package identities, configuration and shipping imports, while the transform smoke owns `ProbeApp`; they do not expand this scanner into an entry dependency closure. The configured `lint:dead` includes files/exports/types/duplicates, not an unlisted-dependency gate.

**Proportionate correction:** Enumerate maintained candidate source/config files, or walk the real entry/config local dependency closure with supported extensions and contained paths. Check external specifiers in every reached file, including literal dynamic import/require cases already recognized by the parser. Add a negative control with a real entry importing a local helper that imports a root-only package, alongside a declared-package positive control. Do this in a reviewed source-expansion unit rather than weakening the present production boundary.

### F2 — Durable progress records lag the paused executable evidence

Priority: P3. Classification: established documentation inconsistency; no inflated product acceptance.

At retained 8ddfc04053ccdf285c2f6fd7c2b75e745a9d2fc6, `migration/probes/web-host/README.md:11-12` states that no install, build or browser run has been performed for this slice. Lines 34-38 still describe complete emitted comparison, source/startup checks and discovery registration as unexercised. The pause packet instead records real successful public calls, release/mechanism builds and browser runs at the retained source, and the source includes discovery registration. CI proposal integration and final review/acceptance are still pending, so those parts should remain pending.

The central `docs/migration/README.md:70-84` promises an update in each reviewed unit but omits the merged native topology and its production version/install repairs. Its phase rows remain broadly correct; the omission understates completed enabling work.

**Consequence:** A resuming owner can mistake the tested source for an unexecuted proposal, redo work, or confuse local proof completion with pending reviewed acceptance. The detailed pause packet prevents evidence loss, so this is a continuity/maintainability issue rather than a campaign completion claim.

**Proportionate correction:** Refresh the retained readme and central ledger on resumption with the exact tested source/evidence paths and a distinct local-tested/review-pending state. Preserve the deferred React/PWA/native/performance acceptance gates.

## Unit assessment

| Unit | Concrete purpose and caller | Implementation assessment and boundary |
| --- | --- | --- |
| PR 2691, merge d3d4203539143584bc1af96e7652fc7f39f3382b | Canonical migration/product/upgrade/acceptance contract | Useful durable decomposition. It is a reviewed proposal and baseline inventory; it does not implement or select a renderer. |
| PR 2692, merge 1ceb97338eced2b280964a5a2257ce4933c489d6 | Repair external `source-map-js` dependency graph used by the existing build | Narrow maintenance unblock. The separately embedded residual is documented and bounded rather than silently counted as repaired. Exact current CI/audit interpretation belongs to the root evidence review. |
| PR 2693, merge d2e77431c4a06bcdea7fe33611a28edd43e8ada2 | Plain stroke/default owners consumed by current drawing engine, state facades and Node replay/generator tools | Good extraction with real production/tool callers, a finite `StrokeSize`, one width/eraser policy and preserved state persistence. This makes defaults portable; it does not make the Svelte drawing engine or all state portable. |
| PR 2694, merge d1402f6b2bedd2c30cbc88d30597466855b33874 | Reviewed Phase 1 sequence and exits | Plans executable partitions and explicit causal/physical gates. No evidence of disguising agreement or a structural source proof as a runtime result. |
| PR 2695, merge e5ab28af553a55841aac35c938fc7b0e19ec9ba7 | PERF-only Magic branch/worker/recode observation through actual brush/worker/engine callers | Distinct cause/origin/outcome counters and diagnostic spans are useful for attribution. Instrumentation is compile-gated and reads are contained. Physical attribution and observer invariance/overhead in scored activity remain separate exits. |
| PR 2698, merge 5ccf8cb1475ba945235bada82c96458a223ccc06 | Repair build version ownership exposed by the production dependency partition | Correctly routes production build metadata through the existing owner rather than inventing a candidate version. Representative implementation 7f090b6fccafdc9d383e2cab8f97c5492c496a60. |
| PR 2699, merge cbb104976d0840611dff7f5188b9b8712050fe6a | Qualify and repair real Netlify production installation | Actual root Netlify command calls the guarded installer. This fixes a real integration boundary and carries a recurring deployment maintenance cost described below. |
| PR 2697, merge dc08a90abc67b53124146bf288c80de0f9ffd1dd | Candidate-only Expo/React Native/renderer dependency alignment, package identity/configuration, topology CI and bounded package mitigation | Real entry, transform and type-check owners; deliberate development-only graph and production closure guards. Live lock/config checks are distinguished from immutable historical receipts. F1 limits import declaration coverage. No native compile/mount is established. |
| Retained local 8ddfc04053ccdf285c2f6fd7c2b75e745a9d2fc6 | Exercise actual unchanged SvelteKit host through isolated copies and actual retained lifecycle owners | Strong local structural control with narrow byte normalization, graph receipts and owned processes/caches. Public-call/build/browser evidence exists; reviewed acceptance and final CI integration remain pending. No React island exists in this unit. |
| Paused uncommitted native slice | Reviewable template intake and maintained Android/iOS source with distinct probe identity and source guard | Provenance and source contracts are concrete; exact source checks pass with the audit adapter. It remains uncommitted and does not prove installed native bindings, optimized compilation or device mount. |

## High-risk boundaries checked

### Portable state, types and failure conventions

There is no `packages/shared-state` directory or public shared-state API at these paused revisions. The implemented seam is the plain default/palette ownership plus Svelte facades. Likewise, UPGRADES specifies continuity but there is no implemented continuity parser to audit. Neither absence is a defect at this stage. They remain implementation and acceptance work; future claims must not cite this defaults extraction as proof of storage/history/upgrade equivalence.

The implemented finite types in defaults and diagnostic causes/outcomes avoid broad strings. The retained callers reject malformed or drifting ownership/configuration and record nonzero child exits rather than accepting log phrases. Native manifest/intake checks fail at explicit trust boundaries. I did not identify a new mixed failure convention causing a current production caller to ignore a failure in the reviewed changes.

### Retained host output comparison and bundler direction

The suspected broad filtering issue was not established. `web-host-comparison.mjs:5-10` only normalizes the exact owned-copy absolute prefix and actual recorded app-shell URL, after a lossless UTF-8 round-trip. Binary bytes do not receive text filtering. It checks file kinds, modes and link targets before comparing contents; it records each normalized path/hash and explicitly keeps build time pinned rather than normalizing timestamps.

The apparent asymmetry of iterating the reference inventory is covered by the actual caller: `web-host-evidence.mjs:116-130` checks complete output path inventories, startup/lazy measures, version and host-source equality, and `:141-146` performs that shape check before the byte comparison. An extra emitted control file cannot pass by merely being absent from the comparison loop. Module receipts are separately validated. These proofs establish the retained wrapper's structural equality for exercised builds; they do not prove every deployed header, browser-floor behavior or future React bundle.

The wrapper imports the retained host configuration rather than maintaining an alternate route tree. Copy inventories bind file kinds/modes/symlinks and hashes; source and dependency ownership are rechecked across lifecycle stages. Fresh UUID browser cache/result folders preserve each invocation and prevent stale run substitution. The exact topology/lock pins are strict intentionally; a future dependency or React-caller unit needs a reviewed requalification rather than relaxed hashes.

The browser controls establish early retained ink and subsequent adoption of the same canvas in the exercised Chromium cases, including a held hydration request in the mechanism control. They are appropriately small enabling controls. They do not establish React recovery, persistence/undo after complex handover, deployed PWA updating/offline operation, compatibility floors or physical performance.

### Native intake and current topology validity

The native maintained source inventory, per-member hashes/modes, omissions, template/license ownership and transformation replay are concrete. The reader rejects unowned additional maintained files and changed bytes; path containment and symlink rejection make the provenance boundary meaningful. The approved archive intake verifies integrity/member inventory and does not run template/native scripts. Offline checking intentionally relies on the reviewed metadata/manifest/recipes; it is not an independent fresh registry attestation.

The probe identity is `art.splotch.migration.probe`, separate from shipping `art.splotch.app`. Android Release requires named external signing inputs and optimized release settings; it rejects debug signing/JSC routes. SDK/Gradle/wrapper ownership is explicit. The iOS scene repair removes duplicate legacy startup and adopts the actual Expo scene/factory lifecycle owner; it checks the default module rather than fabricating a second scene owner.

A focused read-only check validated all 45 maintained native files and source contracts against the paused input manifest. Inspecting installed Expo 57.0.26 from the retained donor verified all three recorded scene-source hashes and its default `main` module. Reproducer and result are [implementation-native-source-check.mjs](implementation-native-source-check.mjs) and [implementation-native-source-check.json](implementation-native-source-check.json). The native checkout has no installed dependencies, so the audit explicitly adapted only `tar` resolution to integration and inspected Expo in the retained checkout. This does not certify a native candidate installed tree, topology reinstallation, compile or mount. A direct unadapted source checker cannot currently resolve `tar`; that environment state is not evidence of a source defect.

The source reader's exact template-origin file set is an excellent intake fence. Before hand-authored native collectors/services are added, the unit must define their maintained extension ownership or deliberately extend reviewed recipes/provenance. Simply allowing arbitrary new files would erase the useful source boundary.

### Fragile agreement, configuration and temporary tooling

The topology checks sensibly distinguish immutable historical evidence from live lock/workspace/installed package checks. A reviewed package allowlist, direct versions and mitigation source bodies are conservative intentionally. The bounded Forge workaround has a documented later owner instead of an unqualified claim that every embedded copy has vanished. Most injected child/record controls are declared fixture seams with actual production callers, not unused product configuration.

The remaining weakness is F1: the import boundary is a hand-maintained five-file list without a closure or maintained-source enumeration. That is exactly the kind of agreement that becomes fragile when source expansion is the next task.

The Netlify repair is a permanent production owner at the pause: root `netlify.toml:16` invokes `tools/netlify-production-install.mjs` before every build. The installer qualifies pnpm 11.22.0 (`:14`), manifests/workspace/lock and candidate ownership, live runtime/config, exact production module metadata (`:287-310`) and a second actual `pnpm ci --prod` (`:313-342`). It rejects unsupported ambient hooks/configuration instead of hiding them. `tools/lib/netlify-cache-config.mjs:18-29` owns specific Netlify cache/home/store families. Those constraints and fixtures are proportionate to the observed warm-cache boundary; no current deployment regression was demonstrated in this review.

The recurring cost is nevertheless real: a pnpm/store-layout change, Netlify image/cache-family change, candidate retirement, or intentional future production React dependency requires explicit requalification and coordinated guard/test/config updates. The present production baseline intentionally excludes the candidate; the React-host unit must consciously change that boundary when a real caller needs it. Keep a named upgrade/retirement owner for this installer and the topology/proof workflow. Retire proof-only source pins and candidate-only owners at their actual exit, while retaining any production cache repair still needed. Code size or install duration alone is not a reason to remove this protection.

## Remaining acceptance

The paused work supports progress into the next reviewable enabling units. It does not select the final architecture or satisfy whole-product acceptance. Concrete private React25/Web30 source preparation also exists; see [the source-only addendum](implementation-react-preparation-addendum.md). It was not integrated or executed at the pause.

- Retained slice: integrate the concrete CI proposal/timeouts, complete the applicable final checks, resume the existing independent review round with its context, create/review the actual PR and validate its exact final head before claiming accepted/merged status. Preserve current successful local evidence separately.
- Native slice: commit/review the source intake, establish fresh candidate installed-tree/topology qualification, then execute optimized Android/iOS builds and actual mounts through owned caches/processes/signing inputs. SDK binding, scene/link/lifecycle behavior and graphics-service ownership require runtime evidence.
- Neutral/React host: integrate and execute the prepared private browser/SSR source through its reviewed owners, then complete bundle direction, hydration/recovery and browser-floor/CSP/PWA/header/offline gates. Structural equality of the retained control alone cannot pass them.
- Shared behavior and upgrades: implement the portable behavior/state APIs and a strict continuity parser/transport; prove real previous-version storage/origin/application identity, history/default/export behavior and secure/native storage on the applicable targets.
- Candidate decision: execute matched physical controls, calibrated canonical work and causal mechanism/invariance checks, including Magic attribution. Compare against the complete acceptance inventory and account for recurring maintenance/runtime costs before selection.

These are declared future exits, not bugs inferred from the absence of an implementation. The strongest work here is the discipline of keeping those exits distinct from topology, source and retained-control receipts.
