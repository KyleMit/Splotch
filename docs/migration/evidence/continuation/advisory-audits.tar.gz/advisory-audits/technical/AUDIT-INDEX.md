# Audit evidence index

The main judgment report is
[REPORT.md](/Users/kylemit/Code/Splotch/logs/migration-progress-review-01a10e92/REPORT.md). The
campaign interval ends at parent raw L17527, 2026-10-06T12:40:02.782Z. Audit-prompt preparation
after that record is excluded. The migration remains paused.

## Judgment and factual records

* `architecture-review.md`, `implementation-review.md`, `validation-review.md` and
  `implementation-react-preparation-addendum.md` are independent specialist judgments, reconciled in
  the main report.
* `2026-10-05-01a10e92-parent-facts.md` is factual extraction from the complete in-scope parent
  skeleton with raw drills. Its separate one-off-scripts and failures appendices preserve exact
  scripts and nested outcomes. Recommendations belong to the judgment reports, not those factual
  reports.
* `2026-10-05-01a10e92-linked-session-inventory.{md,json}` locates actual Claude/Codex records from
  parent references and retained streams. The shorter `linked-session-inventory.json` is an earlier
  retrieval aid; use the dated final inventory for complete counts.
* `parent-skeleton.md`, `claude-skeletons/`, `claude-stream-skeletons/` and their indexes are
  provider-specific retrieval aids. Consequential claims were checked against raw records. Detailed
  review is selective across linked Claude sessions; five official Claude files are absent, with
  retained streams available.
* `linked-codex/2026-10-06-01a11129-native-static-implementation.md` and its skeleton/scratch
  establish authenticated native source intake and Git checks, with no candidate validation
  execution. Encrypted delegated/message bodies are documented as unavailable.
* `github-pr-metadata.json` and `github-ci-and-reviews.json` preserve native GitHub-tool reads for
  exact identities, merge states, CI jobs and reviews. No GitHub writes were performed.

## Audit-only checks and copies

* `implementation-import-boundary.mjs/.json` preserve the fixed-file declaration-guard
  counterexample, direct-import rejection, restored baseline and actual candidate TypeScript
  resolution. `implementation-scratch/` and its relocation record preserve fixtures. Their
  dependency symlinks borrow existing local installations; dependencies are not bundled in this
  evidence directory.
* `implementation-native-source-check.mjs/.json` preserve a source/provenance replay using a
  qualified donor parser/Expo installation. This is an audit result, not a campaign test at the
  pause or a candidate native compilation.
* `implementation-react-source-inspection.json` records passive receipt/hash/mode checks for 53
  private prepared files and selected UI-source equality.
* `private-react-source-snapshot/` and `.json` copy all 185 files from the private 53-source React
  semantic-merge packet, including frozen inputs and receipts. Originals were unchanged. This copy
  was made by the audit and was not part of the campaign pause backup; no candidate code in it was
  executed.
* `audit-manifest.json` records file hashes/sizes and borrowed symlink targets for this output
  directory. It does not turn receipts into acceptance or make external dependencies portable.

No campaign source, existing evidence, branches or agent instructions were modified. No new
installation, full suite, native compilation, simulator/device capture, deployment, merge, push or
external comment was performed. All audit outputs are local under the user-requested directory.
