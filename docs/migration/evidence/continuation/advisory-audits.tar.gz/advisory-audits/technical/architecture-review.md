# Independent architecture review through the migration pause

Verdict: **continue the current direction as a conditional investigation, with the existing evidence gates preserved.** The architecture reasoning at the pause is materially stronger than the initial RN/RNW recommendation. The foundations are coherent and bounded. They have not selected React Native, a shared web vocabulary, a renderer, or a production host, and they do not yet establish a native performance or continuity benefit.

Confidence is high about the current contracts, code boundaries, and historical native baseline arithmetic; moderate about historical causal attribution because the cited raw system traces are absent from this checkout. Confidence about candidate runtime behavior is deliberately low: no native candidate has compiled or mounted. I found no verified architectural correctness defect in the accepted foundations. The principal issues below are unresolved assumptions and evidence boundaries, not claims that the paused work is broken.

## Scope and method

Inspected the clean integration checkout at dc08a90abc67b53124146bf288c80de0f9ffd1dd, retained-control checkout at 8ddfc04053ccdf285c2f6fd7c2b75e745a9d2fc6, and uncommitted native-source checkout based on the integration revision. Read repository instructions; architecture, adrs, mobile, testing, profiling, and transcript-analysis skills; migration README/CONTRACT/PHASE-1/ACCEPTANCE/WEB-CONTRACT/UPGRADES/BASELINE; relevant ADRs; and representative boundary implementations.

The root reviewer owns whole-transcript coverage, review dispositions, exact CI acceptance, and the detailed execution inventory. This specialist consulted targeted parent-skeleton passages and drilled raw parent records L298 and L321, rather than claiming complete independent transcript coverage. The authoritative parent rollout is `/Users/kylemit/.codex/sessions/2026/10/05/rollout-2026-10-05T20-17-33-01a10e92-a1ac-7610-a4f0-3769ecfd495c.jsonl`. Subsequent audit preparation is excluded.

No campaign source, branches, original evidence, instructions, installations, device state, or hosted state was changed. The only executable audit check was pure, in-memory normalization of existing performance artifacts. No native or performance capture was run. This report is an audit artifact.

## Verified native baseline

At the integration revision, `scrapbook/performance/2026-07-31-deployment-target-matrix/data.json` and its `sources.json` produce the following counts:

| Target | Drawing | Undo | Actions including idle | Actions excluding idle | Failed action cells |
| --- | --- | --- | --- | --- | --- |
| Physical iPad Capacitor | 16/16 pass | 4/4 pass | 197/222 pass | 193/218 pass | 25 |
| Physical Android Capacitor | 16/16 pass | 4/4 pass | 192/196 pass | 188/192 pass | 4 |

Per-mode iPad action counts are 48/55, 49/55, 50/56, 50/56; Android counts are 54/56, 55/56, 41/42, 42/42. All native drawing aggregates and action sections are scoreable under the current normalization owners. The generated `physical-native-advisory` label does not overturn those per-run verdicts or the physical release policy.

I resolved all 48 native drawing/undo/action manifest references through `index.capturedFrom + kept.source` to 40 distinct present raw files, requiring unique index resolution and the index product commit to match the source declaration. Using those paths, the existing `normalizeMatrix` function in `tools/perf/gen-performance-matrix.mjs:1512` reproduced every native drawing/undo pass and the identical 25/4 failed action labels without writing a generated report. Independently applying `summarizeUndoActions` to the eight raw pen captures' `undoActions` reproduced their passes: each contains ten undo actions and all next-frame values are present.

The applicable retained indexes are `perf-profiles/evidence/2026-09-23-matrix-ipad-device-native-3928/index.json`, `2026-09-23-matrix-android-device-native-3928/index.json`, `2026-09-23-issue-2212-ipad-native-landscape-actions/index.json`, and `2026-09-26-issue-2340-android-device-native-actions/index.json`. Drawing/undo source is 3928cd88edbf441530e473a4e3c0b6767926bfc6; iPad portrait actions use that revision, landscape actions use d50d73927f1835bbe231d1c2450f49fbe5803f53; Android actions use b453e90c525b290b55d8ef431c583ea09f335bbd. Raw payloads do not uniformly carry a product SHA themselves; the source/index binding supplies that provenance. This is historical instrument evidence, not a capture of the campaign head or optimized native candidate.

The iPad reds are Magic selection, both theme directions, coloring page selection and clearing, and AI waiting in all modes, plus sound enable in portrait/light. Android reds are empty landscape-to-portrait rotation in portrait/light and landscape/light, with-ink landscape-to-portrait rotation in portrait/light, and dark-to-light theme in portrait/dark.

Causal attribution is narrower than those counts:

* The Android 9.5–14.7 ms style-recalculation evidence is web. `perf-profiles/evidence/2026-09-06-issue-1696-android-night-toggle/index.json` labels each retained artifact `android-device-web`; all four raw action payloads use `transport: android-chrome-cdp`. The source analysis `docs/scratchpad/perf/2026-09-06-issue-1696-night-toggle-attribution.md:16` and `:38` records a 26–39 ms input task, 9–12 ms dispatch, and 9.5–14.7 ms style work. Its cited original trace JSON files are absent locally, so I verified runtime provenance, not the trace calculation independently.
* The iPad page-selection attribution is Safari. The retained landscape-retirement control payloads explicitly record `captureRuntime: ios-safari`. `docs/scratchpad/perf/2026-09-05-epic-1567-resumed-campaign.md:26` scopes all selection figures to physical Safari; `:73` describes the clock join and one correlated 29 ms frame. GPU and WebContent samples are concurrent, not additive wall time. Raw Instruments traces/exports are not present here.
* ADR-0085 `:14–19` establishes at-most-2-ms draw calls in one historical drawing baseline. Its gesture-start amendment at `:643–660` also records later 123–127 ms first-draw work from suspended audio resume. Thus the broad proposition that the whole app's JS always finishes in about 2 ms is false. Current native action causes still need measurement.

These distinctions agree with BASELINE `:120–150`, PHASE-1 `:36–39`, and CONTRACT `:53–67`; the reviewed plan does not currently misuse the historical web traces as native causal proof.

## What the foundations establish

| Area | Observed state | Architectural judgment | Remaining acceptance |
| --- | --- | --- | --- |
| Contracts and alternatives | Reviewed requirements exist; architecture remains conditional | Strong separation of product obligations from framework hypotheses | Current control/observer and candidate evidence, final selection ADR |
| Portable drawing defaults | Plain `strokeSettings.ts` owns width vocabulary; real Svelte and Node callers use it | A useful small shared-owner extraction, without speculative interface growth | Further portable behavior extraction only as actual native consumers need it |
| Native package topology | Private Expo/RN member, one root lock, exact direct alignment, live import/production/scanner guards | Candidate-specific coupling is contained; hoisting is explicitly acknowledged rather than called strict isolation | Native projects, compiled optimized binaries, floor/runtime/native-module proof |
| Hosted boundary | SvelteKit/Netlify retain APIs/admin/information; proof and live topology checks have separate owners | Avoids a simultaneous server rewrite and historical-hash coupling to every future PR | Actual chosen shared-product host, deployed CSP/history/PWA integration |
| Retained host control | Local retained Svelte wrapper and build/browser evidence tooling; no React host | Useful calibration/control partition; cannot prove the planned React boundary | Remaining unit review/CI integration, then actual React SSR/adoption/recovery and web vocabulary |
| Native sources | Uncommitted maintained Android/iOS template provenance and source contracts | Prepared mechanics only; legitimate to proceed while hardware is absent | Source acceptance, SDK/materialization, optimized Android/iOS compile/mount |
| Persistence/services | Detailed source-specific continuity inventory; no replacement import accepted | Correctly treats installed data access as a foundation question | Disposable same-ID reader proof, then transactional and signed-channel upgrade matrix |
| Drawing/UI/performance | Existing product retained; no production ownership moved | Reversible investigation preserves the option to retain or choose a hybrid | Complete faithful drawing/screen, calibrated matched mechanisms, then whole-product tuning |

Exact integration anchors: `tools/migration/check-native-topology.mjs:31–80` composes manifest, archive, production/import, actual identity/scanner, TypeScript and transform checks and labels their scope; `tools/migration/lib/topology-policy.mjs:65–84` prevents candidate-only names entering the shipping production graph; `tools/migration/lib/native-config.mjs:196–199` refuses to describe source trees as native integration proof. `docs/adrs/0119-pnpm-as-package-manager.md` explicitly acknowledges forfeited strict hoisted isolation and manual SDK update obligations. `tools/migration/README.md:3–13` separates live gates from historical exact evidence.

The portable change is not a portable-engine claim: `web/src/lib/drawing/engine.ts:15–21` still imports Kit, rune appearance, coloring state and tool types; RENDERER-DEFAULTS `:10–12` states that limit. Preserving those owners until a real extraction is preferable to inventing a broad cross-platform engine interface before its native caller exists.

At retained revision 8ddfc04053ccdf285c2f6fd7c2b75e745a9d2fc6, `migration/probes/web-host/host/vite.config.ts:93–97` imports/merges the unchanged retained Vite configuration. It adds a receipt plugin, not React ownership. The unit README's earlier prepared-only statement is stale relative to the local pause evidence, but neither that statement nor the observed successful control runs can establish React hydration/recovery, deployed worker scope, or a selected host. Root is verifying the local run/acceptance inventory separately.

At the native uncommitted snapshot, `experiments/native-architecture/NATIVE-SOURCES.md` expressly distinguishes maintained source checks from installed SDKs, compile, mount and presentation; candidate identity is `art.splotch.migration.probe`, separate from shipping identity. Pinning API24/iOS16.4 source settings is not proof every installed dependency or artifact honors them.

## Material assessments and next tests

### 1. The original categorical recommendation outran the causal evidence; the reviewed contract corrects it

**Challenged claim:** that browser-rendering evidence already supports selecting full RN plus RNW as the destination, rather than establishing a credible candidate.

**Anchor:** raw parent L321, 2026-10-06T01:58:44.509Z, endorsed full RN/RNW and production-replacement stages after user L298, 01:57:15.497Z, rejected a naive proof-of-concept verdict. Historical baseline and runtime-specific attribution above are the primary counterweight. Current CONTRACT `:84–121` and `:123–162` explicitly require fair native/hybrid checks and separate vocabulary costs.

**Established:** the initial recommendation was stronger than available causal evidence; later requirements restore conditional selection. No candidate has demonstrated removal of the current native action cost. **Inference:** native rendering may bypass relevant WebView surface or surrounding-UI mechanisms, but benefits cannot be predicted from framework identity or fast browser JS.

**Why it matters:** a missing bottleneck can produce a faithful, expensive replacement without the intended benefit; a native surface can retain attachment-area, upload, synchronization and layer costs. Conversely, demanding a polished complete-product verdict from a rough sparse demo would reject a viable architecture unfairly.

**Correction/next test:** preserve the current contract. Refresh the motivating native action families; establish a common visible/readiness observer; run matched complete drawing-screen mechanisms for RN and native-paper-in-Capacitor with the declared prior journey and bounded tuning. Treat this as foundation feasibility/mechanism evidence, retaining final whole-app tuning and performance acceptance later. Do not count errors removed in place as RN improvement.

### 2. Shared UI maintenance savings remain a distinct unproved hypothesis

**Challenged claim:** that RNW or RSD materially reduces recurring ownership for this existing one-UI product merely by sharing component code.

**Anchor:** CONTRACT `:15–36`, `:130–162`; WEB-CONTRACT `:132–165`; PHASE-1 `:141–148`; the current native caller `experiments/native-architecture/src/ProbeApp.tsx:1–9` contains only View/Text, while the retained control has no React host.

**Established:** neither web vocabulary has been selected or exercised here; shipping Svelte/Capacitor already shares one product UI. The plan correctly recognizes web adapter/startup costs and requires the actual vocabulary's native build. **Inference:** shared components can reduce duplicated visual work if RN mobile is selected, but platform adapters can consume that saving or preserve two behavioral owners.

**Why it matters:** preserving HTML dialog focus/Back, Settings reading enlargement, palette drag, theme first paint and early ink involves real platform semantics, not just replacing tags. Current official [RSD HTML compatibility](https://react.github.io/react-strict-dom/api/html/) documents limited native layout and unsupported native dialog/form/checkbox/select/SVG surfaces. [RNW](https://necolas.github.io/react-native-web/docs/) is a compatibility layer using React DOM; its [styling rules](https://necolas.github.io/react-native-web/docs/styling/) impose native-oriented inheritance. These are reasons to measure concrete adapters, not grounds for rejecting either framework in advance.

**Correction/next test:** in the already planned paired vocabulary unit, use a high-risk actual slice: palette drag/selection, a Settings toggle and reading content, and a real modal with focus/Back. Demonstrate it in web and each vocabulary's native build, naming required adapters and owners. Retained paper remains outside React roots; actually trigger unrelated hydration recovery and prove identity, pixels and history survive. Measure the entire deployed host startup graph, including retained Svelte. A button demo or raw-RN native fixture cannot select the vocabulary.

### 3. Native-paper ownership and legacy-origin access are selection-critical, not late release chores

**Challenged claim:** that compiling native graphics or matching app ID makes the candidate structurally viable for the current installed product.

**Anchor:** CONTRACT `:103–105`, `:154–162`; PHASE-1 `:113–130` and `:149–157`; UPGRADES `:14–23`, `:77–127` and its transaction/keychain/download sections. Actual v1.6.0 `storage.ts` has synchronous local writes plus unawaited mirroring and leaves live local values authoritative when both layers exist.

**Established:** no candidate read/import path or native command transaction is accepted. The inventory recognizes live localStorage versus stale Preferences, source-version secure accessibility, held pictures only in applicable sources, installation grants, and persistent background jobs. **Inference:** a narrow legacy WebView reader and reused native service cores are plausible, but origin/profile, signing/access-group and class/session identities can defeat an otherwise correct rewrite.

**Why it matters:** losing the live origin or importing only Preferences silently rolls settings back; secure read failure cannot mean absent credential; replacing worker/session identities can orphan downloads. Async paper work plus native UI commands can capture or clear the wrong epoch even when geometry and callbacks look correct.

**Correction/next test:** retain the early disposable same-ID read-only feasibility unit and the early export/page-plus-undo delayed-work transactions. Do not promote probe-ID installs, clean installs, source hashes or simulator mechanics into signed upgrade evidence. Follow with real supported-source/channel upgrades after feasibility. No reason is established to discard the inventory or rewrite every native implementation.

### 4. Recurring burden must include the actual tooling added by the candidate

**Challenged claim:** that a smaller apparent framework or tool count establishes a maintenance win.

**Anchor:** ADR-0119's native-member amendment; accepted `tools/netlify-production-install.mjs`, `tools/lib/netlify-cache-config.mjs`, Forge patch/guard and manual SDK policy; CONTRACT `:130–152` and PHASE-1 `:55–56`.

**Established:** candidate work adds SDK alignment, archive/provenance checks, a guarded local dependency repair, workspace-production install handling and native dependency/build ownership. The live-versus-historical split avoids freezing all subsequent development to a proof's hashes. I did not find registered concrete burden ranges in migration documents beyond the requirement to register them; candidate comparisons/remedies have not occurred, so that is not currently a violation. **Inference:** some tooling may be retired or simplified after selection, but until an owner can actually be removed it remains an obligation.

**Why it matters:** recurring security/SDK/floor and host glue may offset shared-component gains. The causal RN island must not be priced as the only possible production hybrid; a final hybrid can use different, separately validated native bindings.

**Correction/next test:** register the already required coarse ranges before comparative results. Include surviving SDK/security/update/hosting/test/release owners and identify each experiment tool's final role or retirement condition. Keep runtime gates separate. Treat the 24-month horizon as explicit decision policy, not measured payback; preserve initial ranges and uncertainty. There is no evidence-based reason to remove useful assurance merely because it took many tokens or checks.

## Alternatives are now weighted fairly

| Alternative | Credible benefit | Risk/cost to settle | Current disposition |
| --- | --- | --- | --- |
| Retain Svelte/Capacitor, bounded remedies | Preserves the one working UI, APIs, data/service owners and tuned renderer | Residual native action causes and release readiness | Explicit valid outcome; no-residual and residual branches distinguished |
| Svelte/Capacitor with native paper | Can bypass paper WebView costs while retaining product UI | Input/layer/transaction/coherence glue; residual surrounding WebView costs | Serious symmetric competitor, not a dismissed halfway solution |
| RN mobile with retained Svelte web | Native UI/paper on mobile; preserves browser investment | Two visual implementations and recurring synchronization | Legitimate fallback/interim arrangement; current contract recognizes permanent duplication cost |
| RN mobile plus RNW | Shared RN-oriented product vocabulary | HTML/CSS/SSR/security/PWA adapters and native rendering/continuity | Leading candidate, not selected |
| RN mobile plus RSD | Shared strict HTML/CSS vocabulary and native views | Native API/layout gaps, compiler/theme costs and platform semantics | Real candidate; needs its own native and host measurements |
| Flutter | Another non-WebView UI/rendering pipeline | Dart/TypeScript ownership, browser host/floors/data/service parity | Conditional fallback; not excluded by evidence about RN or WebGL |
| Separate Swift/Kotlin/web UIs | Direct platform control and targeted OS mechanisms | Three recurring visual owners, behavior synchronization | Conditional fallback where a concrete benefit justifies burden |
| Ordinary React DOM rewrite first | Could be a web ownership choice | Does not bypass browser composition; adds simultaneous migration | Correctly not a prerequisite or claimed mobile-performance remedy |

The [RN threading model](https://reactnative.dev/architecture/threading-model) distinguishes JS render/layout and UI-thread mounting; replacing WebView is not replacing all JS or all scheduling cost. The [Flutter architectural overview](https://docs.flutter.dev/resources/architectural-overview) supports treating Flutter as an alternative rendering pipeline, not as an established performance winner. The rejected WebGL spike in ADR-0153 `:14–49` changed appearance and retained attachment-area/software-floor costs; it does not refute all native GPU designs. No neglected alternative in the inspected record is established to dominate the current finalists.

## Recommended next increments

1. Finish acceptance of the isolated retained-control and native-source units without enlarging their claims. Preserve their exact source/evidence bindings, failed attempts, and local-only status until independent review and CI close their actual exits.
2. Obtain optimized native build/mount and early local same-ID reader feasibility. This resolves dependency/floor/runtime and data-access structural risk while leaving production owners untouched.
3. Finish a realistic React host and high-risk RNW/RSD adapter slice, with actual native counterparts. This resolves whether shared UI is a maintainable product boundary rather than an attractive vocabulary.
4. When physical devices are available, refresh causal controls and calibrate content/presentation/readiness observers; only then run the matched faithful full-screen comparison under preregistered materiality and burden assumptions.

The current architecture plan can fairly resolve uncertainty if those gates are executed as written. Continue with that conditional direction; do not describe the infrastructure already accepted as an RN architecture victory or a completed product migration. Leave the campaign paused until the human resumes it.


## Refinement: the exact React runtime result makes host eligibility conditional

**Challenged claim:** either that the embedded SvelteKit plus React host has only an entirely unmeasured budget risk, or that this runtime experiment proves every React host strategy fails.

**Anchors:** parent raw rollout L5227 (2026-10-06 05:06:45.987Z, call_bIQRjb4zy5t3FHSrcxnzE919) and L5367 (05:11:10.349Z, call_eJT4LjLks6JWMU4uJb0W6bbB); accepted dc08a90abc67b53124146bf288c80de0f9ffd1dd `tools/check-bundle-budgets.mjs:20–27`; private `/private/tmp/splotch-react-web30-merge-tieo7hhj/SOURCE-PREPARATION.md:3–6`, `:33–45`, `:67–76`, `:101–111`.

**Established:** the preserved Claude command/output records a runtime-only production ESM experiment from React/ReactDOM 19.2.3 with esbuild 0.25.12, importing hydrateRoot/createElement/useSyncExternalStore: 193,523 raw bytes and 60,333 gzip bytes. Its bundle was cleaned up; I did not independently rebuild it. The shipping lazy guard is 75,000 raw bytes, so that isolated result is 118,523 bytes over the guard (2.58 times the ceiling); gzip is not its scoring unit. The 51,648 startup headroom is the owner's recorded September baseline, not a fresh current host measurement. No full Kit host build, actual host chunk partition, runtime timing or deployed result follows from the isolated output. The merged 53-file packet is prepared and unexecuted. Its proposed chain preserves strict postbuild failure, records failed status and false review eligibility, and refuses browser/check advancement from that failed release artifact. The amended plan explicitly preregisters the expected lazy failure and requires a reviewed causal budget/foundation disposition, without a shipping guard waiver.

**Why it matters:** the exact additive candidate cannot credibly promise ordinary tuning will make this runtime fit the unchanged lazy ceiling. Deferral can protect early startup but transfers activation cost; eager placement consumes startup cost instead. Yet the ReactDOM runtime is also a cost of an ordinary standalone React DOM host. This isolated measurement therefore does not rank embedded Kit against standalone React: the distinguishing quantities are the retained Svelte/Kit overlap, complete graph, activation behavior and actual product cost after replacement. The existing eager budget is 525,000 raw JS/CSS bytes, not a 75,000 ceiling on every conceivable React strategy.

**Correction/next test:** keep the embedded packet eligible only as a bounded mechanism and budget experiment. First obtain the actual complete host release build, fresh retained control and candidate resource graphs, and first/repeat-visit plus activation costs. Its expected postbuild failure must remain a failure. If host mechanics work, review an explicit equivalent-cost allocation against measured product benefit and the competing host, including any retained dual-runtime maintenance; do not infer eligibility from SSR/hydration success alone. This new evidence warrants tightening that decision boundary now, not discarding embedded hosting categorically. All React strategies have not been measured, and changing placement, replacing retained owners or a reviewed new foundation allocation is a distinct hypothesis requiring its own proof.
