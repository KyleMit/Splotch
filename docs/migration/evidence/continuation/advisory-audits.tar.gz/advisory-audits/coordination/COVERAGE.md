# Coverage record

Campaign endpoint: raw parent L17527, 2026-10-06T12:40:02.782Z, the final pause summary. Later audit-prompt request/preparation is excluded. The derived parent skeleton is trimmed before that later activity; its copied front matter describes the original complete raw file.

Full parent semantic-skeleton coverage was divided as follows (derived skeleton line numbers):

| Reader | Sections completed |
| --- | --- |
| Parent factual extractor | 1–10000; all truncated output gaps repaired |
| Native factual extractor | 10001–20000; all truncated output gaps repaired |
| Web factual extractor | 20001–25000; 25351 through the pause endpoint; manageable nontruncated sections |
| Root evaluator | 25001–25350; final receipts and selected consequential raw records independently drilled |

Opaque encrypted message payloads carry no accessible semantics and were visually masked where necessary. Earlier raw records remain authoritative across compaction. The catalog and worker manifest identify eight campaign worker/grandchild records by actual parent-thread spawn references. Detailed native/web reports disclose their own raw/skeleton coverage limitations. Claude manifest identifies39 actual linked conversations,34 available originals/skeletons and five missing originals. Selected architecture, topology, retained-web and Netlify review chains received deep raw drills; every other Claude raw command was not exhaustively inspected.

Factual extraction agents received the relevant provider report-prompt verbatim. Their reports are factual extraction artifacts; root owns the retrospective judgments and recommendations. Root final report links its consequential raw record identities. RAW-REFERENCE-LEDGER.md and raw-reference-ledger.json preserve full paths, lines, timestamps and available tool-call IDs.

No migration work, builds/tests, branch changes, application/instruction edits or GitHub writes were performed. Writes are confined to the user-authorized audit directory. A read-only primary checkout status check showed codex/native-migration matching origin and clean. Preservation receipts were inspected; candidate restoration was not executed.
