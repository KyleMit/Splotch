import { spawnSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { ESLint } from 'eslint';
import prettier from 'prettier';
import stylelint from 'stylelint';
import ts from 'typescript';
import { parseDocument } from 'yaml';
import { describe, expect, it } from 'vitest';
import { QUALITY_COMMANDS } from '../../ci-mirror/run-quality-checks.mjs';
import { CANDIDATE_DIRECTORY } from '../../lib/native-candidate.mjs';
import { GENERATED_NATIVE_DIRECTORIES } from '../lib/native-source-contract.mjs';

const root = join(import.meta.dirname, '..', '..', '..');
const read = (path) => readFileSync(join(root, path), 'utf8');
const sourceCommand = 'npm run check:migration:native-candidate';
const topologyCommand = 'npm run check:migration:native-topology';
const materializerScript = 'gen:migration:native-candidate';
const generatedDirectories = GENERATED_NATIVE_DIRECTORIES.map(
  (directory) => `${CANDIDATE_DIRECTORY}/${directory}`
);
const gitFences = generatedDirectories.map((directory) => `/${directory}/`);
const dprintFences = generatedDirectories.map((directory) => `${directory}/**`);
const manifest = JSON.parse(read('package.json'));
const workflow = read('.github/workflows/test.yml');
const manualEntry = /(?:materialize-native-candidate\.mjs|gen:migration:native-candidate|inspect-android-candidate-archives\.mjs)/;

function registrationViolations(packageManifest, commands, source) {
  const document = parseDocument(source, { uniqueKeys: true });
  if (document.errors.length) return ['invalid workflow'];
  const job = document.toJS().jobs?.quality;
  const failures = [];
  const steps = Array.isArray(job?.steps) ? job.steps : [];
  const matches = steps.filter((step) => step.run === sourceCommand);
  if (
    job?.if !== "${{ github.event_name != 'push' || !startsWith(github.ref, 'refs/tags/') }}" ||
    job?.['continue-on-error'] || matches.length !== 1 ||
    Object.hasOwn(matches[0], 'if') || Object.hasOwn(matches[0], 'continue-on-error')
  ) failures.push('native source CI step is not mandatory');
  if (
    commands.filter((command) => command === sourceCommand).length !== 1 ||
    commands.filter((command) => command === topologyCommand).length !== 1 ||
    commands.indexOf(sourceCommand) !== commands.indexOf(topologyCommand) + 1
  ) failures.push('native source local order differs');
  if (
    steps.filter((step) => step.run === topologyCommand).length !== 1 ||
    steps.findIndex((step) => step.run === sourceCommand) !==
    steps.findIndex((step) => step.run === topologyCommand) + 1
  ) failures.push('native source CI order differs');
  for (const [script, entry] of [
    ['check:migration:native-candidate', 'node tools/migration/check-native-candidate.mjs'],
    [materializerScript, 'node tools/migration/materialize-native-candidate.mjs'],
  ]) {
    if (packageManifest.scripts?.[script] !== entry) failures.push(`native entry changed: ${script}`);
    if (!packageManifest['scripts-info']?.[script]?.trim()) failures.push(`native description missing: ${script}`);
  }
  if (commands.some((command) => manualEntry.test(command)) ||
    steps.some((step) => manualEntry.test(step.run ?? '')))
    failures.push('manual native operation in Quality');
  for (const [name, command] of Object.entries(packageManifest.scripts ?? {})) {
    if (/^(?:pre|post)|^(?:install|prepare)$/.test(name) && manualEntry.test(command))
      failures.push(`manual native operation in lifecycle: ${name}`);
  }
  return failures;
}

function textFenceViolations(gitIgnore, prettierIgnore, dprintSource) {
  const parsed = ts.parseConfigFileTextToJson('dprint.json', dprintSource);
  const failures = [];
  if (parsed.error || !Array.isArray(parsed.config?.excludes)) return ['invalid dprint excludes'];
  for (const [owner, rows, expected] of [
    ['git', gitIgnore.split('\n').map((line) => line.trim()), gitFences],
    ['prettier', prettierIgnore.split('\n').map((line) => line.trim()), gitFences],
    ['dprint', parsed.config.excludes, dprintFences],
  ]) {
    for (const fence of expected) {
      if (rows.filter((row) => row === fence).length !== 1)
        failures.push(`${owner}: missing or duplicate ${fence}`);
    }
    const parent = CANDIDATE_DIRECTORY.slice(0, CANDIDATE_DIRECTORY.lastIndexOf('/'));
    for (const row of rows) {
      if (typeof row !== 'string') { failures.push(`${owner}: nonstring fence`); continue; }
      const normalized = row.replace(/^(?:\*\*\/|\/+)/, '');
      const scoped = row.includes(CANDIDATE_DIRECTORY) ||
        [parent, `${parent}/`, `${parent}/**`].includes(normalized);
      if (scoped && !expected.includes(row)) failures.push(`${owner}: unsupported native fence ${row}`);
    }
  }
  return failures;
}

function mutatedWorkflow(mutate) {
  const document = parseDocument(workflow, { uniqueKeys: true });
  mutate(document.getIn(['jobs', 'quality']));
  return document.toString();
}

function sourceStep(job) {
  return job.get('steps').items.find((step) => step.get('run') === sourceCommand);
}

describe('maintained native source registration', () => {
  it('executes the source checker after topology in both Quality owners with manual materialization', () => {
    expect(registrationViolations(manifest, QUALITY_COMMANDS, workflow)).toEqual([]);
  });

  it('rejects missing, ignored, conditional and duplicate CI source execution', () => {
    for (const mutate of [
      (job) => sourceStep(job).set('run', 'node -e 0'),
      (job) => sourceStep(job).set('if', false),
      (job) => sourceStep(job).set('continue-on-error', true),
      (job) => job.get('steps').add(sourceStep(job).clone()),
      (job) => job.set('if', false),
    ]) {
      expect(registrationViolations(manifest, QUALITY_COMMANDS, mutatedWorkflow(mutate))).toContain(
        'native source CI step is not mandatory'
      );
    }
  });

  it('rejects local omission, wrong CLI bindings and materialization in lifecycle or Quality', () => {
    expect(registrationViolations(manifest, QUALITY_COMMANDS.filter((row) => row !== sourceCommand), workflow))
      .toContain('native source local order differs');
    const wrong = structuredClone(manifest);
    wrong.scripts['check:migration:native-candidate'] = 'node -e 0';
    expect(registrationViolations(wrong, QUALITY_COMMANDS, workflow)).toContain(
      'native entry changed: check:migration:native-candidate'
    );
    wrong.scripts.prebuild = `npm run ${materializerScript}`;
    expect(registrationViolations(wrong, QUALITY_COMMANDS, workflow)).toContain(
      'manual native operation in lifecycle: prebuild'
    );
    expect(registrationViolations(manifest, [...QUALITY_COMMANDS, `npm run ${materializerScript}`], workflow))
      .toContain('manual native operation in Quality');
  });
});

describe('finite generated native output fences', () => {
  it('pins every nonimporting owner to the canonical directory set', () => {
    expect(textFenceViolations(read('.gitignore'), read('.prettierignore'), read('dprint.json'))).toEqual([]);
  });

  it('rejects removal or duplication of each owner row even when existing rules also match', () => {
    for (const fence of gitFences) {
      for (const owner of ['.gitignore', '.prettierignore']) {
        const values = { git: read('.gitignore'), prettier: read('.prettierignore'), dprint: read('dprint.json') };
        const key = owner === '.gitignore' ? 'git' : 'prettier';
        values[key] = values[key].replace(`${fence}\n`, '');
        expect(textFenceViolations(values.git, values.prettier, values.dprint).length).toBeGreaterThan(0);
        values[key] += `${fence}\n${fence}\n`;
        expect(textFenceViolations(values.git, values.prettier, values.dprint).length).toBeGreaterThan(0);
      }
    }
    const parsed = ts.parseConfigFileTextToJson('dprint.json', read('dprint.json')).config;
    for (const fence of dprintFences) {
      expect(textFenceViolations(read('.gitignore'), read('.prettierignore'), JSON.stringify({
        ...parsed, excludes: parsed.excludes.filter((row) => row !== fence),
      })).length).toBeGreaterThan(0);
      expect(textFenceViolations(read('.gitignore'), read('.prettierignore'), JSON.stringify({
        ...parsed, excludes: [...parsed.excludes, fence],
      })).length).toBeGreaterThan(0);
    }
  });

  it('rejects candidate, platform and parent widening with all six canonical rows retained', () => {
    const parent = CANDIDATE_DIRECTORY.slice(0, CANDIDATE_DIRECTORY.lastIndexOf('/'));
    for (const directory of [CANDIDATE_DIRECTORY, `${CANDIDATE_DIRECTORY}/android`, `${CANDIDATE_DIRECTORY}/ios`, parent]) {
      for (const owner of ['git', 'prettier', 'dprint']) {
        const values = { git: read('.gitignore'), prettier: read('.prettierignore'), dprint: read('dprint.json') };
        const fence = owner === 'dprint' ? `${directory}/**` : `/${directory}/`;
        if (owner === 'dprint') {
          const config = ts.parseConfigFileTextToJson('dprint.json', values.dprint).config;
          values.dprint = JSON.stringify({ ...config, excludes: [...config.excludes, fence] });
        } else values[owner] += `${fence}\n`;
        expect(textFenceViolations(values.git, values.prettier, values.dprint)).toContain(
          `${owner}: unsupported native fence ${fence}`
        );
      }
    }
  });

  it('applies actual Git and Prettier ignores while retaining maintained candidate sources', async () => {
    const paths = generatedDirectories.map((directory) => `${directory}/FenceControl.json`);
    const result = spawnSync('git', ['-c', 'core.excludesFile=/dev/null', 'check-ignore', '--no-index', '--stdin'], {
      cwd: root, input: paths.join('\n') + '\n', encoding: 'utf8',
    });
    expect(result.status).toBe(0);
    expect(result.stdout.trim().split('\n')).toEqual(paths);
    for (const path of paths) {
      expect((await prettier.getFileInfo(join(root, path), { ignorePath: join(root, '.prettierignore') })).ignored)
        .toBe(true);
    }
    for (const source of ['android/gradle.properties', 'ios/Podfile.properties.json']) {
      const maintained = `${CANDIDATE_DIRECTORY}/${source}`;
      const retained = spawnSync('git', ['-c', 'core.excludesFile=/dev/null', 'check-ignore', '--no-index', maintained], {
        cwd: root, encoding: 'utf8',
      });
      expect(retained.status).toBe(1);
      expect((await prettier.getFileInfo(join(root, maintained), { ignorePath: join(root, '.prettierignore') })).ignored)
        .toBe(false);
    }
  });

  it('uses actual ESLint and stylelint ignores without fencing maintained candidate code', async () => {
    const eslint = new ESLint({ cwd: root });
    for (const directory of generatedDirectories) {
      expect(await eslint.isPathIgnored(join(root, directory, 'FenceControl.mjs'))).toBe(true);
      const { results } = await stylelint.lint({
        code: '.a { colr: red; }', codeFilename: join(root, directory, 'FenceControl.css'), cwd: root,
      });
      expect(results[0].ignored).toBe(true);
    }
    expect(await eslint.isPathIgnored(join(root, CANDIDATE_DIRECTORY, 'android/app/src/main/FenceControl.mjs')))
      .toBe(false);
    const messages = await eslint.lintText('export const value: any = 1;', {
      filePath: join(root, CANDIDATE_DIRECTORY, 'src/RegistrationControl.tsx'),
    });
    expect(messages[0].messages.map((message) => message.ruleId)).toContain('@typescript-eslint/no-explicit-any');
    const { results } = await stylelint.lint({
      code: '.a { colr: red; }', codeFilename: join(root, CANDIDATE_DIRECTORY, 'src/RegistrationControl.css'), cwd: root,
    });
    expect(results[0].warnings.map((warning) => warning.rule)).toContain('property-no-unknown');
  });
});
