# Native80 intake and validation driver

Use two bounded PRs: maintained candidate/source gates first (60 + registration10),
then the archive-intake source (20) with its audited ZIP dependency. Run source controls
before acquiring native tools. This packet is an execution handoff, not passing evidence.

The roster preserves the original observation of combined parent
9442b27817a61486750b070ff07c880d124571a6 in
`/Users/kylemit/.codex/worktrees/migration-native-topology/Splotch`. Root subsequently reported
foundation PR2697 accepted and merged as dc08a90abc67b53124146bf288c80de0f9ffd1dd. This correction
does not query Git or rebind the historical roster to that merge. Record the actual accepted
execution HEAD after retained-web integration and recompare current owners before native intake.

## Intake inputs and immediate safe preconditions

[ROSTER.json](ROSTER.json) lists all 90 exact paths, bytes, modes, SHA256 hashes and frozen
locations: maintained60, archive20 and registration10 are disjoint. All recorded frozen
bytes/modes were passively verified. No maintained80 path exists in the observed parent.
Nine existing registration preimages match it exactly; the registration fixture is new.
Keep these packets immutable; compare the actual accepted tip again immediately before copying.

| Frozen owner | Actual packet |
| --- | --- |
| Maintained60, including Expo scene bridge | `/private/tmp/splotch-native07a-scene-successor-_lwg85bq/prepared` |
| Archive20, using the scene reader | `/private/tmp/splotch-native07b-scene-helper-successor-ehuh8glf/prepared` |
| Registration10, staged README | `/private/tmp/splotch-native07a-registration-staging-successor/prepared` |

Root supplies a quiescent accepted parent with its qualified frozen dependency tree and
reviewed topology/Netlify/Kit owners. Retained web source may land first. Compose native
registration over those owners; do not replace current package/config/README files with old
whole-file copies. Preserve root packageManager/engine/dependencies, workspace/lock, candidate
six pins and existing alignment/ProbeApp/entry/Metro/Babel/TypeScript files. The roster binds
these observed source owners so drift has an explicit comparison input.

The observed root package hash is `7348b31a67caeecb68b44e4fee005513a4902f125cf874b33d34ed539a5bded9`;
observed lock hash is `705b57623e37d509826f4b6aa42b00d4957d7dd295165d462523b075e42a9f92`.
These identify this read, not a requirement that later legitimate source keep identical hashes.
Current proof inputs must be generated/reviewed for actual new owners as required by the
selected proof route. Historical topology/cloud evidence remains byte-exact and historical.

## First PR: maintained60 and source registration

Copy only the maintained60 roster, retaining executable `gradlew` and every authenticated
mode. The frozen materializer includes exact-mode writes under restrictive umask and canonical
provenance replay. The scene additions are `native-apple-scene.mjs` and its actual source/control
suite. Existing Expo owns scene startup/event dispatch; do not create another event coordinator.

Apply these ten registration paths semantically: `.github/workflows/test.yml`, `.gitignore`,
`.prettierignore`, `dprint.json`, `eslint.config.js`, `package.json`, `stylelint.config.js`,
`tools/ci-mirror/run-quality-checks.mjs`, `tools/migration/README.md` and new
`tools/migration/tests/native-registration.test.mjs`. Add only these scripts/descriptions:

```text
check:migration:native-candidate = node tools/migration/check-native-candidate.mjs
gen:migration:native-candidate = node tools/migration/materialize-native-candidate.mjs
```

Keep the source checker immediately after live topology in both Quality owners. Retain every
existing shipping/Forge/import/witness guard. Use the canonical six generated-directory fences
in Git/Prettier/dprint and imported ESLint/stylelint owners; never exclude the whole candidate.
Broad existing Knip tooling entries and `tools/vitest.config.mjs:15` discover these callers and
suites. Reconcile actual newer retained-web discovery rather than removing it. No new dependency,
lock change, Node floor, `.ruler` change or SDK setup belongs in this PR.

Root then runs these source checks serially, using the actual accepted parent's normal Node:

```sh
npm run check:migration:native-candidate
npm run test:tools -- migration/tests/native-template.test.mjs migration/tests/native-source-contract.test.mjs migration/tests/native-provenance.test.mjs migration/tests/native-apple-scene.test.mjs migration/tests/native-registration.test.mjs --maxWorkers=1
```

These drive authenticated synthetic tar fixtures, canonical replay/joint tampering, actual
checker inversions, real restrictive-umask child controls, actual installed Expo scene hashes
and finite registration/ignore owners. The checker imports existing tar without invoking its
parser. These controls do not prove successful full released-archive materialization or native
compilation. Root also runs required formatting/check/lint/Quality/full tier and the actual
independent source/PR review, with no concurrent full suite or native activity.

Successful full materialization is a separate explicit source operation. Authenticate the
released `expo-template-bare-minimum@57.0.28` archive against the retained manifest before using
`npm run gen:migration:native-candidate -- --archive=<absolute-reviewed-template.tgz>` in an owned
candidate/disposable context. Its pinned compressed size is 297906 bytes, SHA256
`f4457960d6ea35dce4270d8881e42a82e71134964822a15b47549fb8ac44bc96`; the retained manifest owns SRI
and URL. Root subsequently acquired that exact archive at
`/private/tmp/splotch-reviewed-native-template-j0g616uh/expo-template-bare-minimum-57.0.28.tgz`.
Its adjacent `receipt.json` records all 59 member bytes/modes compared with the frozen manifest;
this correction independently rechecked only whole bytes/SHA256/SRI and receipt count. No archive
extraction, candidate parser/materializer or native execution occurred. Use that authenticated
archive for the explicit materialization; actual idempotence/failure preservation remain pending.
Never add materialization/downloads to install, build or Quality hooks.

## Second PR: archive20 and exact ZIP-reader qualification

Preserve the current accepted pre-addition manifest/workspace/lock. The only proposed dependency
addition is root-dev exact `yauzl@3.4.0`; existing root `tar@7.5.22` remains the TAR owner. Prepare
`pnpm add --workspace-root --save-dev --save-exact yauzl@3.4.0 --lockfile-only --ignore-scripts`, then
inspect the real semantic delta and complete new-artifact integrity/lifecycle inventory BEFORE
normal frozen install. Use the existing script-inventory caller against the preserved baseline.
Retain native-run's yauzl2.x/SRI and all candidate pins; inspect legitimate optional-peer snapshot
changes. Preserve shipping production closure and existing allowance/security predicates.

After audited frozen installation, qualify the actual resolved yauzl3.4 source and contexts,
then copy archive20 and run its coherent five-suite unit:

```sh
npm run test:tools -- migration/tests/android-sdk-artifacts.test.mjs migration/tests/candidate-toolchain-roots.test.mjs migration/tests/candidate-archive-downloads.test.mjs migration/tests/android-candidate-archives.test.mjs migration/tests/android-candidate-cli.test.mjs --maxWorkers=1
```

These parse local ZIP/TAR fixtures, stub fetch with real response streams, and drive copied
public CLI controls in owned temporary Git/source roots. They require no listener, real download,
SDK or device. Some helpers can load without yauzl; filtered partial passes do not accept the unit.
Do not land all20 with first PR and waive missing parser failures in broad tools discovery.
Root repeats applicable source/Quality/full/independent review and records actual results.

## Public acquisition and execution order after those source gates

The first acquisition is the small explicit template archive when full materialization is needed;
package qualification is the separate yauzl delta above. The existing no-argument archive caller
is then `node tools/migration/inspect-android-candidate-archives.mjs`, manual and separately released
by root. It authenticates maintained source/scene/profile before writes and around each receive.
Its actual fixed profile selects eight archives on darwin-arm64 or linux-x64 in this order:

```text
build-tools36.0.0 -> cmake3.30.5 -> cmdline20.0 -> Gradle9.3.1 ->
Temurin17.0.20.1+1 -> NDK27.1.12297006 -> Node24.16.0 -> Android36 revision2
```

The profile retains exact public URLs, checksums and available sizes. Do not bootstrap `latest`,
execute a newly received program, change HOME/global SDK/Java/AVD state or invent a selective
Node-first flag. The caller owns a marked canonical cache outside all checkouts, refuses special
files/escapes/link graph hazards, requires quiescent inputs, and records downloaded versus reuse.
Actual vendor archive layouts/encodings remain unproved. Every successful receipt still says
`archive-review-required`, `publicationAllowed:false`, `nativeExecution:false`. Unknown legitimate
layouts need a bounded source-policy correction, not permissive extraction or assumed success.

Review actual full member/layout/license receipts before preparing the NEXT real provisioner.
Archive20 has no extractor/runtime publisher/compiler. That next unit must safely publish owned
Node24/JDK17/SDK/Gradle, enforce finite environment/toolchain downloads-off settings, and record
actual Release Maven/RN/Hermes inputs and installed-package generated outputs. Root's Node floor
and shipping Capacitor JDK21 remain their own owners; RN Gradle jvmToolchain17 must be qualified.
Android/iOS candidate identities remain `art.splotch.migration.probe`, API24/iOS16.4, not store IDs.

Apple preparation is independent of Android archives. Root's controlling accepted tool plan is
`/private/tmp/splotch-ios-node24-ruby-successor-0qwofb43/IOS-ENVIRONMENT.md` (with its
`successor-receipt.json` and `RUBY-BOUNDARY-INDEPENDENT-REVIEW.md`): profile Node24.16.0,
owned Ruby3.4.11 with bundled Bundler2.6.9, CocoaPods1.16.2 and xcodeproj1.27.0. Preserve the
reviewed departure from the incompatible RN reference xcodeproj cap; resolve/audit real owned
gem/pod locks, native extensions and prebuilt RN/Hermes before use. Keep unchanged HOME and the
finite Node/PATH/NETRC/cache owners. Host Xcode27.0 is the compile candidate. Exact iOS16.4/20E247
mount needs separately qualified official Xcode26.6/runtime or an actual supported floor device;
neither is qualified. No CI26.4.1 selection is adopted by this handoff. No system Ruby/Homebrew,
global xcode-select mutation or successful tool qualification is implied. Android API24 and
Apple current-OS scene/lifecycle checks and iOS16.4 mounts remain separate execution work.

The original driver incorrectly promoted tool pins from the structural proposal over this adopted
Apple plan. Receipt timestamps or filename recency do not establish approval; root's explicit
accepted owner controls. The original handoff remains immutable historical data.

Static Skia/Ganesh, mounted output, input/audio/export/product parity and full paper are later units;
none is implemented or qualified by Native80. No performance or architecture selection follows
from source tests, archive inspection or compiler success. This handoff ran only passive source
reads/data hashing and private writing: no candidate imports, tests, Git, network, installs,
formatters, tool acquisition, native execution or checkout edits.
