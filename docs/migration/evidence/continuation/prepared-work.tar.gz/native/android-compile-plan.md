# Next Android unit: inspected tools → owned publication → Release compile

Source-only proposal, 2026-10-06. No acquisition, extraction, imports, tests, native execution,
builds or checkout changes. Existing acquisition/Native80 plans remain controlling inputs.

## Entry boundary

Root first records the actual accepted integrated parent, maintained60/scene registration,
qualified archive20/yauzl3.4.0 and installed lock. Real source/materializer/parser/CLI controls
and released-template authentication precede acquisition. The earlier423 cloud-failed head is
not an accepted baseline. Qualified root Node22 runs the existing no-argument archive inspector;
candidate native execution later uses profile Node24.

**Actual whole-archive/member inspection receipts must be reviewed before any extraction or
publication.** Archive20 still returns publicationAllowed=false/nativeExecution=false. Reuse its
fixed profile/Google XML/Node checksum owners: Node24.16.0, Temurin17.0.20.1+1, Gradle9.3.1,
cmdline20.0, platform36 revision2, build-tools36.0.0, NDK27.1.12297006 and CMake3.30.5. Actual
SDK/JDK/Gradle layouts, modes/links, host architecture and CMake/Ninja utilities remain unqualified.
Unknown legitimate layouts require evidence-led correction before mapping; no permissive default,
moving SDK installer, platform-tools or emulator is added.

## Small implementation and publication

Add two manual real callers: fixed-profile runtime publication and candidate Release build,
with root npm/scripts-info/README and focused controls. Reuse current receipt/profile/source owners;
no extra package or general provisioning framework. Neither runs from install, web build, Quality
or shipping android:* hooks. Split publication and compile PRs only if the real diff needs it.

1. Derive finite mappings from reviewed actual receipts. Stage in a newly owned destination,
   verify mapped bytes, modes and contained graph, then publish only a complete set. Preserve
   originals/failed staging; reject unexpected or preexisting destinations. Explicitly set modes
   on newly owned files independent of umask. Use a separately marked canonical runtime root
   outside every checkout and global SDK/Java/AVD owner; archive20's closed owner remains unchanged.
   Qualify full JDK layout, versioned SDK registration, Node's two-regular-member mapping and
   complete Gradle distribution before executable use.
2. Recognize selected binaries/package revisions in owned temp/cache with explicit SDK root.
   Require actual host architecture/utility compatibility and installed byte identity, not only
   matching version text. No global registration, Java/SDK profile edits or HOME reassignment.
3. Compile in a fresh owned source/qualified-install copy with independent files/contained links.
   Protect published package bytes and admit only actual participating-build outputs; never ignore
   node_modules/build wholesale. Record copied inputs and before/after output identities.
4. Keep authenticated gradlew/JAR and frozen distribution URL/SHA. Derive9.3.1's cache layout from
   its source, prepopulate only owned GRADLE_USER_HOME from reviewed distribution, and fail before
   wrapper invocation if absent. No implicit second download. Direct Gradle is simpler but changes
   the accepted wrapper caller, so is not selected; no wrapper/provenance rewrite.

## Actual child and same-Release qualification

Preserve genuine HOME. Select owned bare Node24 on bounded PATH, full Java17, identical canonical
ANDROID_HOME/ANDROID_SDK_ROOT, owned Android-user/Gradle/project caches and writable temp. Both
settings/app configuration call bare node; JAVA_HOME alone is insufficient. Root Node22/pnpm and
shipping Capacitor Java21 remain their own owners (ADR0012/0119).

Use the accepted finite Node/Expo/JVM scrub-versus-reject policy; no arbitrary env/extra-arguments
option. Scrub inherited Java agent text, generate only reviewed owned JVM temp/UsePerfData=false
options and refuse project/Gradle overrides. Preserve production entry/Metro/Expo behavior and
owned Expo home. Record safe paths/name/action facts, never secrets or full environment.

Every authenticated wrapper invocation uses owned home/project cache, --no-daemon,
--no-configuration-cache, --no-configure-on-demand, --console=plain, the source-bound init probe and:

```text
-Dorg.gradle.java.installations.auto-download=false
-Dorg.gradle.java.installations.auto-detect=false
-Dorg.gradle.java.installations.paths=<owned-Java17>
-Pandroid.builder.sdkDownload=false
-Pandroid.cmakeVersion=3.30.5
```

Keep accepted owned Gradle properties for JVM/temp, Java/SDK denials and Kotlin in-process mode.
No downloads-off bypass. Bind the pinned AGP denial consumer before its guard; missing-component
controls prove no implicit SDK/JDK installation. Same-Release callbacks validate each RN/Expo
included build before work, effective daemon/compiler Java17, loaded Kotlin plugin/strategy, final
native DSL/NDK/CMake/Prefab and executables. Expo's released plugin consumes android.cmakeVersion;
property presence alone is insufficient. Require actual expected rows, including modules without
native work. Reject daemon criteria, late overrides, missing callbacks and unowned tools; verify
no downloaded jdks. No Skia consumer belongs in this unit.

Introduce only actual context inputs android/local.properties (exact owned sdk.dir/cmake.dir) and
stage-bound android/gradle/verification-metadata.xml separately from original template provenance;
the current exact reader rejects both. At Kotlin's real writer, admit copied participating-root
.kotlin outputs, including android/.kotlin, while protecting original bytes. Qualify plugin identity
before version-specific getters. All four splotch.probe.release.* inputs are required during
configuration: create only external owned candidate-release.keystore with qualified Java17 keytool;
private values stay in qualified Gradle properties, never argv/logs or shipping signing storage.

## Dependency, license and final artifact gates

Actual Maven/plugin/AAR/Prefab inputs remain unqualified. Use the accepted explicit provisional
capture, label it unverified, review actual immutable coordinates/bytes from both host contexts,
then fresh strict dependency-verification Release with hash-bound reviewed metadata. Metadata
generation is not verification; the provisional code-execution boundary must be explicitly reviewed
before running it. Refuse inherited/nightly/local RN/Hermes/repository substitutions. Allow reviewed
dependency resolution; offline mode cannot provide missing artifacts or waive their review.

Final task :app:assembleRelease retains declared ABIs. Require exit0 and same-run probes, nonempty
Hermes bundle/assets, R8/resource-shrinking outputs, candidate ID art.splotch.migration.probe,
floor24/target36, disposable signer, permissions and native ABI/alignment checks. Require actual
react-android0.86.3 and Hermes V1 compiler/runtime250829098.0.17 artifact identities; RN's released
plugin substitutes declared com.facebook.react:hermes-android to com.facebook.hermes, so inspect
resolved coordinates/linked bytes. No debug/Metro dependence. This proves compilation/artifacts,
not launch, product parity, input/audio/export or performance.

License ID/body/normalization/accepted-line identity remains receipt-only. First compile with all
packages present and no new acceptance files. Never copy global lines or run sdkmanager --licenses.
If a required tool actually refuses, preserve the result and review only the exact required terms/
owned-state change before retry; no catalog-wide acceptance.

Focused real-caller controls cover tampered receipt/map, modes/links/escape/partial publication,
missing distribution/tool/component, HOME/selector overrides, generated-input/probe/late-DSL failure,
wrong signer/identity, Maven mismatch and an actual downloads-off inversion. Execute source/Quality/
required tiers serially, then real Mac compilation; Linux CI uses its profile/graph and is compile-only.
No branch-rule change or mount starts here.

Hard pending gates: accepted source/dependency integration, actual eight-archive receipts/mappings,
binary/utility qualification, context/probe controls, Maven review and strict optimized compile.
API24 emulator/discovery/auth and iOS16.4 mounts remain separate and do not block this source work.

Basis: mobile/adrs and ADR0012/0119; Native80 DRIVER; acquisition plan; native07b structural plan/SDK
dispositions; frozen profile, source reader/contract and settings/app Gradle. Published RN0.86.3
DependencyUtils and Expo autolinking57.0.13 ExpoRootProjectPlugin were passively checked in the
qualified topology tree. Distinct candidate_entry confirmed real signing/PATH, wrapper, generated
input and released Kotlin output owners without execution or an additional audit dossier.
