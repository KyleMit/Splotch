# Next-source pickup inventory

This packet is a passive inventory, not implementation or acceptance. The migration remains paused.
All selected bytes are available and their recorded identities were checked where a receipt exists.
`inventory.json` is the exact per-file copy list; preserve source bytes/modes and retain original paths
in the packaging manifest. No source imports, installs, tests, builds or Git mutation occurred.

## Already preserved under the ignored pause backup

- Native70 actual uncommitted source: 70 files, including source60 and ten semantic registration owners.
  Every byte and mode matches `native/source-intake-receipt.json`. It has no source validation.
- Corrected Native80 handoff and original90 roster; controlling Apple plan/receipt; Android compile
  plan; authenticated Expo57.0.28 template archive and receipt. Their exact hashes are recorded below.
- Native70 does not contain archive20, React source or future tool provisioners.

## Package before `/private/tmp` cleanup

1. `future/native/archive20`: twenty frozen source files plus source preparation/receipt. These are
   source-only archive-inspection callers, not an extractor or runtime publisher.
2. `future/native/yauzl`: audited route plus all45 frozen consumer/pnpm/context records and provenance.
   Proposed exact root-dev addition3.4.0 has not resolved a lock or installed. The earlier structural
   proposal retained inside audit context is provenance, never the controlling Apple tool plan.
3. `future/native/apple`: current independent Ruby boundary review and its27 public primary sources;
   netrc source/receipt; contextual host/source observations. Current plan and receipt already have
   durable copies. Exclude rejected predecessor plans from the active pickup entry points.
4. `future/react/neutral53`: exact combined53 source, all121 frozen comparison inputs, receipts and
   semantic diff. Source is prepared only. Reconcile against accepted retained source rather than
   copying stale retained/config/package whole files.
5. `future/react/react25` and `future/react/plans`: final selected25 source and concrete handoff,
   plan/partition/dispositions/third-amendment/root-verification/source-review.
6. `future/react/dependency-route`: exact React/ReactDOM/types metadata/public archives/member
   provenance and route. This does not prove a lock delta, installed graph or execution.

## Exact already-preserved owners

| File | Bytes | SHA256 |
| --- | ---: | --- |
| `corrected-toolchain-handoff.md` | 11641 | `ceec42a85c3a5821e491c4463a445c27f0aef4e218546d46b16fb3bf8d5bad3a` |
| `roster.json` | 49767 | `24e50f5b128561ef88525c20472c24af8717053317fa2028b03c05275a12a5e9` |
| `source-intake-receipt.json` | 51623 | `e58f3d2f338eee2f7a559b15f6e96d2f728a9265fe5c241e934d90c5710d4e31` |
| `apple-environment.md` | 13051 | `3302b952b32cf550683437eb073fc852cd50ee7d7c4476972d9b901157450fa8` |
| `apple-successor-receipt.json` | 23028 | `bb6c0cc345b3da4ef4f671359071aec7c2dc980a3681efb66b1992a317de2eee` |
| `android-compile-plan.md` | 8864 | `b7aae25abf7bc6284a2b81dbfa9091339071900c38a2167d71eec61e3a68d213` |
| `template-archive.tgz` | 297906 | `f4457960d6ea35dce4270d8881e42a82e71134964822a15b47549fb8ac44bc96` |
| `template-archive-receipt.json` | 14626 | `20cd2f6cc52081e80281f56f4182227054968bbb3f466e922c3fa98241850e0c` |

## Selection summary

Selected 366 files, 7462805 logical bytes. 363 files (7417862 bytes) lack a byte-identical copy in the existing pause backup. Identity issues: 0. Counts include frozen inputs; they are not counts of completed product work.

## Gaps and continuation constraints

- The ignored pause backup is host-local and not Git durable; a committed transfer note must identify actual durable packaging storage and explicit local-only scope.
- Native70 registration must be composed over the retained accepted source, not replace whole current owners; refresh only current topology proof inputs.
- Combined neutral53 incorporates older retained30 comparison bytes, predating local retained8dd cause preservation. It requires semantic integration into the eventually accepted retained tip, full source/runtime controls and scoped React discovery.
- No reviewed yauzl3.4.0 lock addition, installation or actual installed consumer resolution exists. Original archive receipt is available, but no retained whole yauzl3.4.0 tgz was located in selected current route; actual lock-artifact audit must fetch and verify it anew.
- No Android tool archive/publication/native execution is accepted. Archive20 and the proposed runtime publisher are different units; no extractor/provisioner implementation is present.
- Apple plan pins Node24.16.0/Ruby3.4.11/Bundler2.6.9/CocoaPods1.16.2/xcodeproj1.27.0 and Xcode27.0 compile candidate. Ruby/SSL/libyaml archives, owned gem/pod locks, compiled extensions and iOS16.4 Xcode26.6/runtime mount remain unqualified.
- No neutral React source imports, types, SSR/hydration/browser control, JSX/package installation or candidate performance evidence is established by these packets.
- Stale copied baselines and earlier proposals inside dependency context are historical provenance only. Corrected Apple plan controls; do not promote old Ruby/Bundler/Pods/Xcode pins.
