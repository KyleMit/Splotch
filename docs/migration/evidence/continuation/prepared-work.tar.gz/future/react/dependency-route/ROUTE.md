# Neutral React host dependency route

Prepared on 2026-10-06. This packet proposes the small dependency step for the actual frozen React25/neutral53 caller chain. It does not reopen RNW/RSD selection or certify runtime, browser, cost, CSP/PWA, native, physical, or architecture gates. All retained source packets are unchanged.

## Decision and actual ownership

Add exactly these root `devDependencies`, with exact specifiers:

| Package | Pin | Actual prepared caller |
| --- | --- | --- |
| react | 19.2.3 | ProbeChrome.tsx1 hooks; generated automatic JSX; renderChrome.ts1 createElement |
| react-dom | 19.2.3 | ProbeClient.tsx1/74 hydrateRoot; renderChrome.ts2/36 renderToString |
| @types/react | 19.2.2 | ProbeChrome TSX/hook typing and react/jsx-runtime declarations under the candidate tsconfig |
| @types/react-dom | 19.2.2 | ProbeClient Root type and hydrateRoot options; renderer ServerOptions/identifierPrefix |

Paths are beneath migration/probes/web-host in the bound frozen packets. The existing caller build-web-host.mjs selects neutral-embedded; web-host-react.mjs35–46 invokes the owned compile/render children. The source compiler already uses root Vite 8, configFile:false and Oxc automatic JSX from contract.ts6–10; the client is reached through the single ProbeIsland lazy ProbeClient edge. No Vite React plugin, root Babel, RNW, RSD, React Compiler, @types/scheduler, second package manifest or linker change has an actual caller in this slice.

ADR-0070 owns the split: production dependencies are packages reached by the shipping Netlify build; these experiment-only compile/render/client sources are outside that shipping graph. All four additions therefore belong in root devDependencies. If a future shipping route or build begins consuming this code, that is a separately reviewed dependency-ownership change; do not anticipate it by installing React on Netlify now. ADR-0119 owns pnpm 11.22.0, the one JS lock, hoisted layout and reviewed install-script decisions. Phase 1 unit 7 explicitly authorizes root React/DOM only with this host caller; unit 8 owns later vocabularies/compiler peers.

Direct root declarations prevent reliance on hoisted private-candidate copies. Preserve the candidate's react 19.2.3 and @types/react 19.2.2 pins, Expo 57.0.26 and RN 0.86.3. Do not move or broaden any shipping UI import.

## Baseline and exact released packages

The primary checkout still lacks the candidate manifest; its package/lock/workspace hashes differ from the topology snapshots. The inspected topology and repair trees agree byte-for-byte on package 7348b31a…, lock 705b5762…, workspace eb444062… and candidate 6f95082d…. These are source snapshots, not an invented accepted integrated SHA. Root must record its real combined topology/Kit source and lock before execution.

The topology lock already contains react 19.2.3 (package header5727), @types/react 19.2.2 (2727) and scheduler 0.27.0 (5910), plus csstype 3.2.3 (3570). Fresh exact registry integrities for the first three match those lock records. React DOM and its types are absent from that lock.

Five public exact npm metadata/tarball pairs are retained. Compressed SHA512 SRI and SHA1 both match registry metadata. Every tar member was read as data and hashed; members are canonical relative regular files/directories, without links or special entries. Selected actual manifest/selector/declaration bytes are retained separately. All five packages are MIT; their manifests have no install/lifecycle scripts, bin entries or root binding.gyp. No added allowBuilds permission is needed for this known closure. The script/dependency conclusion is from the full manifests, not package-name reputation.

react-dom 19.2.3 declares scheduler^0.27.0 and peer react^19.2.3. @types/react-dom 19.2.2 peers @types/react^19.2.0; @types/react 19.2.2 declares csstype^3.0.2. Both type manifests declare typeScriptVersion 5.2, below the existing TS 6.0.3; actual type checking is still pending. The retained client.d.ts has identifierPrefix/onUncaughtError/onRecoverableError and hydrateRoot; server.d.ts declares renderToString(element,options) and identifierPrefix. This supports the authored API choice, not successful compilation.

Registry metadata attributes React/DOM/scheduler publishing to react-bot and the type packages to types, with repositories facebook/react and DefinitelyTyped/DefinitelyTyped respectively. No deprecation or attestation field was surfaced. Registry signatures are retained, but not cryptographically verified. The hashes establish exact registry-byte agreement, not a blanket publisher or code-security certification.

## A material peer-resolution caveat

Actual installed Expo 57.0.26 package.json declares optional react-dom:* and the current Expo snapshot lacks that peer. Adding root React DOM can legitimately change Expo's peer-qualified snapshot/importer suffixes and consumers without changing Expo's released archive. RN 0.86.3 directly pins scheduler 0.27.0 and peers react^19.2.3/@types/react^19.1.1.

Expected new artifact identities are react-dom 19.2.3 and @types/react-dom 19.2.2; reuse the existing three React-family artifacts and csstype. Do not preregister an exact line count or demand byte-identical peer suffixes. Inspect the real resolution delta: distinguish dependency identity/integrity changes from peer-context rekeying, verify native React remains19.2.3, and refuse unrelated upgrades/new frameworks or unreviewed hooks. Any genuinely new resolved artifact beyond the audited closure requires its exact released source/metadata audit before normal installation. No override is justified solely to force a desired diff shape.

## Before changing the manifest/lock

1. Accept the first retained-control source/runtime stage and record the actual combined source/lock input. Rebind neutral53 to that source; preserve newer process-group, browserRun/report/cache, kind/mode and Kit-version repairs. The frozen packet is preparation, not a replacement for this integration.
2. Root/Claude review the exact four owner additions with the real neutral production callers and this archive evidence. Check the finite hook/dependency/peer manifests and exact pins against the intended invocation. This packet supplies byte provenance and bounded lifecycle review; it does not assert the entire code/security audit or pending actual lock delta is approved.
3. In the actual isolated source unit, use the reviewed manager/runtime and safe current configuration to author the narrow lock-only delta. Proposed invocation, not executed here:

   `pnpm add -w -D --save-exact --lockfile-only --ignore-scripts react@19.2.3 react-dom@19.2.3 @types/react@19.2.2 @types/react-dom@19.2.2`

   The -w flag assumes the accepted topology workspace exists. Keep packageManager 11.22.0, all other direct pins, candidate manifest, linker, patches and current lifecycle verdicts unchanged. Source owner/metadata derivations must be refreshed as required after actual package/lock bytes exist, never forged from this plan.
4. Inspect the resulting root importer, artifact/SRI set and every changed peer context before full frozen install. Confirm scheduler 0.27.0/csstype 3.2.3 retained or review any actual unexpected delta. Recheck all new archive/lifecycle inputs; preserve the resolution log and before/after owner hashes. Lock-only resolution is not installed-tree proof.

## Frozen install and actual qualification sequence

Use `pnpm install --frozen-lockfile` only after that delta audit. No added package runs a lifecycle hook; existing workspace decisions remain authoritative. Record installed .pnpm/lock.yaml equality, actual React/DOM/types versions and where root/candidate/owned copy callers resolve them. The source's requireFrozenDependencies compares the installed lock before copying, so its accepted lock hash must be the new real one.

Run the narrow real import/type/source controls first, with actual production NODE_ENV and Oxc config; keep the existing development NODE_ENV negative control. Execute the compiler predicate/renderer import binding against released files. Contributing development CJS files must be rejected; dead selector branch strings alone are not participating modules. Do not silence API or generated-union errors with casts.

Then use the actual combined root script graph for check/lint/Quality/tools discovery and the owned retained/neutral release and mechanism callers. Preserve all six real postbuild stages and their strict failure. Actual SSR HTML, matched hydration, intentional recoverable mismatch, dialog lifetime, pre-hydration ink, pixels/history/worker/route-return and cleanup controls remain runtime requirements. Preregistered candidate byte ceilings remain hard; the lazy React DOM cost can fail them. No new diagnostic bypass, cap waiver or eligibility claim is part of this dependency step.

Reproduce a clean/warm production installation through the accepted installer route and a shipping release build: React/DOM/types remain absent from the shipping physical production tree and graph, while shipping startup/byte guards remain unchanged. The newly declared root dev dependencies may alter full-install disk/time, so retain that actual cost separately from candidate runtime cost. The original topology/hosted proof is historical evidence; regenerate only the current owner contract/input inventory and register the actual successor source/proof as required by its existing policy. Do not rewrite any sealed historical proof package or claim its old SHA certifies the new one.

## Current upstream facts and limits

Checked 2026-10-06: [React's version page](https://react.dev/versions) lists 19.3.0 and newer 19.2 patches, so 19.2.3 is a deliberate candidate alignment pin, not latest. The major 19 API docs are maintained across minor/patch versions; exact 19.2.3 archive/declaration evidence is retained to avoid treating newer docs as version-specific proof. No EOL or LTS guarantee was established.

The [current official advisory index](https://github.com/react/react/security/advisories) includes a [July 2026 server-functions DoS](https://github.com/react/react/security/advisories/GHSA-wx67-qw84-cm4g), plus earlier RSC advisories. The July advisory names react-server-dom-webpack/parcel/turbopack, with patches 19.2.8; the [January notice](https://react.dev/blog/2025/12/11/denial-of-service-and-source-code-exposure-in-react-server-components) names the same RSC package family. This host imports ordinary react-dom/server for an owned build-time renderToString child and adds no Flight/RSC plugin, react-server-dom package, Server Function endpoint or react-server condition. That source boundary is why those notices do not automatically require silently bumping this pinned pair. It is not a claim that every 19.2.3 use is secure; audit the actual finalized lock before installation/publication and revisit if the production graph gains RSC.

The boundary remains concrete: exact pins and lifecycle/package provenance support the next dependency step, while actual lock resolution, installations, compilation, production exclusion, hosted execution and UI/performance acceptance are pending. This investigation read source and public registry/docs only. It made no repository/worktree change, package install/import, test/build, Git/site operation or native acquisition. A first sandbox registry read failed DNS before capturing bytes; the successful public-only retry ran with host network access and retained the evidence here.
