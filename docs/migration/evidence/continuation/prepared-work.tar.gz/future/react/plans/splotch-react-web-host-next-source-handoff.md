# Neutral React web slice: next source handoff

This is a concrete implementation handoff of the accepted unit7 plans, not another architecture or
planning review. Governing inputs are the current slice plan, implementation partition and review
dispositions, bound by the third-amendment receipt and root verification. Read their full receipts
rather than treating abbreviated identifiers as execution inputs. First-slice source repairs are
separately owned and not certified by this note.

## Entry and preparation boundary

Root supplies the real accepted topology05 commit/lock and accepted first-slice commit/evidence.
Rebase onto those actual results before integrating into the web-host worktree; record the resulting
source/lock identities. First-slice ordinary/reference/control release and mechanism builds,
isolation/source/graph guards and real ink/early-adoption browser controls must execute before this
slice's dependent runtime work. Cloud05 production proof remains independently required but does not
block source preparation or structural compilation already allowed by the contract.

After the first slice is accepted, all new host/src/test helpers below can be prepared without
installation or execution. Integration edits to existing contract/wrapper/CLI/receipt readers must
start from its accepted repaired bytes, not the frozen22-source predecessor. Root retains manifest/
lock/dependency-audit/install/workflow ownership unless reassigned explicitly. No new worktree,
package installation, source import, build or browser is authorized by this private handoff.

## Actual call chain and file ownership

All new source below is under migration/probes/web-host unless otherwise named. No shipping web
route/config/engine/state/storage/API/admin/PWA/native source is changed.

| Maintained source                                | Actual caller and narrow implementation                                                                                                                                                                                                                                                                                                                   |
| ------------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| host/contract.ts                                 | Existing build/check/serve/test/wrapper readers gain the implemented neutral-embedded variant and closed matching/text-mismatch fixture vocabulary. Release refuses mismatch; all callers refuse PERF_MARKS=true. Own one React-free automatic/development=false/importSource=react JSX value.                                                            |
| host/pageOverlay.ts                              | Neutral wrapper's enforce-pre load transforms only canonical owned-copy web/src/routes/+page.svelte. Insert island import immediately after static earlyBoot import; insert island markup immediately before bottom-dock as its sibling. Require unique exact anchors, deny query submodules, record both original/transformed hashes in both Kit passes. |
| host/renderChrome.ts                             | Neutral copied-build caller compiles the real TSX server renderer with Vite configFile=false before either Kit pass, then invokes the compiled renderer as the owned production child. Use existing allowlisted child/environment/source and output owners; no package import from an active checkout fallback.                                           |
| host/serverStore.ts                              | renderChrome injects the shared immutable pending getServerSnapshot/store into ProbeChrome. This pure module imports no Kit aliases, Svelte/runes/bridge/modal or browser global.                                                                                                                                                                         |
| host/chromeHtml.ts                               | Real renderer writer and neutral wrapper readback share the closed generated-HTML validation: remove only named exact `<!-- -->` separator, then reject residual raw `<!` or `<?`. Bind HTML bytes/hash/props/prefix/render receipt; no general parser or whole-Kit restriction.                                                                          |
| src/probeProps.ts                                | React-free closed props/store types, immutable pending snapshot and identifier prefix are imported by server, TSX and static Svelte island. No TSX value/runtime import enters the island graph.                                                                                                                                                          |
| src/ProbeChrome.tsx                              | Real renderToString and hydrateRoot render the same token-styled swatch, theme button, read-only drawing-state text and dialog opener. useSyncExternalStore receives the injected store; every action calls its owning bridge method. No copied engine/settings/Settings UI.                                                                              |
| src/ProbeIsland.svelte                           | Static overlaid route caller owns an outer element, inner only-child immutable {@html} container and raw sibling dialog. Its synchronous onMount starts only import('./ProbeClient'), returns cancellation/disposal immediately and denies a late mount after exit. No static React/modal import or second lazy edge.                                     |
| src/ProbeClient.tsx                              | Single lazy entry statically imports hydrateRoot, ProbeChrome, actual bridge and late modal binding. Validate current connected nodes, attach dialog owner before enabling opener, inject store/prefix and hydrate only the inner boundary. Compose one cleanup for root/bridge/modal/listeners; onRecoverableError is real, never fabricated.            |
| src/probeBridge.svelte.ts                        | Route factory reads actual appearanceState and canvasState, maintains a stable immutable cached snapshot and subscribes inside its own $effect.root. Theme toggling reads current owner and calls setResolvedTheme. Canvas stays read-only; no appearance install or mirror writer.                                                                       |
| src/probeModal.svelte.ts                         | Deferred client caller reuses app-scoped createModal and actual exported modalDialog action under a route-owned $effect.root; return action.destroy. Own Close/refusal/nested-Settings listeners and retire them. Existing settingsModal/buttonCenter/Back coordinator retain their behavior.                                                             |
| src/probeDiagnostics.ts plus scoped declarations | Only deferred ProbeClient's actual mechanism mount/adoption/recovery/disposal caller publishes the finite diagnostic vocabulary. Release eliminates it. No earlyBoot observer, engine reader or PERF marker added.                                                                                                                                        |
| src/probe.css                                    | Island's critical prefixed styling uses existing design tokens, preserves paper ancestors and palette/Clear/Actions/Settings hit areas, and keeps Settings last button[id]. Added area and encoded CSS are costs.                                                                                                                                         |

Keep raw dialog outside React, and every input/paper/normal/bottom/top tile plane outside ALL React
roots/portals. Reuse existing modal show/hide/retirement/refusal state instead of a second stack.
OnClose re-queries the recovered connected opener, requires a live retired binding and no other open
dialog, and must not steal focus after route departure/nesting. Route disposal retires its
binding/listeners without hiding app-scoped modal state; return binds the new nodes to that state.

## Bounded existing owner extensions

* tools/migration/build-web-host.mjs and lib/web-host-build.mjs dispatch the implemented neutral
  caller only after request/source/lock/copy checks, run SSR production preparation first, then
  unchanged real Kit through the candidate wrapper. Preserve retained reference/control behavior.
* host/vite.config.ts branches only on the validated named experimental build variant. Neutral
  merges the shared Oxc JSX value and actual overlay/HTML/receipt helpers; shipping config remains
  unchanged and sveltekit() still reads its actual host configuration/routes. Preserve source,
  externals, cache/temp and artifact-readback guard repairs from the accepted first slice.
* Existing lib/web-host-artifact.mjs/evidence readers bind new SSR/HTML/props/prefix/overlay and
  both real pass records to maintained source and actual output. check/serve/test still authenticate
  source and installed runtime before any child executes. Do not build a parallel receipt system.
* Add tools/migration/lib/web-host-seams.mjs only for neutral build/check callers. Derive finite
  diagnostic tokens from actual maintained TSX/diagnostic sources, require source/graph membership
  and real release absence/mechanism presence in emitted client JS/HTML. Shipping seam owner stays
  unchanged. Real omission/token mutation/recomputed inventory/checker inversion must fail.
* Give all six shipping postbuild owners their accepted neutral dispositions. Release seams,
  build-version, PWA-precache and static --web remain hard. Reuse bundle measurements/exported
  ceilings plus eagerErrorStartupBytes' linked/error union in the strict candidate budget. Invoke
  eagerErrorResources separately as a hard named-deferred-owner/root-error-closure check.
* Preserve the strict candidate budget's actual nonzero result as its own failure/status/log. The
  preregistered ReactDOM largest-lazy failure grants no waiver, passing aggregate, eligibility or
  performance conclusion. Retained controls still use untouched exact shipping guards.

## Production React and HTML evidence owners

The denial set is the exact7 installed React19.2.3 and11 retained ReactDOM19.2.3 development CJS
files listed in the accepted slice plan. Extend actual contributing client/Kit-server/SSR module and
import readers, including resolved external edges; bind emitted outputs to their contributing
source. Reject real contributing/resolved development files and denied emitted module references. A
selector entry's DEAD conditional string naming both production and development files is NOT a
development contribution; do not scan arbitrary package source text and reject its inert branch. A
filename-only minified byte search cannot prove production either. The renderer receipt records
actual loaded/resolved CJS paths/hashes after real renderToString inside the owned tree. Production
and wrong-NODE_ENV builds/render controls remain future runtime results, with JSX automatic and
development=false held constant; the latter must fail on real dev selection, not jsx-dev-runtime.

The initial prerendered inner container, observed BEFORE Svelte hydration, must have exact first/
last empty Comment children and no empty Comment between them, including descendants. A standalone
generated React fragment has none. The injected interior `<!-->` fixture must fail the real reader.
React recovery may remove its inner Svelte delimiters/opener. Immutable HTML/no later Svelte write
is mandatory; actual repeated recovery/route teardown must prove detached-anchor/root cleanup. Do
not demand initial server markers after recovery or a client-only remount.

## Authored checks and integration evidence

Extend existing tools/migration/tests/web-host-build.test.mjs or a purpose-specific sibling for
actual request/overlay/HTML/source/SSR receipt controls, including writer then recomputed-reader
mutation. Add candidate tests/host-release.spec.ts (scenario1), host-lifecycle.spec.ts (2–4) and
host-modal.spec.ts (5) to the existing explicit artifact-bound Playwright caller. Reuse real current
renderedCanvasHandle/pixels/draw/Undo/navigation/retry helpers and named timeout owners.

Scenario2 holds actual layout hydration, proves ink/all-plane identities with __drawingDebug absent,
then adoption/history and real Undo. Scenario3 holds the one ProbeClient entry, draws/commits after
Svelte adoption, settles backingMigrationPending/history and brackets ONLY unrelated mismatch
recovery with equal paper identities/dimensions/pixels/history. Scenario4 observes real workers/
Magic delayed assets and route-return; theme/asset publication occurs after that equality bracket
and must produce its legitimate outcome. Scenario5 covers Close/Escape/backdrop/refusal/nested
Settings/Back/focus, async cancellation and open-modal route-return with existing sole owners.

Add actual TSX/Svelte/spec inputs to scoped tsconfig with jsx=react-jsx; tsc plus svelte-check
--fail-on-warnings run after owned-copy sync. Reconcile actual stacked Knip/ESLint/discovery/CI/path
filters without widening shipping JSX or production entries; applicable positive guards must fire.
No uncalled package/config/framework is added. ReactDOM19.2.3 and actual React/DOM types are
root-dev callers; actual05 React identity, changed lock closure and full lifecycle archive audit
precede normal install. No React plugin/RNW/RSD/Babel/compiler/PostCSS dependency is introduced.

Finally preserve complete whole-host HTML/CSS/eager/deferred/request/count/error-union costs,
including duplicated prerender HTML in index.html and client remount JS. Applicable source checks,
real Chromium plus required Firefox/WebKit coverage, full tiers, screenshots and exact-head Claude
source review occur when root authorizes/schedules execution. This slice reports individual passes,
failures and pending exits honestly. Deployed CSP/admin/PWA/credential scenarios6/7, cloud05 proof,
physical/native floors, vocabulary/product parity and architecture selection remain later gates.
