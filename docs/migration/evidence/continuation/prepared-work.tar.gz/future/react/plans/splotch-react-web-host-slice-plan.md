# Unit7 second slice — actual React chrome in the retained web host

## Boundary and execution inputs

This implements the second executable partition of the reviewed neutral host plan; it does not
reopen architecture or choose RNW/RSD. The first partition currently has prepared source only. Its
source packet, overall plan, review dispositions and partition are the governing private inputs.
This private amendment incorporates all five Claude f037cee5 findings, the two source-confirmed
recovery/seam corrections, all three subsequent 2207177f corrections and the e956dc0f precision
amendments below. Exact third-round bodies are preserved in *-reviewed-original-e956dc0f.md; the
submitted question and earlier snapshots remain unchanged. Exact second-round reviewed
plan/partition/dispositions are preserved in *-reviewed-original-2207177f.md snapshots. The exact
original plan, partition and question are preserved in sibling *-reviewed-original-f037cee5.md /
*-original-f037cee5.md snapshots; that initial review remains a review of the predecessor and
original text, not of this amendment. Primary source inspected at
e5ab28af553a55841aac35c938fc7b0e19ec9ba7; prepared web worktree is based on
d1402f6b2bedd2c30cbc88d30597466855b33874, which is NOT a topology05 result.

Before dependent runtime work, record actual reviewed05 commit/lock, rebase the first slice, finish
its discovery/CI ownership, and execute its release/mechanism retained controls and applicable
checks. Require real owned-copy isolation, unchanged shipping/control output comparison and browser
ink/early-adoption evidence. Then record the accepted first-slice commit and new slice commit/lock.
All those execution inputs/results remain PENDING here. This amendment is private planning only; no
second-slice checkout edit, install, materialization, build, test, server, native tool or Git
mutation ran. The earlier authorized first-slice source corrections are recorded in its packet.
Pending topology cloud proof does not block independent structural work; topology acceptance and
merge obligations persist. Unit7 cannot merge ahead of05 or infer product/foundation eligibility.

Keep shipping route/config/pre/postbuild/native trees and production dependency classification
unchanged. Paper remains outside all React roots/portals. Real API/admin/CSP/PWA/credential owners
stay in the actual host. Scenarios6/7, vocabulary comparisons, product ownership moves and all
physical/performance/release gates remain their existing later obligations.

## Selected smallest integration and alternatives

Add one static-imported ProbeIsland to the actual `/` page. Its inner root contains build-time React
HTML: a token-styled swatch, theme action, live drawing-state text and named-dialog opener. A raw
HTML dialog remains its Svelte sibling. React reads real state and calls existing writers; there is
no React drawing engine, duplicate persistence or replacement Settings UI.

* Select build-time renderToString followed by real hydrateRoot. Hand-authored HTML or createRoot
  cannot prove React prerender/hydration. Per-request React SSR unnecessarily changes `/`'s SSG.
* Select a route-scoped cached snapshot factory over the existing rune owners. A second settings
  store duplicates write/ordering rules; a generic cross-framework adapter has no present caller.
* Keep the reviewed deferred client edge. Eager React moves known runtime cost onto startup and is
  not authorized in this additive slice. Structural mechanics may pass while budgets fail.
* Keep the existing copy/wrapper host. A second Kit configuration/routes app would duplicate
  services and routing; a new shipping probe route would alter production import/deploy surfaces.

The extra fixture's DOM, hit area, HTML/CSS/runtime bytes, retained Svelte and ongoing ownership are
actual costs. This is not a matched full React drawing screen or a parity/performance result.

## Exact callers, packages and maintained sources

Use root devDependencies only: existing React19.2.3 identity, ReactDOM19.2.3, @types/react19.2.2 and
@types/react-dom19.2.3. Do not add @vitejs/plugin-react: this slice has only production build
callers and Vite8.3.1 already transforms TSX with built-in oxc. Confirm the actual05 manifest/lock
before adding anything; avoid redundant React pins. Before normal install, verify exact registry
integrity, peer resolution and lifecycle scripts for every newly reached archive against the
reviewed audit. No blanket allowBuilds, Babel/compiler, RNW/RSD, PostCSS or workspace. Candidate
CLI/SSR/client are the actual callers. One shared React-free host/contract.ts constant is exactly {
runtime: 'automatic', development: false, importSource: 'react' }; apply it to oxc.jsx in the
configFile=false SSR config and neutral-embedded wrapper. Keep scoped jsx=react-jsx;
retained-control/ shipping configurations stay unchanged. Actual Vite8.3.1 build environments set
isBundled from isBuild (dist/node/chunks/node.js:37100–37104); :7598–7614 passes resolved config.oxc
to Rolldown's native viteTransformPlugin. :37401/:37503–37508 derives development from NODE_ENV
unless explicit; :37256–37262 preserves an inherited NODE_ENV. The earlier esbuild/scanner citations
do not establish this build path. Revalidate one React identity, frozen lock and production install
boundary.

| Source under migration/probes/web-host                          | Actual caller and responsibility                                                                                                                                                 |
| --------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| host/contract.ts and existing wrapper                           | Extend closed variants to retained-control/neutral-embedded and named matching/text-mismatch fixtures; validate copy/artifact ownership.                                         |
| host/pageOverlay.ts                                             | Wrapper loads only exact canonical +page.svelte, preserves all other bytes and records both-pass overlay/source hashes.                                                          |
| host/renderChrome.ts + host/serverStore.ts + host/chromeHtml.ts | Copied builder compiles/runs actual React server renderer before Kit, with pure injected store, validated HTML and owned output; the wrapper reuses the HTML guard.              |
| src/probeProps.ts                                               | React-free props, initial pending snapshot, identifier prefix and closed store contract imported by server/TSX/Svelte.                                                           |
| src/ProbeChrome.tsx                                             | Server/client render the same small component; useSyncExternalStore reads injected snapshots and invokes bridge methods.                                                         |
| src/ProbeClient.tsx                                             | The single dynamic module statically imports hydrateRoot and ProbeChrome, injects the bridge and adopts shared prefix/props; real mechanism diagnostics are its deferred caller. |
| src/ProbeIsland.svelte                                          | Static caller owns outer/inner containers, immutable controlled HTML, raw dialog, synchronous onMount loader/cancellation/cleanup.                                               |
| src/probeBridge.svelte.ts                                       | Route-scoped factory reads existing appearance/canvas getters and publishes stable immutable snapshots; owns only its subscriptions.                                             |
| src/probeModal.svelte.ts + src/probe.css                        | Deferred ProbeClient calls app-scoped createModal and route-scoped real modalDialog binding inside $effect.root; token CSS remains critical.                                     |
| src/probeDiagnostics.ts + scoped declarations                   | ProbeClient records only actual mechanism mount/adoption/recovery/disposal events through the finite candidate diagnostic global; no early observer.                             |
| tests/host-*.spec.ts + scoped declarations/config               | Actual artifact-bound scenarios1–5, negative controls, TSX/Svelte checks and screenshots.                                                                                        |

Reuse tools/migration/{build-web-host,check-web-host,test-web-host}.mjs and their existing lib/
source/copy/metadata/child/artifact/evidence owners. Add only neutral build/evidence helpers where
an actual caller needs them. The maintained directory is host/, not ignored build/.

## Build order and source-bound HTML

Extend the existing builder with a fixed neutral candidate copy; preserve ordinary reference and
retained-wrapper control builds through their current owners. All copies use the same frozen
committed source/lock/pinned metadata and independent destination inodes; preserve verified internal
pnpm links and prove no borrowed cache/output writes. No source execution fallback.

In the candidate copy: actual prebuild generators -> child-owned programmatic production Vite SSR
build -> child-owned renderer execution -> actual Kit build via candidate wrapper -> existing owner
checks below -> scoped types and separate strict candidate budget report. Both SSR compilation and
renderer execution use runCopiedChild with copiedBuildEnvironment plus explicit NODE_ENV=production,
set before Node loads Vite or React; never call production Vite build in-process from Vitest's
NODE_ENV=test. Use that same environment for neutral Kit passes. Record/validate mode=production,
process NODE_ENV, config.isProduction and resolved config.oxc.jsx in SSR and both Kit pass receipts.
Require the exact shared JSX fields. Reject jsx-dev-runtime AND the exact React/ReactDOM19.2.3
development CommonJS file set recorded below in actual contributing client, Kit-server and
configFile=false SSR module/import graphs, including resolved external/static/dynamic edges. Read
actual emitted output for their denied file/import references and bind that output to its real
contributing-module inventory; missing graph/source records fail. A minified file need not retain
source filenames, so a filename byte search alone cannot certify production. The renderer child
additionally records actual loaded/resolved React/ReactDOM CommonJS files, their canonical owned
paths and hashes after real renderToString, and rejects this development set even when a bare
external entry was allowed. Selector entry files may contain both conditional names on disk; their
source presence is not a claim that a development module contributed or loaded. Reuse the current
graph/output and renderer receipt owners, not a new adapter framework.

The NODE_ENV=development negative control keeps automatic JSX and development=false, runs the actual
owned fixture build/renderer and must fail specifically on its real development React CJS
module/file selection as well as the environment receipt. It must not rely on jsx-dev-runtime, which
stays absent in that control. Valid production artifacts and renderer selections are the positive;
injected development-module graph/output and changed renderer-file receipts also fail the actual
reader. This is authored acceptance, not executed evidence. Pure SSR TSX imports no $lib/.svelte.ts;
inject serverStore and keep dependencies inside the owned tree. The wrapper loads only actual
overlay/HTML/receipt helpers for neutral-embedded.

The finite denial set is tied to React19.2.3 installed source and the newly retained exact public
ReactDOM19.2.3 archive, not a recollection of the 19.x layout. Full future install/lock-delta
archive approval remains separate and pending. A package/version/source change requires revalidation
of this set; do not silently broaden a glob or call this source read an install audit.

React19.2.3 development CJS files (actual installed topology source):

```text
react/cjs/react-compiler-runtime.development.js
react/cjs/react-jsx-dev-runtime.development.js
react/cjs/react-jsx-dev-runtime.react-server.development.js
react/cjs/react-jsx-runtime.development.js
react/cjs/react-jsx-runtime.react-server.development.js
react/cjs/react.development.js
react/cjs/react.react-server.development.js
```

ReactDOM19.2.3 development CJS files (exact integrity-verified public registry archive):

```text
react-dom/cjs/react-dom-client.development.js
react-dom/cjs/react-dom-profiling.development.js
react-dom/cjs/react-dom-server-legacy.browser.development.js
react-dom/cjs/react-dom-server-legacy.node.development.js
react-dom/cjs/react-dom-server.browser.development.js
react-dom/cjs/react-dom-server.bun.development.js
react-dom/cjs/react-dom-server.edge.development.js
react-dom/cjs/react-dom-server.node.development.js
react-dom/cjs/react-dom-test-utils.development.js
react-dom/cjs/react-dom.development.js
react-dom/cjs/react-dom.react-server.development.js
```

All six shipping package.json:31 postbuild owners have an explicit neutral disposition:

| Existing owner                             | Neutral disposition                                                                                                                                                                                                                                                                                                                                                                     |
| ------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| tools/check-release-seams.mjs              | Invoke unchanged classified owner; source/build integrity stays hard. Add the separately scoped candidate diagnostic byte owner for actual TSX callers.                                                                                                                                                                                                                                 |
| tools/check-build-version.mjs              | Invoke unchanged web check; client/server/version/manifest agreement is hard.                                                                                                                                                                                                                                                                                                           |
| tools/check-pwa-precache.mjs               | Invoke unchanged; worker/precache/source integrity is hard.                                                                                                                                                                                                                                                                                                                             |
| tools/mobile/check-static-bundle.mjs --web | Invoke unchanged; native-code exclusion and required web output contracts stay hard.                                                                                                                                                                                                                                                                                                    |
| tools/check-bundle-budgets.mjs             | Reuse measureWebBundle/exported ceilings in the strict candidate checker: at-most web preload count, startup and largest-lazy byte gates. Do not invoke or alter its exact shipping-count CLI for neutral.                                                                                                                                                                              |
| tools/check-eager-error-bundle.mjs         | Call exported eagerErrorResources on the real emitted client manifest as a HARD gate, including required named deferred chunks and forbidden root-error closure. Reuse eagerErrorStartupBytes/startupResourcesFromHtml to report the complete linked+error byte union in the strict candidate budget gate. Do not classify the combined CLI as budget-free or skip its structural part. |

Reference/retained controls still run their unchanged full postbuild. Record every structural owner
exit independently and preserve the strict candidate budget's actual nonzero result (expected lazy
failure, plus any other measured failures). No owner/check CLI changes, instrumented-budget waiver
or green aggregate follows. Missing/folded named modalDialog chunk or an eager root-error import is
a hard structural failure to investigate, not an accepted retained-Svelte cost. Retained-control
stays React-free and uses the unchanged copied host.

Use one candidate-only virtual module for immutable generated HTML, with a scoped type declaration.
The generator records props/prefix/source/HTML hashes; the wrapper reads only its owned generated
receipt and validates them before either Kit pass. ProbeIsland imports that React-free module, not
TSX. This avoids a maintained placeholder or generated checkout edit. New SPA instances seed fresh
containers from the same client string, so count HTML bytes in index.html AND client JS. Before
writing the generated receipt, renderChrome calls shared chromeHtml; the wrapper uses that same
guard on readback before Kit. Name the allowed nonempty marker PROBE_TEXT_SEPARATOR_HTML_COMMENT
with value `<!-- -->` in chromeHtml.ts; both real callers use that owner. Remove only that exact
marker for validation, then reject residual raw `<!` or `<?` with /<!|<\?/. No other declaration/
comment vocabulary has a present caller. This is a closed producer contract, not a general HTML
parser or promise of future comment compatibility. This rejects `<!---->`, `<!-->`, `<!--->` and
malformed equivalents such as `<!----!>`, rather than claiming one literal covers empty Comment
nodes. React escapes ordinary text/attributes; declarations/Suspense markers are not part of this
fixture. Future vocabulary requires its actual caller and reviewed contract, not a broad parser
dependency. Scope the guard only to generated React HTML, never the whole Kit document containing
legitimate Svelte delimiters. Svelte5.57.1 server/blocks/html.js:9–10 uses empty OPEN and CLOSE
markers in production; client/dom/blocks/html.js:112–122 stops at the first empty Comment. The
generated React fragment guard does not remove those Svelte-owned markers. The HTML Standard's
comment-start/start-dash/end states define the requested equivalent forms. Actual renderToString
output and its nonempty separators are positives. Each of the three requested spellings, malformed
close `<!----!>`, bogus `<!>` and declaration injection fail via the real writer; every contaminated
HTML receipt with recomputed hash fails the wrapper reader. For the initial prerendered container
BEFORE Svelte hydration, the browser reader requires exact first and last child nodes of type
Comment with data==='' (Svelte's two production delimiters), then rejects every empty Comment
BETWEEN them, including descendants of those interior nodes. A standalone parsed generated React
fragment has no empty Comment at all. The valid actual SSR container is the positive; injecting
`<!-->` into its interior must fail the real browser reader. Do not ignore all empty comments, apply
this assertion to the whole Kit document, or demand the initial-server delimiter shape after
recovery or a client-only SPA remount. Record the virtual module/ imports in both-pass inventories;
no executable inline script enters prerendered HTML. Actual version/UUID/tag history remain existing
buildVersion/PWA behavior, with the first-slice pinned metadata and permitted comparison
normalization only.

The overlay requires unique exact anchors: insert ProbeIsland import immediately after static
`import '$lib/drawing/earlyBoot';`, and markup immediately before `<div class="bottom-dock">`. Use a
copy-relative source import to the maintained island. Current route anchors are lines7/232, not
historical line numbers. Do not overlay query submodules or wrap/change DrawingCanvas ancestors. All
added button[id] occur before Settings; first-paint.spec.ts:147–150 remains authoritative. Record
original/transformed hashes, identical SSR/client transform and unchanged retained owners. Critical
prefixed CSS must use existing tokens, preserve palette/Clear/Actions/Settings hit regions at
supported layouts and report the added fixture area. No shipping token/layout redesign.

## Actual state, hydration and teardown contracts

The initial server snapshot is a closed pending state, never invented theme/stroke values. Static
swatch colors use the existing pre-paint CSS tokens. Client getServerSnapshot returns that same
immutable initial object; getSnapshot returns a stable cached live snapshot from actual owners. The
bridge initializes its live snapshot, tracks rune getters in a scoped $effect.root and publishes
only on field changes; never allocate a new object on every getSnapshot call. Cleanup retires its
root/listeners. Appearance methods read the current owner when toggling, then call setResolvedTheme;
canvas fields are read-only. React cannot call canvas mirror writers or install appearance effects.
Sources: appearance.svelte.ts:33–42,84–87,120–129; canvas.svelte.ts:14–38,58–93.

ProbeIsland's onMount is synchronous: begin only import('./ProbeClient'), return cancellation/
cleanup immediately, and reject late mount after route exit. ProbeClient statically imports
hydrateRoot from react-dom/client and ProbeChrome; Vite owns preloading that edge's dependencies.
Record the single deferred entry and cancellation controls; do not add a second ReactDOM entry.
ProbeIsland's static graph contains no React/JSX/useSyncExternalStore runtime. HydrateRoot owns only
the inner content and uses the same props/prefix. A completed React effect plus real theme/opener
event proves adoption.

Immutable {@html} is the inner container's ONLY child with no reactive dependency or later write.
Verify Svelte's controlled HTML compile path. React owns everything inside its inner boundary,
including the initial Svelte HTML delimiters and opener. Whole-root recovery may remove those
delimiters; re-query the live opener rather than preserving inner anchors. Recovery may not replace
the outer container, dialog, paper/input or tiles. Immutable only-child HTML must have no later
Svelte write that would revisit removed anchors. Real repeated recovery/route fixtures must prove
React unmount, subscriptions and Svelte teardown tolerate detached inner anchors/container and
cancel late imports; this is a required result, not a source-proven teardown promise. No new
beforeNavigate hook. A new route instance legitimately seeds fresh HTML before its own hydration.

Keep the modal factory app-scoped, like ui.svelte.ts, and binding/DOM listeners route-scoped, but
keep their runtime imports behind the SINGLE ProbeClient edge. ProbeIsland renders a raw dialog
without a static use:modalDialog import; it passes its actual dialog/inner-container nodes to the
late ProbeClient mount. Deferred probeModal.svelte.ts calls the existing exported modalDialog inside
$effect.root, returning action.destroy from the root; its disposer is composed into the mount's
single cleanup. The function is compiled through the copied Kit Svelte path, not executed as raw
runes by the separate pure Node SSR renderer; that renderer's imports cannot reach probeModal. This
is the existing owner test pattern (modalDialog.svelte.test.ts:19–25,359–366), not a second dialog
implementation. Root creation permits effects after asynchronous import; calling modalDialog
directly without that root would be invalid. Late mount requires connected, current nodes;
cancellation and setup/hydration failure dispose any attached root/listeners.

ProbeClient attaches the dialog owner before hydrateRoot enables the real opener. Route-owned Close,
refusal-checkbox and nested-Settings DOM listeners are installed by this deferred binding, with
cleanup; no static island import/back-edge may reach it. createModal open state survives SPA
remount, while old route cleanup retires effects/animations, removes listeners and forgets its real
stack entry. React opener uses existing buttonCenter and createModal.show; owner retains showModal,
launch guard, dismissal/refusal and retirement. Nested Settings uses existing settingsModal.show and
the sole webBackHandler; no extra stack/coordinator. OnClose checks the binding is live, dialog is
retired and no other dialog[open] remains, then re-queries a connected opener in this current inner
root after recovery; it does not steal focus from a nested dialog or departed route. Cleanup first
marks the binding disposed, composes React unmount/bridge cleanup and modal root/listener
retirement, and never hides the app-scoped modal merely because the route exited. Exercise refusal,
exit races, actual nested Back, recovered opener and open-dialog route-return.

Alternatives: a static Svelte use:modalDialog would add a demonstrated deferred-owner import to the
startup graph (systemBack.ts:27 loads webBackHandler lazily; it imports modalDialog). Preregistering
that eager move is unnecessary while the real owner's effect-root invocation is available. A new
React dialog/stack or an extra async Svelte-component loader duplicates ownership or adds a second
entry. Select the one-edge late real-owner binding; preregister its unchanged hard deferred-owner
expectation, with actual chunk identity/closure/request and lifecycle evidence still pending. No
preload-count or structural guard waiver is authorized. Sources: modal.svelte.ts:25–41;
modalDialog.svelte.ts:45–53,82–95,278–325,332–370; boot/webBackHandler.ts:3,139;
boot/systemBack.ts:27; ADR0049/0168; official $effect.root manual-cleanup contract.

## Registered artifacts, scenarios and controls

Require the fixed unit7 builder/wrapper to reject PERF_MARKS=true before build work; SSR and both
Kit pass readers must require marks=false. Add a real request/wrapper negative control for true
while the existing false release/mechanism controls pass. Vite8.3.1:37469–37472 ignores shipping
esbuild options when explicit oxc is present, so no speculative keepNames merge or profiling caller
is introduced. A later performance artifact needs a separately reviewed actual caller and effective
profiling setting; this slice cannot accept it.

Release: neutral matching and retained matching, PERF_MARKS=false/harness=false. Mechanism: neutral
matching and neutral text-mismatch plus retained mechanism, PERF_MARKS=false/harness=true. Text
mismatch is a finite build fixture, forbidden in release; it changes only initial React text. There
is no new early owner observer in either artifact. Existing shipping __drawingDebug stays absent
before adoption and is the only post-adoption drawing history/work reader. The deferred ProbeClient
owns real mechanism React diagnostics; it cannot move imports onto earlyBoot.

Add tools/migration/lib/web-host-seams.mjs, called by the neutral copied build immediately after Kit
and the individually registered shipping structural checks above, and by check-web-host readback. It
validates the actual graph/source ownership for src/ProbeClient.tsx and src/probeDiagnostics.ts,
derives the finite private global/event tokens from those maintained sources (including TSX), and
scans actual emitted client JS/HTML. Release requires every candidate diagnostic token absent;
mechanism requires their real reachable bytes present. Unknown emitting source/token or omitted
ownership fails. Drive its actual reader with valid built artifacts and an injected
retained-diagnostic release fixture with recomputed inventory; invert the checker to prove failure.
Fake recovery-event publication still fails the browser recovery scenario. Existing
tools/check-release-seams.mjs and its shipping list remain unchanged; its finite source list does
not cover candidate TSX. Receipts bind the candidate seam gate, fixture,
source/lock/props/prefix/HTML/outputs and actual build/child/check exits.

| Scenario                  | Actual proof and controls                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| ------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1 release prerender/seeds | Actual React HTML/critical CSS before JS; original topology and Settings sentinel; cold/returning light/night versus opposite OS, bare/flat, drawer, hidden controls, scale, reduced motion, storage denial, orientations. Valid hydration + real event, no private seams. Seed/style-removal fixture must fail first-paint geometry/color.                                                                                                                                                                                                                                                                                                                                                                 |
| 2 mechanism early ink     | Hold the actual layout chunk as engine-fallback-replay.spec.ts:16–18 does. Require __drawingDebug absent, real pointer acceptance and visible composite ink before adoption; capture every receiver/normal/bottom/top reference plus dimensions/pixels without adding an early engine reader. After adoption use existing __drawingDebug.getUndoDebug and real Undo to prove that accepted stroke belongs to history and is removed. Compare earlyBoot/input/import ordering against the same-config retained control. Clone/missing-tile/eager-runtime fixtures must fail.                                                                                                                                 |
| 3 mechanism real recovery | Hold the single dynamic ProbeClient entry; Svelte adopts and a real pen stroke commits. Settle actual history/backing migration, then capture every paper identity/dimension/pixel and history. Release text mismatch and require real onRecoverableError/recovered text with those witnesses unchanged during only unrelated recovery, without deliberate owner changes, rotation or asset publication. Matching hydration has zero recovery. Subsequently trigger the real theme action/opener and require the expected owner/art/Magic outcome and Undo ownership; theme-driven pixels need not remain unchanged. Fake callback/inert root, paper inside recovery root and later HTML rewrite must fail. |
| 4 mechanism route/worker  | Actual Kit /privacy/return in same document retains ink/history/Undo, with legitimate new paper nodes on remount. Repeat visits/rotation/late import cancellation prove one root/bridge/engine lifecycle. Use actual Magic UI, delayed canonical asset completion and browser worker handles across unrelated recovery; later real reveal/page/Undo outcome must settle. Actual worker retirement/duplication or lost late result fails.                                                                                                                                                                                                                                                                    |
| 5 mechanism dialog/Back   | Real opener, explicit Close/Escape/backdrop, refusal, nested Settings, exit races, recovered-opener focus and open-dialog route-return. Fine/coarse/standalone Back closes top dialog, preserves refusal, consumes ink guard once, then navigates normally. Actual stale entry/duplicate-coordinator fixtures must fail; durable hydrated readiness, not transient visibility.                                                                                                                                                                                                                                                                                                                              |

Worker witness qualification: magicWorkWitness.ts:24–32 and magicSheetRasterClient.ts:183–192 return
null when PERF_MARKS=false. Do not assert their counters exist or enable marks to rescue this
artifact. Observe actual Playwright worker handles/events and emitted worker module provenance.
Pause the single ProbeClient entry to establish a real worker via shipping Magic controls before
initial recovery; hold an actual fill/overlay fetch outside the recovery-only witness bracket.
Recover and prove identities/settled existing ink/history unchanged, then release publication and
assert its expected real pixels/page/Undo changes. Do not compare unchanged pixels across that
intentional publication or the later theme toggle. After Svelte adoption, existing
__drawingDebug.getDrawingWorkDebug exposes backingMigrationPending with harness=true/PERF=false
(engine.ts:1239–1241; tiledRenderer.ts:68–69); pair it with committed history and stable composite
outcomes to establish the registered recovery window, not a fixed sleep. Hidden backing migration
legitimately changes backing dimensions per rAF (tiledLayout.ts:60–76). Prefer existing
flows-magic-supersession/recode helpers and durable outcomes. Record the actual capability/fallback
on browser floors; an intended supported-worker run with no worker fails, while an actual
unsupported fallback must still prove its product outcome. This is lifecycle proof, not worker
timing/cost, frozen export or complete service/PWA proof.

## Cost accounting, validation and completion

Reuse measureWebBundle and its exported owning ceilings; new candidate checker uses at-most shipping
preload count. Shipping exact38/28 guards remain unchanged on reference/control. Report HTML/CSS,
raw eager/deferred/transitive bytes, resource counts and requests through first usable React,
including retained Svelte and duplicated prerender/remount HTML. Compare actual whole-host release
outputs, not the earlier runtime-only archive/esbuild result or mechanism instrumentation. Deferred
ReactDOM's lazy raw-ceiling failure is preregistered EXPECTED, not an allowed passing gate.
Unexpected pass requires investigation. No chunk padding, gzip substitution, arbitrary splitting,
tuning/removal promise or eager-placement change. Include eagerErrorStartupBytes' actual
linked/error union in the candidate startup gate; eagerErrorResources remains independently hard.
Any later allocation needs reviewed causal ADR and complete first/repeat-visit costs; this slice
cannot claim startup compatibility/eligibility.

Separate valid built structural artifacts from individual gate statuses. Required budget failure
remains nonzero in its own check with preserved logs/receipt; mechanics may consume an owned
hash-verified built artifact without hiding that failure or making a green aggregate acceptance.
Build/owner/type/isolation failures remain hard failures. Check/test readers reject mismatched or
mutated provenance, unknown flags, release mismatch/harness and foreign paths.

Enable scoped jsx=react-jsx and include actual TS/TSX/Svelte callers; tsc plus svelte-check
--tsconfig against the synced owned project, --fail-on-warnings. Pure SSR imports cannot reach
Kit/rune aliases. Reconcile ESLint/Knip/ruler discovery/test placement/production guards and narrow
CI input closure at the actual stacked head, with positive lint/ownership controls; never edit
generated instructions. Run targeted helper/bridge/overlay/HTML/hash controls, Chromium scenarios,
required Firefox/WebKit smoke and current browser-floor assessment; explicit owned ports and one
suite at a time. Reuse existing retryOpen/drawCommittedStroke/pixel/navigation helpers, named
timeout owners and actual complete outcome assertions; no fixed sleeps, fabricated diagnostic
objects or warning suppression. Then applicable root quality/full tiers and independent exact-head
Claude review; screenshots and hash-bound source/lock/graph/check manifests with controls/*.log.txt,
checked for ignored evidence.

Slice completion means reviewed actual prerender/hydration, scenarios1–5 and complete cost report
with honest failed/pending dispositions. It does not complete unit7 host acceptance. Deployed CSP/
admin/fullhost credentials/offline/PWA scenarios6/7, topology proof, budget disposition, paired
vocabularies, native/physical floors, full product parity and architecture selection remain pending.
