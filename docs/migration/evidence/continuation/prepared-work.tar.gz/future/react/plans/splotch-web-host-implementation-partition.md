# Unit7 — executable implementation partitions

**Status:** First partition has 22 maintained sources prepared in the web-host worktree, plus six
root package.json script/description lines; these are unexecuted source, not accepted evidence.
Actual topology05 head/lock remain PENDING inputs for rebase/install/controls. No install,
copy/materialization, build, test, browser or deployment occurred. Subsequent partitions are private
planning only. This amendment changes no checkout source; the exact predecessor partition is
preserved as splotch-web-host-implementation-partition-reviewed-original-f037cee5.md. The reviewed
[neutral host plan](/private/tmp/splotch-neutral-web-host-unit-plan.md) and its targeted amendment
review govern these slices. This partitions one structural unit, not three architectures.

Record05's actual reviewed SHA/lock before dependent unit7 work; never substitute its predecessor.
Every artifact additionally records its own real unit7 commit, complete source/lock hashes and
base05 provenance. Revalidate root lock, lifecycle verdicts and one React identity when05 changes.
Source preparation can proceed independently; unit7 cannot merge ahead of05. Pending topology cloud
proof does not block independent structural work, but cannot certify production isolation.

## First PR: isolated builder with an exercised retained control

Deliver a real complete Kit build and a browser-usable unchanged drawing route through the copy/
wrapper path. No ReactDOM/plugin dependency or empty source-overlay hook lands in this PR. Its CLI
supports retained-control only until the next PR supplies neutral-embedded's actual caller; reject
unimplemented/unknown flags before copying. Release and mechanism controls are both named artifacts.
This is executable infrastructure, not a plan-only PR or a host-selection result.

| Prepared sources                                                                     | Actual caller and bounded responsibility                                                                                                                                              |
| ------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| tools/migration/build-web-host.mjs                                                   | migration:web-host:build validates implemented variant/artifact/source/lock inputs, owns copies, invokes actual builds and records real exits.                                        |
| tools/migration/{check,serve,test}-web-host.mjs                                      | Registered artifact-bound checker/browser CLI and its preview child validate captured ownership/output before operating; no checkout-default preview build.                           |
| tools/migration/lib/web-host-source.mjs                                              | Builder freezes committed/provisional source and copies bytes/modes without credentials/outputs, destination hardlinks or escaping directory links.                                   |
| tools/migration/lib/web-host-dependencies.mjs                                        | Builder requires the frozen installed root lock and independently copies dependencies, preserving only canonical internal pnpm links and relocated owned shims.                       |
| tools/migration/lib/web-host-metadata.mjs                                            | Builder calls existing buildVersion with frozen source Git/tag facts; validates one pinned metadata payload without duplicating derivation.                                           |
| tools/migration/lib/web-host-{build,processes,ownership}.mjs                         | Actual copied children/prebuild/Kit/postbuild/type caller, owned process/output/path contracts and failure logs/receipts.                                                             |
| tools/migration/lib/web-host-{artifact,comparison,evidence,files}.mjs                | CLI/browser readers bind actual graph/bytes/metadata, narrowly normalized output comparison, budget owner and borrowed-write inventories.                                             |
| migration/probes/web-host/host/{contract,vite.config}.ts                             | Actual Vite wrapper imports/merges unchanged copied web/vite.config.ts and keeps sveltekit() argument-free; contract is every CLI/config reader's finite variant/artifact/path owner. |
| tools/migration/tests/web-host-build.test.mjs                                        | Thirteen authored real positive/failure helper controls, including real borrowed-file child write and unchanged positive; not yet run.                                                |
| migration/probes/web-host/{tsconfig.json,playwright.config.ts,tests/control.spec.ts} | Scoped type/browser callers select owned output/explicit port; release uses actual 1×1 receiver, positive CSS/composite and real ink; mechanism holds layout/adopts early paper.      |
| tools/migration/README.md and migration/probes/web-host/README.md                    | Maintained instructions classify control artifacts, execution inputs and remaining acceptance.                                                                                        |

These rows enumerate the prepared22 source paths; host/ is the actual maintained directory. The
exact source-preparation packet records current implementation/formatting and the authorized release
readiness correction. Discovery/CI/path-filter/test-placement reconciliation is still pending the05
rebase; it has not been implemented or checked. Every maintained new source must pass the existing
check-ignore control before final evidence; the earlier source-only check reported no ignored
prepared paths, which does not certify later additions or Git tracking.

Root build/check/test scripts and matching scripts-info entries are prepared. After05 rebase,
register the narrow candidate workflow with existing pinned setup actions and actual host/ inputs.
These are real candidate CLI/build/test callers; none joins Netlify's shipping import or install
path. Do not amend web/vite.config.ts, web/svelte.config.js, shipping prebuild/postbuild commands,
native trees or root production entry classification.

The copy is necessary, not just kit.outDir: adapter-netlify6.0.4 deletes/writes cwd-relative
.netlify; Kit2.70.3's client build forwards configFile but not configLoader, and Vite can write into
node_modules. Own source AND dependency copies, preserve only verified internal pnpm links, require
canonical paths inside that temporary root, and spawn with cwd=copy/web before importing Kit. Reuse
topology's frozen installed tree after its archive audit; no extra lock/workspace/bootstrap install.

Export full commit source and preserve all real build inputs. Record git describe and resolved tag
SHA from its source repository, derive metadata with the existing owner and freeze it across sync,
generators, SSR, client, prerender and checks. Verify client/server/version.json/sw.js agreement.
App-shell UUID remains actual owner behavior; only the recorded app-shell URL and owned-copy path
prefix may normalize, matching the prepared comparison owner. Build time remains identically pinned
in both controls; it is not a permitted time normalization. A dirty trial is explicitly provisional
SHA-plus-patch evidence.

First-PR actual evidence required before merge:

* Build ordinary unchanged shipping and wrapper control from the same frozen source into separate
  owned copies. Compare route manifests, source/module graph, startup resources/counts, metadata,
  CSP configuration, worker/precache manifests and paper geometry. No missing route/module is a
  normalization. Shipping's existing exact release budget guards must pass for this unchanged
  control; control success does not certify a later React host.
* Show real prerendered index.html, emitted SSR/function output and browser first paint; draw and
  observe visible ink on the retained canvas. A same-config mechanism control additionally holds
  actual layout hydration and proves retained early acceptance/adoption using existing helpers.
  Scope this smoke; full React scenarios and deployed headers remain pending.
* Record valid control source/lock/config receipts, both Kit passes and active-checkout before/after
  file inventories proving no outputs/cache/lock writes escaped. Unknown flag, CAPACITOR=true,
  external output/symlink/hardlink, mismatched source/lock/metadata and unexpected candidate/React
  imports fail. Helpers must not hide failed child/check exits or delete borrowed paths.
* Include scoped checks plus applicable full repository quality/tests, an exact-head Claude review,
  actual screenshots and a short evidence ledger. CI path/ownership guards run on the complete
  retained build-input closure, without adding shipping required branch checks.

The runner must not import commonWebServer's default build/harness settings blindly. Reuse its
credential-safety owner and relevant browser helpers from the copy, but explicitly select the
classified build flags, owned preview path, test directory, report path and port; never trigger the
ordinary active-checkout productionPreviewCommand. Release has no private drawing seams.

## Second PR: actual React SSR, hydration and paper-preserving recovery

Build on the accepted first-PR source/lock and executed retained controls. Add exact reviewed root
dev-only ReactDOM19.2.3 and React/DOM types for actual SSR/client callers; reuse topology's
React19.2.3 and re-audit changed closure. Do not add @vitejs/plugin-react: Vite8 built-in oxc
already handles this production-only TSX slice. Both candidate production configs use the shared
React-free { runtime: 'automatic', development: false, importSource: 'react' } JSX value; scoped
jsx=react-jsx owns typing. SSR compilation/renderer and neutral Kit passes are real copied children
under the allowlisted environment plus explicit NODE_ENV=production before imports. Their receipts
validate resolved Oxc JSX/isProduction/mode/NODE_ENV; extend the existing actual graph/import/output
reader to reject the slice plan's exact React19.2.3/ReactDOM19.2.3 development CJS identities in
client, Kit-server and configFile=false SSR contributions/resolutions; emitted denied references and
missing bound graph records fail. Renderer receipts record/reject actual loaded/resolved CJS files.
The real NODE_ENV=development fixture retains automatic JSX/development=false and must fail on
development React selection, not merely jsx-dev-runtime or self-reported fields. Full dependency
audit remains pending. Require the builder/wrapper to reject PERF_MARKS=true until a reviewed actual
performance caller exists; no speculative keepNames merge. No RNW/RSD/Babel/PostCSS or newly
permitted lifecycle execution. Extend the same runner/wrapper, never create a second Kit host,
copied state engine or replacement build-metadata owner.

Concrete additions are migration/probes/web-host/host/{pageOverlay.ts,renderChrome.ts,
serverStore.ts,chromeHtml.ts},
src/{ProbeIsland.svelte,ProbeChrome.tsx,ProbeClient.tsx,probeProps.ts,
probeBridge.svelte.ts,probeModal.svelte.ts,probeDiagnostics.ts,probe.css}, scoped declarations/tests
and tools/migration/lib/web-host-seams.mjs. The last helper is the actual neutral-build/readback
caller's candidate-only diagnostic byte owner, not a replacement shipping seam checker.
probeProps.ts owns React-free initial props/prefix and store-interface values; both ProbeIsland and
TSX import that module, never TSX values into the static island. The wrapper loads only actual
generated HTML/overlay/receipt helpers for neutral-embedded; retained-control remains React-free. No
plugin package/import/audit/guard is added. renderChrome has a real build caller, produces
renderToString HTML from the same TSX/initial-props/prefix owner BEFORE Kit runs, and stays outside
browser graphs. It injects the deterministic pure serverStore; TSX imports no runtime
$lib/.svelte.ts alias/bridge, since that configFile=false build has no Kit aliases or Svelte
compiler. The shared chromeHtml guard runs before writing and on wrapper readback. Its closed
generated- fragment contract names PROBE_TEXT_SEPARATOR_HTML_COMMENT=`<!-- -->`, removes only that
exact allowed marker for validation and rejects residual raw `<!`/`<?`; it is not a general HTML
parser. Actual SSR is positive; `<!---->`, `<!-->`, `<!--->`, `<!----!>`, `<!>` and recomputed-hash
contaminated receipts fail via writer/reader. Before initial Svelte hydration, the real browser
reader requires the inner container's first and last children to be empty Comments (the production
Svelte delimiters), and no empty Comment between them, including interior descendants; real interior
`<!-->` injection must fail. The standalone generated fragment has no empty Comment; whole-Kit
delimiters are not part of its guard. React recovery may remove both inner delimiters. Immutable
only-child/no-later-write and real recovery/route teardown controls must cover detached anchors; no
initial-server marker shape is required after recovery or client remount. The dynamic client injects
the actual rune bridge. Kit then embeds generated HTML in its real prerender. ProbeIsland is the
actual overlay caller; the app-scoped modal factory reuses createModal, with no second persistent
state.

pageOverlay's enforce-pre load matches only canonical copy/web/src/routes/+page.svelte, rejecting
query submodules or ambiguous anchors. Add its single ProbeIsland import after earlyBoot; insert the
self-positioned island/dialog immediately before the bottom-dock sibling, never in its flex row.
Keep Settings the last button[id], all paper ancestors/keys/control markup unchanged, and SSR/client
overlay hashes equal. This file first lands with its real React route consumer, not a test-only
seam.

ProbeIsland's synchronous onMount begins only import('./ProbeClient'); that module statically
imports hydrateRoot and ProbeChrome. All React/JSX runtime stays deferred. Vite preloads actual
dependencies of this one edge; graph/cancellation controls forbid a redundant ReactDOM entry. Return
cancellation/cleanup immediately. HTML is immutable and the container's only child; generated
controlled path and no subsequent Svelte write are mandatory. On SPA remount a new container is
seeded from that immutable client HTML before React adopts it. React's actual recovery can replace
anchors/opener inside it; re-query opener for Back/focus checks. Unmount/subscription cleanup
operates on detached containers and handles a late unresolved import. Existing modalDialog/Back
coordinator remain sole owners. Raw dialog has no static use:modalDialog: only ProbeClient reaches
compiled probeModal's $effect.root call to the existing exported action, returning action.destroy
and composing its root/listener disposal with hydration/cancellation cleanup. Late attachment
precedes opener activation; app-scoped open state survives remount, route stack/ listeners retire,
and focus re-queries the recovered connected opener. This reuses existing owner tests rather than
preregistering an avoidable eager modal import. Actual deferred named-chunk and root-error closure
checks remain hard; their result is pending, not assumed. Real visible state/ action events
establish hydration; actual onRecoverableError with an initial client-text mismatch establishes
recovery.

This PR carries actual scenario1 release first paint/valid hydration and mechanism scenarios2–5:
earlyBoot/first accepted input versus control, every paper receiver/normal/bottom/top tile identity,
dimensions/pixels and committed history through a settled unrelated-recovery bracket, undo/route
return, async cleanup, dialog dismissal/refusal/nesting/Back/focus and open-dialog route-return. No
early observer is added: before adoption use real pointer/pixels/all-plane DOM references with
__drawingDebug absent; after adoption read the existing history/work owner and prove real Undo.
Settle accepted history/backingMigrationPending through existing diagnostics before unrelated React
recovery, without theme change/rotation/asset publication. Require retained identities/
dimensions/ink/history unchanged there; only afterward trigger theme or release held Magic assets
and assert their expected real pixel/art/history outcome rather than unchanged pixels. Add real
negative controls for eager runtime, paper inside recovery root, clone/missing tile, invalid
anchors, later HTML rewrite and stale/duplicate modal owner. The candidate seam owner derives its
finite actual diagnostic global/event tokens from maintained ProbeClient/probeDiagnostics sources
including TSX, validates graph/source membership and reads built client bytes/HTML. Release absence
and mechanism presence are separate real-artifact gates; omitted source and retained-private-token
release controls plus actual checker inversion fail. No early-path candidate observer or shipping
checker change is authorized. Chromium and required Firefox/WebKit smokes prove executed mechanism
coverage; OS/browser floors remain separately assessed, never inferred.

Register and capture the actual complete release startup graph/requests/HTML/CSS/runtime bytes;
markup appears in index.html AND in client JS for SPA remount, and both encoded payloads count. The
deferred lazy ceiling is an EXPECTED FAILURE, grounded in Claude's separate runtime experiment; the
actual Kit artifact must verify it. Neutral postbuild explicitly assigns all six owners: unchanged
release seams/version/PWA/static --web hard checks; bundle measurement/exported ceilings through the
strict candidate budget; and mixed eager-error split using exported eagerErrorResources as a HARD
named-deferred-chunk/root-error-closure gate plus eagerErrorStartupBytes/startupResourcesFromHtml
linked+error byte union in that strict candidate budget. The slice plan owns the exact table.
Preserve every structural component without treating the mixed CLI as budget-free; no instrumented
waiver or shipping exact-count aggregate on neutral; controls still use unchanged full postbuild.
Missing/folded modalDialog chunk fails structurally. Run the strict candidate checker and preserve
its nonzero failure as evidence, distinct from a structural-slice result. Do not make an applicable
failed gate green or use mechanism budgets. Shipping38/28 pins/ceilings stay unchanged; no
tuning/eager success promise, fair-budget inference or foundation eligibility follows from this PR.

## Discovery/type ownership at the first real source

Current web/tsconfig.json, Vitest includes and Knip project lists do not discover this directory.
First PR adds scoped strict/noEmit build typing extending web's generated alias/ambient
declarations; sync/check happens inside the owned copy. Next PR enables jsx=react-jsx and adds
actual TSX/Svelte/ bridge/spec inputs; use both tsc and svelte-check rather than assuming Vite
transpilation checks them. Do not widen shipping web include/JSX settings merely to make candidate
files visible.

Knip gains exact candidate CLI/config/SSR/test entries and the whole maintained candidate project
closure, including tools/migration/**/*.mjs; helper libraries remain imported by their CLI callers.
knip.production.json must continue to exclude candidate/dev ReactDOM/type entries and pass the
untouched production graph. No React plugin is added. Wrapper/CI/discovery ownership uses host/,
never ignored build/; newly maintained paths also need the check-ignore positive control. Scoped
ESLint coverage must preserve applicable shared restrictions/size limits for TSX and candidate
Svelte, with firing positive controls: several current shared globs omit tsx. Candidate
Playwright/Vitest configs explicitly discover their own specs/unit files; the tool-helper tests
already join npm test through tools/vitest.config.mjs. Source-path discovery/CI filter guards cover
route/layout/template/hooks/config, build/version/PWA/budget owners, lock/manifest, helpers,
candidate configs/assets/tests and workflows. Generated/temp outputs are excluded without ignoring
maintained source. No arbitrary blanket exception or silently undiscovered source/test is
acceptable.

## Later unit7 deploy slice and outstanding exits

Only after the builder/React mechanics are reviewable, implement a separately reviewed disposable
origin deployment caller using the SAME built host, not another frontend/config. Production --prod
does not install dev React: deliver complete CI-built SSR function/dependency closure plus assets,
or register a distinct nonproduction full-install route. Reuse tools/stage-netlify-functions.mjs in
the owned copy if that delivery needs root staging; no production site/command/settings bypass.

This later slice carries real deployed scenario6 CSP hash/admin nonce/routes/API checks, then
scenario7 PWA first/repeat install, interrupted recovery, offline content/admin bypass, old-cache
sweep and delayed ink-safe activation on isolated origins and source-bound consecutive builds.
Mechanism scheduling/negative controls supplement outside-only complete-release proof. Preview,
static-only upload and source analysis never substitute for deployed headers/functions/workers.

Any failed budget still needs reviewed causal ADR and actual full first/repeat-visit cost before an
equivalent allocation/foundation can be accepted. A later full UI replacement might remove enough
retained cost to investigate eager placement; this partition cannot infer that result. Cloud05
proof, native/physical observations, full vocabulary/drawing-screen parity and all final release
gates stay pending. Record completion for each executable slice honestly; successful
controls/mechanics alone cannot mark unit7 host acceptance, Phase1 selection or migration completion
achieved.
