# Unit7 React slice — bounded review dispositions

Status: private plan amendment only; no second-slice source, install, test, build, browser, native,
Git or deployment execution. Claude session f037cee5-b04c-4de2-ace7-3c765487224f was fully read,
including its summary and all five findings. Its summary counts four bounded fixes, while the
finding array contains five including the path nit; all five are accepted. The earlier Codex pass is
explicitly the author's self-review, not independent review. Root accepted its two source-confirmed
corrections. The second Claude 2207177f pass closed all seven and requested three bounded
refinements. The completed third e956dc0f pass closes them in substance, with two precision
corrections and one nit accepted below. This amendment changes private prose only; implementation,
controls and actual source review remain pending.

The revised slice and partition supersede only the named package/loader/HTML guard/diagnostic/
assertion/path choices in the reviewed overall neutral-host plan. Its retained real host,
no-paper-in-React, startup-cost, deploy/CSP/PWA, topology and final architecture gates persist. The
previous source-only first-slice smoke correction is already in its preparation packet and is not a
second-slice implementation or passing browser evidence.

## Preserved assessment inputs

Exact byte copies preserve the plan, partition and question that the first Claude pass actually
assessed. The original question included predecessor/source excerpts and remains unchanged. The
initial rival scope had identical predecessor base/head, not an implemented candidate diff. Do not
retrospectively present that assessment as approval of this revised packet or executed07.

| Snapshot                                                                | SHA256                                                             |
| ----------------------------------------------------------------------- | ------------------------------------------------------------------ |
| splotch-react-web-host-slice-plan-reviewed-original-f037cee5.md         | `6288c3a2b999f50bfe065410359ce9b5f00fc53c31d865ac926d8ecc3ccbcf73` |
| splotch-web-host-implementation-partition-reviewed-original-f037cee5.md | `639ebc0ee52e3aba8a16ce694699f0cce00f1f1cc17857db3feab694d3a8eeb9` |
| splotch-react-web-host-review-question-original-f037cee5.md             | `61d0902e1b16418f37fb0c3642b13a5f91fdb28d5624a56b271ac1ed9a139e65` |

## Source validation and decisions

1. **Remove the unused React plugin — accepted.** Actual installed Vite8.3.1's
   dist/node/chunks/node.js:37100–37104 makes build environments bundled; :7598–7614 passes resolved
   config.oxc to Rolldown's native viteTransformPlugin. The earlier esbuild/scanner/JS-hook
   citations were imprecise build evidence and are corrected, with reviewed text preserved. The
   actual callers are production SSR compilation and Kit passes; no dev/Fast Refresh caller exists.
   Both configs share explicit runtime=automatic, development=false, importSource=react. The
   production child/env and resolved JSX receipts are registered in second-round disposition 8. No
   @vitejs/plugin-react package, audit, import or fence is added. Keep React19.2.3 identity,
   ReactDOM19.2.3 and the actual type callers; audit all newly reached archives before install. The
   actual05 lock/version remains an execution revalidation input, not an inferred success.

2. **Reject empty generated HTML comments — accepted.** Installed Svelte5.57.1
   src/internal/server/blocks/html.js:9–10 emits the closing `<!---->` marker. The client
   src/internal/client/dom/blocks/html.js:112–122 walks only to the first empty Comment node. Add
   shared host/chromeHtml.ts, invoked by renderChrome before receipt write and the wrapper's
   generated HTML readback before either Kit pass. Reject empty-comment equivalents in the generated
   React HTML, not the complete Kit document which legitimately contains Svelte delimiters.
   Second-round disposition 10 closes equivalent/malformed spellings using the fixed generated
   comment vocabulary. Actual SSR/nonempty separator passes; writer/guard and recomputed receipt
   failures remain mandatory, without treating an unexecuted control as evidence. Immutable
   controlled only-child HTML and real Svelte/React hydration remain required.

3. **Remove the candidate-only early history observer — accepted.** Actual
   web/tests/engine-fallback-replay.spec.ts:16–18 holds layout, :28/35 requires __drawingDebug
   absent before adoption, and :42–51/:75–77 uses history/Undo after adoption. Existing
   web/src/lib/boot/devHarnessSeam.ts:132–140 installs those drawing readers only from onMount.
   Before adoption prove real pointer acceptance/visible ink and every live-plane DOM reference;
   after adoption prove actual history and Undo removes the accepted stroke. No new earlyBoot
   reader, import, window assignment or candidate/control instrumentation asymmetry is added.

4. **One dynamic client edge — accepted.** ProbeIsland imports only ./ProbeClient from its
   synchronous onMount. ProbeClient statically imports hydrateRoot and ProbeChrome and injects the
   actual bridge. Vite owns dependency preloads for that edge; no second ReactDOM entry is
   requested. The island's static graph stays React-free. Graph, late-import cancellation and
   detached-container disposal controls cover this one actual caller; no two-promise adapter.

5. **Align partition with host/ and actual prepared sources — accepted.** Repository .gitignore:169
   ignores build/. The prepared wrapper and constant already live in
   migration/probes/web-host/host/{vite.config,contract}.ts; the scoped tsconfig includes host/**.
   Prepared tools use web-host-*.mjs, not the stale camelCase invented paths in the old partition.
   The revised first table enumerates all22 maintained paths from the preparation packet plus the
   six package.json script/description lines. It records source prepared, execution pending. All
   later maintained additions use host/. New workflow/discovery/path filters remain pending the
   actual05 rebase; they are not claimed implemented. Check-ignore/no-source-omission controls
   remain final source evidence obligations; the previous source-only check proves only its22.
   Comparison prose also matches the actual owner: only recorded app-shell URL/copy prefix may
   normalize; identically pinned build time is not an allowed difference.

6. **Separate unrelated recovery from deliberate paper changes — accepted.** The actual new action
   calls setResolvedTheme (appearance.svelte.ts:84–87). DrawingCanvas.svelte:182, :199–234/:257–268
   updates themed canonical overlay/fill; flows-magic-recode.spec.ts:110–120 expressly requires
   existing Magic pixel digest to change. First settle a real committed pen stroke and backing
   migration after adoption, then bracket only unrelated React recovery with no intentional theme,
   rotation or asset publication. Every paper identity/dimension/pixel and committed history must
   remain equal in that bracket. Only afterward trigger theme or release held Magic assets and
   verify their expected real art/pixel/history/Undo behavior. Existing getDrawingWorkDebug is
   available with harness=true/PERF=false (engine.ts:1239–1241, tiledRenderer.ts:68–69), and
   backingMigrationPending describes legitimate hidden per-frame resizing (tiledLayout.ts:60–76). Do
   not replace settling with a fixed sleep or enable marks. Worker counters remain unavailable at
   PERF=false; actual worker handles/product outcome prove their lifecycle separately from timing,
   frozen export or full service acceptance.

7. **Add a real candidate diagnostic byte owner — accepted.** Existing shipping
   tools/check-release-seams.mjs:10–30/:145–155 derives tokens from a finite shipping list; :115–116
   does not include TSX. It cannot certify new candidate diagnostics. Add only
   tools/migration/lib/web-host-seams.mjs for the actual neutral-build/check-web-host callers.
   Source/graph ownership covers maintained ProbeClient.tsx and probeDiagnostics.ts, including
   actual finite private global/event tokens. It reads emitted client JS/HTML: release must lack
   them, mechanism must contain their reachable bytes. Source omission, retained-token release
   mutation with recomputed inventory and actual checker inversion must fail; valid artifacts are
   positive controls. Browser mismatch still requires real onRecoverableError and outcomes, so fake
   diagnostic publication cannot stand in for recovery. Shipping checker stays untouched;
   instrumentation is deferred, with no replacement early observer or generic probe framework.

## Exact amended scope and remaining exits

Revised private files: splotch-react-web-host-slice-plan.md and
splotch-web-host-implementation-partition.md. New maintained sources are future explicit callers
listed there: overlay/SSR/pure server/HTML guard, React
component/client/bridge/modal/diagnostics/CSS, scoped tests/declarations and the candidate byte
checker. No checkout source changed in this unit.

The revised slice's table explicitly assigns all SIX shipping postbuild owners. Four unchanged
seam/version/PWA/static-web owners remain hard; bundle budgets use existing measurements/ceilings in
the strict candidate report. Mixed eager-error uses exported eagerErrorResources as a HARD named-
deferred-owner/root-error closure gate, with eagerErrorStartupBytes' complete linked/error union in
the strict candidate budget. Controls still run full postbuild. A failed structural guard never
becomes a preregistered budget failure; a budget's expected nonzero remains real, not report-only or
green aggregate acceptance. This refines the overall neutral plan's abbreviated eager-check prose
without changing shipping owners or final eligibility.

Before dependent runtime work: actual reviewed05 SHA/lock, first-slice rebase/discovery, archive
approval/frozen install and executed retained release/mechanism controls are still PENDING. No
placeholder05 SHA substitutes. Deployed/offline/credential scenarios6/7, complete host startup
allocation, native/physical floors, full drawing-screen parity and architecture selection remain
pending; cloud05 does not block independent structural work but its acceptance/merge gate persists.

## Second-round 2207177f dispositions and primary sources

Full findings/summary read from 2207177f-7ffe-47ad-a10d-e94bc1e0349a; verdict closed original 5+2,
with three scoped suggestions. No implementation/runtime assessment occurred. Exact previously
reviewed plan/partition/dispositions were copied to *-reviewed-original-2207177f.md before
amendment. The original second-round question/source attachments remain unchanged. Earlier f037cee5
snapshots remain the original first-round evidence. No first-slice source change is authorized here.

8. **Explicit production JSX and truthful build citations — accepted.** Installed Vite8.3.1
   :37104/:7598–7614 establishes the real native Rolldown build transformation. :37256–37262,
   :37401/:37503–37508 shows NODE_ENV-dependent defaults. Shared JSX fields explicitly close that
   default; SSR compilation AND renderer execution must use runCopiedChild/copiedBuildEnvironment
   plus NODE_ENV=production before importing React/Vite. Neutral Kit uses the same policy. Record
   resolved JSX/isProduction/mode and process NODE_ENV per pass and inspect actual emitted imports/
   bytes; jsx-dev-runtime and wrong options/env fail actual readers. No in-process Vitest production
   build, implicit parent NODE_ENV or package/plugin caller is introduced. Production controls must
   execute; source reading does not prove production bytes or costs.

9. **Six owners, mixed eager-error split, deferred real modal binding — accepted.** Actual
   package.json:31 names six owners, and check-eager-error-bundle.mjs:16–55/:59–101 mixes hard
   deferred-name/root-error closure with byte-union enforcement. Its exported eagerErrorResources
   and eagerErrorStartupBytes are reused for those two separate dispositions; no shipping edit or
   custom duplicate graph walk. Actual modalDialog.svelte.ts:332 creates $effect, so an asynchronous
   naked function call lacks ownership. Existing modalDialog.svelte.test.ts:19–25/:359–366 already
   supplies the precise valid pattern: $effect.root(() => { const action=modalDialog(...); return
   action.destroy; }). The deferred compiled probeModal uses that same exported function, with real
   options and route cleanup; its only incoming runtime path is ProbeClient. Static ProbeIsland
   contains raw dialog markup and immutable HTML, without use:modalDialog or store/owner back-edge.
   Root's manual disposal covers effect/exit cancellation; returned action.destroy covers stack and
   event cleanup. Connected-node/late-import and partial-setup failure controls are mandatory.
   Refusal, nested Settings/Back, opener recovery focus and persisted-open SPA return still exercise
   the real owner. Evidence: modalDialog.svelte.ts:278–325/:332–370; state/modal.svelte.ts:25–41;
   boot/systemBack.ts:27 and webBackHandler.ts:3/:139; ADR0049/0168. This uses a present owner contract,
   not a speculative cross-framework API. A static eager action would add deferred Svelte imports
   and risk a hard chunk guard; a replacement React stack duplicates behavior; a second late Svelte
   loader adds an entry. Select the bounded one-edge effect-root binding. Its build/lifecycle
   success remains pending, and missing/folded deferred chunk is a HARD failure, never a cost waiver.
   Official [Svelte effect-root contract](https://svelte.dev/docs/svelte/$effect#$effect.root)
   supports creation outside initialization and requires manual cleanup.

10. **Equivalent empty Comment spellings — accepted with a closed producer vocabulary.** The
    [HTML tokenizer](https://html.spec.whatwg.org/multipage/parsing.html#comment-start-state) and
    [comment-start-dash state](https://html.spec.whatwg.org/multipage/parsing.html#comment-start-dash-state)
    confirm `<!-->` and `<!--->` emit empty comments; normal/end-bang states also explain malformed
    `<!----!>`. A three-spelling regex alone is narrower than the invariant. This fixed Chrome
    producer names PROBE_TEXT_SEPARATOR_HTML_COMMENT=`<!-- -->`, removes only that exact marker for
    validation and rejects residual raw `<!`/`<?` using /<!|<\?/. Scope only GENERATED React HTML,
    not whole-Kit Svelte delimiters; this is not a general HTML parser or future-compatibility
    promise. Ordinary text/attributes are escaped by React, and no Suspense/declaration producer
    exists in this slice. This introduces no parser package or full-Kit restriction. Actual
    renderToString is the positive; all three requested empty spellings plus `<!----!>`, `<!>` and
    declaration injections fail through the actual writer and recomputed-receipt reader. Browser
    control validates the standalone generated fragment has no empty Comment. The initial
    SSR-container control now distinguishes the exact outer Svelte delimiters from its interior
    (third-round disposition12). Future comment vocabulary requires its real consumer and review.
    These are authored acceptance requirements, not executed results.

No objection to the three findings. The modal alternative is selected from actual source, not an
assumed chunk/performance result. First-slice provenance/external-SSR import gaps are being reviewed
separately by the parent/independent source reviewer and are not repaired or declared passing here.

## Third-round e956dc0f precision dispositions

Full summary and all three findings read from e956dc0f-3e9c-4f2d-b20d-743acff33972/findings.json.
Nothing blocks the plan; prior settlements remain. Preserve the exact three assessed bodies in
*-reviewed-original-e956dc0f.md before this amendment; original submitted questions/sources stay
unchanged. No new blanket planning review is proposed.

11. **Production React CJS selection — accepted.** Explicit JSX development=false makes a
    jsx-dev-runtime rejection insufficient: Vite8.3.1 definePlugin:16963–16970 still chooses
    NODE_ENV for client defines. Actual React19.2.3 index/jsx-runtime entries select production or
    development CommonJS files. Exact public ReactDOM19.2.3 index/client/server.node entries do the
    same. The newly retained npm registry tarball has verified SHA512 integrity and SHA1; its source
    receipt records raw archive/metadata hashes and all eleven development CJS members. Actual
    installed topology React19.2.3 contributes seven exact names. The slice plan lists the complete
    finite set and source receipt binds its bytes; this is source inspection, not a full fresh
    lock-delta/install audit.

    Extend the existing client/Kit-server/configFile=false SSR graph/import/output owners to reject
    contributing or resolved development modules, including external/static/dynamic edges and
    emitted denied references; output is bound to actual contributing source, not a filename-only
    byte claim. Renderer receipts include actual loaded/resolved CJS files after real
    renderToString. Package selector files containing both branch names on disk are not themselves
    development evidence. The real negative NODE_ENV=development fixture retains JSX
    automatic/development=false and must fail on actual development-module selection plus the
    environment fields. Actual production selection is positive. No build/render/control is claimed
    executed.

12. **Initial Svelte delimiter scope — accepted.** Actual Svelte5.57.1 server/blocks/html.js:9–10
    emits empty opening and closing Comments in production. Before initial Svelte hydration, require
    those exact first/last child nodes and no empty Comment between them, including interior
    descendants. A standalone generated fragment has no empty Comment. Keep a real interior `<!-->`
    injection as the failing browser control; ignoring all empty comments would lose the invariant.
    React recovery owns/removes inner markers as well as its opener; re-query the live opener.
    Immutable only-child/no-later-write prevents later Svelte HTML mutation; repeated actual
    recovery/route teardown must prove cleanup with detached anchors. Do not assert initial server
    delimiter shape after recovery or client remount, or claim teardown tolerance from source
    inspection alone.

13. **PERF_MARKS=true refused — accepted simplest scope.** Vite8.3.1:37469–37472 selects explicit
    oxc over shipping esbuild options, including profiling keepNames. This unit has marks=false
    release/mechanism callers only, so reject true in actual builder/wrapper requests before work
    and require false in pass readers. The real true control must fail; false controls must remain
    valid. No speculative keepNames merge or performance option is added. A later actual performance
    caller needs its own reviewed configuration/effective receipts.

All dependencies, executed host/SSR/browser controls, deployed CSP/PWA/topology proof, physical
floors, vocabulary and architecture selection remain their existing pending gates. This amendment
does not certify separately owned first-slice guard repairs or waive the expected strict nonzero
ReactDOM lazy-budget result.
