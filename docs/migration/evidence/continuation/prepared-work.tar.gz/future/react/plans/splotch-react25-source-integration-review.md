# React25 source review and promotion owners

This source pass found one concrete lifecycle defect in the original nine UI files. Root's
binding-local modal successor closes it at source level, and the distinct child recheck agrees.
No other material source defect was identified in the bounded host/SSR/graph/fixture pass.
Integration, discovery, real fixture execution, released React selection and browser acceptance
remain pending; this is not a runtime verdict or an architecture selection.

I authored the sixteen host/helper/fixture files, so that portion is an author self-review and
integration pass. The original nine UI files were authored by migration_evidence. Existing distinct
source reviews, including the child review of the modal finding and root's successor, are bound in
`/private/tmp/splotch-react25-source-integration-review-receipt.json`.

## Bound inputs and source result

The receipt independently re-reads all original25 files, all successor25 files and the current30
retained web files against their recorded byte counts and SHA256 values. All match. The successor
contains 118376 bytes; only `migration/probes/web-host/src/probeModal.svelte.ts` differs from the
original. The original packet and its 115 context copies remain historical preserved inputs, rather
than claims about a future accepted integration tip.

Promote `/private/tmp/splotch-react-host-modal-lifetime-successor/prepared`, preserving the sealed
original. Twenty-three paths are additions. Exactly two are existing owner merges:

- `migration/probes/web-host/host/contract.ts`
- `migration/probes/web-host/host/vite.config.ts`

The modal before/after SHA256 values are respectively
c92ad89e2e099f288f68dc765dde4bc07fa647d3797496efa725b9735dee4a68 and
ee18102a088963ee8efdc5f133a1e2660610f168132486b83e1393c1aad1b526.
The exact successor changes only factory scope: `createProbeModalState()` is invoked inside
`bindProbeModal` after required-control validation, instead of once at module scope.

The defect was real SPA route lifetime: disposal destroys the physical dialog action and its close
listener, without hiding/resetting a cached logical modal. An open/refused singleton survived route
exit and reopened a successor dialog without a fresh opener. Shipping `modalDialog.svelte.ts` owns
listener/stack retirement, while `modal.svelte.ts` owns logical hiding. Local binding state respects
both owners and cannot let disposal of an older binding modify its successor.

## What the bounded source establishes

The static page overlay authenticates the sole canonical root route and preserves the actual
`earlyBoot` and dock anchors. `ProbeIsland.svelte` renders an immutable virtual HTML value only in
its inner boundary, starts one deferred `ProbeClient` import and cancels/disposes a late mount.
React's paper/input/tile planes remain outside that root. The raw dialog is a sibling controlled by
the existing modal action, and the bridge uses the actual appearance/canvas/settings owners.

The standalone compiler uses an explicit production SSR input and automatic JSX, with no React
plugin. The actual renderer uses `renderToString`, the immutable pending snapshot and common
identifier prefix. Its publication record binds request, HTML bytes, props/prefix, renderer graph,
source bytes and actual loaded React CJS owners. The Kit wrapper authenticates that publication
before exposing its literal virtual module and records the actual client and server passes.

Graph validation binds participating module/output/source bytes, package identities and emitted
literal import/export/dynamic-import/require edges. Positive contribution checks are based on
rendered modules, rather than dead selector strings naming development files. Production CJS
externals and recorded non-React external edges retain their explicit scope. The HTML reader
preserves React's exact nonempty separator, rejects other raw declarations and checks only the
intended boundary; it does not claim to parse arbitrary HTML or certify arbitrary runtime imports.

I read the actual three tool fixture files and HTML-boundary browser fixture. Their publication
mutation, closed type/edge, dev-file, package identity, positive contribution and delimiter checks
are meaningful authored controls. They have not been executed. Real Vite/Rolldown module shapes,
actual production/wrong-NODE_ENV selection and both Kit pass contributions remain unknown until
those callers run. The prior three graph/production successor findings are source-closed in the
separately bound independent receipt; this pass does not substitute a runtime result for it.

## Exact integration checklist

| Owner | Bounded promotion change |
| --- | --- |
| `migration/probes/web-host/host/contract.ts` | Merge the neutral closed request/fixture vocabulary and finite generated paths into the current owner. Preserve current `WEB_HOST_ENV.browserRun`; keep the old reference/control request and two-copy default. Neutral requests require the explicit third copy and release mismatches remain refused. |
| `migration/probes/web-host/host/vite.config.ts` | Merge the neutral authenticated overlay/HTML/pass plugins into the current retained wrapper. Preserve literal actual shipping config owners and the accepted Kit version normalization. No shipping React plugin/config branch or replacement route file. |
| `tools/migration/build-web-host.mjs` | Carry the parsed closed variant/fixture into actual dispatch; materialize reference/control/neutral only for a neutral request. Call the prepared React helper before the neutral Kit stage; preserve actual metadata/source/lock checks and the retained pair's calibration. |
| `tools/migration/lib/web-host-ownership.mjs`, `web-host-inputs.mjs`, `web-host-generated.mjs` | Extend finite role/read/write owners and protected generated inputs for the compiled renderer, graph, request, HTML and pass records. Authenticate before each child/helper import, freeze compiled inputs before use and Kit support after build. Preserve complete dependency bytes/links/modes, additions/deletions and current finite cache owners; no blanket generated or node_modules exclusion. |
| `tools/migration/lib/web-host-build.mjs`, prepared `web-host-react.mjs` | Register the helper's actual production callers. Preserve actual npm prebuild → guard → ignore-scripts build → guard/freeze → actual postbuild ownership, lifecycle validation and current interruption/process-group handling. Carry the neutral publication hashes/environment only after their readback guards succeed. |
| `tools/migration/lib/web-host-artifact.mjs` | Add neutral copy/request/publication/pass bindings to the current artifact reader and invoke actual neutral graph/evidence validation before check, preview, copied helper imports or browser children. Preserve all current complete input/artifact inventory predicates. |
| `tools/migration/lib/web-host-evidence.mjs`, `web-host-comparison.mjs`, prepared `host/neutralEvidence.ts` | Keep reference/control byte, measurement, metadata and pass equality unchanged. Record complete neutral output and whole-host costs separately; intentional chrome/React changes cannot be normalized away or forced through false reference/candidate byte equality. Keep current kind/mode/link checks before the hash shortcut. |
| `tools/migration/check-web-host.mjs`, `serve-web-host.mjs`, `test-web-host.mjs` | Select the authenticated neutral artifact in their existing role dispatch, without parallel readers or launcher owners. Preserve current owned preview group, unique per-browser output/report paths, owned TMP/XDG/transform paths and explicit original installed Playwright registry. Preserve ordinary headless-shell/channel selection. |
| `migration/probes/web-host/playwright.config.ts`, existing `tests/control.spec.ts`, new neutral specs | Keep the retained held-request/post-ink debug controls. Register the existing prepared boundary reader plus actual release, lifecycle and modal scenarios through the artifact-bound caller. Observe initial Svelte boundary comments before hydration, not after React recovery or a client remount. |
| `migration/probes/web-host/tsconfig.json`, scoped root check caller | Include the actual TSX/Svelte/rune/declaration inputs, production `react-jsx` typing and both tsc and svelte-check after owned-copy sync. Do not widen shipping JSX options. |
| Root `package.json`, `pnpm-lock.yaml`, Knip, ESLint, test/discovery/CI owners | Declare actual root React/ReactDOM/type callers directly as dev tooling, with matching exact React19.2.3 identities; do not rely on an undeclared hoisted candidate dependency. Parent selects/verifies actual type pins and new closure/lifecycles before install. Register scoped helper/renderer/spec entries and positive lint/discovery controls, scripts-info and selected CI caller; retain production entry and six-pin native boundaries. |
| Existing neutral seam/budget callers | Integrate the six accepted postbuild dispositions through their real owners. Release seam, version, PWA and static checks stay hard. Preserve the strict largest-lazy/aggregate/error-union measurement and actual nonzero failure; no threshold waiver or passing eligibility label. |

The current30 source has newer process shutdown, browser invocation/cache, kind/mode comparison,
held-request/ink and browser-run ownership absent from the older React context. Wholesale promotion
of that older contract/helper context would lose real fixes. These are explicit merge obligations,
not newly invented architecture or additional generic qualification gates.

## Actual modal navigation control

For the neutral mechanism/matching lane, retain a handle to the original `document.documentElement`.
After real adoption, open the probe dialog, enable “Keep this dialog open” and assert open/refused
state plus disabled Close. Click the existing “Open Settings” control and the real Settings About
“Privacy Policy” anchor (`web/src/lib/components/settings/AboutSection.svelte`, `/privacy`). Navigate
back with the browser's actual back action. Assert the original document element remains current
and connected through the whole route transition, so a reload cannot conceal module caching.

On return, assert the new probe binding starts closed. Its fresh opener must show unchecked refusal
and enabled Close; exercise normal dismissal/focus. In mechanism mode, use the actual
`window.__splotchWebHostDiagnostics.snapshot()` lifecycle counters to show old-root disposal and the
new adoption, retaining prior diagnostics rather than a reset hook. This adds no production reset
API. The normal open/refused route-away case and repeated return remain actual browser controls,
not claims inferred from the authored source fixture.

## Pending execution and scope limits

Actual integration must use the accepted topology/Kit/retained-web owner versions, with honest source
and lock bindings; no future tip is assumed. Format, scoped type/Svelte checks, discovery/Knip/lint
positive controls, all applicable tiers and independent exact-source Claude review remain pending.
The real production/wrong-NODE_ENV render control must hold automatic JSX/development=false fixed
and observe actual loaded CJS paths. Both real Kit passes must show the required rendered module
contributions. Source fixtures alone cannot supply either result.

Literal-edge/source/output receipts do not certify arbitrary computed runtime resolution or a
general conditional ESM graph. The CJS production path is intentionally finite. The input inventory
retains its documented concurrent-mutation limits. Deployed CSP/admin/PWA/credential scenarios6/7,
physical/native floors, vocabulary/product parity and architecture selection remain later gates.
No checkout, Git, imports, formatter, tests, install, build, browser or native execution occurred in
this pass.
