import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { afterEach, describe, expect, it } from 'vitest';
import { buildVersionProblems } from '../check-build-version.mjs';

const fixtures = [];

afterEach(() => {
  for (const dir of fixtures.splice(0)) rmSync(dir, { recursive: true, force: true });
});

function write(root, path, contents) {
  mkdirSync(dirname(join(root, path)), { recursive: true });
  writeFileSync(join(root, path), contents);
}

function writeBundle(root, bundle, version) {
  write(root, `${bundle}/version.json`, JSON.stringify({ version }));
  write(root, `${bundle}/coloring/manifest-${version}.json`, '{}');
}

function buildOutput({
  client = '1.6.896',
  server = client,
  native = false,
  serviceWorker = native ? null : client,
} = {}) {
  const root = mkdtempSync(join(tmpdir(), 'splotch-build-version-'));
  fixtures.push(root);
  writeBundle(root, 'client', client);
  write(root, 'client/_app/version.json', JSON.stringify({ version: client }));
  writeBundle(root, 'server', server);
  if (serviceWorker) {
    write(
      root,
      'client/sw.js',
      `precacheAndRoute([{url:"index.css",revision:"a"},{url:"coloring/manifest-${serviceWorker}.json",revision:"b"}]);`
    );
  }
  return { clientDir: join(root, 'client'), serverDir: join(root, 'server'), native };
}

describe('buildVersionProblems', () => {
  it('accepts a build whose every version surface agrees', () => {
    expect(buildVersionProblems(buildOutput())).toEqual([]);
  });

  it('accepts a native build, which ships no service worker', () => {
    expect(buildVersionProblems(buildOutput({ native: true }))).toEqual([]);
  });

  it('reports a build missing the Kit version endpoint', () => {
    const output = buildOutput();
    rmSync(join(output.clientDir, '_app/version.json'));

    expect(buildVersionProblems(output)).toEqual(['Client _app/version.json is missing']);
  });

  it('reports a Kit endpoint that differs while all app version surfaces agree', () => {
    const output = buildOutput();
    write(output.clientDir, '_app/version.json', JSON.stringify({ version: '1791257537740' }));

    expect(buildVersionProblems(output)).toEqual([
      'Client _app/version.json carries 1791257537740, not 1.6.896',
    ]);
  });

  it('reports a web build that ships no service worker', () => {
    expect(buildVersionProblems(buildOutput({ serviceWorker: null }))).toEqual([
      'Client sw.js is missing',
    ]);
  });

  it('reports a native build that ships a service worker', () => {
    expect(buildVersionProblems(buildOutput({ native: true, serviceWorker: '1.6.896' }))).toEqual([
      'Native client ships sw.js',
    ]);
  });

  it('reports an SSR bundle derived from a different commit than the client', () => {
    const problems = buildVersionProblems(buildOutput({ server: '1.6.895' }));

    expect(problems).toEqual([
      'Server version.json carries 1.6.895, not 1.6.896',
      'Server coloring manifests are [coloring/manifest-1.6.895.json], expected only coloring/manifest-1.6.896.json',
    ]);
  });

  it('reports a service worker precaching another version’s coloring manifest', () => {
    expect(buildVersionProblems(buildOutput({ serviceWorker: '1.6.895' }))).toEqual([
      'sw.js precaches coloring manifests [coloring/manifest-1.6.895.json], expected only coloring/manifest-1.6.896.json',
    ]);
  });

  it('reports a shipped client holding a second version’s coloring manifest', () => {
    const output = buildOutput();
    write(output.clientDir, 'coloring/manifest-1.6.897.json', '{}');

    expect(buildVersionProblems(output)).toEqual([
      'Client coloring manifests are [coloring/manifest-1.6.896.json, coloring/manifest-1.6.897.json], expected only coloring/manifest-1.6.896.json',
    ]);
  });

  it('reports a build with no client version.json', () => {
    const output = buildOutput();
    rmSync(join(output.clientDir, 'version.json'));

    expect(buildVersionProblems(output)).toEqual(['Client version.json does not exist']);
  });
});
