# Neutral React25 onto retained Web30: private semantic source merge

This is a private maintained-source preparation, authored by migration_evidence. It is not an
installed tree, source commit, successful build, browser result or architecture verdict. No checkout,
shipping configuration, budget owner, package/lock, CI file or Git state was edited. No candidate
imports, formatter, tests, install, build, browser/server or native execution occurred.

## Frozen inputs

- Retained Web30: `/private/tmp/splotch-web-host-claude-successor-bll4dilo`, original 30-row digest
  `4832a1da79628b92f8592686bcfb288e95d10e7d13d456b15f5193e8170a9dde`.
- Latest React25: `/private/tmp/splotch-react-host-erased-types-successor-o_iufynq/prepared`, digest
  `0b05c4772633f3670da8ba166307b82b93cd7e42de989d27aba3c6b74ab89c1c`.
  This includes root's real compiler predicate, binding-local modal lifetime and all three
  declaration-level Vite type imports. Earlier modal/compiler/type packets remain untouched.
- The prior `isjrzsfg` React25 was read and preserved before root supplied the final two type-erasure
  corrections. It is historical input, not the selected React source.
- Six registration deltas: `/private/tmp/splotch-web30-registration-cry_w70p`, exact bytes retained in
  `inputs/registration`. They are not rewritten or wholesale installed into `prepared`.
  Root must apply their reviewed semantic delta onto the actual accepted manifest/Knip/ESLint bases.
  In particular, this packet does not promote the old root `package.json` as the current owner.
- Governing neutral plans, dispositions, partition and retained integration plan are hash-bound in
  `input-receipt.json`. The retained plan names Kit integration
  7f090b6fccafdc9d383e2cab8f97c5492c496a60; actual accepted topology/Netlify/Kit composition is a
  root-owned future execution input. No combined accepted tip is assumed here.

All original rows were passively verified for actual bytes, modes and SHA256 before copying. The
original packets are unchanged; the separate `inputs` copies permit comparison without depending on
moving worktree bytes.

## Maintained-source layout

`prepared` contains 53 files: the 29 non-package retained sources, 23 additional React sources and
one bounded neutral-input fixture. Exactly 17 paths differ from the preferred respective input or
are newly authored. `merge-delta.json` names each original/selected/after hash and byte count;
`semantic-merge.diff` is the complete delta against current retained owners for existing paths and
latest React25 for additions. The wrapper retains the current module normalization and retained
receipt plugin; its neutral additions are the already authored React25 implementation.

The original nine UI sources are byte-identical to selected React25. The following retained owners
are also exact current30 bytes: copy/source/dependency/ownership/file/metadata/process/browser
helpers, complete output comparison, real held-request/post-ink `control.spec.ts`, and the three
process/preview/browser fixtures. The exact `runCopiedChild` and `freshBrowserEnvironment` function
source slices are unchanged inside the extended build helper. These are passive byte checks,
rather than runtime results.

## Actual merged caller chain

1. `build-web-host` parses the closed variant/artifact/fixture request. Retained requests still make
   only reference/control copies. Neutral requests make reference/control/neutral copies; their
   calibration pair always uses matching retained requests, including when neutral is a mechanism
   text-mismatch request. Release text-mismatch remains rejected at this actual CLI boundary.
2. Input binding schema2 records the chosen variant and exact role set. The existing complete
   source/dependency/link/mode inventories and finite Kit/Vite scratch boundaries apply to every
   requested copy. Old schema1 artifacts must be regenerated under these changed source owners;
   no legacy inventory or result is silently upgraded.
3. The actual `npm run prebuild` runs for each copy. Neutral preparation then freezes all actual
   maintained/generated source bytes before its compiler child. Only the two named renderer outputs
   may appear in that phase; they freeze before graph read, request publication and renderer use.
   A third file, source/dependency mutation, unexpected role, borrowed link or changed renderer
   byte/mode fails the same owning input guard.
4. The actual prepared `prepareReactChrome` is called only for neutral. It retains the reviewed
   standalone production compiler, real Node renderer and request/HTML/loaded-CJS receipts. Its
   returned frozen input bindings become the builder's current bindings. The real Kit wrapper then
   consumes those bound request/HTML hashes, applies the static source overlay and records both
   actual neutral passes. No shipping route or configuration is rewritten.
5. Each copy still invokes its unchanged actual `npm --ignore-scripts run build` and actual
   `npm run postbuild`; wrapped copies select the candidate-only wrapper. The six actual shipping
   postbuild stages and their strict failure are preserved. There is no budget bypass, threshold
   change, diagnostic replacement or continuation after a failed postbuild command in this unit.
6. On a neutral postbuild failure, the builder records completed children, the actual failed child
   and frozen input hash. If guarded collection succeeds, it records retained calibration plus the
   neutral graph and exact output inventory/`measureWebBundle` values. Capture failures are explicit.
   The result stays `failed`, review eligibility is false, and the actual reader refuses it before
   check/preview/browser children. This does not certify the eager-error byte union or candidate
   ceiling evaluation; those remain separate pending owners.
7. Completed artifacts authenticate all requested copy/output inventories and the neutral
   request/renderer/HTML/pass records through the existing `readWebHostArtifact` owner. Check, serve
   and test select its authenticated copy and publication environment; they do not add parallel
   readers, previews, browser registries or process owners. The unique invocation/report and cache
   behavior remains in the current30 owners. The browser project name records the actual variant.
8. Scoped `tsconfig.json` adds the actual TSX/Svelte/rune inputs and `react-jsx` without changing the
   shipping TS configuration. The existing copied type stage retains tsc, and neutral's actual
   caller also invokes scoped svelte-check. Actual type dependencies/discovery and installed API
   behavior remain root-owned qualification, not passing evidence from this preparation.

## Authored controls and limits

The real argument parser fixture now covers neutral matching release, mechanism mismatch, release
mismatch refusal, retained mismatch refusal and an unknown variant. The existing input fixture adds
failed-partial result controls through the actual check/serve/test CLIs, with no copied helper or
child marker reached. Its established interruption, real PID/group, cache/registry/report and
retained lifecycle controls are preserved.

The new `web-host-neutral-inputs.test.mjs` drives real owned directories and owning capture/freeze/
input readers. It includes an unchanged three-copy positive control; omitted/extra roles; output
before source freezing; missing renderer outputs; valid source/output/final freeze; generated-source
mutation after prebuild; and changed bytes/modes for each exact renderer file. Its tiny renderer
bytes are explicitly input-binding fixtures, not a fabricated valid React graph or successful
SSR/build. The existing distinct graph/production/HTML fixtures remain the real owners for their
respective predicates. No authored control has been run.

Root must first execute and accept retained release/mechanism on the actual accepted combined base.
Only afterward should this packet be integrated with direct audited React19.2.3/ReactDOM/types,
actual TSX/renderer Knip/ESLint/discovery ownership and frozen lock. The six retained registration
paths remain a separate exact input; they do not yet cover all new TSX/standalone entry callers.
Format, types, focused/full tiers, actual production/development controls, real SSR/client adoption,
application recovery/seed/history/worker/modal/route scenarios and exact-source rival review remain
pending. The included HTML-boundary fixture tests only that bounded reader, not those application
scenarios. Deployed/offline/credential scenarios, physical gates, full candidate cost disposition,
product ownership and architecture selection remain their existing later gates.
