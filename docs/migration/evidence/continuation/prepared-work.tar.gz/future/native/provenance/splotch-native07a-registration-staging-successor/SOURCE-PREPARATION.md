# Native07a registration staging successor

Only the README archive-intake paragraph changes. Android archive intake is explicitly pending
Native07b, whose CLI/qualified ZIP reader are absent from the first PR. It also accurately says
that an executed template materializer parses its explicit reviewed template archive; its source
preparation does not certify SDK/native/build/mount/performance results.

`prepared/` contains all ten successor registration paths. The other nine paths remain byte/mode
identical to `/private/tmp/splotch-native78-registration-prepared/prepared`; that original packet
is untouched. Apply the original nine-owner registration delta using its actual accepted-parent
preimages, then this one README paragraph successor. `readme-staging.diff` binds the exact change,
and `source-only-receipt.json` binds all ten rows. No formatting or execution occurred.
