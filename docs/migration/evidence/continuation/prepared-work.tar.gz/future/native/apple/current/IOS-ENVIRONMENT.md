# iOS candidate environment boundary — 2026-10-06

The installed Xcode 27 is a viable **compile candidate**, after CocoaPods provisioning, and
Expo 57.0.26 contains the required scene support. The preserved Native07a template has not
adopted it. Its source/materialization acceptance therefore remains valid in its original scope;
it is not an SDK 27 launch certificate. Keep that packet unchanged and make scene adoption a
small subsequent source unit. iOS 16.4 mount is a separate tool/runtime gate.

## Observed host and official compatibility

The authoritative [host inventory](/private/tmp/splotch-native-host-inventory-20261006/HOST-INVENTORY.md)
records macOS 26.6.2 arm64, Xcode 27.0 / 27A266a, SDK 27.0, available simulator runtimes 26.5
and 27.0, system Ruby 2.6.10 and no CocoaPods in the bounded checked locations. This pass only
read files and immediate `/Applications/Xcode*.app` metadata: `/Applications/Xcode.app` 27.0 is
the sole matching application there. No side-by-side 26.6 was found in that directory; other
locations are not certified absent.

Apple's [current support table](https://developer.apple.com/xcode/system-requirements/)
allows Xcode 27 on macOS 26.6+, deployment targets beginning at iOS 15, but simulator/device
support beginning at iOS 17. Xcode 26.6 supports macOS 26.2–26.x and iOS 15+ simulator/device
support. Xcode 16.4's host range ends at macOS 26.1.x, so it is not the proposed tool on this
host. A deployment target of 16.4 does not demonstrate execution on that runtime.

The [SDK 57 table](https://docs.expo.dev/versions/v57.0.0/) requires iOS 16.4 and Xcode 26.4+.
Expo's [build image inventory](https://docs.expo.dev/build-reference/infrastructure/) assigns
SDK 57 to Xcode 26.6 / CocoaPods 1.16.2 / Ruby 3.2; its Xcode 27 / CocoaPods 1.17 / Ruby 3.4
image is assigned SDK 58. These are reference environments, not a reason to change the six
candidate pins or proof of our Podfile's compilation. All primary pages were retrieved
2026-10-06; the SDK page reports update 2026-09-17.

Apple's [live simulator catalog](https://devimages-cdn.apple.com/downloads/xcode/simulators/index2.dvtdownloadableindex)
contains the exact iOS 16.4 / 20E247 runtime, identifier
`com.apple.dmg.iPhoneSimulatorSDK16_4`, with **both** `maxHostVersion` and `maxXcodeVersion`
`26.99.0`. Its authenticated download source is Apple's developer download service. This
metadata corroborates the Xcode 27 exclusion and supplies a concrete 26.6 qualification route.
It does not prove current authenticated access, artifact bytes/architecture, installation or
boot on this machine. No runtime artifact was fetched.

## Concrete SDK 27 launch gap and source unit

Apple requires apps built against SDK 27 to adopt scenes when running on the corresponding
27 OSes. Its [scene migration guide](https://developer.apple.com/documentation/uikit/transitioning-to-the-uikit-scene-based-life-cycle)
explains that scene callbacks replace AppDelegate UI lifecycle callbacks. An
[Apple frameworks engineer's clarification](https://developer.apple.com/forums/thread/832787)
separates apps built with SDK 27 from older-SDK apps that continue to launch on 27.

The frozen candidate AppDelegate creates its factory, `UIWindow(frame:)` and React root in
`didFinishLaunchingWithOptions`; it does not conform to `ExpoReactNativeFactoryProvider`.
Its plist has no `UIApplicationSceneManifest`. `UILaunchStoryboardName` is already present,
so the separate launch-screen requirement is not a finding here. This is a real source gap,
not a failed launch experiment.

Expo's [SDK 57 scene guidance](https://docs.expo.dev/versions/v57.0.0/sdk/build-properties/)
and [maintainer's dated instruction](https://github.com/expo/expo/issues/46664)
require Expo 57.0.23+ and explicit scene opt-in. Our Expo 57.0.26 meets that version condition.
The official plugin is a prebuild/CNG mechanism; the maintained bare source does not acquire
its behavior by placing a property in app.json. Do not add an unused plugin or run prebuild
over the preserved provenance trees.

Published [expo-build-properties 57.0.22 metadata](https://registry.npmjs.org/expo-build-properties/57.0.22)
binds publisher commit 9349d1457178dd9cccb8bdd3aed47473c49134e1. Its exact
[iosSceneSupport source](https://github.com/expo/expo/blob/9349d1457178dd9cccb8bdd3aed47473c49134e1/packages/expo-build-properties/src/iosSceneSupport.ts)
and [production plugin caller](https://github.com/expo/expo/blob/9349d1457178dd9cccb8bdd3aed47473c49134e1/packages/expo-build-properties/src/withBuildProperties.ts)
provide the bounded recipe: keep factory initialization in AppDelegate, add provider conformance,
remove its window/React startup, and add a single scene configuration using
`EXExpoAppSceneDelegate` with multiple scenes disabled. The installed Expo class creates the
scene window and starts default module `main`; its provider defaults the module name.

The installed delegate rebuilds cold-link launch options for `Linking.getInitialURL()`, forwards
warm URL/user-activity events and lifecycle/quick actions to AppDelegate/subscribers, and dedupes
existing AppDelegate linking announcements. Retain the existing overrides and superclass calls;
adding an additional custom forwarder would risk duplicate delivery. The APIs work within the
retained deployment floor structurally, but 16.4 execution is still pending.

The next source-only unit should touch the existing exact owners:

- `tools/migration/lib/native-template-transforms.mjs`: declare AppDelegate's reviewed scene
  transformation and extend the existing plist recipe. Use exact preimages, not permissive regex
  fallback. Record original AppDelegate template text through the authenticated manifest owner
  because it becomes a transformed member.
- `tools/migration/lib/native-source-contract.mjs`: replace its AppDelegate `withModuleName`
  predicate with the actual provider/default-module owner; require the exact scene manifest,
  factory creation, preserved linking/super calls and absence of legacy root startup. Preserve
  all identity, Release/Hermes, ATS, bundling and floor predicates.
- `tools/migration/tests/native-source-contract.test.mjs`, the derived maintained
  `AppDelegate.swift` / `Info.plist`, manifest and provenance: positive real materializer/checker
  plus missing/wrong scene class, missing provider, legacy/double startup and floor-drift controls;
  retain original archive/source receipts as historical. Generate successor records via owners.

An independent source review precedes execution. Then compile the candidate against SDK 27 and
exercise current-OS cold launch, background/foreground, cold and warm custom/universal links
and once-only event delivery through the real app. A successful compile alone closes none of
those launch/lifecycle checks. The separate 16.4 mount repeats the same representative checks.
Using 26.6 alone can temporarily avoid the new-SDK launch requirement, but delays this required
27-SDK adoption; it does not resolve it.

## Small provisioning and compile route, still pending

Use the separate [Ruby/Bundler/CocoaPods source note](/private/tmp/splotch-ios-ruby-boundary-research-candidate-entry.md)
for the proposed Ruby 3.4.11 / bundled Bundler 2.6.9 / CocoaPods 1.16.2 and xcodeproj 1.27.0,
its explicit incompatible RN-template xcodeproj-bound disposition, and owned path controls.
Ruby 3.2 in the EAS reference is EOL; system Ruby 2.6 is not the proposed provider.
Borrowed OpenSSL linkage and absent private libyaml remain unqualified. The shipping iOS
project uses SPM; provisioning is for the candidate only. No system Ruby, Homebrew installation,
global gem directory, shell startup file or `HOME` rewrite is proposed.

After tool/source approval, use a private owned Ruby prefix and candidate Gemfile/lock with
Bundler. The first lock creation is network resolution, not a frozen reproduction. Audit the
resolved gem closure/native extensions and sources before installation; use the existing standard
Bundler lock/frozen/deployment controls afterward. Add Podfile.lock via the actual candidate
Podfile/autolinking owner, review its pods/source/Release configuration, then use
`bundle exec pod install --deployment` for reproduction. Keep compiled Ruby/OpenSSL, gem,
Bundler, CocoaPods repo/cache and temporary outputs in declared owned paths. Do not copy the
RN reference Gemfile's constraint blindly.

The subsequent compile uses an explicit per-process `DEVELOPER_DIR`, profile-aligned Node 24.16.0,
owned DerivedData, Release and simulator SDK, without mutating `xcode-select` or shipping trees.
The fixed native profile owns `node;24.16.0`; the actual host inventory recorded that exact binary
version with exit 0. Its profile-archive byte/publication proof is still pending. Root Node 22 and
pnpm ownership remain separate. The same Node 24 bin directory leads the finite PATH for pod
preparation/autolinking because the maintained Podfile invokes bare `node`; the Xcode bundle
phase separately requires the absolute `NODE_BINARY`.
After pod installation has actually created the workspace, the bounded command shape is:

```sh
DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer \
NODE_BINARY=/Users/kylemit/.nvm/versions/node/v24.16.0/bin/node \
PATH=/Users/kylemit/.nvm/versions/node/v24.16.0/bin:/usr/bin:/bin:/usr/sbin:/sbin \
xcodebuild -workspace experiments/native-architecture/ios/HelloWorld.xcworkspace \
  -scheme HelloWorld -configuration Release -sdk iphonesimulator \
  -destination 'generic/platform=iOS Simulator' \
  -derivedDataPath "$splotchIosRoot/derived-data/sdk27" CODE_SIGNING_ALLOWED=NO build
```

This is a proposed invocation, not an executed command or provisioned path. Capture actual
resolved settings, deployment target, Podfile.lock/source graph, bundler versions and Release
bundle; do not substitute Debug or a live Metro server for the final Release checks.

For the floor, qualify a separately installed official Xcode 26.6 app first, select it only with
`DEVELOPER_DIR`, and use its Components catalog or documented
`xcodebuild -downloadPlatform iOS -buildVersion 16.4 -exportPath <owned-export>` followed by
`xcodebuild -importPlatform <authenticated-runtime.dmg>`. Apple's
[component documentation](https://developer.apple.com/documentation/xcode/downloading-and-installing-additional-xcode-components)
describes these operations; export does not guarantee private-only installation. Record standard
CoreSimulator/platform writes explicitly. Authenticate actual tools/runtime and verify 20E247,
architecture and availability before creating/reserving a task-owned device. No global selection,
existing-device cleanup or runtime substitution is needed. If that exact runtime cannot be
obtained or used, an actual 16.4 device with a supported tool/host is the remaining floor route;
26.5 or 27 launches cannot be counted as its substitute.

## Evidence bounds

[Primary source receipt](/private/tmp/splotch-ios-environment-primary-20261006/sources-receipt.json)
retains public metadata/source bytes, not package/SDK archives. The
[local owner receipt](/private/tmp/splotch-ios-environment-primary-20261006/local-owner-receipt.json)
binds frozen candidate sources, maintained owners, host context and installed Expo 57.0.26
sources. Installed hashes are observed source context, not a new archive authentication result:

| Source | SHA-256 |
| --- | --- |
| Frozen candidate AppDelegate | `510895dbd9aec82fe5c8143baf7cc4740449433f4a59a7299dd3dc1c6a408aeb` |
| Frozen candidate Info.plist | `78578f597d540f1fde5a8299c98a7b7d826824f225d47bc84bf6915a9b600021` |
| ExpoAppSceneDelegate.swift | `eb614d63c4d2c571da2a34af2666c861c99ff938bd6c93dee82e3e73a03b29bf` |
| ExpoReactNativeFactoryProvider.swift | `2e49994074c7fb4b5b7c496c51a255ff98787523c45e1ab446029532c39e774a` |
| SceneEventForwarder.swift | `12177396ef45d5573aaff31e273a898f7fda7c9833de37154dc8c51b83afa221` |
| Published-commit iosSceneSupport.ts | `df7aaa119466a80f5f4af2f58a7128c9aca5b30e9071b551559d2c24274e3a34` |

No repo/Native07a packet edits, source imports, SDK/tool/archive downloads, provisioning, native
commands, builds, installs, simulator starts/reservations, tests or Git mutations occurred in
this pass. Remaining compilation, SDK 27 launch and exact floor mount are recorded separately;
other source/migration work may continue while they are pending.

## Source-only successor correction

This immutable successor preserves the original sealed report/receipt alongside it. It corrects
the proposed native command from root Node 22 to the fixed native profile's Node 24 and adds
the matching PATH for the actual bare-node callers. The separately authored
[Ruby boundary independent review](RUBY-BOUNDARY-INDEPENDENT-REVIEW.md) verifies the child
recommendation, distinguishes a departure from RN reference constraints from an existing
candidate exception, and specifies an owned NETRC directory for the actual CDN credential-path
consumer. These are source-backed future decisions, not provisioning or executed controls.
