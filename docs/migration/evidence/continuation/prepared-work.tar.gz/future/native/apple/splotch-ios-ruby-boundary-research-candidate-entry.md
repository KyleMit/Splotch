# iOS Ruby boundary: candidate-entry primary research

Recommend an owned CRuby **3.4.11**, its bundled **Bundler2.6.9**, and a candidate-only Gemfile locking **CocoaPods1.16.2 / xcodeproj1.27.0**. Use the standard release-source configure/make prefix and Bundler/Gemfile.lock owners; no global manager, shim framework or system Ruby replacement. This is a proposed boundary, not a provisioned or executed result. Root's Xcode27/16.4 target versus17+ simulator/device and scene-adoption facts remain separate Apple constraints.

## Exact version decisions

[Expo's current sdk-57 image](https://docs.expo.dev/build-reference/infrastructure/) names macos-tahoe-26.5-xcode-26.6, Ruby3.2 and CocoaPods1.16.2. It gives no exact Ruby patch or Bundler pin. Match its CocoaPods version, but do not reproduce its unsupported Ruby branch: [Ruby's branch ledger](https://www.ruby-lang.org/en/downloads/branches/) marks3.2 EOL2026-04-01; [3.2.11](https://www.ruby-lang.org/en/news/2026/03/27/ruby-3-2-11-released/) is the final release. Ruby3.4 remains normally maintained. Its [3.4.11 release](https://www.ruby-lang.org/en/news/2026/09/23/ruby-3-4-11-released/) lists source tar.gz22,492,449 bytes, SHA256 `5c22be44524312b3d433d68739bcc530633b1da5ef8ba0afa0a37680da17d3de`. No Ruby archive was acquired.

The [tagged Ruby3.4.11 Bundler owner](https://raw.githubusercontent.com/ruby/ruby/v3_4_11/lib/bundler/version.rb) sets2.6.9. This avoids a second Bundler bootstrap installation. Public [Bundler2.6.9 metadata](https://rubygems.org/api/v2/rubygems/bundler/versions/2.6.9.json) requires Ruby>=3.1.0 and RubyGems>=3.3.3; its gem SHA256 is `a25675ffbd055ae1186766cc1e120b4cf62588e88abb59b99c57e22b1c55c9eb`. The [CocoaPods1.16.2 metadata](https://rubygems.org/api/v2/rubygems/cocoapods/versions/1.16.2.json) requires Ruby>=2.6 and binds its gem SHA256 `0ff1c860f32df3db8b16df09b58da1a6bb2a12fe55f6d5e8be994a74fadd1e5e`. Those are published metadata observations, not downloaded-gem verification.

There is a real Gemfile conflict. The [RN0.86.3 repository Gemfile](https://raw.githubusercontent.com/facebook/react-native/v0.86.3/Gemfile) and [community app-template0.86.3 Gemfile](https://raw.githubusercontent.com/react-native-community/template/0.86.3/template/Gemfile) both cap xcodeproj below1.26.0. [CocoaPods1.16.2's tagged gemspec](https://raw.githubusercontent.com/CocoaPods/CocoaPods/1.16.2/cocoapods.gemspec) requires xcodeproj>=1.27.0,<2.0. There is no simultaneous solution. The installed RN npm package and existing Expo bare candidate supply no Gemfile/Gemfile.lock. Therefore use an explicit Expo-aligned candidate Gemfile, recording this narrow upstream-template exception rather than claiming its unchanged constraints are satisfied. Pin xcodeproj1.27.0; published gem SHA256 `8cc7a73b4505c227deab044dce118ede787041c702bc47636856a2e566f854d3`. Its use with the actual candidate project under Xcode27 remains a real qualification, not inferred from version arithmetic.

For the candidate Gemfile, retain the community template's activesupport lower bound/exclusion and concurrent-ruby<1.3.4, plus its five explicit Ruby3.4 library gems (bigdecimal, logger, benchmark, mutex_m, nkf); let the reviewed lock bind exact transitive versions. The repository-development Gemfile instead caps activesupport<7.1.0 and allows concurrent-ruby<=1.3.4; do not silently label those differing development/app contexts identical. CocoaPods-core1.16.2 permits activesupport>=5,<8 and concurrent-ruby~>1.1, so the proposed community ranges are compatible with its declared ranges. This research did not resolve them or audit selected native gem extensions.

## Source-build prerequisites and smallest route

The [tagged Ruby build guide](https://raw.githubusercontent.com/ruby/ruby/v3_4_11/doc/contributing/building_ruby.md) needs a C compiler plus OpenSSL/libyaml/zlib for RubyGems. A released source tarball supplies configure; git-source autoconf/gperf/newer-bootstrap-Ruby requirements are not a reason to add those tools for this route. Configure a fixed owned prefix with explicit OpenSSL/libyaml directories, disable installation docs and YJIT to avoid a Rust prerequisite, then standard make/install. These are future executable stages requiring source/archive qualification first.

Fixed-path metadata reads found Homebrew OpenSSL3.6.3 at `/opt/homebrew/opt/openssl@3` (header plus receipt; read only), no libyaml header/receipt under `/opt/homebrew/opt/libyaml`, and no libyaml header/library at either fixed Xcode/CLT SDK path. Both SDKs do provide zlib header/library metadata. No ruby-build/rbenv/Homebrew Ruby executable existed at the queried fixed paths. These are limited path observations, not a complete host search or link/build success.

The minimal first route can borrow the existing OpenSSL prefix read only after qualifying its exact header/library/compiler architecture and linkage receipts, and add a pinned private libyaml0.2.5 source prefix if no other already-qualified libyaml exists. The OpenSSL runtime remains a borrowed host input in that route; it is not a wholly self-contained Ruby provider. An entirely private OpenSSL source build is the fallback if borrowed linkage cannot be qualified or retained; pin that release/archive before execution. Do not use global brew install/upgrade. OpenSSL compilation adds another build/input audit and measurable time/disk cost. libyaml archive/checksum and actual compiled linkage remain pending.

A standalone pinned ruby-build is an alternative, but adds an installer owner and its automatic Homebrew/dependency selection. Its currently retained moving3.4.11 definition chooses OpenSSL3.0.22 conditionally. That moving file is context only, not an accepted installer pin or permission to execute/download it. Direct released-source configure with explicit prefixes is smaller here. [CocoaPods installation guidance](https://guides.cocoapods.org/using/getting-started.html) supports a separate Ruby and non-sudo gem paths; do not use its global/user-profile installation examples verbatim.

## Finite child environment and real commands

Let `T` be one marked external owned iOS tooling root, `R=T/ruby-3.4.11`, and `C` the disposable authenticated native build copy. Preserve actual HOME unchanged. Supply an explicit finite child environment; reject inherited RUBYOPT/RUBYLIB/GEM/BUNDLE/CP selectors rather than letting them override these owners. PATH begins R/bin and the already-qualified owned Node/bin, then fixed Apple/system tool paths; do not prepend a user's version-manager shims. The proposed values are:

| Owner | Explicit value |
| --- | --- |
| GEM_HOME | T/gem-home |
| GEM_PATH | T/gem-home plus R's own versioned default-gem directory; no trailing separator or global path |
| GEM_SPEC_CACHE | T/gem-spec-cache |
| BUNDLE_GEMFILE | T/config/Gemfile |
| BUNDLE_PATH | T/bundle |
| BUNDLE_USER_HOME / BUNDLE_APP_CONFIG | T/bundle-user / T/bundle-app |
| BUNDLE_DISABLE_SHARED_GEMS / BUNDLE_DISABLE_VERSION_CHECK | true / true |
| XDG_CACHE_HOME / XDG_CONFIG_HOME / XDG_DATA_HOME / XDG_STATE_HOME | four named directories below T |
| CP_HOME_DIR / CP_CACHE_DIR / CP_REPOS_DIR / CP_TEMPLATES_DIR | T/cocoapods and explicit cache/repos/templates children |
| TMPDIR | T/tmp |

The [tagged CocoaPods Config owner](https://raw.githubusercontent.com/CocoaPods/CocoaPods/1.16.2/lib/cocoapods/config.rb) proves CP_HOME_DIR relocates config/repositories and its default cache; CP_CACHE_DIR explicitly overrides cache after user settings. CP_REPOS_DIR/CP_TEMPLATES_DIR select their exact owned children. XDG alone does **not** relocate CocoaPods' default Library/Caches path. Ruby's [default cache](https://raw.githubusercontent.com/ruby/ruby/v3_4_11/lib/rubygems/defaults.rb) can prefer an existing HOME/.gem/specs; its [path-support owner](https://raw.githubusercontent.com/ruby/ruby/v3_4_11/lib/rubygems/path_support.rb) explicitly honors GEM_SPEC_CACHE. Set that rather than claiming XDG alone fences legacy caches. Empty owned configuration and reviewed default-gem paths require actual readback; public-network credentials are not copied from HOME. This is a finite known-write boundary, not arbitrary-process syscall containment.

Proposed commands, **not run**, invoked with the above environment:

```sh
R/bin/ruby R/bin/bundle _2.6.9_ lock --add-checksums
R/bin/ruby R/bin/bundle _2.6.9_ install
R/bin/ruby R/bin/bundle _2.6.9_ exec pod install --project-directory=C/experiments/native-architecture/ios --deployment
```

The first command is an explicitly provisional network **resolution** stage: generate Gemfile.lock with CHECKSUMS and actual Mac platform, then review all selected gem coordinates/checksums/source/native-extension declarations. It installs no gems but does perform network metadata resolution; checksum bootstrap is not independent publisher authenticity. No frozen/deployment selectors may accidentally prohibit this initial resolution. No Linux iOS graph/platform is invented.

Only after that review, set BUNDLE_FROZEN=true and BUNDLE_DEPLOYMENT=true for the second command, keep checksum validation enabled, require before/after lock bytes unchanged and use the explicit owned BUNDLE_PATH. Network may still fetch exact locked gem archives and native extensions may compile; this differs from lock creation. The third command runs the locked pod tool through Bundler. [CocoaPods' tagged install owner](https://raw.githubusercontent.com/CocoaPods/CocoaPods/1.16.2/lib/cocoapods/command/install.rb) defines --deployment to disallow Podfile/Podfile.lock changes. The first Podfile.lock generation must instead be a separately labelled pod-resolution/install stage in C with normal install, followed by review and a deployment-mode repeat. Ruby Gemfile.lock and native Podfile.lock are two different graphs.

## Native generated boundaries and pending acceptance

The maintained Podfile executes Node for Expo/RN autolinking, imports released Ruby scripts, and enables prebuilt RN/Expo inputs by default. Pod installation is executable native preparation, not a pure package metadata fetch. Installed RN react_native_pods.rb owns `build/generated/ios/ReactCodegen` and ReactAppDependencyProvider and calls codegen; its installer may generate Pods, lock/workspace and integration changes to the candidate Xcode project. CocoaPods' install command documents the project build-configuration/resource-script modifications. Capture those in the disposable build copy with explicit input/output receipts; do not assert the maintained project remains byte-identical or widen Native07a source ignores to every package build directory. Candidate source/provenance is authenticated before the copy; Podfile.lock and generated integration are separately reviewed build inputs/outputs.

Next qualification is deliberately small: exact Ruby/libyaml/OpenSSL archive or borrowed-link inputs, private prefix runtime identity/OpenSSL/Psych/default-Bundler probe, complete reviewed gem lock/checksums and locked installation, owned-cache/HOME witness, then separate pod graph/output receipts and actual Xcode compilation. No Ruby/gem/pod executable, SDK manager, Xcode build, shell profile, sudo/Homebrew mutation, runtime archive, install, candidate import, test or Git command was executed. Current docs, tagged source and public JSON only were acquired; this note does not claim successful provisioning or solve the independent Xcode27 launch/floor gates.
