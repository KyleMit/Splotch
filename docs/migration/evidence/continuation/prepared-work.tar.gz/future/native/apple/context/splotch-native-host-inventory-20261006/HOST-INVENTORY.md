# Native candidate host prerequisite inventory

The host has compatible Node and Xcode versions and matching Android platform/build-tools
metadata. It is not yet a qualified candidate native build environment: the pinned Java 17,
NDK, CMake and CocoaPods toolchains are missing from the checked locations. Neither OS floor
simulator is currently available. This is read-only inventory; Native78 remains prepared source
without an execution or compile result.

| Prerequisite | Actual host observation | Remaining qualification |
| --- | --- | --- |
| Host | macOS 26.6.2 / 25G83, arm64 | Linux is a separate compile-only caller, with no Linux mount requirement. |
| Root Node | Exact Node 22.23.2 binary version command exits 0. Root owner remains `engines.node >=22.13`. | Preserve the root floor. This inventory does not authenticate the installed binary against a reviewed runtime archive. |
| Profile Node | Exact installed Node 24.16.0 version command exits 0. | Version agrees with the profile; archive-byte equivalence remains unproved. |
| Package manager | Exact Node 22 invokes the cached pnpm 11.22.0 CJS; version command exits 0 with 11.22.0. | The cached CJS is not directly executable. Retain root’s qualified launcher; no global shim/Corepack mutation. |
| JDK | Registered Temurin 21.0.11+10 arm64; exact safe version command agrees. | Profile selects Temurin 17.0.20.1+1. No Java 17 found in registered/common paths; this is a bounded search. |
| Android platform | Global SDK platform 36 revision 2 descriptors and android.jar present. | Metadata identity only; no authenticated archive/compiler proof. |
| Build tools | Global SDK build-tools 36.0.0 descriptors and aapt2 present. | Metadata identity only; no byte-authentication or execution proof. |
| Command-line tools | Revision 20.0 under the global `latest` alias; sdkmanager/avdmanager launchers present. | The alias is not an owned candidate publication. Neither launcher ran. |
| NDK / CMake | Global SDK `ndk` and `cmake` directories absent. | Pinned NDK 27.1.12297006 and CMake 3.30.5 need reviewed intake/publication before compile. |
| Android mount tools | Platform-tools 37.0.0 and emulator 36.6.11 metadata; executables present. | No adb/emulator invocation. These are separate mount inputs; binary/discovery/auth/write fences remain pending. |
| Android API 24 floor | No API 24 image directory or configured API 24 AVD observed. Existing AVDs target 28/33. | Newer images cannot prove API 24. Floor provisioning/mount remains pending. |
| Xcode | Selected full Xcode at `/Applications/Xcode.app/Contents/Developer`; version 27.0 / 27A266a. Version command exits 0. | Meets Expo’s documented 26.4 minimum; candidate Podfile/Xcode 27 compatibility needs a real compile. No selection/license changes. |
| Apple SDKs | Device and simulator SDK version commands exit 0 with 27.0. | SDK presence does not prove compilation or the runtime floor. |
| Apple runtimes | Host simctl query exits 0: iOS 26.5 / 23F77 and 27.0 / 24A434 available. All 23 existing devices are Shutdown. | No boot/reservation/launch occurred. No iOS 16.4 runtime is available; floor mount remains pending. |
| Ruby / CocoaPods | System Ruby 2.6.10; no pod on PATH or checked Homebrew/usr/local paths; no CocoaPods gemspecs in checked conventional roots. | Shipping iOS uses SPM. The candidate requires CocoaPods, with future reviewed Ruby/Bundler/gem provenance and candidate Gemfile/lock/Podfile.lock. |

Requirements have concrete owners:

- The current topology candidate manifest pins Expo 57.0.26, RN 0.86.3 and React 19.2.3,
  plus its reviewed Babel/types/preset dependencies. No Skia/audio/worklet dependency is added
  here. The native WT has prepared native trees but has not integrated that package manifest;
  installed RN/Expo sources were read from the topology WT without importing or running them.
- The [Expo 57 SDK table](https://docs.expo.dev/versions/v57.0.0/) specifies RN 0.86,
  React 19.2.3, Node 22.13.x, Android 7+, compile/target SDK 36, iOS 16.4+ and Xcode 26.4+.
  Retrieved 2026-10-06; the page reports its last update as 2026-09-17.
- `tools/migration/lib/native-source-contract.mjs` owns API 24, compile/target 36,
  build-tools 36.0.0, NDK 27.1.12297006, iOS 16.4 and Gradle 9.3.1. The prepared Podfile
  actually fetches `ios.deploymentTarget`, initializes Expo/RN pods and Hermes, and does not
  copy the shipping SPM project.
- Installed published RN 0.86.3 supports Node `^22.13.0` and `^24.3.0`; both observed versions
  satisfy their respective ranges. RN’s Android catalog owns AGP 8.12.0 and Kotlin 2.1.20.
  `ReactAndroid/build.gradle.kts` requests CMake 3.30.5 by default. ExpoRootProjectPlugin
  consumes `android.cmakeVersion` and assigns externalNativeBuild CMake for application/library
  subprojects. Effective Gradle/included-build values remain unmeasured.
- RN’s pod helper contains weaker library minima of iOS 15.1 / Xcode 16.1. These do not lower
  the Expo/candidate iOS 16.4 / Xcode 26.4 requirements. Being newer than the minima is only
  initial structural feasibility, not build compatibility proof.
- `android-toolchain-profile.json` owns the eight-artifact compile selection
  `expo57-rn0863-agp812-v1`. Its fixed Mac root under
  `/Users/kylemit/.cache/splotch/native-toolchains` is absent. Prepared archive intake returns
  `publicationAllowed=false` and `nativeExecution=false`; no intake/downloader/parser code ran.

The Android receipt records a concrete API 28 image descriptor conflict: source.properties
revision 1 versus package.xml revision 2. Neither revision is preferred or certified. Global
SDK/AVD contents are planning inputs, not an approved substitute for the owned toolchain.

Sandbox simulator queries exited 1 because CoreSimulatorService/log access was blocked; the
host-access read-only query subsequently exited 0. This is an access limitation, not a missing
runtime result. The ordinary query may connect platform services/write platform logs; it did not
boot or change a simulator. No credentials, auth-key contents or whole environment were read.
No downloads, installs, builds, tests, compiler/parser imports, Git writes, SDK publication or
repository edits occurred. Only private note/receipt writes occurred.

`host-ios-node-inventory.json` preserves exact command/exit outputs and selected simulator
metadata, omitting UDIDs. `source-owner-receipt.json` binds it, the Android note/receipt and exact
version-owner sources. Descriptor hashes identify the observed files; they do not prove archive
equivalence, arbitrary host equality, native fidelity or performance. Initial draft note/receipt
are preserved beside the final files; the final receipt uses the actual intake caller paths.
