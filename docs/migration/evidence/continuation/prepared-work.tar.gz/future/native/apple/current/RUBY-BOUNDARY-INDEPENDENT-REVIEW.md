# Ruby boundary independent source review — 2026-10-06

The child's proposed Ruby 3.4.11 / its bundled Bundler 2.6.9 / CocoaPods 1.16.2 /
xcodeproj 1.27.0 is a reasonable candidate boundary. It is **not yet a compiled, installed or
locked environment**. I independently read the reference Gemfiles, the actual preserved Expo
manifest/Podfile/project and installed RN pod/autolinking source, CocoaPods/Bundle/Ruby path
owners and public primary pages. No candidate/Ruby/gem code was imported or executed.

## Verified constraints and precise disposition

The actual `expo-template-bare-minimum` 57.0.28 manifest lists 59 archive members and has no
Gemfile/Gemfile.lock; neither does its maintained Native07a roster. The installed RN npm package
also has no Gemfile. The candidate's actual Podfile imports Expo/RN pod helpers and uses
CocoaPods, so a new candidate-specific Gemfile is justified; no existing candidate xcodeproj
constraint is being waived.

The [RN community app template 0.86.3](https://raw.githubusercontent.com/react-native-community/template/0.86.3/template/Gemfile)
requires Ruby >=2.6.10, CocoaPods >=1.13 except1.15.0/1.15.1, xcodeproj <1.26.0,
activesupport >=6.1.7.5 except7.1.0 and concurrent-ruby <1.3.4. Its five Ruby3.4 compatibility
gems are bigdecimal/logger/benchmark/mutex_m/nkf. The
[RN repository development Gemfile](https://raw.githubusercontent.com/facebook/react-native/v0.86.3/Gemfile)
has different ActiveSupport/concurrent-ruby ranges and omits nkf; these are distinct contexts.

[CocoaPods 1.16.2's exact gemspec](https://raw.githubusercontent.com/CocoaPods/CocoaPods/1.16.2/cocoapods.gemspec)
requires xcodeproj >=1.27.0,<2.0 and Ruby >=2.6. The intersection with the reference xcodeproj
cap is empty. The Expo SDK57 build image explicitly uses CocoaPods1.16.2; therefore choose it
and xcodeproj1.27.0 in the new candidate Gemfile, documenting the **departure from the RN
reference template**. Do not describe this as satisfying that unchanged template or create a
new policy exception to a nonexistent candidate constraint. Choosing an older CocoaPods to
retain the reference cap would depart from Expo's actual baseline and adds an unnecessary
qualification alternative; using the newer SDK58 tool/image would not itself prove57 support.

Retain the community app-template ActiveSupport/concurrent-ruby compatibility constraints and
Ruby3.4 library declarations as upstream app compatibility inputs. Their exact versions belong
in the reviewed Gemfile.lock. CocoaPods-Core1.16.2's actual metadata admits ActiveSupport>=5,<8
and concurrent-ruby~>1.1, which is compatible with those ranges. This is constraint arithmetic,
not a resolved graph. I observed the RN autolinking helper's real `require 'cocoapods'`; I did not
prove that its executed path directly requires every one of the five library gems. Their role is
retained template compatibility, not five independently measured application dependencies.

[Ruby's current branch ledger](https://www.ruby-lang.org/en/downloads/branches/) marks3.4
normally maintained and3.2 EOL2026-04-01. The
[3.4.11 release](https://www.ruby-lang.org/en/news/2026/09/23/ruby-3-4-11-released/) is dated
2026-09-23, and its tagged Bundler source sets2.6.9. Prefer that supported3.4 provider over
reproducing the EAS image's EOL3.2 branch or the observed system2.6. Do not add a separate
Bundler bootstrap installation. Exact runtime/default-gem behavior and the actual candidate
Xcode project remain unqualified; its preserved objectVersion54 does not establish Xcode27
compatibility.

## One concrete finite environment addition

The child's CP_HOME_DIR/CP_CACHE_DIR/CP_REPOS_DIR/CP_TEMPLATES_DIR and GEM_SPEC_CACHE choices
are supported by the retained tagged source. XDG alone does not relocate CocoaPods' default
Library/Caches directory or an existing RubyGems HOME/.gem/specs cache. Explicit GEM_PATH has
no trailing separator and includes only the owned gem root plus the owned Ruby default-gem
directory. BUNDLE_USER_HOME/APP_CONFIG are owned, with ambient selectors refused rather than
silently inherited. HOME itself stays unchanged.

The current table needs one additional known input owner before public pod network execution.
[CocoaPods Core1.16.2 CDN source](https://raw.githubusercontent.com/CocoaPods/Core/1.16.2/lib/cocoapods-core/cdn_source.rb)
passes optional `Netrc.default_path` to libcurl. The tagged
[netrc0.11.0 implementation](https://raw.githubusercontent.com/geemus/netrc/v0.11.0/lib/netrc.rb)
defines that path as `File.join(ENV['NETRC'] || home_path, netrc_filename)`. Therefore set
`NETRC` to an owned **directory**, such as `T/netrc`, with an owned empty `.netrc` for this
public-source caller. Do not set it to the filename, rewrite HOME, copy/read host credential
contents or claim the original cache variables prevent credential lookup. Reject conflicting
ambient NETRC; the eventual locked gem/source proof must retain this exact consumer behavior.
This finite standard selector closes the demonstrated HOME/.netrc fallback without a new
network/credential framework. Actual positive/missing/conflicting-path controls remain pending.

## Decisions before the next executable unit

1. Bind released Ruby3.4.11 source, compiled prefix and its bundled2.6.9/default gem identity.
   Direct configure/make with explicit owned prefixes is smaller than an extra moving installer.
   Qualify borrowed OpenSSL3.6.3 linkage/architecture or choose an independently pinned private
   OpenSSL build; the bounded host read did not certify either. Qualify private libyaml because
   it was absent in the queried locations. No source archive or build was acquired/run here.
2. Add the explicit candidate Gemfile with the choices above, generate a provisional Mac lock
   using the existing Bundler owner and checksum support, then review the complete selected gem
   sources/checksums/native extensions before a frozen/deployment installation. The reference
   ranges are compatibility inputs; the lock owns actual selected versions. No resolver result
   is available in this pass.
3. Supply the existing finite CP/GEM/BUNDLE/XDG/TMP owners plus NETRC and profile Node24 PATH.
   Use the actual Podfile through locked `bundle exec pod install` in an authenticated disposable
   native copy. Initial Podfile.lock generation is a separate graph/install stage; subsequent
   `--deployment` reproduces it. Pod installation executes published helpers/codegen and may
   change generated Pods/workspace/project integration; it is not a pure metadata read.
4. Qualify the resulting locks, tool versions/paths, generated integration and actual SDK27
   Release compile separately from scene launch/lifecycle and16.4 mount. The current source
   boundary does not assert arbitrary read/write isolation or successful provisioning.

The child's retained primary text/metadata rows were hash-checked; path-support source is a
separately retained additional row. The successor receipt binds the reviewed child report and
actual local owners. No original child/report, Native58, worktree, package/lock, provisioning or
Git state changed. Public pages/tagged source were read; no archives/binaries were downloaded,
no runtime was imported, and no command/control/boot was executed.
