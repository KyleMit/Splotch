import { createHash } from 'node:crypto';
import { linkSync, mkdtempSync, readFileSync, rmSync, symlinkSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterEach, expect, it } from 'vitest';
import { inspectAndroidCandidateArchive } from '../lib/android-candidate-archives.mjs';
import { ARCHIVE_TEXT_LIMIT_BYTES } from '../lib/android-sdk-members.mjs';
import { tinyArtifact, tinyTar, paxFixtureRecord } from './archive-fixtures.mjs';

const ZIP_STREAM_ERROR_CONTROL_TIMEOUT_MS = 5_000;
const roots = [];
const zipFixtures = JSON.parse(
  readFileSync(join(import.meta.dirname, 'fixtures/native-archive-zip.json'), 'utf8')
);
const hash = (text) => createHash('sha256').update(text).digest('hex');
function archived(bytes, format, fields) {
  const root = mkdtempSync(join(tmpdir(), 'splotch-archive-fixture-'));
  roots.push(root);
  const artifact = tinyArtifact(bytes, format, fields);
  const file = join(root, artifact.filename);
  writeFileSync(file, bytes);
  return { artifact, file, root };
}
afterEach(() => roots.splice(0).forEach((root) => rmSync(root, { recursive: true, force: true })));

it('consumes actual stored and deflated ZIP member bytes before emitting a nonpublication receipt', async () => {
  const fixture = archived(Buffer.from(zipFixtures.storedAndDeflated, 'base64'), 'zip');
  const result = await inspectAndroidCandidateArchive(fixture.file, fixture.artifact);
  for (const [name, text] of [
    ['stored', 'stored fixture content\n'],
    ['deflated', 'deflated fixture content\n'.repeat(8)],
  ]) {
    const row = result.members.find((member) => member.path === `fixture/${name}.txt`);
    expect(row.bytes).toBe(Buffer.byteLength(text));
    expect(row.sha256).toBe(hash(text));
  }
  expect(result.publicationAllowed).toBe(false);
  expect(result.nativeExecution).toBe(false);
  expect(result.selectedNodeMembers).toBeNull();
});

it.each([
  ['corruptDeflateStream', /invalid block type/],
  ['inflatedSizeTooLarge', /not enough bytes in the stream\. expected 201\. got only 200/],
])('settles the real ZIP stream error and reader close for %s', async (name, error) => {
  const positive = archived(Buffer.from(zipFixtures.storedAndDeflated, 'base64'), 'zip');
  const receipt = await inspectAndroidCandidateArchive(positive.file, positive.artifact);
  const deflated = receipt.members.find((row) => row.path === 'fixture/deflated.txt');
  expect(deflated.bytes).toBe(200);
  expect(deflated.sha256).toBe(hash('deflated fixture content\n'.repeat(8)));
  expect(receipt.publicationAllowed).toBe(false);

  const negative = archived(Buffer.from(zipFixtures[name], 'base64'), 'zip');
  await expect(inspectAndroidCandidateArchive(negative.file, negative.artifact)).rejects.toThrow(error);
}, ZIP_STREAM_ERROR_CONTROL_TIMEOUT_MS);

it('checks full archive identity and independent file ownership before parsing', async () => {
  const bytes = Buffer.from(zipFixtures.storedAndDeflated, 'base64');
  const fixture = archived(bytes, 'zip');
  await expect(
    inspectAndroidCandidateArchive(fixture.file, fixture.artifact)
  ).resolves.toMatchObject({ publicationAllowed: false });
  writeFileSync(fixture.file, Buffer.concat([bytes, Buffer.from('changed')]));
  await expect(inspectAndroidCandidateArchive(fixture.file, fixture.artifact)).rejects.toThrow(
    /Archive size/
  );
  writeFileSync(fixture.file, bytes);
  fixture.artifact.checksum.hex = '0'.repeat(64);
  await expect(inspectAndroidCandidateArchive(fixture.file, fixture.artifact)).rejects.toThrow(
    /Archive checksum/
  );
  fixture.artifact = tinyArtifact(bytes, 'zip');
  const link = join(fixture.root, 'link.zip');
  symlinkSync(fixture.file, link);
  await expect(inspectAndroidCandidateArchive(link, fixture.artifact)).rejects.toThrow(
    /regular independent/
  );
  linkSync(fixture.file, join(fixture.root, 'hardlink.zip'));
  await expect(inspectAndroidCandidateArchive(fixture.file, fixture.artifact)).rejects.toThrow(
    /regular independent/
  );
});

it('records a real internal ZIP symlink while rejecting unsafe links, names, types and extra encodings', async () => {
  const positive = archived(Buffer.from(zipFixtures.internalSymlink, 'base64'), 'zip');
  const receipt = await inspectAndroidCandidateArchive(positive.file, positive.artifact);
  expect(receipt.members.find((row) => row.type === 'symlink').link).toBe('stored.txt');
  for (const [name, error] of [
    ['escapingSymlink', /Escaping/],
    ['duplicate', /Duplicate/],
    ['traversal', /relative path|Unsafe|invalid relative/i],
    ['specialType', /Unix type/],
    ['unknownExtraField', /extra field/],
  ]) {
    const fixture = archived(Buffer.from(zipFixtures[name], 'base64'), 'zip');
    await expect(inspectAndroidCandidateArchive(fixture.file, fixture.artifact)).rejects.toThrow(
      error
    );
  }
});

function nodeTar(extra = []) {
  const prefix = 'node-v24.16.0-linux-x64';
  return tinyTar([
    { path: `${prefix}/bin/node`, body: 'fixture executable bytes', mode: 0o755 },
    { path: `${prefix}/LICENSE`, body: 'fixture license\n' },
    ...extra,
  ]);
}

it('selects only the two regular Node members and inventories every other safe member', async () => {
  const fields = {
    key: 'node;24.16.0',
    source: 'node-shasums',
    publication: 'node-two-regular-members',
  };
  const fixture = archived(
    nodeTar([
      { path: 'node-v24.16.0-linux-x64/bin/npm', type: 'SymbolicLink', link: '../LICENSE' },
    ]),
    'tgz',
    fields
  );
  const receipt = await inspectAndroidCandidateArchive(fixture.file, fixture.artifact);
  expect(receipt.members).toHaveLength(3);
  expect(receipt.selectedNodeMembers.map((row) => row.target)).toEqual([
    'node-24.16.0/bin/node',
    'node-24.16.0/LICENSE',
  ]);
  expect(receipt.selectedNodeMembers.every((row) => !row.source.endsWith('/npm'))).toBe(true);
  expect(receipt.publicationAllowed).toBe(false);
  const bad = archived(nodeTar([{ path: 'wrong-root/extra', body: 'wrong' }]), 'tgz', fields);
  await expect(inspectAndroidCandidateArchive(bad.file, bad.artifact)).rejects.toThrow(
    /wrong distribution root/
  );
  const missing = archived(
    tinyTar([{ path: 'node-v24.16.0-linux-x64/LICENSE', body: 'license' }]),
    'tgz',
    fields
  );
  await expect(inspectAndroidCandidateArchive(missing.file, missing.artifact)).rejects.toThrow(
    /selected regular member: bin\/node/
  );
});

it('drives TAR graph failures through the actual authenticated archive reader', async () => {
  const positive = archived(
    tinyTar([
      { path: 'root/file', body: 'original' },
      { path: 'root/link', type: 'Link', link: 'root/file' },
    ]),
    'tgz'
  );
  await expect(
    inspectAndroidCandidateArchive(positive.file, positive.artifact)
  ).resolves.toMatchObject({ publicationAllowed: false });
  const cases = [
    [[{ path: '../escape', body: 'unsafe' }], /Unsafe/],
    [[{ path: 'root/link', type: 'SymbolicLink', link: '../../escape' }], /Escaping/],
    [
      [
        { path: 'root/a', type: 'SymbolicLink', link: 'b' },
        { path: 'root/b', type: 'SymbolicLink', link: 'a' },
      ],
      /Cyclic/,
    ],
    [
      [
        { path: 'root/a', body: 'first' },
        { path: 'root/a', body: 'second' },
      ],
      /Duplicate/,
    ],
    [
      [
        { path: 'root/A', body: 'first' },
        { path: 'root/a', body: 'second' },
      ],
      /host-colliding/,
    ],
    [[{ path: 'root/fifo', type: 'FIFO' }], /Unsupported TAR/],
    [[{ path: 'root/ignored', type: 'SolarisACL', body: 'ignored bytes' }], /Ignored TAR member/],
    [[{ path: 'root/control\nname', body: 'unsafe' }], /Unsafe candidate archive member/],
  ];
  for (const [entries, error] of cases) {
    const fixture = archived(tinyTar(entries), 'tgz');
    await expect(inspectAndroidCandidateArchive(fixture.file, fixture.artifact)).rejects.toThrow(
      error
    );
  }
});

it('retains valid ordered PAX text, applies the effective name and rejects malformed metadata', async () => {
  const record = paxFixtureRecord('path', 'root/effective.txt');
  const fixture = archived(
    tinyTar([
      { path: 'metadata', type: 'ExtendedHeader', body: record },
      { path: 'root/header.txt', body: 'effective content' },
    ]),
    'tgz'
  );
  const receipt = await inspectAndroidCandidateArchive(fixture.file, fixture.artifact);
  expect(receipt.members[0].path).toBe('root/effective.txt');
  expect(receipt.metadata).toEqual([
    {
      kind: 'validated-pax-record-text',
      bytes: Buffer.byteLength(record),
      text: record,
      sha256: hash(record),
    },
  ]);
  expect(receipt.inventoryScope).toContain('without a physical header/type inventory');
  for (const text of ['100 path=bad\n', paxFixtureRecord('unknown-field', 'bad')]) {
    const bad = archived(
      tinyTar([
        { path: 'metadata', type: 'ExtendedHeader', body: text },
        { path: 'root/file', body: 'original' },
      ]),
      'tgz'
    );
    await expect(inspectAndroidCandidateArchive(bad.file, bad.artifact)).rejects.toThrow(
      /PAX metadata/
    );
  }
});

it('rejects framed PAX value controls before accepting an inspection', async () => {
  for (const control of ['\n', '\r', '\t', '\u0001', '\u007f']) {
    const fixture = archived(tinyTar([
      { path: 'metadata', type: 'ExtendedHeader', body: paxFixtureRecord('path', `root/a${control}b`) },
      { path: 'root/header.txt', body: 'effective content' },
    ]), 'tgz');
    await expect(inspectAndroidCandidateArchive(fixture.file, fixture.artifact)).rejects.toThrow(
      /Unreviewed PAX metadata field/
    );
  }
});

it('checks actual SDK source properties against the selected package and revision', async () => {
  const fields = { key: 'cmake;3.30.5', revision: '3.30.5', source: 'sdk-registry' };
  const good = archived(
    tinyTar([
      { path: 'cmake/source.properties', body: 'Pkg.Path=cmake;3.30.5\nPkg.Revision=3.30.5\n' },
    ]),
    'tgz',
    fields
  );
  const receipt = await inspectAndroidCandidateArchive(good.file, good.artifact);
  expect(receipt.sourceProperties[0].values['Pkg.Revision']).toBe('3.30.5');
  const bad = archived(
    tinyTar([
      { path: 'cmake/source.properties', body: 'Pkg.Path=cmake;3.30.5\nPkg.Revision=9.0\n' },
    ]),
    'tgz',
    fields
  );
  await expect(inspectAndroidCandidateArchive(bad.file, bad.artifact)).rejects.toThrow(
    /contradict pinned identity/
  );
});

it('requires one shallow SDK source-properties identity with supported line separators', async () => {
  const fields = { key: 'cmake;3.30.5', revision: '3.30.5', source: 'sdk-registry' };
  for (const separator of ['\n', '\r\n', '\r']) {
    for (const path of ['source.properties', 'cmake/source.properties']) {
      const fixture = archived(tinyTar([{ path,
        body: `Pkg.Path=cmake;3.30.5${separator}Pkg.Revision=\t3.30.5\t${separator}`,
      }]), 'tgz', fields);
      const receipt = await inspectAndroidCandidateArchive(fixture.file, fixture.artifact);
      expect(receipt.sourceProperties).toHaveLength(1);
      expect(receipt.sourceProperties[0].values['Pkg.Revision']).toBe('3.30.5');
    }
  }
  const body = 'Pkg.Path=cmake;3.30.5\nPkg.Revision=3.30.5\n';
  for (const entries of [
    [{ path: 'cmake/bin/cmake', body: 'fixture file' }],
    [{ path: 'cmake/nested/source.properties', body }],
    [{ path: 'cmake/source.properties', body }, { path: 'other/source.properties', body }],
  ]) {
    const fixture = archived(tinyTar(entries), 'tgz', fields);
    await expect(inspectAndroidCandidateArchive(fixture.file, fixture.artifact)).rejects.toThrow(
      /exactly one shallow source.properties/
    );
  }
});

it('rejects hidden controls in otherwise matching SDK source properties', async () => {
  const fields = { key: 'cmake;3.30.5', revision: '3.30.5', source: 'sdk-registry' };
  for (const control of ['\0', '\u0001', '\u000b', '\u000c', '\u001f', '\u007f']) {
    const fixture = archived(tinyTar([{ path: 'cmake/source.properties',
      body: `Pkg.Path=cmake;3.30.5\nPkg.Revision=3.30.5\nFixture.Name=${control}value\n`,
    }]), 'tgz', fields);
    await expect(inspectAndroidCandidateArchive(fixture.file, fixture.artifact)).rejects.toThrow(
      /source properties control character/
    );
  }
});

it('retains the strict nested metadata text boundary without qualifying unknown vendor layouts', async () => {
  const binary = Buffer.from([0xff]);
  const regular = archived(tinyTar([{ path: 'root/nested/data.bin', body: binary }]), 'tgz');
  const receipt = await inspectAndroidCandidateArchive(regular.file, regular.artifact);
  expect(receipt.members[0].text).toBeNull();
  const nonUtf8 = archived(tinyTar([{ path: 'root/nested/LICENSE', body: binary }]), 'tgz');
  await expect(inspectAndroidCandidateArchive(nonUtf8.file, nonUtf8.artifact)).rejects.toThrow(
    /Archive text is not UTF-8: root\/nested\/LICENSE/
  );
  const overLimit = archived(tinyTar([{ path: 'root/nested/LICENSE',
    body: 'x'.repeat(ARCHIVE_TEXT_LIMIT_BYTES + 1),
  }]), 'tgz');
  await expect(inspectAndroidCandidateArchive(overLimit.file, overLimit.artifact)).rejects.toThrow(
    /Archive text exceeds review limit: root\/nested\/LICENSE/
  );
});

it('reports both colliding member spellings while preserving fail-closed rejection', async () => {
  const fixture = archived(tinyTar([
    { path: 'root/A', body: 'first' }, { path: 'root/a', body: 'second' },
  ]), 'tgz');
  await expect(inspectAndroidCandidateArchive(fixture.file, fixture.artifact)).rejects.toThrow(
    'Duplicate or host-colliding archive members: root/A and root/a'
  );
});

it('rejects ambiguous NUL metadata and GNU long names instead of inferring a producer', async () => {
  for (const type of ['ExtendedHeader', 'NextFileHasLongPath']) {
    const fixture = archived(
      tinyTar([
        { path: 'metadata', type, body: 'unrecognized metadata\0' },
        { path: 'root/file', body: 'original' },
      ]),
      'tgz'
    );
    await expect(inspectAndroidCandidateArchive(fixture.file, fixture.artifact)).rejects.toThrow(
      /Unreviewed NUL archive metadata/
    );
  }
  const record = paxFixtureRecord('path', 'root/effective.txt');
  const ambiguous = archived(
    tinyTar([
      { path: 'metadata', type: 'NextFileHasLongPath', body: record },
      { path: 'root/file', body: 'original' },
    ]),
    'tgz'
  );
  await expect(inspectAndroidCandidateArchive(ambiguous.file, ambiguous.artifact)).rejects.toThrow(
    /Unsafe candidate archive member/
  );
});

it('rejects a checksum-matching truncated compressed TAR through the actual reader', async () => {
  const bytes = tinyTar([{ path: 'root/file', body: 'original' }]);
  const fixture = archived(bytes.subarray(0, -8), 'tgz');
  await expect(inspectAndroidCandidateArchive(fixture.file, fixture.artifact)).rejects.toThrow();
});

it('accepts safe normalized directory parents with exact file and link targets', async () => {
  for (const [directory, child] of [
    ['A', 'a'],
    ['é', 'e\u0301'],
  ]) {
    const fixture = archived(
      tinyTar([
        { path: `root/${directory}`, type: 'Directory', mode: 0o755 },
        { path: `root/${child}/file`, body: 'original' },
        { path: 'root/symlink', type: 'SymbolicLink', link: `${child}/file` },
        { path: 'root/hardlink', type: 'Link', link: `root/${child}/file` },
      ]),
      'tgz'
    );
    const receipt = await inspectAndroidCandidateArchive(fixture.file, fixture.artifact);
    expect(receipt.members).toHaveLength(4);
    expect(receipt.members.find((row) => row.path === `root/${child}/file`).sha256).toBe(
      hash('original')
    );
    expect(receipt.publicationAllowed).toBe(false);
  }
});

it('rejects normalized regular-file parents through actual TAR and ZIP readers', async () => {
  for (const [directory, child] of [
    ['A', 'a'],
    ['é', 'e\u0301'],
  ]) {
    const positive = archived(
      tinyTar([
        { path: `root/${directory}`, type: 'Directory', mode: 0o755 },
        { path: `root/${child}/file`, body: 'original' },
      ]),
      'tgz'
    );
    await expect(
      inspectAndroidCandidateArchive(positive.file, positive.artifact)
    ).resolves.toMatchObject({ publicationAllowed: false });
    const negative = archived(
      tinyTar([
        { path: `root/${directory}`, body: 'parent' },
        { path: `root/${child}/file`, body: 'original' },
      ]),
      'tgz'
    );
    await expect(inspectAndroidCandidateArchive(negative.file, negative.artifact)).rejects.toThrow(
      /Archive member has a nondirectory parent/
    );
  }
  const positive = archived(Buffer.from(zipFixtures.normalizedDirectoryLinks, 'base64'), 'zip');
  await expect(
    inspectAndroidCandidateArchive(positive.file, positive.artifact)
  ).resolves.toMatchObject({ publicationAllowed: false });
  for (const name of ['caseParentFile', 'nfcParentFile']) {
    const negative = archived(Buffer.from(zipFixtures[name], 'base64'), 'zip');
    await expect(inspectAndroidCandidateArchive(negative.file, negative.artifact)).rejects.toThrow(
      /Archive member has a nondirectory parent/
    );
  }
});

it('rejects normalized nondirectory link prefixes while retaining exact target existence', async () => {
  for (const [directory, child] of [
    ['A', 'a'],
    ['é', 'e\u0301'],
  ]) {
    const negative = archived(
      tinyTar([
        { path: `root/${directory}`, body: 'parent' },
        { path: 'root/link', type: 'SymbolicLink', link: `${child}/missing` },
      ]),
      'tgz'
    );
    await expect(inspectAndroidCandidateArchive(negative.file, negative.artifact)).rejects.toThrow(
      /Archive link crosses a nondirectory/
    );
  }
  for (const [type, exact] of [
    ['SymbolicLink', 'Target'],
    ['Link', 'root/Target'],
  ]) {
    const positive = archived(
      tinyTar([
        { path: 'root/Target', body: 'original' },
        { path: 'root/link', type, link: exact },
      ]),
      'tgz'
    );
    await expect(
      inspectAndroidCandidateArchive(positive.file, positive.artifact)
    ).resolves.toMatchObject({ publicationAllowed: false });
    const negative = archived(
      tinyTar([
        { path: 'root/Target', body: 'original' },
        { path: 'root/link', type, link: exact.toLowerCase() },
      ]),
      'tgz'
    );
    await expect(inspectAndroidCandidateArchive(negative.file, negative.artifact)).rejects.toThrow(
      /Broken candidate archive link/
    );
  }
});

it('keeps hardlink-to-symlink rejection under the normalized topology lookup', async () => {
  const negative = archived(
    tinyTar([
      { path: 'root/target', body: 'original' },
      { path: 'root/alias', type: 'SymbolicLink', link: 'target' },
      { path: 'root/hard', type: 'Link', link: 'root/alias' },
    ]),
    'tgz'
  );
  await expect(inspectAndroidCandidateArchive(negative.file, negative.artifact)).rejects.toThrow(
    /Archive hardlink targets a symlink/
  );
});
