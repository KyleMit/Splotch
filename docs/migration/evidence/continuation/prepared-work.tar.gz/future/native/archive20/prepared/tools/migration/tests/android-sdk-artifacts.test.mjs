import {
  copyFileSync,
  linkSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  rmSync,
  symlinkSync,
  writeFileSync,
} from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterEach, expect, it } from 'vitest';
import { ROOT } from '../../lib/proc.mjs';
import {
  androidArchiveHost,
  readAndroidArchiveProfile,
  selectAndroidArchives,
} from '../lib/android-sdk-artifacts.mjs';

const roots = [];
const PROFILE_INPUTS = [
  'tools/migration/inputs/android-toolchain-profile.json',
  'tools/migration/inputs/android-sdk-repository2-3.xml.txt',
  'tools/migration/inputs/node-24.16.0-SHASUMS256.txt',
  'experiments/native-architecture/android/gradle/wrapper/gradle-wrapper.properties',
];
function profileFixture() {
  const root = mkdtempSync(join(tmpdir(), 'splotch-archive-inputs-'));
  roots.push(root);
  for (const path of PROFILE_INPUTS) {
    mkdirSync(join(root, path, '..'), { recursive: true });
    copyFileSync(join(ROOT, path), join(root, path));
  }
  return root;
}
afterEach(() => roots.splice(0).forEach((root) => rmSync(root, { recursive: true, force: true })));

it('authenticates retained primary inputs and selects exactly the base compile archives on each host', () => {
  const profile = readAndroidArchiveProfile(profileFixture());
  for (const host of ['darwin-arm64', 'linux-x64']) {
    const archives = selectAndroidArchives(profile, host);
    expect(archives).toHaveLength(8);
    expect(archives.some((row) => /emulator|system-images|platform-tools/.test(row.key))).toBe(
      false
    );
    expect(archives.filter((row) => row.source === 'sdk-registry')).toHaveLength(5);
    expect(archives.find((row) => row.key === 'platforms;android-36').revision).toBe('2');
  }
  expect(profile.license.acceptedLineSha1).toBe('24333f8a63b6825ea9c5514f83c2829b004d1fee');
  expect(androidArchiveHost('darwin', 'arm64')).toBe('darwin-arm64');
  expect(androidArchiveHost('linux', 'x64')).toBe('linux-x64');
  expect(() => androidArchiveHost('darwin', 'x64')).toThrow(/Unsupported/);
  expect(() => selectAndroidArchives(profile, 'linux-arm64')).toThrow(/Unsupported/);
});

it.each(PROFILE_INPUTS)('rejects actual changed authenticated input %s', (path) => {
  const root = profileFixture();
  expect(() => readAndroidArchiveProfile(root)).not.toThrow();
  const original = readFileSync(join(root, path));
  const changed = path.endsWith('gradle-wrapper.properties')
    ? original
        .toString()
        .replace(/distributionSha256Sum=[a-f0-9]+/, `distributionSha256Sum=${'0'.repeat(64)}`)
    : Buffer.concat([original, Buffer.from('changed')]);
  writeFileSync(join(root, path), changed);
  expect(() => readAndroidArchiveProfile(root)).toThrow(
    /input changed|Gradle archive identity changed/
  );
});

it('rejects source aliases and independent-inode violations through the actual reader', () => {
  const root = profileFixture();
  expect(() => readAndroidArchiveProfile(root)).not.toThrow();
  const path = PROFILE_INPUTS[0];
  const original = join(root, 'original-profile.json');
  copyFileSync(join(root, path), original);
  rmSync(join(root, path));
  symlinkSync(original, join(root, path));
  expect(() => readAndroidArchiveProfile(root)).toThrow(/Unowned/);
  rmSync(join(root, path));
  linkSync(original, join(root, path));
  expect(() => readAndroidArchiveProfile(root)).toThrow(/Unowned/);
});

it('rejects a missing optional-looking base archive without adding platform payloads', () => {
  const profile = readAndroidArchiveProfile(profileFixture());
  const changed = structuredClone(profile);
  changed.artifacts = changed.artifacts.filter((row) => row.key !== 'cmake;3.30.5');
  expect(() => selectAndroidArchives(changed, 'linux-x64')).toThrow(
    /base archive selection changed/
  );
});
