import { execFileSync } from 'node:child_process';
import {
  mkdtempSync,
  readFileSync,
  readdirSync,
  realpathSync,
  rmSync,
  unlinkSync,
  writeFileSync,
} from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterEach, expect, it, vi } from 'vitest';
import { ROOT } from '../../lib/proc.mjs';
import { readAndroidArchiveProfile } from '../lib/android-sdk-artifacts.mjs';
import {
  candidateArchiveOwner,
  createCandidateArchiveOwner,
} from '../lib/candidate-toolchain-roots.mjs';
import {
  assertArchiveIntakeContents,
  receiveCandidateArchive,
} from '../lib/candidate-archive-downloads.mjs';
import { tinyArtifact } from './archive-fixtures.mjs';

const roots = [];
function temporary() {
  const root = realpathSync(mkdtempSync(join(tmpdir(), 'splotch-archive-download-')));
  roots.push(root);
  return root;
}
function fixture() {
  const source = temporary();
  execFileSync('git', ['init', '-q', source]);
  const owner = createCandidateArchiveOwner(
    candidateArchiveOwner(source, readAndroidArchiveProfile(ROOT), 'linux-x64', {
      HOME: process.env.HOME,
      RUNNER_TEMP: temporary(),
    })
  );
  const bytes = Buffer.from('authenticated small fixture\n');
  const artifact = tinyArtifact(bytes, 'zip');
  const file = join(owner.root, 'archives', artifact.filename);
  return { owner, bytes, artifact, file, partial: `${file}.partial` };
}
function response(artifact, body) {
  const value = new Response(body);
  Object.defineProperty(value, 'url', { value: artifact.url });
  return value;
}
afterEach(() => {
  vi.unstubAllGlobals();
  roots.splice(0).forEach((root) => rmSync(root, { recursive: true, force: true }));
});

it('authenticates downloaded bytes and reuses the same archive without requesting it again', async () => {
  const value = fixture();
  const fetch = vi.fn(async () => {
    const delivered = new Response(value.bytes);
    Object.defineProperty(delivered, 'url', { value: 'https://archive-fixture.invalid/served.zip' });
    return delivered;
  });
  vi.stubGlobal('fetch', fetch);
  await expect(receiveCandidateArchive(value.owner, value.artifact)).resolves.toMatchObject({
    downloaded: true,
    path: value.file,
    bytes: value.bytes.length,
    finalOrigin: 'https://archive-fixture.invalid',
  });
  expect(readFileSync(value.file)).toEqual(value.bytes);
  expect(() => assertArchiveIntakeContents(value.owner, [value.artifact])).not.toThrow();
  const reused = await receiveCandidateArchive(value.owner, value.artifact);
  expect(reused.downloaded).toBe(false);
  expect(Object.hasOwn(reused, 'finalOrigin')).toBe(false);
  expect(fetch).toHaveBeenCalledOnce();
  expect(fetch.mock.calls[0][0]).toBe(value.artifact.url);
  expect(readdirSync(join(value.owner.root, 'archives'))).toEqual([value.artifact.filename]);
});

it('retains a checksum-failed owned partial and permits an authenticated retry', async () => {
  const value = fixture();
  const bad = Buffer.alloc(value.bytes.length, 0x78);
  const fetch = vi.fn(async () => response(value.artifact, bad));
  vi.stubGlobal('fetch', fetch);
  await expect(receiveCandidateArchive(value.owner, value.artifact)).rejects.toThrow(
    /Archive checksum/
  );
  expect(readdirSync(join(value.owner.root, 'archives'))).toEqual([]);
  const retained = readdirSync(join(value.owner.root, 'receipts')).find((name) =>
    name.endsWith('.partial')
  );
  expect(readFileSync(join(value.owner.root, 'receipts', retained))).toEqual(bad);
  const receipt = JSON.parse(
    readFileSync(join(value.owner.root, 'receipts', `${retained}.json`), 'utf8')
  );
  expect(receipt).toMatchObject({
    filename: value.artifact.filename,
    retainedPartial: retained,
    bytes: bad.length,
    status: 'download-or-authentication-failed',
  });
  fetch.mockImplementation(async () => response(value.artifact, value.bytes));
  await expect(receiveCandidateArchive(value.owner, value.artifact)).resolves.toMatchObject({
    downloaded: true,
  });
  expect(fetch).toHaveBeenCalledTimes(2);
  expect(readFileSync(value.file)).toEqual(value.bytes);
});

it('retains an owned partial after a response-stream failure and permits a retry', async () => {
  const value = fixture();
  const fetch = vi.fn(async () =>
    response(
      value.artifact,
      new ReadableStream({
        start(controller) {
          controller.error(new Error('fixture stream failure'));
        },
      })
    )
  );
  vi.stubGlobal('fetch', fetch);
  await expect(receiveCandidateArchive(value.owner, value.artifact)).rejects.toThrow(
    /fixture stream failure/
  );
  expect(readdirSync(join(value.owner.root, 'archives'))).toEqual([]);
  expect(
    readdirSync(join(value.owner.root, 'receipts')).filter((name) => name.endsWith('.partial'))
  ).toHaveLength(1);
  fetch.mockImplementation(async () => response(value.artifact, value.bytes));
  await expect(receiveCandidateArchive(value.owner, value.artifact)).resolves.toMatchObject({
    downloaded: true,
  });
});

it('preserves a preexisting partial and refuses it before requesting network bytes', async () => {
  const value = fixture();
  writeFileSync(value.partial, 'foreign preexisting partial');
  const fetch = vi.fn();
  vi.stubGlobal('fetch', fetch);
  await expect(receiveCandidateArchive(value.owner, value.artifact)).rejects.toThrow(/EEXIST/);
  expect(fetch).not.toHaveBeenCalled();
  expect(readFileSync(value.partial, 'utf8')).toBe('foreign preexisting partial');
  expect(readdirSync(join(value.owner.root, 'receipts'))).toEqual([]);
});

it('refuses to move a replacement partial owned by another writer', async () => {
  const value = fixture();
  vi.stubGlobal('fetch', async () => {
    unlinkSync(value.partial);
    writeFileSync(value.partial, 'foreign replacement partial');
    throw new Error('fixture request failure after replacement');
  });
  await expect(receiveCandidateArchive(value.owner, value.artifact)).rejects.toThrow(
    /Failed archive partial changed ownership/
  );
  expect(readFileSync(value.partial, 'utf8')).toBe('foreign replacement partial');
  expect(readdirSync(join(value.owner.root, 'receipts'))).toEqual([]);
});
