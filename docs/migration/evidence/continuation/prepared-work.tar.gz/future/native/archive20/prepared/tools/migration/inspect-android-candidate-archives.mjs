import { readFileSync, writeFileSync } from 'node:fs';
import { parseArgs } from 'node:util';
import { ROOT, isMain, runMain } from '../lib/proc.mjs';
import { assertNativeSourceContract } from './lib/native-source-contract.mjs';
import { readTemplateManifest } from './lib/native-template.mjs';
import {
  readCandidateEntry,
  readMaintainedNativeFiles,
  readNativeCandidateRoot,
} from './lib/native-source-files.mjs';
import {
  androidArchiveHost,
  readAndroidArchiveProfile,
  selectAndroidArchives,
} from './lib/android-sdk-artifacts.mjs';
import {
  candidateArchiveOwner,
  createCandidateArchiveOwner,
  candidateArchivePath,
} from './lib/candidate-toolchain-roots.mjs';
import {
  assertArchiveIntakeContents,
  receiveCandidateArchive,
} from './lib/candidate-archive-downloads.mjs';
import { inspectAndroidCandidateArchive } from './lib/android-candidate-archives.mjs';

function assertMaintainedInputs(root) {
  const manifest = readTemplateManifest(root);
  const candidate = readNativeCandidateRoot(root);
  const files = readMaintainedNativeFiles(candidate, manifest);
  const { packageManifest, indexSource } = readCandidateEntry(candidate);
  assertNativeSourceContract(files, packageManifest, indexSource);
}

function writeInspectionReceipt(owner, artifact, receipt) {
  const path = candidateArchivePath(owner, `receipts/${artifact.filename}.inspection.json`);
  const bytes = `${JSON.stringify(receipt, null, 2)}\n`;
  try {
    writeFileSync(path, bytes, { flag: 'wx', mode: 0o600 });
  } catch (error) {
    if (error.code !== 'EEXIST') throw error;
    if (!readFileSync(path).equals(Buffer.from(bytes)))
      throw new Error(`Existing archive inspection differs: ${artifact.filename}`);
  }
}

export async function runAndroidCandidateArchiveInspection(argv) {
  parseArgs({ args: argv, strict: true, allowPositionals: false });
  assertMaintainedInputs(ROOT);
  const profile = readAndroidArchiveProfile(ROOT);
  const host = androidArchiveHost(process.platform, process.arch);
  const artifacts = selectAndroidArchives(profile, host);
  const owner = createCandidateArchiveOwner(
    candidateArchiveOwner(ROOT, profile, host, process.env)
  );
  assertArchiveIntakeContents(owner, artifacts);
  const results = [];
  for (const artifact of artifacts) {
    assertMaintainedInputs(ROOT);
    readAndroidArchiveProfile(ROOT);
    const received = await receiveCandidateArchive(owner, artifact);
    const receipt = await inspectAndroidCandidateArchive(received.path, artifact);
    assertMaintainedInputs(ROOT);
    readAndroidArchiveProfile(ROOT);
    writeInspectionReceipt(owner, artifact, receipt);
    results.push({ key: artifact.key, archive: received.path, status: receipt.status,
      downloaded: received.downloaded, finalOrigin: received.finalOrigin ?? null });
  }
  return {
    owner: owner.root,
    host,
    profile: profile.profile,
    archives: results,
    publicationAllowed: false,
    nativeExecution: false,
  };
}

if (isMain(import.meta.url))
  runMain(async () =>
    console.log(JSON.stringify(await runAndroidCandidateArchiveInspection(process.argv.slice(2))))
  );
