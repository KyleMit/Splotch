import { createHash } from 'node:crypto';
import { gzipSync } from 'node:zlib';
import { Header } from 'tar';

const TAR_BLOCK_BYTES = 512;

export function tinyTar(entries) {
  const blocks = entries.flatMap((row) => {
    const body = Buffer.from(row.body ?? '');
    const header = new Header({
      path: row.path,
      type: row.type ?? 'File',
      size: body.length,
      mode: row.mode ?? 0o644,
      linkpath: row.link ?? '',
      uid: 0,
      gid: 0,
    });
    header.encode();
    return [
      header.block,
      body,
      Buffer.alloc((TAR_BLOCK_BYTES - (body.length % TAR_BLOCK_BYTES)) % TAR_BLOCK_BYTES),
    ];
  });
  return gzipSync(Buffer.concat([...blocks, Buffer.alloc(TAR_BLOCK_BYTES * 2)]));
}

export function tinyArtifact(bytes, format, fields = {}) {
  return {
    key: 'gradle;9.3.1',
    host: 'linux-x64',
    revision: '9.3.1',
    format,
    url: 'https://services.gradle.org/distributions/gradle-9.3.1-bin.zip',
    filename: format === 'zip' ? 'fixture.zip' : 'fixture.tar.gz',
    bytes: bytes.length,
    checksum: { algorithm: 'sha256', hex: createHash('sha256').update(bytes).digest('hex') },
    source: 'maintained-gradle-wrapper',
    publication: 'layout-review-required',
    ...fields,
  };
}

export function paxFixtureRecord(key, value) {
  const body = ` ${key}=${value}\n`;
  let size = Buffer.byteLength(body) + 1;
  while (Buffer.byteLength(`${size}${body}`) !== size) size = Buffer.byteLength(`${size}${body}`);
  return `${size}${body}`;
}
