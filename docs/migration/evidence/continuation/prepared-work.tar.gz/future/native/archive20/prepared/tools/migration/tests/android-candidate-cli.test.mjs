import { execFileSync, spawnSync } from 'node:child_process';
import {
  chmodSync,
  copyFileSync,
  existsSync,
  lstatSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  readdirSync,
  realpathSync,
  rmSync,
  symlinkSync,
  writeFileSync,
} from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { afterEach, expect, it } from 'vitest';
import { ROOT } from '../../lib/proc.mjs';

const SENTINEL = 'owned archive fixture reached fixed download boundary';
const SOURCE_PATHS = [
  'tools/lib/proc.mjs',
  'tools/lib/native-candidate.mjs',
  'tools/migration/inspect-android-candidate-archives.mjs',
  ...[
    'native-template',
    'native-template-transforms',
    'native-source-files',
    'native-source-contract',
    'native-apple-scene',
    'archive-inventory',
    'android-sdk-artifacts',
    'candidate-toolchain-roots',
    'candidate-archive-downloads',
    'android-candidate-archives',
    'android-sdk-members',
    'android-sdk-properties',
    'android-sdk-tar',
    'android-sdk-zip',
  ].map((name) => `tools/migration/lib/${name}.mjs`),
  'tools/migration/inputs/native-template-manifest.json',
  'tools/migration/inputs/expo-template-bare-minimum-57.0.28.metadata.json.txt',
  'tools/migration/inputs/android-toolchain-profile.json',
  'tools/migration/inputs/android-sdk-repository2-3.xml.txt',
  'tools/migration/inputs/node-24.16.0-SHASUMS256.txt',
  'experiments/native-architecture/package.json',
  'experiments/native-architecture/alignment.json',
  'experiments/native-architecture/src/index.ts',
  'experiments/native-architecture/native-template-provenance.json',
];
const roots = [];
function temporary() {
  const root = realpathSync(mkdtempSync(join(tmpdir(), 'splotch-archive-cli-')));
  roots.push(root);
  return root;
}
function copied(root, path) {
  const target = join(root, path);
  mkdirSync(dirname(target), { recursive: true });
  copyFileSync(join(ROOT, path), target);
  chmodSync(target, lstatSync(join(ROOT, path)).mode & 0o777);
}
function fixture() {
  const root = temporary();
  const provenance = JSON.parse(
    readFileSync(
      join(ROOT, 'experiments/native-architecture/native-template-provenance.json'),
      'utf8'
    )
  );
  for (const path of SOURCE_PATHS) copied(root, path);
  for (const record of provenance.records.filter((row) => row.target))
    copied(root, `experiments/native-architecture/${record.target}`);
  symlinkSync(realpathSync(join(ROOT, 'node_modules')), join(root, 'node_modules'));
  execFileSync('git', ['init', '-q', root]);
  const runner = temporary();
  const marker = join(root, 'download-requested.txt');
  const preload = join(root, 'fixture-preload.mjs');
  writeFileSync(
    preload,
    [
      "import { writeFileSync } from 'node:fs';",
      "Object.defineProperty(process, 'platform', { value: 'linux' });",
      "Object.defineProperty(process, 'arch', { value: 'x64' });",
      'globalThis.fetch = async () => {',
      '  writeFileSync(process.env.SPLOTCH_ARCHIVE_FIXTURE_MARKER, process.env.SPLOTCH_ARCHIVE_FIXTURE_SENTINEL);',
      '  throw new Error(process.env.SPLOTCH_ARCHIVE_FIXTURE_SENTINEL);',
      '};',
    ].join('\n')
  );
  const env = {
    ...process.env,
    RUNNER_TEMP: runner,
    SPLOTCH_ARCHIVE_FIXTURE_MARKER: marker,
    SPLOTCH_ARCHIVE_FIXTURE_SENTINEL: SENTINEL,
  };
  return { root, marker, preload, env };
}
function invoke(value, argv = []) {
  return spawnSync(
    process.execPath,
    [
      '--import',
      value.preload,
      join(value.root, 'tools/migration/inspect-android-candidate-archives.mjs'),
      ...argv,
    ],
    {
      cwd: value.root,
      env: value.env,
      encoding: 'utf8',
      timeout: 20_000,
    }
  );
}
function expectDownloadSentinel(value) {
  const result = invoke(value);
  expect(result.error).toBeUndefined();
  expect(result.status).toBe(1);
  expect(result.stderr).toContain(SENTINEL);
  expect(readFileSync(value.marker, 'utf8')).toBe(SENTINEL);
  rmSync(value.marker);
}
afterEach(() => roots.splice(0).forEach((root) => rmSync(root, { recursive: true, force: true })));

it('drives the actual CLI to a controlled download boundary without requesting runtime bytes', () => {
  const value = fixture();
  expectDownloadSentinel(value);
  expect(value.env.HOME).toBe(process.env.HOME);
});

it('rejects process-level redirected HOME before the actual CLI creates its archive owner', () => {
  const qualified = fixture();
  expectDownloadSentinel(qualified);
  const redirected = fixture();
  const alternateHome = temporary();
  const beforeRunner = readdirSync(redirected.env.RUNNER_TEMP);
  const result = invoke({ ...redirected, env: { ...redirected.env, HOME: alternateHome } });
  expect(result.error).toBeUndefined();
  expect(result.status).toBe(1);
  expect(result.stderr).toContain('Received HOME is not the qualified host home');
  expect(result.stderr).not.toContain(SENTINEL);
  expect(existsSync(redirected.marker)).toBe(false);
  expect(readdirSync(redirected.env.RUNNER_TEMP)).toEqual(beforeRunner);
  expect(readdirSync(alternateHome)).toEqual([]);
});

it('rejects actual maintained-source mutation before the CLI reaches its download boundary', () => {
  const value = fixture();
  expectDownloadSentinel(value);
  const source = join(value.root, 'experiments/native-architecture/android/app/build.gradle');
  writeFileSync(source, readFileSync(source, 'utf8') + '\nfixture source mutation\n');
  const result = invoke(value);
  expect(result.error).toBeUndefined();
  expect(result.status).toBe(1);
  expect(result.stderr).toContain('Maintained native source changed: android/app/build.gradle');
  expect(existsSync(value.marker)).toBe(false);
});

it('rejects actual authenticated profile mutation before the CLI reaches its download boundary', () => {
  const value = fixture();
  expectDownloadSentinel(value);
  const profile = join(value.root, 'tools/migration/inputs/android-toolchain-profile.json');
  writeFileSync(profile, readFileSync(profile, 'utf8') + '\n');
  const result = invoke(value);
  expect(result.error).toBeUndefined();
  expect(result.status).toBe(1);
  expect(result.stderr).toContain(
    'Android archive input changed: tools/migration/inputs/android-toolchain-profile.json'
  );
  expect(existsSync(value.marker)).toBe(false);
});

it('rejects unsupported CLI flags before reaching the fixed download boundary', () => {
  const value = fixture();
  expectDownloadSentinel(value);
  const result = invoke(value, ['--url=https://example.invalid/foreign.zip']);
  expect(result.error).toBeUndefined();
  expect(result.status).toBe(1);
  expect(result.stderr).toContain("Unknown option '--url'");
  expect(existsSync(value.marker)).toBe(false);
});
