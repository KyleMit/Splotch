import { execFileSync } from 'node:child_process';
import {
  linkSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  realpathSync,
  rmSync,
  symlinkSync,
  writeFileSync,
} from 'node:fs';
import { tmpdir, userInfo } from 'node:os';
import { join } from 'node:path';
import { afterEach, expect, it } from 'vitest';
import { ROOT } from '../../lib/proc.mjs';
import { readAndroidArchiveProfile } from '../lib/android-sdk-artifacts.mjs';
import {
  assertCandidateArchiveOwner,
  candidateArchiveOwner,
  candidateArchivePath,
  createCandidateArchiveOwner,
} from '../lib/candidate-toolchain-roots.mjs';

const roots = [];
function temporary() {
  const root = realpathSync(mkdtempSync(join(tmpdir(), 'splotch-toolchain-owner-')));
  roots.push(root);
  return root;
}
afterEach(() => roots.splice(0).forEach((root) => rmSync(root, { recursive: true, force: true })));
function fixture() {
  const source = temporary();
  execFileSync('git', ['init', '-q', source]);
  const runner = temporary();
  const env = { HOME: process.env.HOME, RUNNER_TEMP: runner };
  const owner = candidateArchiveOwner(source, readAndroidArchiveProfile(ROOT), 'linux-x64', env);
  return { source, runner, env, owner };
}

it('creates only the marked archive intake in a separate canonical Linux owner', () => {
  const value = fixture();
  createCandidateArchiveOwner(value.owner);
  expect(() => assertCandidateArchiveOwner(value.owner)).not.toThrow();
  expect(value.owner.root).toBe(
    join(value.runner, 'splotch-native-toolchains/expo57-rn0863-agp812-v1/linux-x64')
  );
  expect(value.owner.marker.home).toBe(realpathSync(userInfo().homedir));
  expect(realpathSync(value.env.HOME)).toBe(realpathSync(userInfo().homedir));
  expect(candidateArchivePath(value.owner, 'archives/input.zip')).toBe(
    join(value.owner.root, 'archives/input.zip')
  );
  expect(() => candidateArchivePath(value.owner, '../escape')).toThrow(/Unsafe/);
  expect(() =>
    candidateArchiveOwner(value.source, readAndroidArchiveProfile(ROOT), 'linux-x64', {
      ...value.env,
      RUNNER_TEMP: value.source,
    })
  ).toThrow(/overlaps/);
});

it('rejects a received home outside the independent effective-user account', () => {
  const value = fixture();
  expect(() => candidateArchiveOwner(value.source, readAndroidArchiveProfile(ROOT), 'linux-x64', {
    ...value.env, HOME: temporary(),
  })).toThrow(/qualified host home/);
});

it('refuses an unmarked existing root and a changed source marker', () => {
  const value = fixture();
  mkdirSync(value.owner.root, { recursive: true });
  expect(() => createCandidateArchiveOwner(value.owner)).toThrow(/ENOENT/);
  rmSync(value.owner.root, { recursive: true });
  createCandidateArchiveOwner(value.owner);
  const marker = join(value.owner.root, '.splotch-native-toolchain.json');
  const original = JSON.parse(readFileSync(marker, 'utf8'));
  writeFileSync(marker, JSON.stringify({ ...original, profileSha256: '0'.repeat(64) }));
  expect(() => assertCandidateArchiveOwner(value.owner)).toThrow(/source marker changed/);
});

it('rejects outside aliases, regular hardlinks and unexpected root contents', () => {
  const value = fixture();
  createCandidateArchiveOwner(value.owner);
  expect(() => assertCandidateArchiveOwner(value.owner)).not.toThrow();
  const foreign = join(temporary(), 'foreign.zip');
  writeFileSync(foreign, 'borrowed bytes');
  const path = join(value.owner.root, 'archives/input.zip');
  symlinkSync(foreign, path);
  expect(() => candidateArchivePath(value.owner, 'archives/input.zip')).toThrow(/aliases/);
  rmSync(path);
  linkSync(foreign, path);
  expect(() => candidateArchivePath(value.owner, 'archives/input.zip')).toThrow(/aliases/);
  rmSync(path);
  writeFileSync(join(value.owner.root, 'unreviewed.txt'), 'extra');
  expect(() => assertCandidateArchiveOwner(value.owner)).toThrow(/unreviewed contents/);
});
