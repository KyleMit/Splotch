# Android candidate archive intake

This source partition supplies the fixed archive-intake caller
`inspect-android-candidate-archives.mjs`. It authenticates maintained candidate inputs and retained
primary metadata, selects the eight base compile archives for each supported host, and records
whole-archive and streamed member receipts in a separate marked owner. It does not extract files,
accept licenses, publish a toolchain, execute downloaded programs, or build or mount an app.

The command remains outside the public script graph until the reviewed topology baseline and audited
ZIP-reader dependency are integrated. Its authored fixtures have not been executed. Executing the
intake also requires review of these sources and root authorization; archive metadata pins do not
constitute downloaded-archive, installed-toolchain, or native-success evidence.

## Authenticated inputs

`inputs/android-toolchain-profile.json` retains the reviewed host-specific SDK, Temurin, Node and
Gradle URLs and checksum identities. The retained Google XML and official Node checksum text are
bound by the archive-profile reader. Gradle agreement is checked against the maintained candidate
wrapper; that wrapper's exact bytes and mode remain owned by the maintained-source reader. SDK
license body, normalized text and accepted-line hash are receipt-only observations. They neither
write SDK license state nor infer changed terms from a whole license-file hash.

The profile was prepared from the exact retained primary metadata and SDKmanager-normalized license
body in the reviewed Native07b packet. Regeneration must preserve those source bytes, recalculate
the profile hash, and explicitly review changed pins or selected license terms. A moving registry
query is not a regeneration input. The private source-preparation writer and its source receipt are
kept in the review packet; the public intake never invokes that writer.

## Member and layout boundary

ZIP inspection uses audited `yauzl` 3.4.0 with lazy entry ownership and completed stored or deflated
content streams. Entries retain raw names, creator attributes, extra fields, modes, link targets,
byte lengths and SHA256 values. Unknown creators, unsupported encodings, special files or unsafe
paths fail for review. DOS entries without Unix mode attributes retain an unspecified mode; no
executable-mode qualification is inferred from them.

TAR inspection uses the declared strict parser's public events. Its receipt inventories effective
filesystem members and ordered raw metadata text. Public metadata events do not expose physical
producer header types. Only strictly framed, supported PAX-record text is accepted; NUL/GNU
long-name text and unsafe effective names or links fail for review. The whole-archive hash binds
physical bytes, but the receipt does not claim a physical metadata-header inventory. Any selected
archive that needs another format requires a bounded source-policy amendment before extraction.
PAX values with control characters are rejected before an inspection receipt can be accepted. SDK archives must contain exactly one shallow regular-text `source.properties` whose observed
identity agrees with the pinned package and revision; a missing or ambiguous member fails for review.

Every member graph is checked before any mapping is returned. Safe links are inventoried, with
cycles, escapes, collisions, missing targets and nondirectory parent crossings rejected. Node's
known mapping selects only the regular `bin/node` and `LICENSE` members under its exact distribution
root; all other content and links remain inventory rows and are never published. SDK, Java and
Gradle archive layouts still require actual full-archive review. All inspection receipts state
`archive-review-required`, `publicationAllowed: false` and `nativeExecution: false`.

## Ownership and failed downloads

macOS uses a profile owner under the qualified host home's cache; Linux uses a profile owner under
`RUNNER_TEMP`. Received `HOME` is checked against the effective user's OS-provided
`os.userInfo().homedir` before the first write and is preserved. Owners must be canonical and separate
from the checkout, other registered worktrees, host SDK/AVD paths and known Java homes. Existing owners
require an exact source marker, regular independent input files and the closed intake directory set.

A download first creates its partial file exclusively. It authenticates complete bytes before
renaming that file into the archive store. A failed partial created by the caller is moved to a
nonce-named receipt path only after its owner and inode identity are checked; its small failure
receipt records no secret exception text. The retry slot then becomes available. Preexisting or
replaced partials are preserved and rejected rather than adopted or removed.

The filesystem fences detect source/input changes at each boundary; they are not a proof against
arbitrary concurrent privileged host mutation. In particular, authentication and parsing reopen the
path: a concurrent replace-and-restore A → B → A can describe B while both complete boundary hashes
observe A. A pre/post inode comparison alone would not close that race. This intake requires a
quiescent owned input; a shared-descriptor parser protocol is not implemented or certified.

All captured metadata-named files, including nested license files, retain the strict text/size gate.
Case/NFC collisions fail on both hosts, with both conflicting member names in the error. Actual
vendor layouts and encodings remain unknown until reviewed whole-archive intake; no permissive
collision or nested-text policy is inferred. The CLI's invocation result records download versus
reuse and the current serving origin (null on reuse), outside the deterministic inspection receipt.

The next reviewed partitions own extraction,
qualified runtime publication, finite child environment/PATH, effective same-Release Gradle probes,
installed build copies and Maven verification. Mounted emulator and Apple qualification remain
separate acceptance gates.
