import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import { archiveMemberPath, consumeArchiveMember } from './android-sdk-members.mjs';

const ZIP_EXTRA_FIELDS = [0x0001, 0x000a, 0x5455, 0x7075, 0x7875];
const UNIX_CREATORS = [3, 19];

async function qualifiedZipReader() {
  const require = createRequire(import.meta.url);
  const metadata = JSON.parse(readFileSync(require.resolve('yauzl/package.json'), 'utf8'));
  if (metadata.version !== '3.4.0') throw new Error('Android ZIP reader must be audited yauzl 3.4.0');
  return (await import('yauzl')).default;
}

function zipMemberType(entry) {
  const creator = entry.versionMadeBy >>> 8;
  const mode = entry.externalFileAttributes >>> 16;
  const bits = mode & 0xf000;
  const slash = entry.fileName.endsWith('/');
  if (UNIX_CREATORS.includes(creator)) {
    const type = ({ 0x8000: 'file', 0x4000: 'directory', 0xa000: 'symlink' })[bits];
    if (!type || slash !== (type === 'directory'))
      throw new Error(`Unreviewed ZIP Unix type: ${entry.fileName}`);
    if (mode & 0o7000) throw new Error(`Unsafe ZIP special permissions: ${entry.fileName}`);
    return { type, mode: mode & 0o777, modeSource: 'unix-attributes' };
  }
  if (creator !== 0 || slash !== !!(entry.externalFileAttributes & 0x10))
    throw new Error(`Unreviewed ZIP creator/type: ${entry.fileName}`);
  return { type: slash ? 'directory' : 'file', mode: null, modeSource: 'unspecified-dos' };
}

async function zipMember(zip, entry, setStream) {
  if (!entry.canDecodeFileData()) throw new Error(`Unsupported/encrypted ZIP member: ${entry.fileName}`);
  if (entry.extraFields.some((field) => !ZIP_EXTRA_FIELDS.includes(field.id)))
    throw new Error(`Unreviewed ZIP extra field: ${entry.fileName}`);
  const { type, mode, modeSource } = zipMemberType(entry);
  const path = archiveMemberPath(entry.fileName, type);
  const stream = await zip.openReadStreamPromise(entry);
  setStream(stream);
  const content = await consumeArchiveMember(stream, path, type, entry.uncompressedSize);
  if (type === 'directory' && content.bytes) throw new Error(`ZIP directory has data: ${path}`);
  return { path, type, mode, ...content, link: type === 'symlink' ? content.text : null,
    source: { format: 'zip', creator: entry.versionMadeBy >>> 8, modeSource,
      externalFileAttributes: entry.externalFileAttributes,
      rawFileNameHex: entry.fileNameRaw.toString('hex'), compressionMethod: entry.compressionMethod,
      extraFields: entry.extraFields.map((field) => ({ id: field.id, dataHex: field.data.toString('hex') })) } };
}

export async function readAndroidZipMembers(file) {
  const yauzl = await qualifiedZipReader();
  const zip = await yauzl.openPromise(file, {
    autoClose: false, decodeStrings: true, validateEntrySizes: true, strictFileNames: true,
  });
  const members = [];
  let failure;
  let ended = false;
  let active;
  const closed = new Promise((resolve) => zip.once('close', resolve));
  const failed = new Promise((_, reject) => {
    zip.on('close', () => {
      if (!ended && !failure) reject(new Error('ZIP reader closed before complete member inventory'));
    });
    zip.on('error', (error) => { failure ??= error; active?.destroy(error); reject(error); });
  });
  try {
    await Promise.race([failed, new Promise((resolve, reject) => {
      zip.on('entry', (entry) => {
        const work = zipMember(zip, entry, (stream) => {
          active = stream;
          if (failure) stream.destroy(failure);
        });
        work.then((row) => {
          members.push(row);
          if (!failure) zip.readEntry();
        }, reject);
      });
      zip.once('end', () => { ended = true; resolve(); });
      zip.readEntry();
    })]);
  } finally {
    zip.close();
    await closed;
  }
  if (failure) throw failure;
  return { members, metadata: [], inventoryScope: 'all ZIP central members and decoded content' };
}
