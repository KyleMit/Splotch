# Native07b: owned base toolchain source plan

Planning only, following the accepted template plan, SDK amendment, all six SDK dispositions and the
seven Native07b review dispositions in `/private/tmp/splotch-native-sdk-review-dispositions.md` and
`/private/tmp/splotch-native07b-review-dispositions.md`. No new repository source, installation,
binary provisioning, native command, test, staging or commit occurred for this plan. Native07a
remains quiescent after the root/Claude-accepted original-text source correction; execution and
integration proof still await reviewed topology05 provenance and rebase.

## Reviewable scope and callers

The first implementation route is owned Node 24 + Java 17 + fixed SDK compile inputs + the real
optimized Android Release caller, on Mac arm64 and Linux x64. Keep Apple preparation and all
mounting in separately named later units. Keep the unresolved Mac Android mount outside their
executable package selection and caller interfaces. Linux exposes compilation only: no emulator,
image, AVD, ADB, KVM/sudo/udev change or software-rendered mount claim. The later required Mac
Android API 24 arm64 mount and Mac iOS mount are distinct acceptance rows.

Enter source integration only after root supplies actual reviewed topology05 head/provenance and
rebases 07a. Reuse its path, package-resolution, integrity and archive-inventory owners; use 07a's
native identity/wrapper/entry/signing owners. Do not infer source versions from a requested range.
Assert actual Expo/RN/plugin source receipts before selecting this toolchain profile; a changed
consumer needs review rather than a moving fallback.

Immediate Android callers and their narrow support ownership:

| Caller                                   | Action and narrow support ownership                                                                                                                                                                                                           |
| ---------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `inspect-android-candidate-archives.mjs` | Downloads only fixed approved base URLs, verifies full bytes, emits complete member/layout/source-property receipts, executes nothing; it refuses extraction publication until those actual layouts are reviewed                              |
| `provision-android-candidate.mjs`        | Publishes only previously reviewed base payload mappings into the one marked owner, verifies actual executables/metadata and runs the qualified pinned installed-package report                                                               |
| `build-android-candidate.mjs`            | Real optimized Release caller; obtains exact owned context, checks inputs, prepares disposable signing, passes the owned init/module probe to the same Release invocation, and records compiled output; no mount mode or arbitrary extra argv |

Supporting modules stay purpose-named under `tools/migration/lib/`: `candidate-toolchain-roots.mjs`,
`candidate-child-environment.mjs`, `candidate-host-fence.mjs`, `android-sdk-artifacts.mjs`,
`android-sdk-members.mjs`, `android-candidate-context.mjs`, `android-candidate-build-copy.mjs` and
`android-release-inputs.mjs`. The last two have the actual Release caller below; neither is a
generic copy runner or Maven downloader. Split only when an actual concern warrants it; keep each
below normal caps. The Android init/module probe is an owned source input consumed by the real build
caller, not an uncalled diagnostic API. No generic provisioner, arbitrary command runner, external
root override, automatic package script or test-only production reset.

Register root npm/scripts-info, migration README/knip/workflow inputs and scoped generated output
fences with the source PRs after rebasing. The root test runner already discovers capability tests;
do not manufacture a per-tool package. Native build invocations remain separate from web/Capacitor
helpers and signing routes. Review/land owned Node 24 + Java 17 + SDK archive/context policy first,
then the real Android build caller and its effective included-build/module receipts. All archive
publication and native execution still follow their explicit reviewed stages; structural source
review does not claim installed success.

The copied candidate has exactly two generated regular-input declarations:
`android/local.properties`, owned by android-candidate-context's machine-path writer, and
`android/gradle/verification-metadata.xml`, owned by android-release-inputs' provisional-generation
/ reviewed-input copy route. Actual 07a collectNativeFiles currently includes every regular file and
readMaintainedNativeFiles compares that set to canonical provenance, so both additions fail its
current exact reader. Introduce those two declarations only with their real writers; require
canonical contained regular files and leave both outside the original-template receipt. The build
context requires exact sdk.dir/cmake.dir keys, values and mode before any command; the verification
owner requires the stage-appropriate provisional output or hash-bound reviewed metadata and strict
policy described below. Initial source validation permits neither unowned generated input nor
preexisting residue. Unknown sibling inputs, wrong metadata location and local Xcode overrides still
fail. Fixtures drive actual writer/read/spawn consumers, including each positive input separately
and both together, wrong path/mode/contents, links, extra local.properties keys and review-hash
drift. No generated machine path or verification bytes become a fabricated template provenance row.
Committed Gem/pod locks need their separate native-input owner only in the later Apple resolution
unit.

## One owned context per host

Profile `expo57-rn0863-agp812-v1` owns the Mac arm64 root
`/Users/kylemit/.cache/splotch/native-toolchains/expo57-rn0863-agp812-v1/darwin-arm64` and Linux x64
root under canonical `RUNNER_TEMP/splotch-native-toolchains/expo57-rn0863-agp812-v1/linux-x64`.
Resolve user/runner ownership once; require an absolute canonical owner outside the primary
checkout, every actual managed worktree and all qualified global SDK/AVD/Java/Xcode roots. Reject
aliases, escaping links, unexpected contents or an existing root without the matching profile/source
marker. The marker authenticates recorded inputs, not a merely matching version string.

Base children are `sdk/`, `node-24.16.0/`, `archives/`, `staging/`, `receipts/`, `runtime/bin/`,
`runtime/host-bin/`, `runtime/expo-home/`, `runtime/android-user/`, `runtime/gradle-9.3.1-jdk17/`,
`runtime/gradle-project-cache/`, `runtime/kotlin-user/`, `runtime/tmp/` and owned signing storage.
Apple adds exact Ruby/build/cache/gems/Bundler/pod preparation/DerivedData children. Proposed
mount-only AVD/emulator/discovery/ADB children are not created by base provisioning. No selected
toolchain or writable cache lives inside a borrowed checkout. The real Release caller uses the
disposable owned build copy described below; installed-package outputs remain inside that copy
rather than the active checkout.

Capture received HOME and preserve its exact value in children; validate its canonical host identity
rather than silently assigning another HOME. Never repurpose it, unset it, source a profile or alter
shell/global registration. Child temporary roots and bounded PATH are owned explicitly. JVM
temporary roots require `java.io.tmpdir` in addition to TMPDIR. Allocate a fresh
runtime/tmp/<receipt-id> for each real invocation window so Metro/JVM temporary caches cannot
silently bridge build copies. Receipt IDs are 32 lowercase hexadecimal characters; before any JVM
launcher, require the entire generated absolute tmp path to contain only `[A-Za-z0-9_./-]`, no quote
or line break and no `version` substring. The pinned SDK launchers parse all `java -version` stderr
with awk `/version/`, including the JAVA_TOOL_OPTIONS banner; unsafe generated paths must fail
before spawn rather than polluting that parser. Use absolute verified executables.
SDKmanager/Gradle/Ruby operations get their actual composed environment and argument vector, not a
second descriptive object that can disagree.

Refresh global operational fences before every approved provision/build/launch window and compare
after success or failure. Cover SDK/AVDs, `.android` locators, preferences and keys, global SDK
license file, console token, Mac discovery tree, possible `adb.<uid>.log` files under actual TMPDIR
and `/tmp`, Java receipt, received HOME/.kotlin, possible Kotlin daemon paths derived from its
released FileSystem owner, and actual native JVM `hsperfdata_<user>` directories, alongside global
Expo settings/cache paths and Xcode selection. OpenJDK17's native Linux temp is /tmp; macOS uses
`confstr(_CS_DARWIN_USER_TEMP_DIR)`, independent of TMPDIR/java.io.tmpdir. Qualify that actual
native Darwin path with a read-only host observation, not by substituting a shell TMPDIR; capture
existing perf-data files without deleting them or attributing a foreign JVM's writes to this run.
Record stat/link/critical hashes accurately; that inventory is not full cryptographic equality for
every large disk image. A foreign change invalidates the unchanged-host assertion; preserve it and
repeat exclusively, without terminating the foreign process or repairing global state.

## Fixed base artifacts and archive boundary

Executable base SDK selection on both hosts is exactly cmdline-tools 20.0, platform 36 revision2,
build-tools 36.0.0, NDK 27.1.12297006 and CMake 3.30.5. Do not select Linux platform-tools; no
compile consumer is declared in its reviewed catalog. Likewise withhold Mac platform-tools until the
separate real ADB mount consumer is unlocked. A concrete compile demand for it requires an exact
payload amendment, not an implicit SDK installation.

The package/URL/size/upstream SHA1 pins below come from the exact inspected Google XML snapshot with
SHA256 `c9e2f9e8b118dcc9c5584904ea27cbcefb217a5807029cedadfaa0b2f842fa8d`. The registry snapshot and
selected package/license records must be retained as source inputs. SDK archives have not been
downloaded or their layouts approved. Do not infer top-level prefixes or local package.xml contents
from filenames.

The fixed Gradle 9.3.1 bin URL/wrapper JAR/distribution SHA256 are 07a's existing owner. The same
owned download/layout gate applies to the distribution; preserve its original archive and
extracted-member identity even if the wrapper removes its temporary ZIP. Do not bypass the wrapper
or loosen version semantics.

Java is Temurin 17.0.20.1+1 from its exact release. Mac arm64 archive
`OpenJDK17U-jdk_aarch64_mac_hotspot_17.0.20.1_1.tar.gz` has reviewed SHA256
`196d13ba5f10414bef7f6a05a9b3f00edacb18ebacef2b99485db9e2ee18f0e8`; Linux x64
`OpenJDK17U-jdk_x64_linux_hotspot_17.0.20.1_1.tar.gz` has
`3808d1d15e3ec6bd5b84057fb5d84c33d8a1536a258146bcea2e603fc726e08e`. Exact official URLs are
[Mac arm64](https://github.com/adoptium/temurin17-binaries/releases/download/jdk-17.0.20.1%2B1/OpenJDK17U-jdk_aarch64_mac_hotspot_17.0.20.1_1.tar.gz)
and
[Linux x64](https://github.com/adoptium/temurin17-binaries/releases/download/jdk-17.0.20.1%2B1/OpenJDK17U-jdk_x64_linux_hotspot_17.0.20.1_1.tar.gz).
Verify actual archive length, checksum, layout, release file and executable identity before
selection. No pkg/global Java installation or borrowed Java 21 fallback.

Topology05's verifyArtifactIntegrity and declared tar Parser supply integrity/TGZ primitives but
inspectArchive is specifically an npm-package hook reader: it requires exactly one root package.json
and returns hook metadata, not a complete distro-member/extraction receipt. It cannot be called
unchanged on a Node distribution. Reuse those primitives through the bounded Node mapping below,
without weakening that npm-package reader. They supply no ZIP reader. Propose one root-dev
`yauzl@3.4.0` for the real SDK/Gradle ZIP consumer, rather than an unqualified OS unzip/Python tool
or a handwritten ZIP framework. Its exact public source archive was inspected in memory: 31577
bytes, six regular members, complete registry SRI matched, root scripts contains test only,
dependencies pend ~1.2.0. Its source receipt is
`/private/tmp/splotch-native07b-yauzl-source-receipt.json`. This is a proposed reviewed dependency
addition, not installed success. pend 1.2.0 is already locked through yauzl 2/fd-slicer and is not a
new artifact. With the actual hoisted layout, root yauzl changes 2.10.0 to 3.4.0;
@puppeteer/browsers 3.2.1 optional peer accepts both, so its peer key and the lighthouse 13.5.0 /
puppeteer-core 25.9.0 dependent snapshot keys can re-resolve. native-run 2.0.3 still needs yauzl
2.10.0 and must resolve its preserved nested copy. Audit the actual lock-only delta, all those
consumer realpaths and original production closure, then rerun 05
frozen-install/lifecycle/production guards before normal installation. No transitive-addition claim
replaces that real delta.

Use its strict filename decoding/lazy entry/size validation options, plus our closed package
mapping/type/link/destination guards. Verify exact whole-archive checksum before parsing; reject
encrypted/unsupported members, duplicate normalized names, absolute/backslash/traversal/ambiguous
paths and unsafe symlink targets. Archive inspection determines genuine internal links that must be
preserved; reject all escaping/cyclic/type-conflicting links before publishing. Emit original member
metadata and digests; no blind extractAll or arbitrary prefix stripping. Streaming avoids buffering
the NDK into Node memory. Only approved mappings are extracted to owned staging and atomically
published to their one fixed destination.

Verify source.properties and supplied local metadata against the exact reviewed ID/revision. Where
registration is absent, derive only from its retained reviewed remote-package element,
inspect/review that generated record, and prove pinned SDKmanager recognizes the exact closed
installed set. No registration JSON or source.properties file alone certifies executable identity.
Recognition is an actual future receipt, not a source-test outcome.

## Owned Node and finite Expo build selectors

Compare two real routes. An existing absolute qualified Node 22/24 provider could be linked alone
into runtime/bin without exposing its NVM/Homebrew directory; qualification would bind
binary/distribution identity, architecture, version, auxiliary-library provenance and unchanged host
inputs on each host. Read-only inventory found NVM 22.23.2 and 24.16.0 on Mac, but presence/version
receipts from 05 are not installation ownership or that qualification. Linux would need its own
equally qualified provider, and neither host may source a shell/NVM profile during a build.

Choose a newly owned official Node 24.16.0 archive on both hosts. This matches 05's recorded
runtime, satisfies the actual Expo/RN engine ranges, and supplies one reproducible provider instead
of two host-install qualifications. It adds one fixed TGZ per host to a narrow tar-based
distribution mapping, with no installer or additional ZIP parser. For each exact
node-v24.16.0-<host> root, provision selects only the regular members bin/node and LICENSE, written
as node-24.16.0/bin/node and node-24.16.0/LICENSE. Bind their exact bytes/type/mode and the selected
executable's architecture/version during the archive and runtime qualification stages. Inventory
every other member, mode and link target; validate the archive path/type/link boundary, but never
publish a link member or npm/npx/corepack payload. The only later link is the separately validated
runtime/bin/node → owned regular executable. No arbitrary distribution prefix or file mapping is
accepted. An omitted/wrong-type/wrong-root node or LICENSE, extra published member, published
archive link or replacement executable must fail the actual mapping/publication consumer. This is a
reviewed two-member extraction surface; actual full archives and executable/auxiliary-library
qualification remain pending, so do not infer successful standalone execution from checksum text.

The official checksum text is https://nodejs.org/dist/v24.16.0/SHASUMS256.txt, saved as
/private/tmp/splotch-native07b-node24-shasums.txt with SHA256
`e20ebbf68d33f42d196a7a11b8a91d422fa37b759c0a51aa4857977135cc5e95`. Fixed Node archive pins:

| Host      | URL                                                                | SHA256                                                             |
| --------- | ------------------------------------------------------------------ | ------------------------------------------------------------------ |
| Mac arm64 | https://nodejs.org/dist/v24.16.0/node-v24.16.0-darwin-arm64.tar.gz | `39189dab4eeb15706c424af0ac08a3044c9e48f7db12a7d77f6b7aafc7dd5df6` |
| Linux x64 | https://nodejs.org/dist/v24.16.0/node-v24.16.0-linux-x64.tar.gz    | `2faf6a387e9b62b888e21c54f01249fb27537ffecf1842f29f4c919d0a59a0ff` |

These are primary metadata pins, not archive audit or installed-success evidence.

The actual child PATH contains only runtime/bin, verified owned JDK/CMake bins and a finite
runtime/host-bin. The latter links only qualified absolute system utilities demanded by the exact
Gradle wrapper and selected SDK launcher. The complete currently inspected union is
sh/uname/ls/xargs/sed/tr/dirname/awk/basename/expr, including /usr/bin/env sh's interpreter lookup.
The exact public Mac and Linux 14742923 ZIP launcher text members independently confirm the SDK
subset; their bounded range/source receipts do not verify whole-archive integrity. Qualify every
individual utility's absolute source path and resolver entry; any additional selected-archive demand
is inspected/reviewed before publication. It never exposes /opt/homebrew/bin, /usr/local/bin or an
entire host Java/SDK/CMake directory. Missing selected Node/JDK/CMake/Ninja fails before invocation
rather than finding a host fallback. Source-only fixtures inspect this actual PATH and resolver
result; future execution binds every Node invocation (including configuration/autolinking and
bundle/codegen task vectors) to runtime/bin/node.

candidate-child-environment rejects nonempty inherited NODE_OPTIONS/NODE_PATH and every inherited
EXPO_PUBLIC_* key. It then generates NODE_OPTIONS=--no-global-search-paths, a supported Node 24
option that also closes HOME/.node_modules fallback; there is no extra-option caller. Scrub other
recognized Node cache/debug/coverage/ICU/TLS/loader controls from the exact versioned CLI source
(the finite selector list and source hash are in installed-source-receipt.json); unknown inherited
NODE_* controls fail for review except the explicitly owned NODE_ENV. Scrub UV_THREADPOOL_SIZE from
its actual Node consumer rather than inheriting a scheduler override, and set
NODE_DISABLE_COMPILE_CACHE=1. Any network CA/proxy input needed by a separate approved download
caller has an explicit read-only input owner; it is not silently inherited into the Release child.
Set NODE_ENV=production and BABEL_ENV=production explicitly. Reject inherited ENTRY_FILE,
REACT_NATIVE_OVERRIDE_HERMES_DIR and APP_MANIFEST; they redirect actual RN entry/Hermes or Babel
manifest consumers. Scrub BABEL_8_BREAKING rather than selecting an unreviewed preset mode.

The finite Expo policy is derived from the installed released @expo/cli 57.0.27 env.js getters,
@expo/env 2.4.3, @expo/metro-config 57.0.12, @expo/config paths and babel-preset-expo 57.0.13. Its
56 declared CLI selectors and exact source hashes are recorded in
/private/tmp/splotch-native07b-review-sources/installed-source-receipt.json. Scrub those actual
EXPO_* selectors to released defaults before generating the explicitly chosen values:
EXPO_NO_DOTENV=1, EXPO_NO_TELEMETRY=1, EXPO_NO_TELEMETRY_DETACH=1, EXPO_NO_CACHE=1 and
EXPO_NO_DEPLOY=1. Scrub internal __EXPO_ENV_LOADED/__EXPO_CONFIG_MODE/__EXPO_EAGER_BUNDLE_OPTIONS,
EXPO_UNSAFE_DOTENV_KEYS, EXPO_TOKEN and actual inherited project/router root selectors. Set
EXPO_PROJECT_ROOT to the owned copied candidate root and __UNSAFE_EXPO_HOME_DIRECTORY to owned
runtime/expo-home. The latter is a real released UserSettings.js consumer, not HOME reassignment.
Unknown inherited EXPO_*/__EXPO_* selector names fail for review; EXPO_PUBLIC_* remains a separate
content-injection rejection. Preserve default Metro/React behavior rather than enabling Atlas,
experimental graph optimization, alternate Metro configuration, server deployment or a host Expo
credential session. Compose CI=1/EAS_BUILD absent and scrub inherited RCT_METRO_PORT/WEB_HOST.

Disable dotenv before the first Node child; also reject `.env*` inputs in the candidate/root
ancestry used for config loading so the copy cannot contain undeclared configuration. The real
Release source reader covers candidate root/entry/app/Metro/Babel metadata plus maintained native
source; 07a's native-tree reader alone is not this fence. Required controls inspect the actual spawn
request and prove no child on bad Node symlink/provider, host PATH, NODE_OPTIONS preloader,
NODE_PATH, public content, alternate entry/Hermes/manifest, .env file, unknown selector or missing
selected Node. Known scrubbed dotenv markers, wrong inherited NODE_ENV/BABEL_ENV, Expo
credential/home/root selectors and agent Java options must instead compose a valid clean owned
production child; positive controls assert those exact generated values. Mutations that leak a
scrubbed marker, wrong generated mode/home/root or cache path must fail the actual final
spawn-request validator before a child is created. There is no arbitrary environment override API.
These authored controls do not certify binaries until the archive/provision/Release gates execute.

## Receipt-only license identity

All selected base records name android-sdk-license. Keep its exact decoded body, normalization owner
and hashes under owned receipts: decoded SHA256
`1f8729233617b193fd619213792ae16a41b95d2bbbf525dfe66998252ba68b16`, normalized SHA256
`aaf80cd0aee7e569ffa8a4be1b61189c0fefccf23068e38dfafe336289b8c723`, accepted-line SHA1
`24333f8a63b6825ea9c5514f83c2829b004d1fee`. Read global acceptance only as qualified unchanged
comparison identity; match exact line values after line-ending removal and permit coexisting older
accepted lines. Do not equate a whole-file receipt hash with normalized license text.

Do not create/copy acceptance state into sdk/licenses on either host and do not run --licenses.
Package extraction/registration is not acceptance. Required present-package compilation without
acceptance remains an execution gate. If an actual tool demands acceptance for fully present
packages, preserve that exact failure for narrow review rather than broadening terms or borrowing
global state.

## Finite child policy and actual Gradle selection

Scrub known inherited selectors, then generate owned values. The finite list includes
ANDROID_HOME/ANDROID_SDK_ROOT, ANDROID_NDK/ANDROID_NDK_HOME/
ANDROID_NDK_ROOT/ANDROID_NDK_LATEST_HOME, legacy ANDROID_SDK_HOME/ ANDROID_PREFS_ROOT, controlled
Android/emulator/AVD/discovery/ADB auth/endpoint/log variables, CMAKE_VERSION, JAVA_HOME and
declared JAVA_HOME_<version>_X64 keys, JAVA_TOOL_OPTIONS, _JAVA_OPTIONS and JDK_JAVA_OPTIONS.
Harmless agent launcher injections therefore compose valid children after scrubbing.

Reject any ORG_GRADLE_PROJECT_* key, and nonempty GRADLE_OPTS/JAVA_OPTS, before invocation. Do not
parse or forward shell option text. Installed host cmdline 20 launcher source additionally reads
SDKMANAGER_OPTS/AVDMANAGER_OPTS and SKIP_JDK_VERSION_CHECK; explicitly scrub those and qualify the
selected archive's actual launcher/class owner before execution. Host cmdline 20 is physically under
latest but its source.properties says cmdline-tools;20.0; this is read-only source comparison, not
permission to use that moving locator. Read-only installed launcher lines173–176 require JDK17 or
later; this supports the chosen major but is not proof of the selected archive's executable
identity. Audit actual recognized launcher variables for every selected tool and extend the finite
reviewed policy only from those source owners.

Children receive owned ANDROID_HOME/ANDROID_SDK_ROOT with identical canonical SDK,
ANDROID_USER_HOME, JAVA_HOME, GRADLE_USER_HOME, bounded PATH/temp roots and closed typed arguments.
No extra Gradle arguments or arbitrary environment override flag. Record only
name/presence/policy/redacted fingerprints for inherited inputs; record canonical generated safe
paths. Never print environment/option contents, private key/token bytes or signing passwords.
Disposable signing property storage must be owned/mode-qualified and excluded from public
command/receipt echoes. Supply secret signing values through the owned Gradle properties file rather
than printed `-P` arguments. The caller creates only the external candidate-named key with owned
Java 17 keytool, validates that directory/file, and never reads a shipping signing key.

Every Gradle invocation includes exact wrapper, owned home/project cache, fixed
`--no-daemon --no-configuration-cache --no-configure-on-demand --console=plain` and:

```text
-Dorg.gradle.java.installations.auto-download=false
-Dorg.gradle.java.installations.auto-detect=false
-Dorg.gradle.java.installations.paths=<verified-owned-Java 17>
-Pandroid.builder.sdkDownload=false
-Pandroid.cmakeVersion=3.30.5
```

Put the same denials/Java path, `android.builder.sdkDownload=false` and
`kotlin.compiler.execution.strategy=in-process` and `kotlin.user.home=<owned runtime/kotlin-user>`
in owned Gradle-home properties. Preserve 07a maintained android/gradle.properties unchanged.
Compose org.gradle.jvmargs from its reviewed `-Xmx2048m -XX:MaxMetaspaceSize=512m` plus owned
`-Djava.io.tmpdir` and `-XX:-UsePerfData`; record that exact composition. Generate trusted
JAVA_TOOL_OPTIONS containing only the same owned tmpdir selector and `-XX:-UsePerfData` after
scrubbing inherited text. It reaches internal launcher `java -version` calls which SDKMANAGER_OPTS
does not cover. Generate owned SDKMANAGER_OPTS, pass `-J-Djava.io.tmpdir` to keytool and preserve
the generated JAVA_TOOL_OPTIONS for every owned JVM. OpenJDK17 globals.hpp defaults
UsePerfData=true; perfMemory_init returns before initialization when false, while
perfMemory_posix.cpp otherwise uses os::get_temp_directory for `hsperfdata_<user>`. The retained
exact release's Linux/BSD owners demonstrate why TMPDIR and java.io.tmpdir alone cannot contain that
output. Qualify the selected owned binary's effective UsePerfData=false in its actual Java
recognition receipt; the same-Release probe reads the running JVM's HotSpotDiagnosticMXBean
UsePerfData and java.io.tmpdir, not just environment presence. SDK/keytool chains additionally bind
that qualified executable, actual generated options and unchanged native-temp fence. No selected
Temurin binary/flag behavior is claimed verified from upstream source alone. No user-supplied JVM
option text is forwarded. Generated local.properties names owned sdk.dir/cmake.dir only, without
deprecated ndk.dir. Reject contradictory values and daemon-JVM criteria files anywhere in
candidate/included-build closure. Keep configuration cache/configuration-on-demand from skipping the
diagnostic inventory. Reject the specific deprecated Java project-property warning and any
downloaded jdks.

The actual fixed Release invocation includes
`--init-script <owned android-release-probe.init.gradle>`; there is no earlier probe invocation
supplying its receipt. The exact init source is copied/hash-bound from tools/migration/inputs.
Gradle 9.3.1 BuildDefinition.startParameterForIncludedBuildFrom explicitly copies the root init
scripts into each included build’s start parameter; the retained source receipt verifies that owner.
Its callbacks must actually run for every participating build. It attaches before project
configuration, validates finalized settings/project identities and records the same task graph at
taskGraph.whenReady before tasks in that build. Included-plugin compilation can precede the root
graph, so its own participating build must emit/validate the same receipt; a root-only callback is
insufficient. Recheck relevant effective task values immediately before Kotlin/native task work so a
later callback cannot escape a one-time graph read. Missing expected included-build or native-module
rows fail the final real receipt reader. Project/property extraction is a closed allowlist; the four
signing properties and credentials are never enumerated or emitted.

The probe reads effective providers.gradleProperty in root and every RN/Expo included build and
requires the closed Java installation set, exact daemon JVM Java 17, owned java.io.tmpdir and
effective UsePerfData=false. For every Kotlin-applying project and actual compile task, require
effective compilerExecutionStrategy=IN_PROCESS, not only the project property. Reject contradictory
project/Gradle-home/task settings before compilation. Bind each Kotlin-applying build/project and
compile task to its actual loaded KGP version, plugin class/code-source artifact and requested
versus selected plugin/module identities before using version-specific getters. KGP 2.1.20's
DefaultKotlinBasePlugin.pluginVersion/getKotlinPluginVersion reads project.version from its own
resource; do not infer it from kotlinVersion text or the compiler's Kotlin language/api target. The
retained installed RN catalog and its four JVM plugin projects, Expo autolinking's four JVM plugin
projects and Expo core-plugin declare JVM KGP 2.1.20. Expo's shared autolinking project separately
requests serialization plugin 1.9.24; retain that subplugin request and actual selected artifact
instead of asserting every Kotlin plugin is 2.1.20. Root application/module selection still requires
the real receipt. None of these inspected build declarations applies kotlin-dsl or embedded-kotlin,
but Gradle 9.3.1's retained KotlinDslPlugin → KotlinDslBasePlugin → EmbeddedKotlinPlugin chain
applies KotlinPluginWrapper using its embedded owner. If such a project participates,
classify/authenticate that actual Gradle/KGP version separately and review its strategy/temp getter
semantics before work; do not blindly require 2.1.20 or apply 2.1.20 getters to another
classloader/version. A missing, changed or unsupported version returns to review and fails before
compilation. The exact Kotlin 2.1.20 PropertiesProvider reads kotlin.compiler.execution.strategy,
CompileUsingKotlinDaemon defines the default DAEMON and IN_PROCESS value, and
GradleKotlinCompilerWork takes the in-process branch directly when selected. Thus there is no Kotlin
daemon connection/fallback attempt; its actual in-process execution and absence of a new Kotlin
daemon/host run file remain execution receipts. In-process compilation is nonincremental in this
release; report its measured build cost rather than promising daemon-speed parity. Native/shared
included-build receipts cannot be replaced by toolchain flags or a root report.

KGP 2.1.20's GradleCompilerRunner constructs ProjectFilesForCompilation before selecting compiler
work; its constructor calls getOrCreateSessionFlagFile regardless of strategy.
GradleCompileTaskProvider passes project.kotlinSessionsDir, and persistentCaches.kt resolves it to
the participating root's .kotlin/sessions by default. Add exactly each authenticated participating
build root's .kotlin to copied generated outputs, including installed RN/Expo plugin roots. At its
first real writer, also declare exactly android/.kotlin as a generated directory in 07a's maintained
source reader; it currently recursively collects that directory's files too. Installed-package
.kotlin paths belong only to the authenticated build-copy output map, not a wider 07a or
node_modules ignore. Read the released PropertiesProvider.Companion.invoke(project) getters in each
Kotlin project so build extra and local.properties precedence cannot redirect
kotlin.project.persistent.dir; require the default owned root/.kotlin selection and owned
kotlin.user.home before work. The latter has an actual userKotlinPersistentDir accessor in
persistentCaches.kt, explicitly annotated unused in this release: its source confirms
property/default semantics, not a claim that this build necessarily creates HOME/.kotlin. Keep that
host fence defensive. The same runner constructor also calls getOrCreateClientFlagFile; runner lines
412–420 supplies prefix kotlin-compiler-in-<project>- and suffix .alive to
org.jetbrains.kotlin.gradle.utils.newTmpFile with no directory. The retained actual
utils/fileUtils.kt 54–67 calls Files.createTempFile(prefix,suffix) and defaults deleteOnExit=true.
Exact OpenJDK17's TempFileHelper uses StaticProperty.javaIoTmpDir when directory is null. This
places the actual client flag in the already-owned per-invocation runtime/tmp/<id>, independently of
compiler strategy. Classify the .alive regular files in that existing temp inventory and record any
actual observed paths/modes; do not call the getter merely to create a diagnostic file. JVM
deleteOnExit can remove them before final inventory, so an absent final file is not claimed proof
that no client flag was created. Effective JVM tmpdir plus actual before/during/after observations
remain execution proof. Real-reader controls must permit the exact .kotlin outputs and owned .alive
temp files, and reject a changed participating root/persistent-dir/user-home/tmpdir value or a write
outside the copy/context.

android.cmakeVersion has a concrete released Expo consumer: expo-modules-autolinking 57.0.13's
ExpoRootProjectPlugin.maybeOverrideCmakeVersion reads it and assigns application/library CMake DSL
version; the template applies expo-root-project. This is not an AGP builtin. Inspect final module
DSL after all callbacks, then actual native configure executable/version/path. Inventory every
application/library with native work, including app/Expo and later Skia; record modules with no
native work explicitly. RN source-built ReactAndroid's separate CMAKE_VERSION/default 3.30.5
consumer is classified rather than assumed executed under the accepted prebuilt baseline. Scrub
CMAKE_VERSION, reject unowned ndkPath, and require final CMake 3.30.5/NDK 27.1.12297006/Prefab/owned
realpaths. A later module override must fail even if the early Expo callback once set the right
version.

## Installed-package outputs and Maven inputs

Topology05 owns npm lock/source-hook/version/resolution boundaries, not a complete installed-member
post-build inventory or Maven. Its general package collector tolerates extra Gradle outputs; that is
not permission for unfenced writes. Forge retains its separate exact source/consumer hashes.
Published Expo package-root build/*.js is input source, so no `**/build/**` ignore or
node_modules-wide generated exception is allowed.

The Android caller obtains a fresh disposable native build copy under runtime/builds/<receipt-id>
before Release. android-candidate-build-copy reproduces the maintained root/candidate input layout
and qualified frozen installation using existing ownership primitives where verified; copies have
independent destination inodes and only internal validated links. It does not mutate or install
inside the borrowed active checkout, and it does not introduce an automatic install path. Parent
releases the actual frozen installation/reproduction stage separately. Reject preexisting generated
residue and unregistered source inputs; record copied source/member hashes, modes, logical/allocated
bytes and copy time. Where registry-member equality has not been established, label that as actual
installed-input identity rather than claiming full registry-byte proof. Authenticate every reviewed
native configuration/plugin input against its inspected artifact before native use.

The same Release probe enumerates actual settings roots, included builds, projectDir/buildDirectory
and native module .cxx owners. Compare those identities/paths to the independently prepared map from
authenticated 07a settings, 05 autolinking source records and released included-project settings;
the probe cannot grant an output exception merely because a project reports it. Unknown/changed
project/build paths fail before tasks. RN's included root has four projects; Expo autolinking and
core-plugin roots are actual installed-package projects, not ordinary candidate source directories.
Preserve released Gradle layouts in the copy. Generated ownership is exactly each declared build
root's .gradle and source-owned .kotlin, each actual project layout.buildDirectory and actual native
projectDir/.cxx, all canonical inside the copy. Any published original bytes within an overlapping
directory remain protected; preflight a published file/generated-output collision and fail rather
than widening an ignore. Record output manifests after success/failure, compare protected inputs and
the borrowed checkout/install fence, and reject unowned paths/extra source mutations. Additional
output roots require their concrete released writer before becoming allowed. This is a closed output
inventory, not a general syscall-reachability claim. Tests drive the real copy/reader/spawn
consumer: exact Gradle and Kotlin generated paths succeed; original-byte mutation, injected
source/.env, stale output, escaping link, modified project/build/.cxx/.kotlin selection or
borrowed-package destination fails.

android-release-inputs owns Maven identity for this real caller. Actual RN ReactPlugin reads
ReactAndroid/gradle.properties and sdks/hermes-engine/version.properties; those select react-android
0.86.3 and Hermes V1 250829098.0.17 (classic 0.17.0 is a distinct branch). DependencyUtils applies
substitutions/repository policy. RN catalog declares AGP 8.12.0 and Kotlin 2.1.20, while Expo
core-plugin declares an additional compileOnly AGP 8.5.0 dependency. Declarations are not selected
identities; record every actual selected configuration rather than labelling all AGP artifacts
8.12.0.

Use Gradle 9.3.1's existing gradle/verification-metadata.xml mechanism instead of a custom Maven
fetcher. The fixed Android task set is :app:assembleRelease for both provisional generation and
accepted Release. Separately released provisional stages each use a fresh owned copy on BOTH Mac
arm64 and Linux x64, with that same Release task set, signing route, runtime/context properties and
hash-bound init probe, plus --write-verification-metadata sha256. Each host's outputs include an
unaccepted optimized APK; generation can execute plugin/configuration/compile work, and both stages
remain explicitly provisional. Linux is compile-only and this does not authorize mounting or a
platform-floor pass. Retained published AGP 8.12.0 Aapt2FromMaven.kt:119–149 resolves a detached
com.android.tools.build:aapt2 configuration with osx or linux classifier. Therefore one host's
generation cannot supply the other host's complete checksum input. Retain each host's generated
metadata, original-artifact receipts, host identity and task/probe vector. Review one union metadata
file bound to both provisional receipts: same coordinate/filename must have the same SHA256;
conflicting bytes return to review rather than adding also-trust or another checksum. The fixed
published AGP source archive is read-only source evidence, not compiled-plugin or AAPT2 identity
proof; actual selected version/classifier/original/derived bytes remain real Release receipts.
Gradle 9.3.1 documents automatic resolution of resolvable root/subproject/plugin/included-build
configurations plus additional dependencies found by actual executed tasks; help misses detached
task configurations. The real provisional and strict spawn fixtures must compare their task/probe
vectors and fail an omitted/replaced task or probe. Audit/review actual POM/module/JAR/AAR
checksums, coordinates and repository/source selection from BOTH hosts before accepting the union
metadata. Then use a new fresh copy on the target host, copy that reviewed hash-bound union to
candidate android/gradle/verification-metadata.xml through android-release-inputs and run the same
Release with --dependency-verification strict. New/task-discovered artifacts missing from reviewed
metadata fail; additions return through that same reviewed generation stage. Plugins' private HTTP
clients and local/generated artifacts are outside Gradle's dependency-verification mechanism and
retain their separate authenticated-input owners; this stage never silently certifies them.

The metadata owner accepts a closed SHA256-only subset of the retained Gradle schema 1.3: exact
namespace/root, configuration verify-metadata=true and verify-signatures=false, unique literal
component group/name/version plus artifact filename and exactly one 64-hex SHA256 per original
artifact. Origin/reason labels are nonauthoritative. Reject trusted-artifacts/trust, also-trust,
verify-metadata=false, alternate algorithms/signature allowances, duplicate or unknown rows/fields,
DOCTYPE/entity/external-resource declarations and wrong namespace/schema location. The owned Android
init probe can read this bounded XML using the JDK's secure namespace-aware SAX facilities with
external entities/DTD disabled; no new Node XML dependency or downloader is needed. The real caller
first binds the review receipt and complete copied metadata hash, then the same probe emits its
validated coordinate/filename/checksum map for android-release-inputs to consume and compare.
Parsing/schema validation is a policy check; copied-byte hash remains a separate prior-review fence.
Gradle's own DependencyVerificationsXmlReader demonstrates secure DOCTYPE denial but accepts trust
constructs, so its successful read alone is not our stricter policy.

DefaultResolutionStrategy.disableDependencyVerification sets verifyDependencies=false;
ExternalModuleComponentResolverFactory.maybeApplyDependencyVerification then bypasses the wrapper
and warns exactly “Dependency verification has been disabled.” Reject that retained source-bound
warning in the complete actual Release stdout/stderr. The fixed caller permits no
quiet/log-suppression or caller-supplied Gradle arguments. Gradle 9.3.1
StartParameterBuildOptions.DependencyVerificationModeOption owns the alternative
org.gradle.dependency.verification property, and StartParameter exposes
getDependencyVerificationMode and copies it into new-build parameters. Reject that exact selector in
authenticated participating project/local/owned Gradle-home properties and
systemProp/extra/start-parameter inputs; generated Java option ownership already denies inherited
caller options. This does not reject the separate console-reporting property by prefix. In each
participating build, record and require effective
gradle.startParameter.dependencyVerificationMode=STRICT before configuration/resolution work and
again at its existing task/compile boundaries. Root CLI text alone cannot certify included builds;
missing/lenient/off or a later mutation fails the actual receipt even if the root still says STRICT.
Cross-check direction is every recorded original external Maven artifact
(group/name/version/filename, including POM/module/JAR/AAR) IN the reviewed union map with equal
recomputed SHA256; missing means a recorded original lacks its reviewed row, not that every reviewed
row must be consumed on both hosts. Extra reviewed host-specific rows unused on this host are
explicitly classified unused with their provenance, never falsely counted as resolved/missing.
Conflicting or unknown recorded originals fail even if Gradle returned zero.
Transformed/Prefab/native outputs are separately named generated derivations bound to authenticated
originals and final linked hashes, not pretended XML checksum entries. The controls use the real
metadata/probe/input consumer: valid reviewed metadata plus original artifact passes;
trusted-artifacts, also-trust, false metadata verification, duplicate/missing/changed checksum, the
actual warning, changed copied input, selector injection or non-STRICT participating build fail for
their specific policy errors. Union controls include valid Mac originals with unused reviewed Linux
classifier rows and the reciprocal Linux case, then a missing own-host row or changed bytes; unused
reviewed rows cannot excuse either error. Kotlin controls distinguish authenticated version
identities from language/API targets and fail unknown/changed plugin or classloader ownership. No
such control is claimed executed before the native stage.

The same accepted Release invocation emits build/project/configuration, selected component/version,
variant, artifact filename, owned cache realpath, length/SHA256 and repository metadata with
credentials redacted. Include original POM/module and JAR/AAR bytes, transformed/Prefab inputs,
actual react/Hermes native libraries and final linked APK .so/ABI hashes; distinguish locally
compiled included-plugin outputs from Maven inputs. An owned cache path alone is not identity.
Changing/SNAPSHOT/local/nightly/mirror/substitution routes are forbidden unless specifically
reviewed; Gradle verification does not authenticate changing or local-produced artifacts.
Native/input receipts remain 07b-owned; 05 is not expanded into a generic native dependency system.
Fixture controls mutate a real cached/checksummed artifact, omit a selected row, change React/Hermes
selection and introduce an override; each must fail the actual receipt/strict boundary. First
resolution, final receipt and strict Release are all pending execution, and none is inferred from
planning/source tests.

## Separate Apple source boundary

Later actual callers are `provision-apple-candidate.mjs`, `resolve-apple-candidate-pods.mjs` and
`build-apple-candidate.mjs`, with purpose-named Apple context and native-input support. They do not
ship speculative interfaces in the first Android source PR. The first prepares reviewed owned
Ruby/gems; the second owns first audited resolution versus frozen locks and prebuilt inputs; the
third invokes the exact unsigned Simulator Release route. Mac Android discovery cannot block this
separate Apple compile preparation either.

Use owned Ruby 3.4.11, Bundler 4.0.22, CocoaPods 1.17.0 and Xcodeproj 1.28.1. Ruby-build v20260924
SHA256 is `cbdd65281cbf2b81d963545533ea8ea6110e089bc5a92c281f0e076fde2dee0d`; Ruby 3.4.11 tar.gz is
`5c22be44524312b3d433d68739bcc530633b1da5ef8ba0afa0a37680da17d3de`; libyaml 0.2.5 tar.gz is
`c642ae9b75fee120b2d96c712538bd2cf283228d2337df2cf2988e3c02678ef4`. Audit exact ruby-build
definition/downloader and all gem native-extension/download sources before running them. Explicitly
use reviewed owned libyaml and qualified host OpenSSL 3.6.3 dependency; no implicit
Homebrew/rbenv/system Ruby install. Record actual compiler/prefix versions. Gemfile/locks are real
resolution outputs, never fabricated. Initial resolution produces an audited/reviewed lock;
subsequent resolution uses frozen gems and pod install --deployment.

Pod resolution/build callers own GEM_HOME/GEM_PATH/Bundler/pod/cache and temp selectors with
unchanged HOME. Explicitly set RCT_USE_RN_DEP=1, RCT_USE_PREBUILT_RNCORE=1, RCT_HERMES_V1_ENABLED=1,
EXPO_USE_PRECOMPILED_MODULES=1 and RCT_SKIP_CACHES=1. Own EXPO_USE_COMMUNITY_AUTOLINKING,
USE_FRAMEWORKS and USE_CCACHE according to their actual released consumer semantics; unset values
whose presence itself changes mode rather than writing a truthy string "false". Reject inherited
RCT_DEPS_VERSION, RCT_USE_LOCAL_RN_DEP, RCT_TESTONLY_RNCORE_VERSION,
RCT_TESTONLY_RNCORE_TARBALL_PATH, HERMES_ENGINE_TARBALL_PATH, HERMES_COMMIT,
REACT_NATIVE_OVERRIDE_HERMES_DIR, RCT_BUILD_HERMES_FROM_SOURCE and ENTERPRISE_REPOSITORY; no
source/nightly/mirror fallback. RCT_SKIP_CACHES=1 avoids borrowed RN cache mutation; it does not
authenticate downloaded frameworks. Inspect sources and hashes before native use, capture both
Debug/Release downloads, and record actual post-swap Release selected inputs/linker/embedded
binaries. Keep Gem/pod source audit and download identity independent of the JS lifecycle inventory.

The host 27 compiler/mount receipt records Xcode 27.0/27A266a and its actual SDK; CI selects/asserts
26.4.1/17E202 at /Applications/Xcode_26.4.1.app/Contents/Developer, with actual ImageVersion/SDK. No
moving default, global xcode-select or cross-labelling receipts. Both real Release callers reject
local Xcode/bundle overrides, use owned DerivedData and CODE_SIGNING_ALLOWED=NO for Simulator.
Neither newer simulator proves 16.4 runtime. 07a’s accepted canonical replay must actually pass for
the entire maintained bundle phase before this boundary is accepted.

## Mount-only gate retained outside base routes

Mac mounting will require separately reviewed platform-tools 37.0.1, emulator 37.2.12 arm64 and
default API 24 arm64 image revision9; their pins remain in the SDK source record but are not base
provisioner selections. Before publishing or invoking mount binaries, inspect exact selected
payloads and prove supported flags and actual discovery ownership. Immutable public ADB/QEMU
comparison source is not demonstrated build provenance for those exact released bytes.

HOME stays unchanged. Qualify existing .android directory/RSA adbkey/optional pub, nonempty console
token and discovery root as canonical mode/owner/type-qualified read-only inputs before a real Mac
mount caller. Missing/replaced/invalid inputs fail; no repair, generation, chmod or global-write
exception. The ADB server still loads the borrowed global key; the separately owned vendor key is
additional. Preseed the reviewed owned emulator key pair and compare its normalized derived public
payload with the guest's selected/injected public payload.

The actual selected 37.2.12 Mac discovery route must work without HOME reassignment or writing
global discovery. If it cannot, mount is unresolved; review a compatible owned binary/host route,
preserve API 24 and do not substitute a newer installed AVD. No mount helper API or fake successful
receipt is shipped in base 07b.

The later actual mount caller must reserve unused even console/paired ADB ports beyond 5555–5585 and
a distinct loopback server port, assert selected binary scan/ notification controls, start recorded
owned foreground server/emulator handles, use explicit endpoint/serial for every request, observe
foreign daemon attachment sets before/after and stop only recorded owned handles. Pure fixture plans
include missing/malformed key/token, unsafe mode/link, key mismatch, default/occupied port, wrong
endpoint, unsupported discovery override, host attachment and host-state mutation. Implement these
with that real later caller after the binary gate, instead of adding uncalled mount interfaces to
the base source PR.

## Staged acceptance and meaningful controls

| Stage                    | Required evidence and rejection controls                                                                                                                                                                                                                                                         |
| ------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Source review            | Codex/Claude accept actual callers, fixed artifact list, policy and native source owners; pure fixtures prove canonical roots, all selectors and actual composed child argv/environment; no native pass                                                                                          |
| Archive review           | Exact bytes/IDs, full member/layout/link/source-property receipts and generated registration reviewed before binary publication/use; wrong URL/hash/ID/layout/member/type/alias fails                                                                                                            |
| Base provision           | Owned Node/Java/source/executable recognition, all expected packages present, no sdk/licenses acceptance state, unchanged global fence, actual sdkmanager installed set; missing/extra/replaced package fails before Gradle                                                                      |
| Native configure/compile | Same-Release root/included-build properties, Node/Java/Kotlin/temp identity, strict Maven input and owned copy/output receipts, finalized CMake/NDK/Prefab and actual configure/build receipts; wrong one module, unowned CMake, daemon criteria, deprecated selector or implicit download fails |
| License controls         | Actual all-present compile without acceptance; isolated missing-package preflight rejection and a separately reviewed isolated preflight-bypass build control must fail without installing; source mocks alone do not satisfy this                                                               |
| Apple                    | Audited/frozen real gem/pod inputs, exact selected Xcode receipts, unsigned Release bundle/native/linker evidence, unchanged host inputs; version/source/local override and missing binary identity fail                                                                                         |
| Mac mount                | Separate exact-binary/discovery/auth/port/guest-key gate, then API 24 Ganesh visible fixture and iOS visible fixture; no Linux mount cell or 16.4 runtime inference                                                                                                                              |

Finite environment fixtures include the real GitHub SDK/NDK/JAVA_HOME_* variable set and harmless
agent JAVA_TOOL_OPTIONS, both yielding valid clean children; unsafe Gradle/project variables and
arbitrary extra arguments fail before spawn. Tests must inspect the exact spawn request and verify
no child handle is created on rejection, rather than validating unused explanatory data. Each guard
has its own failing mutation; applicable full tiers run exclusively when root schedules them. Actual
selected tool versions/exit codes and unchanged-host results are separate from these pure controls.

Base Android build can compile the existing native View/Text probe after reviewed inputs; its
receipt cannot claim Ganesh. Static Skia install/copy and both mounted fixtures remain 07c/07d
inputs. Matched macOS/Linux full-install cost and copier measurements require an explicit recorded
Codex and Claude acceptance decision, with logical/allocated/store/COW/cold-warm attribution and
exact locks. Node/SDK/JDK/build-copy/Maven/gem/pod costs have separate receipts; no invented numeric
threshold, dropping required platform packages or automatic copying. Fresh production Skia-free
proof remains an independent gate.

Root should give this revised source plan, the seven review dispositions and the six SDK
dispositions to Claude before implementation. Archive publication/native execution requires its
later explicit reviewed stage; neither this private plan nor successful structural tests unlocks the
unresolved Mac mount or supplies migration/performance completion.

## Exact SDK archive pins

These are fixed base inputs for archive review, not downloaded/installed receipts.

| Package / revision                  | Host      | Exact URL                                                                                                                         |     Bytes | Google SHA1                                |
| ----------------------------------- | --------- | --------------------------------------------------------------------------------------------------------------------------------- | --------: | ------------------------------------------ |
| `cmdline-tools;20.0` / 20.0         | Mac arm64 | [commandlinetools-mac-14742923_latest.zip](https://dl.google.com/android/repository/commandlinetools-mac-14742923_latest.zip)     | 150703968 | `cc27cca4b84bfdbc7df17e3d0a01d0c640d8ee71` |
| `cmdline-tools;20.0` / 20.0         | Linux x64 | [commandlinetools-linux-14742923_latest.zip](https://dl.google.com/android/repository/commandlinetools-linux-14742923_latest.zip) | 172789259 | `48833c34b761c10cb20bcd16582129395d121b27` |
| `platforms;android-36` / 2          | both      | [platform-36_r02.zip](https://dl.google.com/android/repository/platform-36_r02.zip)                                               |  65878410 | `2c1a80dd4d9f7d0e6dd336ec603d9b5c55a6f576` |
| `build-tools;36.0.0` / 36.0.0       | Mac arm64 | [build-tools_r36_macosx.zip](https://dl.google.com/android/repository/build-tools_r36_macosx.zip)                                 |  79121749 | `199ae0047ee61e842f8ee0c6d3918e44fb9a1f83` |
| `build-tools;36.0.0` / 36.0.0       | Linux x64 | [build-tools_r36_linux.zip](https://dl.google.com/android/repository/build-tools_r36_linux.zip)                                   |  63737259 | `b0b6376977657e8ad9b969bacf4093601da2c6fb` |
| `ndk;27.1.12297006` / 27.1.12297006 | Mac arm64 | [android-ndk-r27b-darwin.zip](https://dl.google.com/android/repository/android-ndk-r27b-darwin.zip)                               | 836151734 | `c70c9791b0d258858678f6df31c4319140e2926e` |
| `ndk;27.1.12297006` / 27.1.12297006 | Linux x64 | [android-ndk-r27b-linux.zip](https://dl.google.com/android/repository/android-ndk-r27b-linux.zip)                                 | 663976775 | `6fc476b2e57d7c01ac0c95817746b927035b9749` |
| `cmake;3.30.5` / 3.30.5             | Mac arm64 | [cmake-3.30.5-darwin.zip](https://dl.google.com/android/repository/cmake-3.30.5-darwin.zip)                                       |  41485176 | `3a7d78b52bdb455d9f041b1e521fc3e0dcbaef29` |
| `cmake;3.30.5` / 3.30.5             | Linux x64 | [cmake-3.30.5-linux.zip](https://dl.google.com/android/repository/cmake-3.30.5-linux.zip)                                         |  29566687 | `c999a37fa18cb3e24dc003386cffe1d86add91b5` |

Mount-only Mac inputs below remain outside base selection and require their separate exact-binary
gate.

| Package / revision                               | Exact URL                                                                                                             |     Bytes | Google SHA1                                |
| ------------------------------------------------ | --------------------------------------------------------------------------------------------------------------------- | --------: | ------------------------------------------ |
| `platform-tools` / 37.0.1                        | [platform-tools_r37.0.1-darwin.zip](https://dl.google.com/android/repository/platform-tools_r37.0.1-darwin.zip)       |  16110554 | `6ae73f4de6452dc57e62ec02b68eed92a4c21661` |
| `emulator` / 37.2.12                             | [emulator-darwin_aarch64-16428233.zip](https://dl.google.com/android/repository/emulator-darwin_aarch64-16428233.zip) | 416112708 | `3af4fe44ce82b3d88ae5678a53735f27ad729c15` |
| `system-images;android-24;default;arm64-v8a` / 9 | [arm64-v8a-24_r09.zip](https://dl.google.com/android/repository/sys-img/android/arm64-v8a-24_r09.zip)                 | 305854153 | `e88ebdf4533efa0370603ee4ab0e7834e0cc364f` |

The proposed exact root-dev ZIP parser pin is yauzl 3.4.0:
[https://registry.npmjs.org/yauzl/-/yauzl-3.4.0.tgz](https://registry.npmjs.org/yauzl/-/yauzl-3.4.0.tgz)
with
`sha512-jIH9yLR9wqr0wOS0TpBvo/g/2UgZH5qePVbjgRliiF0BYvOZyaBknKsF+x9Iht0O6sqgnB93rCICdOZFecJuDw==`.
Its complete source SRI was verified; the future frozen lock and actual changed closure audit remain
required before installation.
