# Native07b: seven review dispositions

Planning correction for Claude session c880cc0b-6a58-4600-b31d-3668cc3d5a28. Read the full findings
and accepted SDK dispositions. Revised plan: /private/tmp/splotch-native07b-structural-plan.md;
previous plan retained as /private/tmp/splotch-native07b-structural-plan-pre-review.md. No
repository source edits, tests, package imports, installation, binary provisioning or native
execution occurred.

All seven findings are valid in their bounded form. The first two are build-environment source gaps,
not reasons to defer independent archive/context source preparation. The revised plan defines actual
callers and controls; no unexecuted control or primary metadata receipt is labelled an installed
pass.

## 1. Node and Expo children: accept; own the real provider and selectors

Released owners confirm the gap. The maintained template invokes node for entry/package/Hermes
resolution and settings autolinking; RN 0.86.3 ReactExtension.kt defaults nodeExecutableAndArgs to
node, and BundleHermesCTask builds the actual export:embed command from it. @expo/cli 57.0.27
export/embed/exportEmbedAsync.js sets production mode and calls loadEnvFiles before bundling.
@expo/env 2.4.3 index.js gates loading on EXPO_NO_DOTENV and interprets inherited internal markers.
The preset's inline-env-vars.js consumes every EXPO_PUBLIC_* key. RN TaskConfiguration.kt reads
ENTRY_FILE; PathUtils.kt reads REACT_NATIVE_OVERRIDE_HERMES_DIR. BABEL_ENV and APP_MANIFEST have
concrete released preset/transformer consumers.

An existing qualified absolute Node 22/24 executable linked alone into owned runtime/bin can work
without adding its host directory to PATH. But the two read-only Mac NVM locations are merely
available: 05 records runtime version, not archive/installation ownership, and Linux needs a
separate provider qualification. Choose one newly owned official Node 24.16.0 distribution per host
instead. It reuses integrity/tar primitives with a bounded distribution mapping, adds no installer,
and publishes only regular bin/node plus LICENSE. The actual 05 npm hook reader requires a root
package.json, so it is not reusable unchanged for Node. All distribution links and npm/corepack
files are inventoried but never published, executed or exposed on PATH.
Archive/member/link/executable audit and actual runtime receipt remain gates; checksum text alone
does not qualify a provider.

The revised finite child policy rejects inherited nonempty NODE_OPTIONS/NODE_PATH, then generates
only NODE_OPTIONS=--no-global-search-paths. The exact 24.16.0 CLI documentation supports that flag
and excludes HOME/.node_modules fallback. It controls recognized Node caches/coverage/loader/TLS
selectors, explicitly sets NODE_ENV/BABEL_ENV production, rejects
public-content/entry/Hermes/manifest redirection, disables dotenv and rejects candidate ancestry
.env* inputs. It scrubs known Expo selectors to defaults, rejects unknown inherited names in the
Expo selector namespaces, and owns EXPO_PROJECT_ROOT plus __UNSAFE_EXPO_HOME_DIRECTORY. The latter
is explicitly read by released UserSettings.js and redirects Expo state/cache without changing HOME.
Telemetry/detach/API caching are disabled through their real consumers. The source receipt includes
the 56 CLI getters and hashes of the additional preset/config/env/RN owners; it does not claim
general arbitrary-process immunity.

PATH is owned Node/JDK/CMake bins plus qualified individual system-utility links needed by the
actual wrapper/SDK launcher, never a whole Homebrew/local host-tools directory. Missing components
fail before spawn. Controls inspect the actual child request, exercise wrong provider/link/PATH,
preloader/module/public/config/entry/credential/dotenv injection and wrong mode/cache values, and
assert no child on rejection. Actual Node calls and resolution contexts are checked during the real
Release route.

## 2. Kotlin daemon: accept; require the effective task strategy

Installed RN and Expo autolinking plugin sources both declare Kotlin 2.1.20. Its exact tagged
PropertiesProvider.kt reads kotlin.compiler.execution.strategy; CompileUsingKotlinDaemon.kt defines
DAEMON as default and IN_PROCESS as the in-process value; GradleKotlinCompilerWork.kt enters daemon
connection only for DAEMON and directly compiles in process when IN_PROCESS is selected.
DaemonParams.kt delegates its run directory to FileSystemUtils.kt: Mac uses the user's Application
Support path; Unix uses XDG_DATA_HOME or .local/share, with a home-based fallback if the base is
unavailable. Thus a hardcoded default-only directory fence would also be incomplete.

Use kotlin.compiler.execution.strategy=in-process in owned Gradle-home properties and reject
contradictory candidate/included-project/task settings. The same-Release init probe requires every
actual Kotlin compile task's effective compilerExecutionStrategy to be IN_PROCESS, in addition to
the project provider, so a task override cannot evade it. It records Java 17/owned temp identity for
the participating build and rechecks before compile work. No Kotlin daemon connection, surviving
owned/foreign daemon attachment or host run-file change may be claimed absent until actual execution
receipts exist. This release's in-process route is nonincremental; measure its build cost
explicitly.

## 3. Probe invocation: accept; one actual Release invocation

Pass the owned hash-bound android-release-probe.init.gradle as a fixed --init-script argument to
Release. There is no earlier diagnostic invocation. Gradle 9.3.1
BuildDefinition.startParameterForIncludedBuildFrom explicitly inherits the root init-script list for
included builds; its exact source receipt supports this route. Attach callbacks in every
participating build; whenReady reads finalized module/task/provider state before that build's tasks.
Included-plugin compilation may happen before the root graph, so its own callback/receipt is
mandatory. Recheck relevant effective Kotlin/native task values before work, and require the
expected participating build/module set in the final receipt. A root-only probe or missing row
fails. Emit a closed nonsecret property allowlist; never enumerate signing properties or
credentials. Source fixtures must demonstrate the actual Release argv includes this script and the
real receipt reader rejects missing/changed graph/module records.

## 4. SDK denial property owner: accept; preserve 07a bytes

Use owned GRADLE_USER_HOME/gradle.properties for SDK denial, Java selectors and Kotlin strategy;
retain the fixed -Pandroid.builder.sdkDownload=false argument. Do not modify 07a's maintained
android/gradle.properties. Generated local.properties is the sole Android machine-path input owner;
verification metadata has its separate exact generated-input declaration and checksum policy
described under C6 below; it is written inside the owned build copy, with canonical
sdk.dir/cmake.dir and exact keys/mode checked before spawn. Contradictory closure properties remain
failures. The revised plan removes the ambiguous candidate-properties wording.

## 5. yauzl closure: accept; audit the real peer/layout delta

The actual lock already contains pend 1.2.0 and yauzl 2.10.0. native-run 2.0.3 depends on yauzl
^2.10.0; @puppeteer/browsers 3.2.1 declares optional peer ^2.10.0 || ^3.4.0 and dynamically imports
yauzl in lib/fileUtil.js. The current hoisted root resolves 2.10.0; the exact root 3.4.0 addition
can re-resolve that peer and lighthouse 13.5.0 / puppeteer-core 25.9.0 snapshot keys while
preserving native-run's nested 2.10.0 copy. No new-pend claim remains. The actual lock-only diff,
installation realpaths, production closure and 05 frozen-install/lifecycle/audit controls must
validate the eventual delta; its precise lock keys/layout are not inferred before resolution.

## 6. JVM temporary storage: accept; compose real JVM selectors

TMPDIR does not establish java.io.tmpdir. The owned Gradle-home org.gradle.jvmargs composes the
reviewed template heap/metaspace values with owned tmpdir. SDKMANAGER_OPTS and keytool's explicit -J
selector also carry it. The inspected cmdline 20 launcher separately invokes java -version without
SDKMANAGER_OPTS, so the revised policy additionally generates a trusted JAVA_TOOL_OPTIONS tmpdir
selector after scrubbing inherited text. This reaches that internal JVM too; no inherited arbitrary
options are parsed or forwarded. Assert effective JVM property receipts for client/daemon/SDK and
compile context, rather than an unused environment object. Actual selected launcher source/layout
and JVM output remain unexecuted gates.

## 7. Installed outputs and Maven: accept the ownership questions

Topology05's general checker validates lock/hooks/version/resolution, not every installed member.
Its autolink scanner asserts source containment, not generated-output identity. Forge has its own
specific byte fences. Thus outputs are neither automatically rejected nor owned by 05. A blanket
build ignore would be wrong: Expo package-root build contains published JS inputs.

Use the real Android caller's fresh disposable owned native build copy with independent files and
contained links, preserving released package/Gradle layouts. Fence borrowed installation/checkouts
before/after. The same-Release probe enumerates actual included/project roots and grants only their
exact buildRoot/.gradle, layout.buildDirectory and native projectDir/.cxx outputs inside the copy,
after comparison with the independently prepared authenticated settings/autolink/project owner map;
unknown or changed paths do not earn an exception through self-reporting. In that copy, all
published source bytes remain protected even in overlapping directories. Copied-byte identity is
distinguished from full registry-member proof, which must actually be established where claimed.
Copy/install measurements and unknown generated paths are separately reviewed, not ignored.

RN ReactPlugin/DependencyUtils and authenticated ReactAndroid/Hermes version properties own expected
React/Hermes selection; catalog AGP 8.12.0/Kotlin 2.1.20 declarations do not erase Expo
core-plugin's separate AGP 8.5.0 compileOnly input. 07b android-release-inputs records every actual
selected Maven component/variant/original and transformed artifact, lengths/SHA256, owned path and
redacted repository identity from the same Release invocation, plus final Prefab/native-library/link
identities.

Use Gradle 9.3.1 verification-metadata.xml rather than a new Maven downloader. A separately released
provisional resolution stage produces metadata for review; --write-verification-metadata resolves
all resolvable configurations, including plugin/included builds, and can execute configuration code.
It is not trusted Release proof. Review the exact artifact/source/checksum records, then fixed
Release uses the reviewed copied native input and --dependency-verification strict. Native
verification covers included builds through the current root input; changing/local-produced
artifacts are outside that mechanism and must be excluded/classified rather than certified.
Cached-byte/row/coordinate/override controls drive the actual strict/receipt consumers. First
resolution and compile are pending.

## Primary metadata supplement and limits

Claude's independent metadata request failed DNS and delivered that failure through the broker. Root
later observed a successful host retry; its actual output is the same session outputs/1.out. That
later observation matches the retained XML SHA256, all nine base SDK archive rows, both Temurin
SHA256 values and yauzl SRI/dependency declaration. It supplements the next review; it is not an
independent check retroactively performed by Claude. Archive bytes, layouts, executable
qualification and installed recognition are still pending.

For newly proposed Node, this agent's fixed official checksum-text read succeeded on host retry,
exit 0, after sandbox DNS failure; the retained text and its hash are in the revised plan. No Node
archive was downloaded. Read-only released source receipts are under
/private/tmp/splotch-native07b-review-sources; failed guessed source paths were 404 and are not
evidence. Actual tagged Kotlin owners and Gradle 9.3.1 verification documentation succeeded.
Independent Codex source inspection supplied the installed-output/Maven owner analysis without
executing package code.

The Mac discovery mount, Apple gem/pod/prebuilt compiler route, unchanged-host and receipt-only
license checks, effective same-Release tool/module/input proof and measured install/copy acceptance
retain their separate gates. This plan does not authorize binaries, installation, native
resolution/build/launch, a floor change or a claimed migration pass. Next step is root/Claude review
of this bounded amendment before repository implementation.

## Targeted review corrections C1–C6: source-confirmed dispositions

Full targeted review: session 1c716fad-f1d8-4ae3-85dc-67d608ed31f8 findings.json. Empty findings is
not approval; all six summary corrections are accepted with the qualifications below. The exact
reviewed current plan and dispositions were retained byte-for-byte before amendment as the
`*-pre-corrections-1c716fad-f1d8-4ae3-85dc-67d608ed31f8.md` files; preservation hashes are in
/private/tmp/splotch-native07b-corrections-preservation.json. Fixed public source and actual 05/07a
read-only source receipts are under /private/tmp/splotch-native07b-review-sources; the consolidated
corrections-confirmed-source-receipt.json lists each URL/path, byte length and SHA256.

### C1: accept .kotlin outputs; qualify the user-home accessor

The retained actual GradleKotlinCompilerRunner.kt:175–180 constructs ProjectFilesForCompilation
before compiler work. Its constructor calls getOrCreateSessionFlagFile; the runner's method creates
the session directory/file. GradleCompileTaskProvider.kt:49–50 supplies project.kotlinSessionsDir;
persistentCaches.kt:21–27 chooses the participating root's .kotlin/sessions by default. Thus this is
source-confirmed rather than the review's runner inference, including IN_PROCESS. The copied output
map adds exactly each authenticated build root's .kotlin; 07a's source reader also needs exactly
android/.kotlin declared as a generated directory with that real writer, since it currently collects
those files. Package .kotlin directories remain solely in the copy owner's exact map. The probe
checks effective PropertiesProvider getters so extra/local/project properties cannot change it. The
owned Gradle-home also sets kotlin.user.home; the accessor userKotlinPersistentDir reads it,
defaulting to System.getProperty("user.home")/.kotlin, but is annotated unused in KGP 2.1.20.
Therefore HOME/.kotlin is fenced defensively, without claiming this Release necessarily writes that
global cache. Controls must exercise actual path ownership, not only property text.

### C2: accept exact HotSpot perf-data owner and effective suppression

The exact upstream OpenJDK17 jdk-17.0.20.1+1 annotated tag resolves to commit
c35a8d5a87559ad2734f1023bb321176c13c7ba0. Retained os_linux.cpp:1439–1440 returns /tmp independently
of java.io.tmpdir; os_bsd.cpp:924–940 uses `confstr(_CS_DARWIN_USER_TEMP_DIR)` on Mac.
perfMemory_posix.cpp:136–154 forms `hsperfdata_<user>` from that native path. globals.hpp:1804
defaults UsePerfData=true and perfMemory.cpp:58–62 exits initialization when false. Add
-XX:-UsePerfData to both generated JAVA_TOOL_OPTIONS and owned org.gradle.jvmargs; retain
java.io.tmpdir ownership too. The selected binary recognition and actual same-Release
HotSpotDiagnosticMXBean receipt must prove false. Bind SDK/keytool's actual qualified
executable/options and fence actual Linux/Darwin native perf-data paths, preserving existing/foreign
files. Upstream exact source is not Temurin executable or effective-flag proof; those remain
archive/runtime gates.

### C3: accept actual public pinned launcher and precise Node mapping

Both exact commandlinetools-<mac|linux>-14742923_latest.zip source members were read using bounded
HTTP ranges, with exact total-length responses, local/central metadata and text length/CRC checks.
Only sdkmanager text was retained: Mac 5761 bytes SHA256
6decd5850a052dbba93ae735cef7aa839328bbf26a2a29bfa9dbf95e74a3f81f; Linux 5763 bytes SHA256
38cedc04eacc1c24d635caade961ff15d86cf070f44da7f9eebbb2ab988817ba. Both confirm /usr/bin/env sh,
basename/expr/ls/sed/uname/dirname/awk and awk /version/ on java -version output. Complete archive
SHA1/audit was not performed by range inspection; source provenance receipt says that explicitly.
Qualify the finite wrapper/SDK PATH union sh/uname/ls/xargs/sed/tr/dirname/awk/basename/expr.
Generated tmp paths use a restricted alphabet, no quotes or version substring, and receipt IDs use
32 lowercase hex characters; reject bad paths before SDK JVM launch. The actual 05 tar source
confirms the npm-specific reader limitation; the narrow Node distribution owner publishes exactly
two regular members bin/node and LICENSE, inventories but never publishes any archive link, and
leaves full archive/standalone executable qualification pending.

### C4: accept actual Release generation, still provisional

Gradle 9.3.1 dependency_verification.adoc:125–161 names automatic resolvable configurations,
explains why help misses detached task configurations, and warns about plugins' private HTTP
clients. Both routes now fix :app:assembleRelease and the same hash-bound init
script/context/signing/task vector. Provisional --write-verification-metadata sha256 runs real
Release work in its own fresh copy, producing unaccepted native outputs and checksum inputs for
review. Accepted Release uses a new fresh copy, reviewed metadata and --dependency-verification
strict. Compare actual spawn vectors in controls. Task choice cannot claim exhaustive private-client
or arbitrary-runtime reachability; those inputs retain their separately authenticated owners.

### C5: accept strict metadata subset, actual warning and byte cross-check

Tagged DefaultResolutionStrategy.java:389–391 disables the verifier; tagged
ExternalModuleComponentResolverFactory.java:195–204 bypasses wrapping and logs the exact warning
“Dependency verification has been disabled.” Reject it in actual full output, with no quiet/extra
arguments. Gradle 9.3.1 docs and retained schema 1.3 permit trusted-artifacts, also-trust and
disabled metadata checks; its DependencyVerificationsXmlReader accepts those constructs. Our review
input policy rejects them and uses only unique literal original-artifact coordinates/filenames and
one SHA256, verify-metadata=true, verify-signatures=false, exact namespace and no entities/unknown
fields. The same owned probe uses secure JDK SAX to emit the reviewed checksum map; the actual
caller binds the review receipt/copied hash before launch. Every original external Maven record must
match that map and recomputed bytes, even on exit 0. Transformed/Prefab/native outputs have separate
authenticated-original lineage and generated-output hashes; their different bytes are not falsely
compared to an original Maven checksum. Fixtures must assert specific rejection causes for trust
constructs, warning and missing/changed checksums. XML/Gradle consumer execution remains pending.

### C6: accept exactly two generated regular-input declarations

Actual 07a native-source-files.mjs:25–58 recursively collects every regular android/ios file and
compares it to canonical provenance. It currently rejects both new regular files. The maintained
reader/discovery source receives exactly android/local.properties (machine-path context writer) and
android/gradle/verification-metadata.xml (07b provisional/reviewed verification owner), outside the
original template receipt. Both require canonical regular-file containment and stage-appropriate
mode/contents/hash checks; extra siblings, links, wrong location or fabricated provenance fail.
Controls drive real writers plus that real reader, including positive cases for each and both. No
change was made to 07a source in this correction round.

Only private plan/disposition/source-evidence files were written. No complete Node/JDK/SDK archive
was downloaded; no repository source, package imports/tests, native tool, provisioning, build or
launch occurred. All archive, effective same-Release, strict verification, unchanged-host and
measured acceptance gates remain pending. Root owns subsequent inspection and any further rival
round.

## Third targeted review R1–R4: bounded source corrections

Full review: session 6ace5a5d-ad3e-4b26-9f8c-53dfeb0dd254 findings.json. Root and this agent fully
read its summary. C1–C6 are accepted in substance; the empty arrays do not certify pending
execution. The prior current plan/dispositions are retained byte-exact in the pre-R1-R4 files with
their preservation receipt. No fourth blanket planning review is proposed. Root's accepted bounded
Android source-preparation route can proceed after these exact amendments are read; source
preparation is separate from all executable provisioning/build/launch gates.

### R1: accept both-host provisional Release generation and reviewed union

The published fixed Google Maven com.android.tools.build:gradle:8.12.0 sources.jar was read solely
as source. Its Aapt2FromMaven.kt member is 9441 bytes SHA256
91c02d333fbfec2dcd2c1011d2935a08b489ef31c731ad952bf081a9680f5aff, and exactly matches the fixed
official Studio2025.1.2 tag's peeled commit d40089ba20c03c029b929f3492030210420b40b8 source bytes.
Lines 119–149 select osx/linux then create the detached com.android.tools.build:aapt2 dependency.
The retained source archive is 3879732 bytes SHA256
55d4e82406b9061f885ec6784c9bca72a809ce2269def5b4c4c371f3ae257eef. This is primary source retention,
not an installed AGP/AAPT2 executable, selected-version or native build proof.

The provisional same :app:assembleRelease/init/context/signing stage must run on BOTH Mac arm64 and
Linux x64 in separate fresh owned copies. Both optimized APKs remain unaccepted; Linux remains
compile-only. Review the union of both actual metadata/original-artifact receipts. Coordinate plus
filename rows must agree on SHA256; no also-trust/extra checksum disguises conflicting bytes. Every
recorded original on a given host must be IN that reviewed map with equal recomputed bytes. Reviewed
host-specific rows unused on the other host receive an explicit unused classification, not a false
missing/resolved claim. Positive fixtures use each host's actual-shaped classifier rows plus unused
other-host rows; missing own-host review, changed checksum or an unrecorded/conflicting original
fails specifically. Both-host generation, union review and strict Release remain pending execution.

### R2: accept the real KGP newTmpFile and .alive owner

The retained Kotlin v2.1.20 gradle/utils/fileUtils.kt is 5841 bytes SHA256
738938ecc8ba40f6d2b1a1686c849c1455986c4c03420c574f527f4094890408. Its newTmpFile:54–67 uses
Files.createTempFile(prefix,suffix) when directory is null and calls deleteOnExit by default. The
retained GradleKotlinCompilerRunner.kt:412–420 uses it for kotlin-compiler-in-<project>-*.alive;
ProjectFilesForCompilation constructs this client flag before strategy selection. The previously
retained FileSystemUtils.kt belongs to the Kotlin daemon common package and is not this helper.

Exact upstream OpenJDK17 TempFileHelper.java at reviewed c35a8d5a87559ad2734f1023bb321176c13c7ba0
uses StaticProperty.javaIoTmpDir for null-directory temp creation. Its 6976 bytes hash to
b6efd442a788e24fab513ad31559cb86060cc8cb9aad2ffc0bf357717f1dcd15. Thus classify these regular .alive
files in the existing invocation-owned runtime/tmp/<id> inventory, with actual observed paths/modes
and effective Java temp identity. Do not call a getter to manufacture a diagnostic write.
deleteOnExit means final absence cannot prove they were never created; before/during/after
observations and unchanged global-temp fences remain execution receipts. Effective Temurin/JVM
ownership and real controls are pending.

### R3: accept effective per-build STRICT mode and exact selector denial

Tagged Gradle9.3.1 StartParameterBuildOptions.java:398–416 binds org.gradle.dependency.verification
and --dependency-verification to the mode setter. StartParameter.java:103 defaults STRICT, :268
copies the mode for a new build, and :910–912 exposes getDependencyVerificationMode. These owners
supplement the retained fixed documentation.

Reject that exact selector from participating project/local and owned Gradle-home properties,
systemProp/extra/start-parameter inputs and caller JVM options. The finite policy does not
accidentally reject org.gradle.dependency.verification.console. The real same-invocation probe
records and requires STRICT per participating build before configuration/resolution and at existing
task/compile boundaries; init inheritance or a strict root flag alone is insufficient. Effective
included-build LENIENT/OFF, missing row, injected selector or later mode mutation fails, even when
the root is STRICT. These source assertions do not claim callbacks or Gradle execution have
occurred.

### R4: accept actual KGP version/code-source identity without a blanket pin

The sixteen retained actual installed RN/Expo build/catalog/settings/source owners are indexed in
R1-R4-installed-source-receipt.json. RN's catalog declares JVM KGP2.1.20, used by its four plugin
projects; Expo autolinking's root declares JVM2.1.20 for its four projects; Expo core-plugin also
explicitly declares JVM2.1.20. Expo shared autolinking separately requests serialization1.9.24.
These are authenticated declarations, not selected plugin/runtime proof. The application and
native-module roots still require their actual selected receipt.

Kotlin v2.1.20 KotlinPluginWrapper.kt:64–67 and :302–320 exposes
pluginVersion/getKotlinPluginVersion from project.version in its own resource. The probe binds each
participating Kotlin build/project, applied plugin, actual loaded version/class/code-source and
selected original artifact before using that version's strategy/temp getters. It separately records
compiler subplugins; language/API target 1.8 or JVM target11 is not the KGP version. Unknown/changed
version or classloader returns to review before compilation rather than assuming an approved getter
shape.

No kotlin-dsl/embedded-kotlin plugin is applied in those inspected sixteen installed source owners.
Nevertheless retained exact Gradle9.3.1 KotlinDslPlugin, KotlinDslBasePlugin and
EmbeddedKotlinPlugin show that route applies KotlinPluginWrapper and warns if it differs from
embeddedKotlinVersion; EmbeddedKotlinProvider owns its separate resource map. A newly participating
embedded route needs its actual reviewed Gradle/KGP version and compatible strategy/temp-source
owner; never require 2.1.20 merely because RN declares it. The retained kotlin-versions.properties
is a latest-test matrix, not proof of Gradle's embedded version, so no embedded-version number is
invented here. Actual plugin/artifact/classloader receipts remain pending alongside same-Release
callbacks.

R1-R4-source-receipt.json retains successful source paths, exact URLs/coordinates, lengths/hashes,
and the actual installed-source basis. Failed guessed paths remain in acquisition receipts as 404,
never accepted evidence. Public tree/tag metadata only located fixed owners. No repository edits,
package imports/tests, native execution, provisioning or launch occurred in this R1–R4 pass. Root
owns final source review and any subsequent bounded implementation authorization.
