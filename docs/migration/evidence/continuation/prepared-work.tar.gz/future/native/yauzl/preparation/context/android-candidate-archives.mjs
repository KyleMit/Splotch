import { authenticateCandidateArchive } from './candidate-archive-downloads.mjs';
import { assertArchiveMemberGraph, nodeArchiveMapping } from './android-sdk-members.mjs';
import { readAndroidZipMembers } from './android-sdk-zip.mjs';
import { readAndroidTarMembers } from './android-sdk-tar.mjs';
import { androidArchiveSourceProperties } from './android-sdk-properties.mjs';

// Fixtures supply small authenticated descriptors; the CLI obtains every descriptor from the pinned profile.
export async function inspectAndroidCandidateArchive(file, artifact) {
  const authenticated = await authenticateCandidateArchive(file, artifact);
  if (!['zip', 'tgz'].includes(artifact.format)) throw new Error('Unsupported Android archive format');
  const inventory = await (artifact.format === 'zip' ? readAndroidZipMembers(file) : readAndroidTarMembers(file));
  inventory.members.sort((left, right) => left.path < right.path ? -1 : left.path > right.path ? 1 : 0);
  if (!inventory.members.length) throw new Error('Candidate archive omitted all filesystem members');
  assertArchiveMemberGraph(inventory.members);
  const selectedNodeMembers = nodeArchiveMapping(artifact, inventory.members);
  const sourceProperties = androidArchiveSourceProperties(artifact, inventory.members);
  await authenticateCandidateArchive(file, artifact);
  return { artifact, ...authenticated, ...inventory, selectedNodeMembers, sourceProperties,
    status: 'archive-review-required', publicationAllowed: false, nativeExecution: false };
}
