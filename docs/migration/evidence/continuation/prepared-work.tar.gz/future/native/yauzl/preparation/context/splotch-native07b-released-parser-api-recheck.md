# Native07b released parser API comparison

Bounded independent read-only comparison of the current ZIP/TAR readers and the actual released
yauzl3.4.0/tar7.5.22 source expectations. No candidate/package imports, network, tests, archive
execution, install, build, native tools, Git or repository edits ran. This is not the parent's
full archive source review or an actual parser/distro acceptance result.

**No material API mismatch found in this scope.**

* ZIP's qualified owner selects exact3.4.0; openPromise forces lazy entries (retained index.js:31–38).
  Current open sets autoClose=false, strict names and entry-size validation. Omitted read-stream
  options match the actual deflate implementation (:573–575), avoiding the released explicit-true
  discrepancy. `consumeArchiveMember` awaits real stream count/digest, and next-entry publication
  occurs only afterward. Permanent error/close ownership remains through idempotent close and the
  awaited actual close (:262–290/:608–620/:711–718). These are source facts, not exercised exits.
* TAR's actual Parser constructor uses strict/onReadEntry; ignored types are rejected independently
  of strict. Raw meta events lack physical header/type, so the corrected reader neither infers GNU
  format from a terminator nor claims a physical header inventory. It rejects NUL, lossy text,
  malformed framing and unlisted PAX keys, records raw text/hash and effective finite members, and
  preserves the complete archive digest as physical-byte authentication. Source: actual parse.js
  :270–289/:343–369, read-entry.js:30–38/:65–98 and pax.js:128–175.
* Parser's PAX implementation is deliberately not treated as a strict policy validator: it may
  ignore malformed lengths/unknown keys. Current private framing/key validation and effective
  path/type/mode/size plus the existing member/link graph remain the relevant policy owners.
  The documented rejection of unreviewed metadata may reject a legitimate future distribution;
  actual archive intake is the declared dependency, rather than a currently proved compatibility.

Stored/deflated known-byte controls, actual read/error/close/abort exits and supported real distro
metadata still require scheduled execution. No source-only zero-findings result certifies them or
widens publication/provisioning/native permissions.
