import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { readLockFile } from '../lib/lock-artifacts.mjs';
import {
  AUDIO_EVIDENCE,
  projectAudioLock,
  qualifyAudioInputs,
} from '../lib/native-audio-qualification.mjs';
const root = join(import.meta.dirname, '../../..');
const baseline = readLockFile(
  join(root, AUDIO_EVIDENCE, 'controls/source-window-0541/before-pnpm-lock.yaml.txt')
);
const input = JSON.parse(readFileSync(join(root, AUDIO_EVIDENCE, 'audio-lock-inputs.json')));
const manifest = JSON.parse(
  readFileSync(join(root, 'experiments/native-architecture/package.json'))
);
const lock = readLockFile(join(root, 'pnpm-lock.yaml'));
describe('new audio qualification', () => {
  it('qualifies actual installed source, registry archives and eighteen finite paths', () => {
    const result = qualifyAudioInputs(root);
    expect(result.actualPaths).toHaveLength(18);
    expect(result.installed.map((p) => p.version)).toEqual(['57.0.5', '57.0.18']);
    expect(result.lock).toEqual(baseline);
  });
  for (const [name, mutate] of [
    [
      'extra artifact',
      (l) => {
        l.packages['unqualified@1.0.0'] = {};
      },
    ],
    [
      'changed inherited snapshot',
      (l) => {
        l.snapshots[Object.keys(baseline.snapshots)[0]].audioMutation = true;
      },
    ],
    [
      'changed audio SRI',
      (l) => {
        l.packages['expo-audio@57.0.5'].resolution.integrity = 'invalid';
      },
    ],
    [
      'changed audio peer',
      (l) => {
        l.packages['expo-audio@57.0.5'].peerDependencies.expo = '58';
      },
    ],
    [
      'undeclared direct root',
      (l) => {
        l.importers['experiments/native-architecture'].devDependencies.unqualified = {
          specifier: '1',
          version: '1',
        };
      },
    ],
    [
      'audio outside dev graph',
      (l) => {
        l.importers['experiments/native-architecture'].dependencies = {
          'expo-audio': input.roots[0].entry,
        };
      },
    ],
  ])
    it(`rejects ${name}`, () => {
      const changed = structuredClone(lock);
      mutate(changed);
      expect(() => projectAudioLock(changed, baseline, manifest, input)).toThrow();
    });
  it('rejects extra Forge paths in qualification input', () => {
    const changed = structuredClone(input);
    changed.forgePaths.push('unqualified>node-forge');
    expect(() => projectAudioLock(lock, baseline, manifest, changed)).toThrow();
  });
});
