import { createRequire, isBuiltin } from 'node:module';
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, existsSync, chmodSync } from 'node:fs';
import { dirname, join, resolve, relative } from 'node:path';
import { createHash } from 'node:crypto';
const root='/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch';
const ts=createRequire(join(root,'package.json'))('typescript');
const hash=b=>createHash('sha256').update(b).digest('hex');
assert(!process.env.NODE_OPTIONS, 'Readonly resolver expects no custom Node conditions');
const conditions=new Set(['node','import','node-addons',...(process.features.require_module?['module-sync']:[]),'default']);
const queue=['node_modules/@sveltejs/kit/src/core/env.js','node_modules/@sveltejs/kit/src/core/config/index.js'];
const seen=new Set(), inputs=[], edges=[], manifests=new Map(), nativeBoundaries=[];
const packageName=specifier=>specifier.startsWith('@')?specifier.split('/').slice(0,2).join('/'):specifier.split('/')[0];
function manifest(name){if(!manifests.has(name)){const p=join(root,'node_modules',name,'package.json'),b=readFileSync(p);manifests.set(name,{path:relative(root,p),bytes:b.length,sha256:hash(b),value:JSON.parse(b)});}return manifests.get(name).value;}
function select(value){if(typeof value==='string')return value;if(Array.isArray(value)){for(const v of value){const r=select(v);if(r)return r;}}else if(value&&typeof value==='object'){for(const [key,v] of Object.entries(value))if(conditions.has(key)){const r=select(v);if(r)return r;}}return null;}
function owner(filename){const rel=relative(root,filename).split('/');if(rel[0]!=='node_modules')throw Error('Outside owned module tree');return rel[1].startsWith('@')?rel.slice(1,3).join('/'):rel[1];}
function resolveSpecifier(filename,specifier,cjs){
 if(isBuiltin(specifier))return {builtin:true};
 if(specifier.endsWith('.node')||specifier.startsWith('@rolldown/binding-')){nativeBoundaries.push({from:relative(root,filename),specifier,scope:'Conditional native-loader candidate; not executed or guessed. Existing fixture selects one actually loaded native owner and real browser/node runtime controls qualify it.'});return {existingSelectedNativeBoundary:true};}
 if(specifier.startsWith('.')){const p=resolve(dirname(filename),specifier);for(const q of [p,p+'.js',p+'.json',join(p,'index.js')])if(existsSync(q))return {target:relative(root,q)};throw Error('Missing relative '+p);}
 const name=specifier.startsWith('#')?owner(filename):packageName(specifier),pkg=manifest(name);let path;
 if(specifier.startsWith('#'))path=select(pkg.imports?.[specifier]);
 else {const sub='.'+specifier.slice(name.length);const exports=pkg.exports;path=typeof exports==='string'||(exports&&!Object.keys(exports).some(k=>k.startsWith('.')))?select(exports):select(exports?.[sub]);if(!path&&!exports)path=sub==='.'?(pkg.module??pkg.main??'index.js'):sub.slice(2);}
 if(!path){if(cjs)return {unresolvedConditionalRequire:true,package:name};throw Error('Missing production import export '+specifier);}
 const target=relative(root,resolve(root,'node_modules',name,path));if(!existsSync(join(root,target)))throw Error('Missing package export '+target);return {target,package:name};
}
const svelte=manifest('svelte');
let peer=svelte.exports['./compiler'];
while(typeof peer!=='string'){assert(peer&&typeof peer==='object');peer=peer.import??peer.default;}
const peerEntry=relative(root,resolve(root,'node_modules/svelte',peer));
queue.push(peerEntry);
while(queue.length){const rel=queue.shift();if(seen.has(rel))continue;seen.add(rel);const filename=join(root,rel),b=readFileSync(filename);inputs.push({path:rel,bytes:b.length,sha256:hash(b)});if(rel.endsWith('.json'))continue;
 const source=ts.createSourceFile(filename,b.toString(),ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
 const requests=[];
 for(const node of source.statements)if((ts.isImportDeclaration(node)||ts.isExportDeclaration(node))&&node.moduleSpecifier&&ts.isStringLiteral(node.moduleSpecifier)&&!node.isTypeOnly&&!node.importClause?.isTypeOnly)requests.push({specifier:node.moduleSpecifier.text,cjs:false});
 function visit(node){if(ts.isCallExpression(node)&&ts.isIdentifier(node.expression)&&node.expression.text==='require'&&node.arguments.length===1&&ts.isStringLiteral(node.arguments[0]))requests.push({specifier:node.arguments[0].text,cjs:true});ts.forEachChild(node,visit);}visit(source);
 for(const request of requests){const resolved=resolveSpecifier(filename,request.specifier,request.cjs);edges.push({from:rel,...request,...resolved});if(resolved.target)queue.push(resolved.target);}
}
const out={state:'read-only-complete-static-link-closure-qualified',scope:'Actual production Node ESM link closure and literal CJS imports from Kit env generator/normalized config plus its actual manifest-selected default peer svelte/compiler source. No dependency module was evaluated; dynamic selected native loading remains separately qualified by existing actual loaded-owner fixture and controls. Conditional require candidates are recorded, not claimed executed.',actualKitPeer:{specifier:'svelte/compiler',traversal:'Installed import_peer resolves the manifest exports entry through import ?? default',target:peerEntry},conditions:[...conditions],node:{execPath:process.execPath,version:process.version,requireModule:process.features.require_module,customConditions:false},inputs,manifests:[...manifests.values()],edges,nativeBoundaries};
const path='/private/tmp/splotch-neutral-resume-670_yiah/facade-repair-01/generator-complete-closure-03.json';writeFileSync(path,JSON.stringify(out,null,2)+'\n',{flag:'wx'});chmodSync(path,0o600);console.log(JSON.stringify({path,sha256:hash(readFileSync(path)),files:inputs.length,bytes:inputs.reduce((n,r)=>n+r.bytes,0),packages:[...manifests.keys()].sort(),unresolvedConditionalRequire:edges.filter(e=>e.unresolvedConditionalRequire),nativeBoundaries:nativeBoundaries.length,actualKitPeer:out.actualKitPeer}));
