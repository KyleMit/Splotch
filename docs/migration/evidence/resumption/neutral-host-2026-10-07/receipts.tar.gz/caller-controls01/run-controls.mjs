import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { cpSync, mkdirSync, readFileSync, realpathSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { build } from '/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch/node_modules/vite/dist/node/index.js';
import { captureReactGraph, assertReactGraph } from '/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch/migration/probes/web-host/host/reactGraph.ts';
import { assertStandaloneReactCompilerConfig, REACT_DEVELOPMENT_FILES } from '/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch/migration/probes/web-host/host/reactProduction.ts';
import { WEB_HOST_ENV, WEB_HOST_JSX, WEB_HOST_REACT_EXTERNALS, WEB_HOST_REACT_SOURCE_PATHS, WEB_HOST_REACT_RENDERER_DIRECTORY, WEB_HOST_REACT_RENDERER, WEB_HOST_REACT_RENDERER_GRAPH } from '/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch/migration/probes/web-host/host/contract.ts';
import { makeRenderRequest, writeRenderRequest, readRenderedChrome, chromeDigest } from '/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch/migration/probes/web-host/host/chromeHtml.ts';
import { createOwnedArtifact } from '/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch/tools/migration/lib/web-host-ownership.mjs';
import { runCopiedChild } from '/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch/tools/migration/lib/web-host-build.mjs';
const root='/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch';
const output='/private/tmp/splotch-neutral-resume-670_yiah/react-caller-controls-01';
const rendererSource='migration/probes/web-host/host/renderChrome.ts';
const ownershipSource='tools/migration/lib/web-host-ownership.mjs';
const node='/Users/kylemit/.nvm/versions/node/v24.16.0/bin/node';
const started=performance.now();
process.env.NODE_ENV='production';
process.env.PERF_MARKS='false';
assert.equal(REACT_DEVELOPMENT_FILES.length,18);
const currentDenied=readFileSync(join(root,'migration/probes/web-host/host/reactProduction.ts'));
assert.equal(currentDenied.compare(execFileSync('git',['show','HEAD:migration/probes/web-host/host/reactProduction.ts'],{cwd:root})),0);
const controls=[];
for(const control of [
  {label:'inherited-production',nodeEnv:'production',inherited:true,expectedCode:1},
  {label:'actual-production',nodeEnv:'production',inherited:false,expectedCode:0},
  {label:'real-development',nodeEnv:'development',inherited:false,expectedCode:1},
  {label:'restored-production',nodeEnv:'production',inherited:false,expectedCode:0},
]) {
  const owned=createOwnedArtifact(output); const copyRoot=join(owned.root,'neutral');
  mkdirSync(copyRoot);
  const sourceBindings=[];
  for(const path of [...WEB_HOST_REACT_SOURCE_PATHS,ownershipSource]) {
    const target=join(copyRoot,path);mkdirSync(join(target,'..'),{recursive:true});
    const bytes=control.inherited&&path===rendererSource ? execFileSync('git',['show','HEAD:'+path],{cwd:root}) : readFileSync(join(root,path));
    writeFileSync(target,bytes);sourceBindings.push({path,bytes:bytes.length,sha256:chromeDigest(bytes)});
  }
  mkdirSync(join(copyRoot,'node_modules'));
  for(const name of ['react','react-dom'])cpSync(join(root,'node_modules',name),join(copyRoot,'node_modules',name),{recursive:true});
  const outDir=join(copyRoot,WEB_HOST_REACT_RENDERER_DIRECTORY);mkdirSync(outDir);
  let config;let graph;
  const compileStarted=performance.now();
  await build({root:copyRoot,configFile:false,mode:'production',oxc:{jsx:WEB_HOST_JSX},logLevel:'silent',plugins:[{name:'splotch-caller-regression-graph',configResolved(resolved){assertStandaloneReactCompilerConfig(resolved,copyRoot);config=resolved;},async writeBundle(_options,bundle){graph=await captureReactGraph({copyRoot,outputDirectory:outDir,stage:'ssr-renderer',overlay:null,bundle,plugin:this,context:{mode:config.mode,nodeEnv:process.env.NODE_ENV,isProduction:config.isProduction,perfMarks:process.env.PERF_MARKS,jsx:config.oxc.jsx}});}}],build:{ssr:join(copyRoot,rendererSource),outDir,emptyOutDir:false,sourcemap:false,rolldownOptions:{external:[...WEB_HOST_REACT_EXTERNALS],output:{format:'es',entryFileNames:'renderer.mjs'}}}});
  assertReactGraph(copyRoot,graph,'ssr-renderer');
  writeFileSync(join(copyRoot,WEB_HOST_REACT_RENDERER_GRAPH),JSON.stringify(graph,null,2)+'\n',{flag:'wx'});
  const compileElapsedMilliseconds=performance.now()-compileStarted;
  const request=makeRenderRequest(copyRoot,{variant:'neutral-embedded',artifact:'release',fixture:'matching'},graph.context);
  const requestSha256=writeRenderRequest(owned,request);
  const env={PATH:'/Users/kylemit/.nvm/versions/node/v24.16.0/bin:/usr/bin:/bin',NODE_ENV:control.nodeEnv,CAPACITOR:'false',PERF_MARKS:'false',PUBLIC_ENABLE_DEV_HARNESS:'false',[WEB_HOST_ENV.artifactRoot]:owned.root,[WEB_HOST_ENV.copyRoot]:copyRoot,[WEB_HOST_ENV.token]:owned.token,[WEB_HOST_ENV.artifact]:'release',[WEB_HOST_ENV.variant]:'neutral-embedded',[WEB_HOST_ENV.fixture]:'matching',[WEB_HOST_ENV.renderRequestSha256]:requestSha256};
  let child;
  try{child=await runCopiedChild({owned,copyRoot,env,label:control.label,command:node,args:[WEB_HOST_REACT_RENDERER]});}
  catch(error){if(!error.childRecord)throw error;child=error.childRecord;}
  assert.equal(child.code,control.expectedCode);
  const raw=readFileSync(child.logPath);
  let chrome;
  if(child.code===0){const bytes=readFileSync(join(owned.root,'react-chrome.json'));chrome=readRenderedChrome(owned,copyRoot,chromeDigest(bytes),requestSha256);assert.ok(chrome.html.includes(request.pendingLabel));assert.ok(chrome.loadedReactFiles.some(row=>row.path.endsWith('/react/cjs/react.production.js')));assert.ok(chrome.loadedReactFiles.every(row=>!row.path.includes('.development.js')));}
  else assert.match(raw.toString(),/Development React module participated: react\/cjs\/react\.development\.js/);
  controls.push({...control,owned,sourceBindings,compileElapsedMilliseconds,rendererSha256:chromeDigest(readFileSync(join(copyRoot,WEB_HOST_REACT_RENDERER))),graphSha256:chromeDigest(readFileSync(join(copyRoot,WEB_HOST_REACT_RENDERER_GRAPH))),requestSha256,child,finalClosedLog:{path:child.logPath,bytes:raw.length,sha256:chromeDigest(raw)},chromeSha256:chrome?chromeDigest(readFileSync(join(owned.root,'react-chrome.json'))):null,loadedReactFiles:chrome?.loadedReactFiles??null});
}
const summary={scope:'Actual small maintained renderer compiled and executed in four owned React copies; no complete app build or host acceptance',sourceRoot:realpathSync(root),denialOwnerSha256:chromeDigest(currentDenied),deniedDevelopmentIdentityCount:REACT_DEVELOPMENT_FILES.length,elapsedMilliseconds:performance.now()-started,controls};
writeFileSync(join(output,'summary.json'),JSON.stringify(summary,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({summary:join(output,'summary.json'),elapsedMilliseconds:summary.elapsedMilliseconds,individualRendererExits:controls.map(row=>({label:row.label,code:row.child.code})),denialOwnerSha256:summary.denialOwnerSha256}));
