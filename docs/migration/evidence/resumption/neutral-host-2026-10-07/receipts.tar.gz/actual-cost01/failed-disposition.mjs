import { createHash } from 'node:crypto';
import { readFileSync, realpathSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { assertOwnedArtifact, ownedPath } from '/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch/tools/migration/lib/web-host-ownership.mjs';
import { assertFinalInputBindings } from '/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch/tools/migration/lib/web-host-inputs.mjs';
import { copiedBuildEnvironment, runCopiedChild } from '/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch/tools/migration/lib/web-host-build.mjs';
import { readWebHostArtifact } from '/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch/tools/migration/lib/web-host-artifact.mjs';
import { WEB_HOST_ENV } from '/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch/migration/probes/web-host/host/contract.ts';
const root=realpathSync(process.argv[2]);const output=process.argv[3];
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const marker=JSON.parse(readFileSync(join(root,'.splotch-web-host.json')));const owned={root,token:marker.token};assertOwnedArtifact(owned);
const inputBytes=readFileSync(ownedPath(owned,'inputs.json'));const resultBytes=readFileSync(ownedPath(owned,'result.json'));
const inputs=JSON.parse(inputBytes);const result=JSON.parse(resultBytes);
if(inputs.variant!=='neutral-embedded'||inputs.artifact!=='release'||inputs.fixture!=='matching')throw new Error('Disposition requires actual matching release neutral artifact');
if(result.status!=='failed'||result.partial?.failedChild?.label!=='neutral-postbuild'||result.reviewEvidenceEligible!==false||!result.partial?.evidence)throw new Error('Only an actual fully captured neutral postbuild failure is eligible for failed-cost disposition');
assertFinalInputBindings(owned,inputs.bindings);
const copyRoot=realpathSync(inputs.copies.neutral);if(copyRoot!==join(root,'neutral'))throw new Error('Neutral failed copy must remain owned');
const packageBytes=readFileSync(join(copyRoot,'package.json'));const {postbuild}=JSON.parse(packageBytes).scripts;
const commands=postbuild.split(' && ');const guards=commands.slice(0,-1);
const expected=['tools/check-release-seams.mjs','tools/check-build-version.mjs','tools/check-pwa-precache.mjs','tools/mobile/check-static-bundle.mjs','tools/check-bundle-budgets.mjs','tools/check-eager-error-bundle.mjs'];
if(guards.length!==expected.length||commands.at(-1)!=='node tools/migration/gen-hosted-topology.mjs')throw new Error('Actual registered hard-guard sequence changed');
const request={variant:inputs.variant,artifact:inputs.artifact,fixture:inputs.fixture};
const env={...copiedBuildEnvironment(owned,copyRoot,inputs.artifact,inputs.pinned.env,request),[WEB_HOST_ENV.renderRequestSha256]:inputs.neutral.requestSha256,[WEB_HOST_ENV.chromeSha256]:inputs.neutral.chromeSha256};
const children=[];
for(let index=0;index<guards.length;index++) {
 const parts=guards[index].split(' ');if(parts.shift()!=='node'||parts.filter(part=>part===expected[index]).length!==1||parts.some(part=>!part||/[\s'"`$;&|<>]/.test(part)))throw new Error('Hard guard must be the exact literal registered Node owner');
 assertFinalInputBindings(owned,inputs.bindings);
 try { children.push(await runCopiedChild({owned,copyRoot,env,label:`failed-cost-hard-guard-${index+1}`,command:process.execPath,args:parts})); }
 catch(error) { if(!error.childRecord)throw error;children.push({...error.childRecord,error:error.message}); }
 assertFinalInputBindings(owned,inputs.bindings);
}
let readerRefusal;
try {readWebHostArtifact(root);throw new Error('Failed artifact reader unexpectedly accepted');}
catch(error){if(!error.message.includes('Only a completed, source-bound structural build artifact'))throw error;readerRefusal=error.message;}
const bundle=await import(pathToFileURL(join(copyRoot,'tools/check-bundle-budgets.mjs')).href);
const eager=await import(pathToFileURL(join(copyRoot,'tools/check-eager-error-bundle.mjs')).href);
const measurement=result.partial.evidence.neutral.measurement;
const indexPath=join(copyRoot,'web/.svelte-kit/output/prerendered/pages/index.html');
const manifest=JSON.parse(readFileSync(join(copyRoot,'web/.svelte-kit/output/client/.vite/manifest.json')));
const {statSync}=await import('node:fs');
const {hrefs,inlineStyleBytes}=bundle.startupResourcesFromHtml(readFileSync(indexPath,'utf8'));
const linked=hrefs.map(href=>new URL(href,'https://bundle.invalid/').pathname.slice(1));
const error=eager.eagerErrorResources(manifest);
const sizeOf=file=>statSync(join(copyRoot,'web/.svelte-kit/output/client',file)).size;
const eagerUnionBytes=eager.eagerErrorStartupBytes(linked,error,inlineStyleBytes,sizeOf);
if(!readFileSync(ownedPath(owned,'inputs.json')).equals(inputBytes)||!readFileSync(ownedPath(owned,'result.json')).equals(resultBytes))throw new Error('Failed public artifact inputs or result changed during disposition');
const receipt={scope:'Actual six unmodified hard shipping guard owners independently rerun after public postbuild short-circuit; failed public artifact status and strict reader refusal unchanged; no serve/browser or acceptance',publicResultPath:join(root,'result.json'),publicResultSha256:sha(resultBytes),publicInputsSha256:sha(inputBytes),packageSha256:sha(packageBytes),literalPostbuild:postbuild,children,strictFailedReaderRefusal:readerRefusal,measurement,eagerStartup:{linked,error,inlineStyleBytes,unionRawBytes:eagerUnionBytes,maxRawBytes:bundle.MAX_STARTUP_JS_CSS_BYTES},publicArtifactUnchanged:true};
writeFileSync(output,JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({receipt:output,individualGuardExits:children.map(row=>({label:row.label,code:row.code,signal:row.signal})),measurement,eagerUnionBytes,strictFailedReaderRefusal:readerRefusal}));
