import datetime
import hashlib
import json
import os
import re
from pathlib import Path
import signal
import socket
import stat
import subprocess
import sys
import time

STARTED = time.monotonic()
active = None
profile_path = Path(sys.argv[1])
profile_bytes = profile_path.read_bytes()
assert hashlib.sha256(profile_bytes).hexdigest() == sys.argv[2]
profile = json.loads(profile_bytes)
WHOLE_SECONDS = profile['wholeSeconds']
FINAL_SECONDS = profile['finalSeconds']
assert WHOLE_SECONDS == 1200 and FINAL_SECONDS == 60
root = Path(profile['worktree'])
attempt = Path(profile['attemptRoot'])
assert not attempt.exists()
attempt.mkdir()
if os.getpgrp() != os.getpid():
    os.setsid()
record = {'owner': 'neutral_host', 'state': 'starting', 'scope': profile['scope'], 'wholeDeadlineSeconds': WHOLE_SECONDS, 'finalReserveSeconds': FINAL_SECONDS, 'startedAtUtc': datetime.datetime.now(datetime.UTC).isoformat(), 'pid': os.getpid(), 'pgid': os.getpgrp(), 'profileSha256': hashlib.sha256(profile_bytes).hexdigest(), 'children': []}

def now():
    return datetime.datetime.now(datetime.UTC).isoformat()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def remaining():
    return max(0.001, STARTED + WHOLE_SECONDS - time.monotonic())

def alarm(_signum, _frame):
    raise TimeoutError('Neutral release cost whole-stage deadline')

signal.signal(signal.SIGALRM, alarm)
signal.setitimer(signal.ITIMER_REAL, WHOLE_SECONDS - FINAL_SECONDS)

def ps_rows():
    raw = subprocess.run(['/bin/ps', '-ww', '-axo', 'pid=,ppid=,pgid=,lstart=,args='], capture_output=True, check=True, timeout=min(5, remaining())).stdout
    rows = []
    for line in raw.decode().splitlines():
        fields = line.split(None, 8)
        if len(fields) == 9:
            rows.append({'pid': int(fields[0]), 'ppid': int(fields[1]), 'pgid': int(fields[2]), 'birth': ' '.join(fields[3:8]), 'observedOsTitleOrArguments': fields[8]})
    return rows

def identity(pid, rows=None):
    return next((row for row in (ps_rows() if rows is None else rows) if row['pid'] == pid), None)

def git(*args):
    return subprocess.run(['/usr/bin/git', '--no-optional-locks', *args], cwd=root, capture_output=True, check=True, timeout=min(10, remaining())).stdout

def file_bind(row):
    path = Path(row['path'])
    assert path.is_file() and not path.is_symlink() and path.resolve(strict=True) == path
    raw = path.read_bytes()
    assert stat.S_IMODE(path.lstat().st_mode) == row['mode'] and len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'Changed frozen input: ' + str(path)

def metadata(label):
    result = {}
    for name, args in [('head', ['rev-parse', 'HEAD']), ('tree', ['rev-parse', 'HEAD^{tree}']), ('branch', ['branch', '--show-current']), ('index', ['ls-files', '--stage', '-z']), ('membership', ['ls-files', '-z']), ('status', ['status', '--porcelain=v1', '-z', '--untracked-files=all']), ('staged-diff', ['diff', '--cached', '--binary', '--no-ext-diff']), ('unstaged-diff', ['diff', '--binary', '--no-ext-diff'])]:
        raw = git(*args)
        path = attempt / (label + '-' + name + '.bin')
        path.write_bytes(raw)
        result[name] = {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}
    return result

def assert_metadata(rows):
    assert {name: row['sha256'] for name, row in rows.items()} == {name: row['sha256'] for name, row in profile['metadata'].items()}, 'Source/index/status changed during gates'

def source_observation(label):
    started = time.monotonic()
    source_bytes = Path(profile['sourceSnapshot']).read_bytes()
    assert sha(source_bytes) == profile['sourceSnapshotSha256']
    rows = json.loads(source_bytes)
    for row in rows:
        path = root / row['path']
        assert path.is_file() and not path.is_symlink()
        raw = path.read_bytes()
        assert stat.S_IMODE(path.lstat().st_mode) == row['mode'] and len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'Source changed: ' + row['path']
        assert time.monotonic() - started < 60, 'Source observation stage deadline'
    assert set(git('ls-files', '-z').decode().rstrip('\0').split('\0')) == {row['path'] for row in rows}
    (attempt / (label + '-source.json')).write_bytes(source_bytes)
    return {'path': str(attempt / (label + '-source.json')), 'sha256': sha(source_bytes), 'rows': len(rows), 'elapsedSeconds': time.monotonic() - started}

def same_birth_parent_group(old, live):
    return live is not None and all(live[name] == old[name] for name in ['pid', 'ppid', 'pgid', 'birth'])

def current_proof(child, item):
    assert child.pid == item['pid'] and child.poll() is None, 'No live owned Popen handle; decline signal'
    live = identity(child.pid)
    assert item['identity'] is not None, 'No observed owned birth identity; decline signal'
    assert same_birth_parent_group(item['identity'], live) and live['ppid'] == os.getpid() and live['pgid'] == child.pid, 'No current birth/parent/group ownership; decline signal'
    return {'live': live, 'ownedPopenHandleLive': True, 'birthParentGroupMatch': True, 'originalInvocationArgv': item['invocationArgv'], 'osTitleIsNotOriginalInvocationProof': True}

def observe_consumers(item):
    rows = ps_rows()
    descendants = {item['pid']}
    while True:
        added = {row['pid'] for row in rows if row['ppid'] in descendants}
        if added <= descendants:
            break
        descendants |= added
    seen = {(row['pid'], row['birth']) for row in item['observedConsumers']}
    for row in rows:
        if row['pid'] in descendants and (row['pid'], row['birth']) not in seen:
            observed = dict(row)
            title = row['observedOsTitleOrArguments'].strip()
            observed['eligibleLongConsumerArgumentTextObserved'] = title.startswith(profile['node'] + ' ') or title.startswith('node ')
            observed['originalInvocationVectorForDescendantClaimed'] = False
            observed['observationLimit'] = 'OS text may be a mutable process title; the original Popen vector is recorded separately'
            item['observedConsumers'].append(observed)

def release_active():
    global active
    if active is None:
        return
    child, item = active
    if child.poll() is None:
        proof = current_proof(child, item)
        item['signals'].append({'signal': 'SIGTERM', 'at': now(), 'proof': proof})
        os.killpg(child.pid, signal.SIGTERM)
        try:
            child.wait(timeout=min(5, remaining()))
        except subprocess.TimeoutExpired:
            proof = current_proof(child, item)
            item['signals'].append({'signal': 'SIGKILL', 'at': now(), 'proof': proof})
            os.killpg(child.pid, signal.SIGKILL)
            child.wait(timeout=min(5, remaining()))
    item['exitCode'] = child.returncode
    rows = ps_rows()
    groups = {item['pid']} | {row['pgid'] for row in item['observedConsumers']}
    item['remainingObservedGroups'] = [row for row in rows if row['pgid'] in groups]
    item['releaseObservedAtUtc'] = now()
    assert not item['remainingObservedGroups'], 'Unresolved observed owned group; no historical-PID signal'
    active = None

def run_child(label, argv, seconds, extra_environment=None):
    global active
    item = {'label': label, 'invocationArgv': argv, 'invocationArgvSource': 'actual owned subprocess.Popen call', 'startedAtUtc': now(), 'signals': [], 'cwd': str(root), 'observedConsumers': [], 'maxSeconds': seconds, 'beforeSourceMetadata': metadata(label + '-before')}
    assert_metadata(item['beforeSourceMetadata'])
    record['children'].append(item)
    stdout_path, stderr_path = attempt / (label + '.stdout.log.txt'), attempt / (label + '.stderr.log.txt')
    item['stdoutPath'] = str(stdout_path)
    item['stderrPath'] = str(stderr_path)
    child_environment = dict(environment)
    if extra_environment:
        child_environment.update(extra_environment)
    child_started = time.monotonic()
    try:
        with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
            child = subprocess.Popen(argv, cwd=root, env=child_environment, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, start_new_session=True)
            item['pid'] = child.pid
            item['identity'] = None
            active = (child, item)
            item['identity'] = identity(child.pid)
            if item['identity'] is not None:
                assert item['identity']['ppid'] == os.getpid() and item['identity']['pgid'] == child.pid
            else:
                assert child.poll() is not None, 'Live child lacks identity; setup refusal'
                item['identityLimit'] = 'Child already completed; no live argv/birth inferred'
            item['originalFullOsArgvClaimed'] = False
            while child.poll() is None:
                assert time.monotonic() - child_started < seconds, 'Child deadline: ' + label
                observe_consumers(item)
                try:
                    child.wait(timeout=max(0.001, min(0.25, remaining() - FINAL_SECONDS)))
                except subprocess.TimeoutExpired:
                    pass
            item['exitCode'] = child.returncode
            assert time.monotonic() - child_started <= seconds, 'Completed child exceeded its deadline: ' + label
    finally:
        try:
            release_active()
            assert active is None and item.get('remainingObservedGroups') == [], 'No proved output-writer release'
        except BaseException as cleanup:
            item['outputFinalization'] = {'state': 'unfinalized', 'observedAtUtc': now(), 'failure': {'type': type(cleanup).__name__, 'message': str(cleanup)}, 'finalClosedChannelBindingsClaimed': False}
            raise
        item['elapsedSeconds'] = time.monotonic() - child_started
        item['finishedAtUtc'] = now()
        item['outputFinalization'] = {'state': 'finalized', 'ownedGroupReleasedAtUtc': item['releaseObservedAtUtc'], 'finalClosedChannelBindingsClaimed': True}
        for name, path in [('stdout', stdout_path), ('stderr', stderr_path)]:
            if path.exists():
                raw = path.read_bytes()
                item[name] = {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}
    item['afterSourceMetadata'] = metadata(label + '-after')
    assert_metadata(item['afterSourceMetadata'])
    assert item['exitCode'] == 0, 'Actual registered gate failed: ' + label

def installed_observation(label):
    output = attempt / (label + '-installed.json')
    run_child(label + '-installed-observer', [profile['node'], profile['installedQualifier'], str(root), str(output)], 90)
    raw = output.read_bytes()
    data = json.loads(raw)
    assert data['sourceRoot'] == str(root) and data['node'] == 'v24.16.0'
    return {'path': str(output), 'bytes': len(raw), 'sha256': sha(raw), 'inventorySha256ByContext': {row['relativePath']: row.get('inventorySha256') for row in data['contexts']}}


def cache_path(path):
    return re.fullmatch(r'\.vite/vitest/[a-f0-9]+/results\.json', path) is not None

def cache_directory(path):
    return path == '.vite-temp' or path == '.vite' or re.fullmatch(r'\.vite/vitest(?:/[a-f0-9]+)?', path) is not None

def cache_backups():
    record['cacheBackups'] = []
    data = json.loads(Path(record['beforeInstalled']['path']).read_bytes())
    for index, context in enumerate(data['contexts']):
        for row in context.get('files', []):
            if not cache_path(row['path']):
                continue
            path = root / context['relativePath'] / row['path']
            actual = path.lstat()
            assert row['kind'] == 'file' and not path.is_symlink() and actual.st_nlink == 1
            raw = path.read_bytes()
            assert sha(raw) == row['sha256'] and stat.S_IMODE(actual.st_mode) == row['mode']
            backup = attempt / ('cache-before-' + str(index) + '-' + sha(row['path'].encode()) + '.bin')
            backup.write_bytes(raw)
            record['cacheBackups'].append({'relativeContext': context['relativePath'], 'path': row['path'], 'backupPath': str(backup), 'sha256': sha(raw), 'mode': row['mode']})

def restore_caches(observation):
    before = json.loads(Path(record['beforeInstalled']['path']).read_bytes())['contexts']
    after = json.loads(Path(observation['path']).read_bytes())['contexts']
    assert len(before) == len(after)
    restorations = []
    backups = {(row['relativeContext'], row['path']): row for row in record['cacheBackups']}
    for old, new in zip(before, after):
        assert old['relativePath'] == new['relativePath'] and old['present'] == new['present']
        if not old['present']:
            continue
        assert old['rootIdentity'] == new['rootIdentity']
        old_files = {row['path']: row for row in old['files']}
        new_files = {row['path']: row for row in new['files']}
        assert not old_files.keys() - new_files.keys(), 'Removed installed file; decline cache restoration'
        for name, current in new_files.items():
            previous = old_files.get(name)
            if previous == current:
                continue
            assert cache_path(name) and current['kind'] == 'file', 'Installed delta outside actual Vitest results cache: ' + name
            path = root / old['relativePath'] / name
            info = path.lstat()
            assert not path.is_symlink() and info.st_nlink == 1 and sha(path.read_bytes()) == current['sha256']
            if previous is None:
                path.unlink()
                restorations.append({'relativeContext': old['relativePath'], 'path': name, 'after': current, 'action': 'remove newly test-owned result cache'})
            else:
                assert previous['kind'] == 'file'
                backup = backups[(old['relativePath'], name)]
                raw = Path(backup['backupPath']).read_bytes()
                assert sha(raw) == previous['sha256']
                path.write_bytes(raw)
                path.chmod(previous['mode'])
                restorations.append({'relativeContext': old['relativePath'], 'path': name, 'before': previous, 'after': current, 'backupPath': backup['backupPath'], 'action': 'restore exact captured test-cache payload and mode'})
        old_dirs = {row['path']: row for row in old['directories']}
        new_dirs = {row['path']: row for row in new['directories']}
        assert not old_dirs.keys() - new_dirs.keys()
        assert all(old_dirs[name] == new_dirs[name] for name in old_dirs.keys() & new_dirs.keys())
        for name in sorted(new_dirs.keys() - old_dirs.keys(), key=lambda path: path.count('/'), reverse=True):
            assert cache_directory(name), 'Installed directory outside actual Vitest/Vite cache: ' + name
            path = root / old['relativePath'] / name
            assert path.is_dir() and not path.is_symlink()
            path.rmdir()
            restorations.append({'relativeContext': old['relativePath'], 'path': name, 'action': 'remove observed newly test-owned empty cache directory'})
    record['cacheRestoration'] = {'scope': 'Actual cache mutations preserved before bounded byte/mode restoration; no package/input exclusion, failed-attempt relabel, or installation', 'restorations': restorations}

try:
    record['identity'] = identity(os.getpid())
    assert record['identity']['pgid'] == os.getpid() and record['identity']['observedOsTitleOrArguments'].endswith(' -B ' + str(Path(__file__).resolve()) + ' ' + str(profile_path) + ' ' + sys.argv[2])
    for row in profile['immutableBindings']:
        file_bind(row)
    record['beforeSource'] = source_observation('before')
    record['beforeMetadata'] = metadata('before')
    assert_metadata(record['beforeMetadata'])
    environment = {key: os.environ[key] for key in ['HOME', 'USER', 'LOGNAME', 'LANG', 'LC_ALL', 'TMPDIR'] if key in os.environ}
    environment.update({'PATH': str(Path(profile['node']).parent) + ':/usr/bin:/bin:/usr/sbin:/sbin', 'CI': 'true', 'NODE_DISABLE_COMPILE_CACHE': '1', 'COREPACK_ENABLE_NETWORK': '0'})
    record['beforeInstalled'] = installed_observation('before')
    record['registeredInfoReuse'] = None
    for command in profile['commands']:
        extra_environment = None
        if command['label'] == 'full-browserless':
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
                probe.bind(('127.0.0.1', 0))
                address, port = probe.getsockname()
                record['smokePort'] = {'address': address, 'port': port, 'observedUnusedAtUtc': now(), 'reservationAfterProbeCloseClaimed': False}
            extra_environment = {'SMOKE_PORT': str(port)}
        run_child(command['label'], command['argv'], command['maxSeconds'], extra_environment)
    if 'smokePort' in record:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            probe.bind((record['smokePort']['address'], record['smokePort']['port']))
            record['smokePort']['rebindPassedAtUtc'] = now()
    record['afterInstalled'] = installed_observation('after')
    before_graph = json.loads(Path(record['beforeInstalled']['path']).read_bytes())
    after_graph = json.loads(Path(record['afterInstalled']['path']).read_bytes())
    record['completeInstalledContextsEqual'] = before_graph['contexts'] == after_graph['contexts']
    assert record['completeInstalledContextsEqual'], 'Actual complete installed graph changed; preserve and halt'
    record['afterSource'] = source_observation('after')
    record['afterMetadata'] = metadata('after')
    assert_metadata(record['afterMetadata'])
    for row in profile['immutableBindings']:
        file_bind(row)
    record['state'] = 'release-build-owner-returned'
    record['hostRuntimeArchitectureOrProductAccepted'] = False
except BaseException as error:
    record['state'] = 'failed'
    record['failure'] = {'type': type(error).__name__, 'message': str(error)}
    try:
        release_active()
    except BaseException as cleanup:
        record['unresolvedOwnership'] = {'type': type(cleanup).__name__, 'message': str(cleanup)}
    if active is None and record['children'] and record['children'][-1]['label'] == 'release-cost-build' and record['children'][-1].get('exitCode') == 1:
        try:
            child = record['children'][-1]
            output = Path(child['stdoutPath']).read_text()
            artifacts = [line.removeprefix('Owned web-host artifact: ') for line in output.splitlines() if line.startswith('Owned web-host artifact: ')]
            assert len(artifacts) == 1, 'Actual failed builder must publish exactly one owned artifact'
            artifact = Path(artifacts[0]).resolve(strict=True)
            assert artifact.parent == Path(profile['artifactParent']).resolve(strict=True)
            record['failedArtifactRoot'] = str(artifact)
            run_child('failed-cost-guard-disposition', [profile['node'], profile['failedDisposition'], str(artifact), str(attempt / 'failed-cost-disposition.json')], 90)
        except BaseException as disposition:
            record['failedDispositionFailure'] = {'type': type(disposition).__name__, 'message': str(disposition)}
finally:
    signal.setitimer(signal.ITIMER_REAL, min(FINAL_SECONDS, remaining()))
    if 'afterInstalled' not in record and active is None:
        try:
            record['afterInstalled'] = installed_observation('after-failure')
            record['completeInstalledContextsEqual'] = json.loads(Path(record['beforeInstalled']['path']).read_bytes())['contexts'] == json.loads(Path(record['afterInstalled']['path']).read_bytes())['contexts']
            record['afterSource'] = source_observation('after-failure')
            record['afterMetadata'] = metadata('after-failure')
            assert_metadata(record['afterMetadata'])
        except BaseException as observation:
            record['postObservationFailure'] = {'type': type(observation).__name__, 'message': str(observation)}
    record['finishedAtUtc'] = now()
    record['elapsedSeconds'] = time.monotonic() - STARTED
    record['wholeDeadlinePassed'] = record['elapsedSeconds'] <= WHOLE_SECONDS
    record['activeOwnedChildRemaining'] = active is not None
    (attempt / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'state': record['state'], 'result': str(attempt / 'result.json'), 'pid': os.getpid(), 'pgid': os.getpgrp(), 'elapsedSeconds': record['elapsedSeconds']}))
    assert record['state'] == 'release-build-owner-returned' and record['wholeDeadlinePassed'] and active is None
