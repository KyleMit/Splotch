import assert from 'node:assert/strict';
import { createElement } from '/private/tmp/splotch-neutral-resume-670_yiah/release-cost-artifacts-01/splotch-web-host-nDCmKg/neutral/node_modules/react/index.js';
import { renderToString } from '/private/tmp/splotch-neutral-resume-670_yiah/release-cost-artifacts-01/splotch-web-host-nDCmKg/neutral/node_modules/react-dom/server.node.js';
import { createRequire } from 'node:module';
import { readWebHostArtifact } from '/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch/tools/migration/lib/web-host-artifact.mjs';
const html = renderToString(createElement('span', null, 'actual owned React render'));
assert.equal(html, '<span>actual owned React render</span>');
const cache = Object.entries(createRequire(import.meta.url).cache)
  .filter(([path]) => /\/node_modules\/(?:react|react-dom)\//.test(path))
  .map(([path, module]) => ({ path, loaded: module.loaded, children: module.children.map(child => child.filename) }));
let strictReaderRefusal;
try {
  readWebHostArtifact('/private/tmp/splotch-neutral-resume-670_yiah/release-cost-artifacts-01/splotch-web-host-nDCmKg');
} catch (error) {
  strictReaderRefusal = error.message;
}
assert.equal(strictReaderRefusal, 'Only a completed, source-bound structural build artifact can be checked/served');
console.log(JSON.stringify({scope:'Read-only plain Node named-ESM CJS cache inspection; real minimal SSR only, no artifact renderer rerun or publication, no failed-artifact change or acceptance',node:process.version,nodeEnv:process.env.NODE_ENV,html,cache,strictReaderRefusal},null,2));
