import hashlib,json,os,stat,subprocess
from pathlib import Path
p=Path(__file__).resolve().parent;a=p/'attempt-01';r=json.loads((a/'result.json').read_bytes());profile=json.loads((p/'profile.json').read_bytes());root=Path(profile['worktree']);h=lambda b:hashlib.sha256(b).hexdigest()
def bound(row):
 f=Path(row['path']);b=f.read_bytes();assert len(b)==row['bytes'] and h(b)==row['sha256'],str(f)
channels=[];groups={r['pgid']}
for c in r['children']:
 assert c['outputFinalization']['state']=='finalized' and c['outputFinalization']['finalClosedChannelBindingsClaimed'] and not c['remainingObservedGroups']
 groups.add(c['identity']['pgid']);groups.update(x['pgid'] for x in c['observedConsumers'])
 for key in ['stdout','stderr']:bound(c[key]);channels.append(c[key])
ps=subprocess.run(['/bin/ps','-axo','pid=,pgid=,command='],capture_output=True,text=True,check=True).stdout
live=[line for line in ps.splitlines() if len(line.split())>=2 and int(line.split()[1]) in groups];assert not live,live
for k in ['beforeMetadata','afterMetadata']:
 assert {n:v['sha256'] for n,v in r[k].items()}=={n:v['sha256'] for n,v in profile['metadata'].items()}
 for row in r[k].values():bound(row)
source=json.loads(Path(profile['sourceSnapshot']).read_bytes());total=0
for row in source:
 f=root/row['path'];b=f.read_bytes();assert stat.S_IMODE(f.stat().st_mode)==row['mode'] and len(b)==row['bytes'] and h(b)==row['sha256'],row['path'];total+=len(b)
assert r['beforeSource']['sha256']==r['afterSource']['sha256']==profile['sourceSnapshotSha256']
before=json.loads(Path(r['beforeInstalled']['path']).read_bytes());changed=json.loads(Path(r['afterInstalledBeforeCacheRestoration']['path']).read_bytes());after=json.loads(Path(r['afterInstalled']['path']).read_bytes());assert before['contexts']==after['contexts'] and r['completeInstalledContextsEqual']
for k in ['beforeInstalled','afterInstalledBeforeCacheRestoration','afterInstalled']:bound(r[k])
for row in profile['immutableBindings']:bound(row)
expected={}
for old,new in zip(before['contexts'],changed['contexts']):
 assert old['relativePath']==new['relativePath'];prior={v['path']:v for v in old.get('files',[])}
 for row in new.get('files',[]):
  if prior.get(row['path'])!=row:expected[(new['relativePath'],row['path'])]=row
saved={}
for row in r.get('changedCachePayloads',[]):
 key=(row['relativeContext'],row['path']);assert key not in saved and expected[key]==row['observed']
 f=Path(row['preservedPath']);assert f.parent==a and not f.is_symlink() and stat.S_IMODE(f.stat().st_mode)==0o600
 b=f.read_bytes();assert len(b)==row['preservedBytes']==row['observed']['bytes'] and h(b)==row['preservedSha256']==row['observed']['sha256'];saved[key]=row
assert set(saved)==set(expected)
assert not r['activeOwnedChildRemaining'] and r['wholeDeadlinePassed']
passed=r['state']=='scoped-quality-browserless-passed'
if passed:assert all(c['exitCode']==0 for c in r['children']) and len(r['children'])==10
outer=[]
for name in ['controller.stdout.log.txt','controller.stderr.log.txt']:
 f=p/name;b=f.read_bytes();outer.append({'path':str(f),'bytes':len(b),'sha256':h(b)})
if passed:assert outer[1]['bytes']==0
out={'state':'passed-source-readback-qualified' if passed else 'failed-source-readback-qualified','scope':'Closed source gate outputs and exact frozen source/metadata/restored installed equality; no host cost/browser/runtime architecture acceptance','resultSha256':h((a/'result.json').read_bytes()),'individualExits':[[c['label'],c['exitCode']] for c in r['children']],'elapsedSeconds':r['elapsedSeconds'],'closedChildChannels':channels,'closedOuterChannels':outer,'observedGroups':sorted(groups),'remainingOwnedGroups':live,'sourceRows':len(source),'sourceBytes':total,'sourceAndMetadataEqual':True,'completeInstalledContextsEqual':True,'changedCachePayloadsVerified':list(saved.values()),'changedCachePayloadCount':len(saved),'changedCachePayloadBytes':sum(x['preservedBytes'] for x in saved.values()),'cacheRestorationCount':len(r['cacheRestoration']['restorations']),'smokePort':r.get('smokePort')}
f=p/'final-readback.json';assert not f.exists();f.write_text(json.dumps(out,indent=2)+'\n');os.chmod(f,0o600)
print(json.dumps({k:out[k] for k in ['state','resultSha256','individualExits','elapsedSeconds','sourceRows','sourceBytes','remainingOwnedGroups','changedCachePayloadCount','changedCachePayloadBytes','cacheRestorationCount','smokePort']}));print('readback',h(f.read_bytes()),'childChannels',len(channels),'groups',len(groups))
