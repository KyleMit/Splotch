import datetime,hashlib,json,os,stat,subprocess,time
from pathlib import Path
started=time.monotonic();root=Path(__file__).resolve().parent;profile=json.loads((root/'profile.json').read_bytes());attempt=root/'attempt-01';record_path=attempt/'result.json';record=json.loads(record_path.read_bytes());artifact=Path(record['failedArtifactRoot']);public_path=artifact/'result.json';public=json.loads(public_path.read_bytes());sha=lambda raw:hashlib.sha256(raw).hexdigest()
def bind(path):
 raw=path.read_bytes();return {'path':str(path),'bytes':len(raw),'sha256':sha(raw)}
assert record['state']=='failed' and record['wholeDeadlinePassed'] and not record['activeOwnedChildRemaining']
assert public['status']=='failed' and public['reviewEvidenceEligible'] is False
assert public['partial']['failedChild']['label']=='neutral-postbuild' and public['partial']['evidenceError']=='Malformed React chunk contributors' and 'evidence' not in public['partial']
assert [child['exitCode'] for child in record['children']]==[0,1,1,0]
channels=[];groups={record['pgid']}
for child in record['children']:
 assert child['outputFinalization']['state']=='finalized' and child['outputFinalization']['finalClosedChannelBindingsClaimed'] and child['remainingObservedGroups']==[]
 groups.add(child['pid']);groups.update(row['pgid'] for row in child['observedConsumers'])
 for name in ['stdout','stderr']:
  actual=bind(Path(child[name]['path']));assert actual==child[name];channels.append(actual)
children=public['partial']['children']+[public['partial']['failedChild']];assert [c['code'] for c in children]==[0]*10+[1];logs=[]
for child in children:
 assert not child['timedOut'] and not child['interrupted'];groups.add(child['termination']['groupPid']);path=Path(child['logPath']);assert path.parent==artifact/'controls' and path.is_file() and not path.is_symlink();logs.append({'label':child['label'],'exitCode':child['code'],**bind(path)})
ps=subprocess.run(['/bin/ps','-axo','pid=,ppid=,pgid='],capture_output=True,check=True,timeout=5).stdout;remaining=[line.decode().strip() for line in ps.splitlines() if int(line.split()[2]) in groups];assert remaining==[]
before=json.loads(Path(record['beforeInstalled']['path']).read_bytes());after=json.loads(Path(record['afterInstalled']['path']).read_bytes());assert before['contexts']==after['contexts'] and len(before['contexts'])==5
assert Path(record['beforeSource']['path']).read_bytes()==Path(record['afterSource']['path']).read_bytes();source=json.loads(Path(record['afterSource']['path']).read_bytes());assert len(source)==8482
for row in source:
 path=Path(profile['worktree'])/row['path'];raw=path.read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'] and stat.S_IMODE(path.stat().st_mode)==row['mode']
for label in ['beforeMetadata','afterMetadata']:
 for name,row in record[label].items():assert row['sha256']==profile['metadata'][name]['sha256'] and bind(Path(row['path']))==row
for row in profile['immutableBindings']:
 path=Path(row['path']);assert bind(path)=={key:row[key] for key in ['path','bytes','sha256']} and stat.S_IMODE(path.stat().st_mode)==row['mode']
strict=json.loads((root/'strict-reader.stdout.txt').read_bytes());assert strict['publicBytesUnchanged'] and strict['resultSha256']==sha(public_path.read_bytes()) and strict['inputsSha256']==sha((artifact/'inputs.json').read_bytes())
outer=[bind(root/name) for name in ['controller.stdout.log.txt','controller.stderr.log.txt']]
result={'scope':'Closed actual neutral-postbuild hard lazy-budget failure and independently refused complete facade graph evidence; source-only source09 acceptance remains separate; no complete-cost disposition, serving, browser or architecture acceptance','observedAtUtc':datetime.datetime.now(datetime.UTC).isoformat(),'controllerExit':1,'controllerResult':bind(record_path),'publicResult':bind(public_path),'publicInputs':bind(artifact/'inputs.json'),'failedChild':'neutral-postbuild','evidenceCaptureRefusal':public['partial']['evidenceError'],'actualChildren':[{'label':c['label'],'code':c['code']} for c in children],'individualControllerExits':[[c['label'],c['exitCode']] for c in record['children']],'closedControllerChannels':channels,'closedOuterChannels':outer,'closedCopiedLogs':logs,'observedGroups':sorted(groups),'allObservedGroupsAbsent':True,'completeInstalledContextsEqual':True,'installedContextInventories':record['afterInstalled']['inventorySha256ByContext'],'currentSourceRowsMatch':len(source),'sourceIndexMetadataMatch':True,'immutableBindingsMatch':len(profile['immutableBindings']),'failedDispositionHelper':next(row for row in profile['immutableBindings'] if row['path']==profile['failedDisposition']),'strictReader':{'exitCode':0,'receipt':strict,'stdout':bind(root/'strict-reader.stdout.txt'),'stderr':bind(root/'strict-reader.stderr.txt')},'elapsedSeconds':time.monotonic()-started}
assert result['elapsedSeconds']<=60;f=root/'final-readback.json';assert not f.exists();f.write_text(json.dumps(result,indent=2)+'\n');os.chmod(f,0o600);print(json.dumps({'result':str(f),'sha256':sha(f.read_bytes()),'controllerResultSha256':result['controllerResult']['sha256'],'copiedLogs':len(logs),'closedControllerChannels':len(channels),'closedOuterChannels':len(outer),'observedGroups':len(groups),'elapsedSeconds':result['elapsedSeconds'],'allObservedGroupsAbsent':True,'currentSourceRowsMatch':len(source),'individualExits':result['individualControllerExits']}))
