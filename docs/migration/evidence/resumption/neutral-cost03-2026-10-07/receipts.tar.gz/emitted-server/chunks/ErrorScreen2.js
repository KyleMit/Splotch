import { t as ErrorScreen } from "./ErrorScreen.js";
export { ErrorScreen as default };
