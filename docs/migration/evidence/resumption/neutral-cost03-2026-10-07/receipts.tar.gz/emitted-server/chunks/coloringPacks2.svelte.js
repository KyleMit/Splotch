import "./server2.js";
import { t as readonlyValue } from "./readonlyView.js";
import { a as STARTER_COLORING_BOOK_ID, o as booksForPlatform } from "./books.js";
//#region src/lib/state/coloringPacks.svelte.ts
function createColoringPacks() {
	const s = {
		installedBookIds: [STARTER_COLORING_BOOK_ID],
		downloadingBookId: null,
		downloadedBytes: 0,
		totalBookCount: 1,
		initialized: false
	};
	function setInstalledColoringBooks(bookIds) {
		s.installedBookIds = [STARTER_COLORING_BOOK_ID, ...bookIds.filter((id) => id !== STARTER_COLORING_BOOK_ID)];
		s.initialized = true;
	}
	return {
		get installedBookIds() {
			return readonlyValue(s.installedBookIds);
		},
		get downloadingBookId() {
			return s.downloadingBookId;
		},
		get downloadedBytes() {
			return s.downloadedBytes;
		},
		get downloadedBookCount() {
			return s.installedBookIds.filter((id) => id !== STARTER_COLORING_BOOK_ID).length;
		},
		get downloadableBookCount() {
			return s.totalBookCount - 1;
		},
		get initialized() {
			return s.initialized;
		},
		availableColoringBooks(platform) {
			return booksForPlatform(platform).filter((book) => s.installedBookIds.includes(book.id));
		},
		setInstalledColoringBooks,
		setNoDownloadedColoringBooks(platform) {
			setInstalledColoringBooks([]);
			s.totalBookCount = booksForPlatform(platform).length;
			s.downloadedBytes = 0;
		},
		recordInstalledPacks(totalBookCount, downloadedBytes) {
			s.totalBookCount = totalBookCount;
			s.downloadedBytes = downloadedBytes;
		},
		startBookDownload(bookId) {
			s.downloadingBookId = bookId;
		},
		markColoringBookInstalled(bookId, bytes) {
			if (!s.installedBookIds.includes(bookId)) s.installedBookIds = [...s.installedBookIds, bookId];
			s.downloadedBytes += bytes;
		},
		endBookDownload() {
			s.downloadingBookId = null;
		},
		resetDownloadedColoringBooks() {
			s.installedBookIds = [STARTER_COLORING_BOOK_ID];
			s.downloadedBytes = 0;
			s.downloadingBookId = null;
		}
	};
}
var coloringPacksState = createColoringPacks();
var { availableColoringBooks, setInstalledColoringBooks, setNoDownloadedColoringBooks, markColoringBookInstalled, resetDownloadedColoringBooks } = coloringPacksState;
//#endregion
export { resetDownloadedColoringBooks as a, markColoringBookInstalled as i, coloringPacksState as n, setInstalledColoringBooks as o, createColoringPacks as r, setNoDownloadedColoringBooks as s, availableColoringBooks as t };
