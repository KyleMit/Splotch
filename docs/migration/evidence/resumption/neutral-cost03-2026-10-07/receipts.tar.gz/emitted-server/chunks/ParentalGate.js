import { E as attr, O as escape_html, a as bind_props, c as ensure_array_like, n as attr_style, o as derived, t as attr_class } from "./server2.js";
import { a as paletteHex } from "./palette.js";
import { t as SplotchyIcon } from "./SplotchyIcon.js";
import { n as Icon } from "./Icon.js";
import { t as VisuallyHidden } from "./VisuallyHidden.js";
import { i as dismissGate, l as parentalGateState, o as gateAnswer, t as GATE_KEYPAD_KEYS, u as redirectGateToParentCenter } from "./parentalGate.svelte.js";
import "./deferredIcons.js";
import "./modalDialog.svelte.js";
import { t as DialogHeader } from "./DialogHeader.js";
//#region src/lib/components/ParentalGateKeypad.svelte
function ParentalGateKeypad($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		/** The gate moves focus onto a key and routes Enter by whether a key has it. */
		let { element = void 0 } = $$props;
		const KEY_ICONS = {
			delete: "backspace",
			submit: "check"
		};
		const KEY_LABELS = {
			delete: "Delete",
			submit: "Check answer"
		};
		$$renderer.push(`<div class="gate-keypad svelte-187wrha"><!--[-->`);
		const each_array = ensure_array_like(GATE_KEYPAD_KEYS);
		for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
			let key = each_array[$$index];
			$$renderer.push(`<button class="gate-key svelte-187wrha"${attr("data-key", key)}${attr("aria-label", typeof key === "number" ? void 0 : KEY_LABELS[key])}${attr("aria-disabled", parentalGateState.lockoutUntil !== null)}>`);
			if (typeof key === "number") $$renderer.push(`<!--[0-->${escape_html(key)}`);
			else {
				$$renderer.push("<!--[-1-->");
				Icon($$renderer, {
					name: KEY_ICONS[key],
					class: "gate-key-icon"
				});
			}
			$$renderer.push(`<!--]--></button>`);
		}
		$$renderer.push(`<!--]--></div>`);
		bind_props($$props, { element });
	});
}
//#endregion
//#region src/lib/components/ParentalGateManageFooter.svelte
function ParentalGateManageFooter($$renderer, $$props) {
	/** Retargets the challenge — the gate owns it, since activating this line
	*  unmounts the line, and the focus that was on it has to go somewhere the
	*  keypad's keydown handler can still reach. */
	let { onManage } = $$props;
	$$renderer.push(`<button class="gate-manage svelte-8pxk2e"><span>Manage these checks in</span> <span class="gate-manage-path svelte-8pxk2e"><span class="gate-manage-place svelte-8pxk2e">`);
	Icon($$renderer, {
		name: "settings",
		class: "gate-manage-icon",
		"aria-hidden": "true"
	});
	$$renderer.push(`<!----> <span>Settings</span></span> <span aria-hidden="true">›</span> <span class="gate-manage-place svelte-8pxk2e">`);
	Icon($$renderer, {
		name: "parent-center",
		class: "gate-manage-icon",
		"aria-hidden": "true"
	});
	$$renderer.push(`<!----> <span>Parent Center</span></span></span></button>`);
}
//#endregion
//#region src/lib/hexPickerLayout.ts
var PICKER_DIM_BORDER = "#1A1F24";
var COLOR_FAMILIES = [
	{
		name: "reds",
		shades: [
			"#FFB3C1",
			"#FF8FA3",
			"#FF6B6B",
			"#EE5A6F",
			"#E63946",
			"#D62828",
			"#C1121F",
			"#9D0208",
			"#6A040F"
		]
	},
	{
		name: "oranges",
		shades: [
			"#FFAC81",
			"#FFA07A",
			"#FF9E00",
			"#FF8C42",
			"#FB8500",
			"#F77F00",
			"#E85D3B",
			"#D36135",
			"#C34A36"
		]
	},
	{
		name: "yellows",
		shades: [
			"#FFEA00",
			"#FFE66D",
			"#FFD60A",
			"#FFC300",
			"#FFB703",
			"#FFAA00",
			"#F9C74F",
			"#F9B44A",
			"#F9844A"
		]
	},
	{
		name: "greens",
		shades: [
			"#AED581",
			"#73E2A7",
			"#8FD694",
			"#52B788",
			"#2ECC71",
			"#10B981",
			"#00B894",
			"#2D6A4F",
			"#1B5E3F"
		]
	},
	{
		name: "blues",
		shades: [
			"#90CAF9",
			"#4CC9F0",
			"#64B5F6",
			"#42A5F5",
			"#2196F3",
			"#0096C7",
			"#0077B6",
			"#023E8A",
			"#03045E"
		]
	},
	{
		name: "purples",
		shades: [
			"#E0AAFF",
			"#D8A7FF",
			"#C77DFF",
			"#B565D8",
			"#9D4EDD",
			"#9B59B6",
			"#8E44AD",
			"#7209B7",
			"#5A189A"
		]
	},
	{
		name: "pinks",
		shades: [
			"#FFB3D9",
			"#FF8AC7",
			"#F06292",
			"#FF4081",
			"#FF006E",
			"#E91E63",
			"#D81B60",
			"#C2185B",
			"#AD1457"
		]
	},
	{
		name: "browns",
		shades: [
			"#BCAAA4",
			"#A1887F",
			"#8D6E63",
			"#795548",
			"#6D4C41",
			"#5D4037",
			"#4E342E",
			"#3E2723",
			"#2C1810"
		]
	},
	{
		name: "greys",
		shades: [
			"#FFFFFF",
			"#90A4AE",
			"#78909C",
			"#607D8B",
			"#546E7A",
			"#455A64",
			"#37474F",
			"#263238",
			PICKER_DIM_BORDER
		]
	}
];
function colorFamilyShade(name, shadeIndex) {
	const shade = COLOR_FAMILIES.find((family) => family.name === name)?.shades[shadeIndex];
	if (!shade) throw new Error(`No shade ${shadeIndex} in color family "${name}"`);
	return shade;
}
/** Portrait grid: one row per family, shades light → dark across. */
var PORTRAIT_ROWS = COLOR_FAMILIES.map((f) => ({
	key: f.name,
	colors: f.shades
}));
/** Landscape grid: the transpose — one row per shade level, families across. */
var LANDSCAPE_ROWS = Array.from({ length: 9 }, (_, s) => ({
	key: `shade-${s + 1}`,
	colors: COLOR_FAMILIES.map((f) => f.shades[s])
}));
//#endregion
//#region src/lib/components/ParentalGateProblem.svelte
function ParentalGateProblem($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		const OPERAND_FILLS = [paletteHex("Purple"), colorFamilyShade("blues", 4)];
		const dabs = derived(() => Array.from({ length: gateAnswer(parentalGateState).length }, (_, i) => parentalGateState.input[i] ?? ""));
		$$renderer.push(`<div class="gate-problem"><div class="gate-equation svelte-19o4qdl" role="img"${attr("aria-label", `What is ${parentalGateState.x} times ${parentalGateState.y}?`)}><span class="gate-operand svelte-19o4qdl" aria-hidden="true"${attr_style("", {
			background: OPERAND_FILLS[0],
			"border-radius": "var(--radius-blob-1)"
		})}>${escape_html(parentalGateState.x)}</span> <span class="gate-operator svelte-19o4qdl" aria-hidden="true">×</span> <span class="gate-operand svelte-19o4qdl" aria-hidden="true"${attr_style("", {
			background: OPERAND_FILLS[1],
			"border-radius": "var(--radius-blob-2)"
		})}>${escape_html(parentalGateState.y)}</span> <span class="gate-operator svelte-19o4qdl" aria-hidden="true">=</span> <!--[-->`);
		const each_array = ensure_array_like(dabs());
		for (let i = 0, $$length = each_array.length; i < $$length; i++) {
			let digit = each_array[i];
			$$renderer.push(`<span${attr_class("gate-dab svelte-19o4qdl", void 0, { "filled": digit !== "" })} aria-hidden="true">${escape_html(digit)}</span>`);
		}
		$$renderer.push(`<!--]--></div> <p class="gate-error svelte-19o4qdl" aria-hidden="true">${escape_html(parentalGateState.lockoutMessage ?? parentalGateState.error ?? "")}</p> `);
		VisuallyHidden($$renderer, {
			as: "p",
			role: "status",
			children: ($$renderer) => {
				$$renderer.push(`<!---->${escape_html(parentalGateState.announcement)}`);
			},
			$$slots: { default: true }
		});
		$$renderer.push(`<!----></div>`);
	});
}
//#endregion
//#region src/lib/components/ParentalGate.svelte
function ParentalGate($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { manageDestination } = $$props;
		const managingPolicies = derived(() => parentalGateState.feature === "parentCenter");
		let keypadEl = void 0;
		function manageGatePolicies() {
			keypadEl?.querySelector("button")?.focus();
			redirectGateToParentCenter(manageDestination);
		}
		let $$settled = true;
		let $$inner_renderer;
		function $$render_inner($$renderer) {
			$$renderer.push(`<dialog class="parental-gate modal-dialog modal-fly-in modal-shell svelte-us2qoq" id="parentalGate" aria-labelledby="parentalGateTitle"><div${attr_class("gate-content svelte-us2qoq", void 0, { "shaking": parentalGateState.shaking })}${attr_style("", { "--gate-shake-duration": `400ms` })}>`);
			if (parentalGateState.unlocked) {
				$$renderer.push(`<!--[0--><div class="gate-success svelte-us2qoq" role="status"><span class="gate-success-badge svelte-us2qoq">`);
				Icon($$renderer, {
					name: "check",
					class: "gate-success-icon"
				});
				$$renderer.push(`<!----></span> <h2 class="gate-success-title svelte-us2qoq" id="parentalGateTitle">Unlocked!</h2> <p class="gate-success-sub svelte-us2qoq">You're all set.</p></div>`);
			} else {
				$$renderer.push("<!--[-1-->");
				DialogHeader($$renderer, { onclose: dismissGate });
				$$renderer.push(`<!----> <div class="gate-main svelte-us2qoq"><header class="gate-header svelte-us2qoq">`);
				SplotchyIcon($$renderer, { class: "gate-mascot" });
				$$renderer.push(`<!----> <div class="gate-heading svelte-us2qoq"><h2 class="gate-title svelte-us2qoq" id="parentalGateTitle">Grown-Ups Only</h2> <p class="gate-subtitle svelte-us2qoq">${escape_html(managingPolicies() ? "Solve the problem to manage grown-up checks" : "Solve the problem to continue")}</p></div></header> `);
				ParentalGateProblem($$renderer, {});
				$$renderer.push(`<!----> `);
				ParentalGateKeypad($$renderer, {
					get element() {
						return keypadEl;
					},
					set element($$value) {
						keypadEl = $$value;
						$$settled = false;
					}
				});
				$$renderer.push(`<!----> `);
				if (!managingPolicies()) {
					$$renderer.push("<!--[0-->");
					ParentalGateManageFooter($$renderer, { onManage: manageGatePolicies });
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div>`);
			}
			$$renderer.push(`<!--]--></div></dialog>`);
		}
		do {
			$$settled = true;
			$$inner_renderer = $$renderer.copy();
			$$render_inner($$inner_renderer);
		} while (!$$settled);
		$$renderer.subsume($$inner_renderer);
	});
}
//#endregion
export { PORTRAIT_ROWS as i, LANDSCAPE_ROWS as n, PICKER_DIM_BORDER as r, ParentalGate as t };
