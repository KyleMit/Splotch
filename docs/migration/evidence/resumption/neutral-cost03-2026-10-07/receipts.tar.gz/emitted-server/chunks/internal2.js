//#region ../node_modules/@sveltejs/kit/src/runtime/app/env/internal.js
var version = "1.6.2783";
var building = false;
var prerendering = false;
function set_building() {
	building = true;
}
function set_prerendering() {
	prerendering = true;
}
//#endregion
export { version as a, set_prerendering as i, prerendering as n, set_building as r, building as t };
