import { h as html, l as head, n as attr_style } from "./server2.js";
import { t as dottie_stumped_default } from "./dottie-stumped.js";
//#region src/lib/components/ErrorScreen.svelte
function ErrorScreen($$renderer, $$props) {
	let { onRestart = () => location.assign("/") } = $$props;
	head("1cqwkza", $$renderer, ($$renderer) => {
		$$renderer.title(($$renderer) => {
			$$renderer.push(`<title>Oops! · Splotch</title>`);
		});
	});
	$$renderer.push(`<div class="error-screen svelte-1cqwkza" role="alert"><div class="error-dottie svelte-1cqwkza" aria-hidden="true"${attr_style("", {
		width: "128px",
		height: "128px"
	})}>${html(dottie_stumped_default)}</div> <h1 class="svelte-1cqwkza">Oops!</h1> <p class="svelte-1cqwkza">Something went wrong.<br/>Let's start a fresh drawing.</p> <button type="button" class="error-restart svelte-1cqwkza">Start over</button></div>`);
}
//#endregion
export { ErrorScreen as t };
