import { r as tick } from "./index-server.js";
import { E as attr, Ft as run, O as escape_html, c as ensure_array_like, o as derived, s as element, t as attr_class } from "./server2.js";
import { n as IMAGE_REPORT_FORM_FIELDS } from "./imageReport.js";
import { i as attachesDevice } from "./report.js";
import { n as looksLikeApiKey, r as looksLikeRetiredGeminiKey } from "./keyFormat.js";
import "./idle.js";
import { t as Button } from "./Button.js";
import { t as SplotchyIcon } from "./SplotchyIcon.js";
import { n as Icon } from "./Icon.js";
import { t as releases_default } from "./releases.js";
import { t as VisuallyHidden } from "./VisuallyHidden.js";
import { t as ExternalMark } from "./ExternalMark.js";
import { r as PHONE_LANDSCAPE_QUERY } from "./breakpoints.js";
import { l as orientationLockApplies, n as autoOrientationOverridesSystemLock, r as getPlatform } from "./platform.js";
import { a as readString, d as writeString, f as STORAGE_KEYS, n as onDurableRestore } from "./storage.js";
import { i as prefersReducedMotion } from "./reducedMotion.js";
import { C as setSoundVolume, D as setToolbarStyle, E as setToolDrawerEnabled, O as setUndoButton, S as setSound, T as setTheme, _ as setMagicBrush, a as orientationChoice, b as setSaveOnDelete, c as setAiImage, d as setColoringPacksAllowMetered, f as setCrayon, g as setEraser, h as setDrawingSound, k as settingsState, l as setAutoSaveAi, n as actionControlShown, o as setActionButtonScale, p as setDeleteSound, r as aiCredentialKind, s as setAiCustomization, t as TOOL_DRAWER_CONTROLS, u as setColoringBook, v as setOrientationChoice, w as setStrokeWidthControl, x as setScreenshot, y as setPencilEraserEnabled } from "./settings.svelte.js";
import { C as playVolumePreview, T as stopDrawSound, _ as NETWORK_ERROR_MESSAGE, a as maxActionButtonScale, p as freeGenerationsState, v as createLatestRequest, x as layoutState, y as apiUrl } from "./actionButtonLayout.js";
import { i as setResolvedTheme, n as resolvedTheme, r as setReducedMotion, t as reducedMotion } from "./appearance.svelte.js";
import { t as BOOKS } from "./books.js";
import { t as clearOverlay } from "./coloringBook.svelte.js";
import { C as settingsModal, S as setResizingActionButtons, T as buttonCenter, a as endsParentCenterProtection, c as isParentalGateModeAvailable, d as requireParentalGate, f as requiresParentalGate, g as SETTINGS_MODAL_ID, l as parentalGateState, n as PARENTAL_GATE_FEATURES, p as setParentalGateMode, r as PARENTAL_GATE_MODES, s as isParentCenterUnprotected, w as uiState } from "./parentalGate.svelte.js";
import { n as fullscreenState } from "./persistedStateStatus.svelte.js";
import { c as setUserSubmittedAiUserApiKey, d as setUserSubmittedAiAccessToken, i as changeSaveFolder, r as sessionCountersState } from "./sessionCounters.svelte.js";
import { a as isIosOutsideSafari, i as installState, n as installDeviceOs, o as promptInstall } from "./install.svelte.js";
import { r as notifyColoringPackPolicyChanged } from "./policy.js";
import { t as RuleLabel } from "./RuleLabel.js";
import { t as StatusMessage } from "./StatusMessage.js";
import "./deferredIcons.js";
import { t as Disclosure } from "./Disclosure.js";
import { t as ScrollCue } from "./ScrollCue.js";
import { t as SegmentedPicker } from "./SegmentedPicker.js";
import { t as ReleaseSectionHeading } from "./ReleaseSectionHeading.js";
import { n as SectionIcon, t as SidebarToc } from "./SidebarToc.js";
import { n as ToggleSwitch, r as SliderRow, t as ToggleRow } from "./ToggleRow.js";
import { n as APP_VERSION, o as slide, r as calm, t as ReportFields } from "./ReportFields.js";
import "./parentalGateLink.js";
import { i as waitForDialogRetirement, t as DIALOG_CLOSING_CLASS } from "./modalDialog.svelte.js";
import { n as coloringPacksState } from "./coloringPacks2.svelte.js";
import { t as DialogHeader } from "./DialogHeader.js";
import { r as folderSaveSupported } from "./folderSave2.js";
import { t as GITHUB_REPO_URL } from "./githubRepo.js";
//#region src/lib/components/settings/OrientationPicker.svelte
function OrientationPicker($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		const options = [
			{
				value: "portrait",
				label: "Portrait",
				icon: "mobile-portrait",
				id: "orientationOption-portrait"
			},
			{
				value: "landscape",
				label: "Landscape",
				icon: "mobile-landscape",
				id: "orientationOption-landscape"
			},
			{
				value: "auto",
				label: "Auto",
				icon: "mobile-rotate",
				id: "orientationOption-auto"
			}
		];
		const selected = derived(orientationChoice);
		$$renderer.push(`<div class="orientation-picker svelte-1f2cuze">`);
		SegmentedPicker($$renderer, {
			label: "Orientation",
			class: "orientation-track",
			options,
			selected: selected(),
			onSelect: setOrientationChoice
		});
		$$renderer.push(`<!----></div>`);
	});
}
//#endregion
//#region src/lib/components/settings/AppearanceSection.svelte
function AppearanceSection($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		const showOrientationControls = derived(() => orientationLockApplies(fullscreenState.active));
		const autoFollowsSystemRotation = !autoOrientationOverridesSystemLock();
		const toolbarOptions = [{
			value: "buttons",
			label: "Raised",
			icon: "button-style-raised"
		}, {
			value: "bare",
			label: "Flat",
			icon: "button-style-flat"
		}];
		const themeOptions = [
			{
				value: "light",
				label: "Light",
				icon: "theme-light",
				id: "themeOption-light"
			},
			{
				value: "dark",
				label: "Dark",
				icon: "theme-dark",
				id: "themeOption-dark"
			},
			{
				value: "system",
				label: "System",
				icon: "theme-auto",
				id: "themeOption-system"
			}
		];
		$$renderer.push(`<section class="setting-group"><div class="setting"><div class="appearance-label svelte-a5dcr5">`);
		Icon($$renderer, {
			name: "theme-auto",
			class: "setting-icon"
		});
		$$renderer.push(`<!----> <span class="appearance-title svelte-a5dcr5">Theme</span></div> `);
		SegmentedPicker($$renderer, {
			label: "Theme",
			options: themeOptions,
			selected: settingsState.theme,
			onSelect: setTheme
		});
		$$renderer.push(`<!----></div> <div class="setting"><div class="appearance-label svelte-a5dcr5">`);
		Icon($$renderer, {
			name: "button-style-raised",
			class: "setting-icon"
		});
		$$renderer.push(`<!----> <span class="appearance-title svelte-a5dcr5">Button style</span></div> `);
		SegmentedPicker($$renderer, {
			label: "Button style",
			options: toolbarOptions,
			selected: settingsState.toolbarStyle,
			onSelect: setToolbarStyle
		});
		$$renderer.push(`<!----></div> `);
		if (showOrientationControls()) {
			$$renderer.push(`<!--[0--><div class="setting"><div class="appearance-label svelte-a5dcr5">`);
			Icon($$renderer, {
				name: "mobile-rotate",
				class: "setting-icon"
			});
			$$renderer.push(`<!----> <span class="appearance-title svelte-a5dcr5">Orientation</span></div> `);
			OrientationPicker($$renderer, {});
			$$renderer.push(`<!----> `);
			if (autoFollowsSystemRotation) $$renderer.push(`<!--[0--><p class="orientation-note svelte-a5dcr5">Auto follows your device's rotation setting.</p>`);
			else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></section>`);
	});
}
//#endregion
//#region src/lib/components/settings/drawingTools.ts
var DRAWING_TOOL_META = {
	crayonEnabled: {
		id: "crayonToggle",
		label: "Crayon",
		icon: "brush-crayon",
		toggle: setCrayon
	},
	magicBrushEnabled: {
		id: "magicBrushToggle",
		label: "Magic brush",
		icon: "brush-magic",
		toggle: setMagicBrush
	},
	eraserEnabled: {
		id: "eraserToggle",
		label: "Eraser",
		icon: "brush-eraser",
		toggle: setEraser
	},
	strokeWidthControlEnabled: {
		id: "strokeWidthToggle",
		label: "Stroke width",
		icon: "line-weight-brush",
		toggle: setStrokeWidthControl
	},
	undoButtonEnabled: {
		id: "undoToggle",
		label: "Undo",
		icon: "undo",
		toggle: setUndoButton
	}
};
var DRAWING_TOOLS = TOOL_DRAWER_CONTROLS.map((setting) => ({
	setting,
	...DRAWING_TOOL_META[setting]
}));
/** Whether the parent has this tool switched on, regardless of the drawer switch above it. */
function isDrawingToolOn(tool) {
	return settingsState[tool.setting];
}
/** How many tools the parent has turned off — what the hub row reports. */
function hiddenDrawingToolCount() {
	return DRAWING_TOOLS.filter((tool) => !isDrawingToolOn(tool)).length;
}
//#endregion
//#region src/lib/components/settings/sections.ts
var SECTIONS = [
	{
		id: "appearance",
		label: "Appearance",
		icon: "appearance",
		contentStamp: "1"
	},
	{
		id: "sound",
		label: "Sound",
		icon: "sound",
		contentStamp: "2"
	},
	{
		id: "controls",
		label: "Tool Drawer",
		icon: "controls",
		contentStamp: "1"
	},
	{
		id: "accessibility",
		label: "Accessibility",
		icon: "accessibility",
		contentStamp: "2"
	},
	{
		id: "coloring",
		label: "Coloring",
		icon: "shapes",
		contentStamp: "1"
	},
	{
		id: "ai",
		label: "AI Art",
		icon: "wand-stars",
		contentStamp: "2"
	},
	{
		id: "saving",
		label: "Saving",
		icon: "save-picture",
		contentStamp: "1"
	},
	{
		id: "parentCenter",
		label: "Parent Center",
		icon: "parent-center",
		contentStamp: "1"
	},
	{
		id: "setup",
		label: "Install",
		icon: "setup",
		contentStamp: "1"
	},
	{
		id: "feedback",
		label: "Feedback",
		icon: "feedback",
		contentStamp: "1"
	},
	{
		id: "whatsnew",
		label: "What's New",
		title: "Updates",
		icon: "whats-new",
		contentStamp: APP_VERSION
	},
	{
		id: "about",
		label: "About",
		icon: "splotchy",
		contentStamp: "1"
	}
];
var SECTION_BY_ID = Object.fromEntries(SECTIONS.map((s) => [s.id, s]));
function isSectionId(id) {
	return Object.hasOwn(SECTION_BY_ID, id);
}
function sectionContentStamp(id) {
	return SECTION_BY_ID[id].contentStamp;
}
/** The heading a section carries once it is on screen, in either shell. */
function sectionHeading(id) {
	const meta = SECTION_BY_ID[id];
	return meta.title ?? meta.label;
}
var SECTION_SLIDE = { duration: 220 };
var ALL_TOOLS_SHOWING = "Pen, crayon, magic brush & more";
function sectionSubtitle(id) {
	switch (id) {
		case "appearance": {
			const parts = ["Night Mode"];
			const orientation = orientationChoice();
			if (orientation !== "auto") parts.push(`${orientation} lock`);
			return parts.join(" · ");
		}
		case "sound": {
			if (!settingsState.soundEnabled) return "Muted";
			if (!settingsState.drawingSoundEnabled && !settingsState.deleteSoundEnabled) return "No sources";
			const volume = `Volume ${settingsState.soundVolume}%`;
			if (settingsState.drawingSoundEnabled && settingsState.deleteSoundEnabled) return volume;
			return `${volume} · ${settingsState.drawingSoundEnabled ? "drawing" : "deleting"} only`;
		}
		case "saving": return settingsState.saveOnDeleteEnabled ? "Auto-save on" : "Auto-save off";
		case "coloring": {
			if (!settingsState.coloringBookEnabled) return "Coloring books off";
			const books = coloringPacksState.downloadedBookCount;
			return `${books} extra ${books === 1 ? "book" : "books"} ready`;
		}
		case "controls": {
			if (!settingsState.toolDrawerEnabled) return "Tool drawer off";
			const hidden = hiddenDrawingToolCount();
			if (!hidden) return ALL_TOOLS_SHOWING;
			return `${hidden} ${hidden === 1 ? "tool" : "tools"} hidden`;
		}
		case "accessibility": return "Make it easier to see and tap";
		case "ai": {
			if (!settingsState.aiImageEnabled) return "Turned off";
			const kind = aiCredentialKind();
			if (kind === "none") {
				const { grant } = freeGenerationsState;
				return grant.status === "available" ? `${grant.remaining} free ${grant.remaining === 1 ? "creation" : "creations"} left` : "Free allowance unavailable";
			}
			return kind === "apiKey" ? "Your OpenAI key" : "Access code";
		}
		case "parentCenter": return "Choose when grown-up checks appear";
		case "setup": return "Install & lock the app";
		case "whatsnew": return "See what's changed";
		case "feedback": return "Report a bug or share an idea";
		case "about": return `Version ${APP_VERSION}`;
	}
}
calm(slide, SECTION_SLIDE);
//#endregion
//#region src/lib/components/settings/SoundSection.svelte
function SoundSection($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		const PREVIEW_SPEED = .45;
		let previewingVolume = false;
		function previewVolume() {
			if (!settingsState.soundEnabled || !previewingVolume) return;
			playVolumePreview({
				speed: PREVIEW_SPEED,
				isStrokeStart: false
			});
		}
		function onVolumeActive(active) {
			previewingVolume = active;
			if (active) playVolumePreview({
				speed: PREVIEW_SPEED,
				isStrokeStart: true
			});
			else stopDrawSound();
		}
		function onVolumeInput(value) {
			setSoundVolume(value);
			previewVolume();
		}
		$$renderer.push(`<section class="setting-group"><div class="setting">`);
		ToggleRow($$renderer, {
			icon: settingsState.soundEnabled ? "volume-on" : "volume-off",
			label: "Sound",
			id: "soundToggle",
			checked: settingsState.soundEnabled,
			onToggle: setSound
		});
		$$renderer.push(`<!----> `);
		if (settingsState.soundEnabled) {
			$$renderer.push(`<!--[0--><div class="slider-setting svelte-1ozveb0">`);
			SliderRow($$renderer, {
				id: "soundVolumeLabel",
				label: "Volume",
				value: settingsState.soundVolume,
				min: 0,
				max: 100,
				snap: 50,
				onInput: onVolumeInput,
				onActiveChange: onVolumeActive
			});
			$$renderer.push(`<!----></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> `);
		if (settingsState.soundEnabled) {
			$$renderer.push(`<!--[0--><div class="sound-sources svelte-1ozveb0">`);
			RuleLabel($$renderer, {
				as: "h4",
				strong: true,
				class: "sources-heading",
				children: ($$renderer) => {
					$$renderer.push(`<!---->What makes sound`);
				},
				$$slots: { default: true }
			});
			$$renderer.push(`<!----> <div class="source-rows svelte-1ozveb0"><div class="setting">`);
			ToggleRow($$renderer, {
				icon: "brush-pen",
				label: "Drawing",
				id: "drawingSoundToggle",
				checked: settingsState.drawingSoundEnabled,
				onToggle: setDrawingSound
			});
			$$renderer.push(`<!----></div> <div class="setting">`);
			ToggleRow($$renderer, {
				icon: "trash-closed",
				label: "Deleting",
				id: "deleteSoundToggle",
				checked: settingsState.deleteSoundEnabled,
				onToggle: setDeleteSound
			});
			$$renderer.push(`<!----></div></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></section>`);
	});
}
//#endregion
//#region src/lib/components/settings/SavingSection.svelte
function SavingSection($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		const showFolderSave = folderSaveSupported();
		$$renderer.push(`<section class="setting-group"><div class="setting">`);
		ToggleRow($$renderer, {
			icon: "camera",
			label: "Camera button",
			id: "screenshotToggle",
			checked: settingsState.screenshotEnabled,
			onToggle: setScreenshot,
			help: "Shows the camera button in the tool drawer"
		});
		$$renderer.push(`<!----></div> <div class="setting">`);
		ToggleRow($$renderer, {
			icon: "camera-party",
			label: "Auto-Save on Delete",
			id: "saveOnDeleteToggle",
			checked: settingsState.saveOnDeleteEnabled,
			onToggle: setSaveOnDelete,
			help: "Saves the current drawing each time the page is cleared"
		});
		$$renderer.push(`<!----></div> `);
		if (showFolderSave) {
			$$renderer.push(`<!--[0--><div class="setting folder-location svelte-6qmqxp"><div class="folder-info svelte-6qmqxp">`);
			Icon($$renderer, {
				name: "folder",
				class: "setting-icon"
			});
			$$renderer.push(`<!----> <span class="folder-title svelte-6qmqxp">Save drawings to</span></div> `);
			if (settingsState.saveFolderName) {
				$$renderer.push(`<!--[0--><div class="folder-actions svelte-6qmqxp">`);
				Button($$renderer, {
					variant: "wash",
					size: "sm",
					class: "folder-pill",
					id: "changeSaveFolderButton",
					title: "Change folder",
					onclick: changeSaveFolder,
					children: ($$renderer) => {
						$$renderer.push(`<!---->${escape_html(settingsState.saveFolderName)}`);
					},
					$$slots: { default: true }
				});
				$$renderer.push(`<!----> <button class="folder-clear svelte-6qmqxp" id="forgetSaveFolderButton" aria-label="Forget folder" title="Forget folder">`);
				Icon($$renderer, {
					name: "close",
					class: "folder-clear-icon"
				});
				$$renderer.push(`<!----></button></div>`);
			} else {
				$$renderer.push("<!--[-1-->");
				Button($$renderer, {
					variant: "brand",
					size: "sm",
					class: "folder-change",
					id: "changeSaveFolderButton",
					onclick: changeSaveFolder,
					children: ($$renderer) => {
						$$renderer.push(`<!---->Choose folder`);
					},
					$$slots: { default: true }
				});
			}
			$$renderer.push(`<!--]--></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></section>`);
	});
}
//#endregion
//#region src/lib/components/settings/ColoringSection.svelte
function ColoringSection($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let removing = false;
		let removeError = false;
		const downloadedBookCount = derived(() => coloringPacksState.downloadedBookCount);
		const downloadableBookCount = derived(() => coloringPacksState.downloadableBookCount);
		const downloadingBookName = derived(() => BOOKS.find((book) => book.id === coloringPacksState.downloadingBookId)?.name ?? null);
		function megabytes(bytes) {
			return `${(bytes / 1e6).toFixed(1)} MB`;
		}
		function setAllowMetered(next) {
			setColoringPacksAllowMetered(next);
			notifyColoringPackPolicyChanged();
		}
		function setColoringBooksEnabled(next) {
			setColoringBook(next);
			if (!next) clearOverlay();
			notifyColoringPackPolicyChanged();
		}
		async function removeDownloadedPictures() {
			removing = true;
			removeError = false;
			try {
				const { removeDownloadedColoringPacks } = await import("./manager.js");
				await removeDownloadedColoringPacks();
			} catch {
				removeError = true;
			} finally {
				removing = false;
			}
		}
		$$renderer.push(`<section class="setting-group"><div class="setting">`);
		ToggleRow($$renderer, {
			icon: "shapes",
			label: "Coloring book",
			id: "coloringBookToggle",
			checked: settingsState.coloringBookEnabled,
			onToggle: setColoringBooksEnabled,
			help: "Show coloring pages and download new books automatically"
		});
		$$renderer.push(`<!----></div> <div class="setting">`);
		ToggleRow($$renderer, {
			icon: "download",
			label: "Download over mobile data",
			id: "coloringPacksMeteredToggle",
			checked: settingsState.coloringPacksAllowMetered,
			onToggle: setAllowMetered,
			help: "Allows automatic picture downloads when Wi-Fi isn't available",
			disabled: !settingsState.coloringBookEnabled
		});
		$$renderer.push(`<!----></div> <div class="setting pack-storage svelte-wbfm42"><div class="pack-summary svelte-wbfm42">`);
		Icon($$renderer, {
			name: "picture-stack",
			class: "setting-icon"
		});
		$$renderer.push(`<!----> <div><span class="pack-title svelte-wbfm42">Downloaded pictures</span> `);
		if (coloringPacksState.initialized) {
			$$renderer.push(`<!--[0--><p class="svelte-wbfm42">${escape_html(downloadedBookCount())} of ${escape_html(downloadableBookCount())} extra books · ${escape_html(megabytes(coloringPacksState.downloadedBytes))}</p> `);
			if (downloadingBookName()) $$renderer.push(`<!--[0--><p class="svelte-wbfm42">Downloading ${escape_html(downloadingBookName())} in the background</p>`);
			else if (downloadedBookCount() === downloadableBookCount()) $$renderer.push(`<!--[1--><p class="svelte-wbfm42">Every coloring book is ready offline</p>`);
			else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		} else if (!settingsState.coloringBookEnabled) $$renderer.push(`<!--[1--><p class="svelte-wbfm42">Storage details are unavailable while coloring books are off</p>`);
		else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div> `);
		Button($$renderer, {
			variant: "danger",
			size: "sm",
			disabled: removing || coloringPacksState.initialized && downloadedBookCount() === 0,
			onclick: removeDownloadedPictures,
			children: ($$renderer) => {
				$$renderer.push(`<!---->${escape_html(removing ? "Removing…" : "Remove downloaded pictures")}`);
			},
			$$slots: { default: true }
		});
		$$renderer.push(`<!----> `);
		if (removeError) $$renderer.push(`<!--[0--><p class="remove-error svelte-wbfm42">Downloaded pictures could not be removed. Try again.</p>`);
		else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></section>`);
	});
}
//#endregion
//#region src/lib/components/settings/ControlsSection.svelte
function ControlsSection($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		const toolOptions = DRAWING_TOOLS.map(({ id, label, icon }) => ({
			value: id,
			label,
			icon,
			id
		}));
		const shownTools = derived(() => DRAWING_TOOLS.filter(isDrawingToolOn).map((tool) => tool.id));
		function toggleTool(id) {
			const tool = DRAWING_TOOLS.find((entry) => entry.id === id);
			if (tool) tool.toggle(!isDrawingToolOn(tool));
		}
		const useChips = derived(() => false);
		$$renderer.push(`<section class="setting-group"><div class="setting">`);
		ToggleRow($$renderer, {
			icon: "dashboard-customize",
			label: "Enable tool drawer",
			id: "toolDrawerToggle",
			checked: settingsState.toolDrawerEnabled,
			onToggle: setToolDrawerEnabled,
			help: "Shows the brushes, stroke width, and undo in the drawer"
		});
		$$renderer.push(`<!----></div> `);
		if (settingsState.toolDrawerEnabled) {
			$$renderer.push(`<!--[0--><div class="tool-drawer-settings svelte-1k5fhex"><div class="tools-block svelte-1k5fhex">`);
			RuleLabel($$renderer, {
				as: "h4",
				strong: true,
				class: "tools-heading",
				children: ($$renderer) => {
					$$renderer.push(`<!---->Drawing Tools`);
				},
				$$slots: { default: true }
			});
			$$renderer.push(`<!----> `);
			if (useChips()) {
				$$renderer.push("<!--[0-->");
				SegmentedPicker($$renderer, {
					variant: "chip",
					mode: "toggle",
					class: "control-chips",
					label: "Drawing Tools",
					options: toolOptions,
					selected: shownTools(),
					onSelect: toggleTool
				});
			} else {
				$$renderer.push(`<!--[-1--><div class="tool-rows svelte-1k5fhex"><!--[-->`);
				const each_array = ensure_array_like(DRAWING_TOOLS);
				for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
					let tool = each_array[$$index];
					$$renderer.push(`<div class="setting">`);
					ToggleRow($$renderer, {
						icon: tool.icon,
						label: tool.label,
						id: tool.id,
						checked: isDrawingToolOn(tool),
						onToggle: tool.toggle
					});
					$$renderer.push(`<!----></div>`);
				}
				$$renderer.push(`<!--]--></div>`);
			}
			$$renderer.push(`<!--]--></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (settingsState.applePencilSeen && actionControlShown("eraserEnabled")) {
			$$renderer.push(`<!--[0--><div class="setting pencil-eraser svelte-1k5fhex">`);
			ToggleRow($$renderer, {
				icon: "brush-eraser",
				label: "Apple Pencil double-tap to erase",
				id: "pencilEraserToggle",
				checked: settingsState.pencilEraserEnabled,
				onToggle: setPencilEraserEnabled,
				help: "Double-tap an Apple Pencil to switch between drawing and erasing"
			});
			$$renderer.push(`<!----></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></section>`);
	});
}
//#endregion
//#region src/lib/components/settings/ButtonSizeSetting.svelte
function ButtonSizeSetting($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		const scaleCeiling = derived(maxActionButtonScale);
		const displayedScale = derived(() => Math.min(settingsState.actionButtonScale, scaleCeiling()));
		$$renderer.push(`<div class="setting button-size-setting">`);
		SliderRow($$renderer, {
			id: "accessibilityButtonScaleLabel",
			label: "Button Size",
			icon: "photo-size-select-small",
			value: displayedScale(),
			min: 70,
			max: scaleCeiling(),
			snap: scaleCeiling() > 100 ? 100 : void 0,
			help: "Bigger buttons help small or unsteady hands",
			onInput: setActionButtonScale,
			onActiveChange: setResizingActionButtons
		});
		$$renderer.push(`<!----></div>`);
	});
}
//#endregion
//#region src/lib/components/settings/AccessibilitySection.svelte
function AccessibilitySection($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		$$renderer.push(`<section class="setting-group">`);
		ButtonSizeSetting($$renderer, {});
		$$renderer.push(`<!----> <div class="setting">`);
		ToggleRow($$renderer, {
			icon: "reduce-motion",
			label: "Reduce Motion",
			id: "reduceMotionToggle",
			checked: reducedMotion(),
			onToggle: setReducedMotion,
			help: "Calmer screens help children who are sensitive to movement"
		});
		$$renderer.push(`<!----></div></section>`);
	});
}
//#endregion
//#region src/lib/components/settings/aiSettingsCopy.ts
var AI_CREATE_LABEL = "Create AI Images";
var AI_CREATE_HELP = {
	off: "Turns a finished drawing into an AI picture based on it.",
	on: "A finished drawing can now be turned into an AI picture based on it."
};
var AI_CUSTOMIZATION_LABEL = "Customize AI Style";
var AI_CUSTOMIZATION_HELP = "Offers a small set of distinct styles to pick from before the picture is generated.";
var AI_AUTO_SAVE_LABEL = "Auto-Save AI Images";
function aiAutoSaveHelp(canChooseFolder) {
	return canChooseFolder ? "Saves each AI picture and the drawing behind it to your downloads, or to your chosen folder" : "Saves each AI picture and the drawing behind it to your downloads";
}
//#endregion
//#region src/lib/components/settings/AiFeatureToggles.svelte
function AiFeatureToggles($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		$$renderer.push(`<section class="setting-group"><div class="setting">`);
		ToggleRow($$renderer, {
			icon: "customize",
			label: AI_CUSTOMIZATION_LABEL,
			id: "aiCustomizationToggle",
			checked: settingsState.aiCustomizationEnabled,
			onToggle: setAiCustomization,
			help: AI_CUSTOMIZATION_HELP
		});
		$$renderer.push(`<!----></div> <div class="setting">`);
		ToggleRow($$renderer, {
			icon: "download",
			label: AI_AUTO_SAVE_LABEL,
			id: "autoSaveAiToggle",
			checked: settingsState.autoSaveAiEnabled,
			onToggle: setAutoSaveAi,
			help: aiAutoSaveHelp(folderSaveSupported())
		});
		$$renderer.push(`<!----></div></section>`);
	});
}
//#endregion
//#region src/lib/components/settings/AiValueProp.svelte
function AiValueProp($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		const STEPS = [
			{
				number: 1,
				caption: "They draw",
				alt: "A child's colorful crayon drawing of a smiling person"
			},
			{
				number: 2,
				caption: "One magic tap",
				alt: "The same drawing with the AI picture button glowing over it"
			},
			{
				number: 3,
				caption: "Ta-da!",
				alt: "The drawing transformed into a colorful storybook character"
			}
		];
		const theme = derived(resolvedTheme);
		const credentialKind = derived(aiCredentialKind);
		const freeRemaining = derived(() => freeGenerationsState.lastGrantRemaining ?? 10);
		$$renderer.push(`<section class="ai-value-prop svelte-1l1q0w8" aria-labelledby="ai-value-prop-title"><h3 id="ai-value-prop-title" class="svelte-1l1q0w8">What turning this on does</h3> <p class="ai-value-prop-body svelte-1l1q0w8">One tap on a finished drawing, and it comes back as a storybook picture — same colors, same
    character, same big smile.</p> <ol class="ai-value-prop-steps svelte-1l1q0w8"><!--[-->`);
		const each_array = ensure_array_like(STEPS);
		for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
			let step = each_array[$$index];
			$$renderer.push(`<li class="svelte-1l1q0w8"><div class="ai-value-prop-image-wrap svelte-1l1q0w8"><img${attr("src", `/ai-value-prop/step-${step.number}.${theme()}.webp`)}${attr("alt", step.alt)} width="556" height="426" loading="lazy" decoding="async" class="svelte-1l1q0w8"/> <span class="ai-value-prop-badge svelte-1l1q0w8" aria-hidden="true">${escape_html(step.number)}</span></div> <span class="ai-value-prop-caption svelte-1l1q0w8">${escape_html(step.caption)}</span></li>`);
		}
		$$renderer.push(`<!--]--></ol> <ul class="ai-value-prop-claims svelte-1l1q0w8"><li class="svelte-1l1q0w8">`);
		Icon($$renderer, {
			name: "check",
			class: "ai-value-prop-claim-icon"
		});
		$$renderer.push(`<!----> <span>`);
		if (credentialKind() === "accessCode") $$renderer.push(`<!--[0-->Your access code is saved — turn this on whenever you're ready.`);
		else if (credentialKind() === "apiKey") $$renderer.push(`<!--[1-->Your OpenAI key is saved and ready whenever you turn this on.`);
		else if (freeRemaining() === 0) $$renderer.push(`<!--[2-->Your ${escape_html(10)} free pictures are used up.`);
		else if (freeRemaining() < 10) $$renderer.push(`<!--[3-->You have ${escape_html(freeRemaining())} free ${escape_html(freeRemaining() === 1 ? "picture" : "pictures")} left — nothing
          to set up, no card.`);
		else $$renderer.push(`<!--[-1-->The first ${escape_html(10)} pictures are free — nothing to set up, no card.`);
		$$renderer.push(`<!--]--></span></li> <li class="svelte-1l1q0w8">`);
		Icon($$renderer, {
			name: "lock",
			class: "ai-value-prop-claim-icon"
		});
		$$renderer.push(`<!----> <span>`);
		if (credentialKind() === "accessCode") $$renderer.push(`<!--[0-->AI art is on us with your access code — no OpenAI key needed.`);
		else if (credentialKind() === "apiKey") $$renderer.push(`<!--[1-->Your key stays saved on this device only.`);
		else $$renderer.push(`<!--[-1-->After that, use your own OpenAI key — saved on this device only.`);
		$$renderer.push(`<!--]--></span></li></ul></section>`);
	});
}
//#endregion
//#region src/lib/components/settings/OpenAiKeyHowTo.svelte
function OpenAiKeyHowTo($$renderer) {
	$$renderer.push(`<div class="openai-key-howto svelte-1t7btji">`);
	{
		function summary($$renderer) {
			$$renderer.push(`<!---->How do I get an OpenAI API key?`);
		}
		Disclosure($$renderer, {
			class: "byok-howto",
			summary,
			children: ($$renderer) => {
				$$renderer.push(`<ol><li>Open <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer">the OpenAI API keys page`);
				ExternalMark($$renderer, { variant: "inline" });
				$$renderer.push(`<!----></a>.</li> <li>Sign in, or create an OpenAI account.</li> <li>Under <strong>Settings → Organization</strong>, finish <strong>verification</strong>. OpenAI requires it before any key can make pictures. Do this <em>before</em> the next step — a key made without it saves here perfectly and then fails when
        the picture button is tapped.</li> <li>Click <strong>Create new secret key</strong>, then copy it (it starts with <code>sk-…</code>) and paste it below. You only get to see it once.</li></ol> <p class="byok-howto-note svelte-1t7btji">OpenAI bills picture-making usage to your account at its own rates, and requires the account
      to have billing set up before a key can make pictures. Sent an access code by us instead?
      Paste that in the same box — it works there too.</p>`);
			},
			$$slots: {
				summary: true,
				default: true
			}
		});
	}
	$$renderer.push(`<!----></div>`);
}
//#endregion
//#region src/lib/ai/verifyCredential.ts
async function verifyCredential(value, { signal } = {}) {
	if (looksLikeRetiredGeminiKey(value)) return {
		ok: false,
		kind: "retiredGeminiKey"
	};
	const kind = looksLikeApiKey(value) ? "apiKey" : "accessCode";
	const endpoint = kind === "apiKey" ? "/api/verify-key" : "/api/verify-access-code";
	const body = kind === "apiKey" ? { apiKey: value } : { code: value };
	const res = await fetch(apiUrl(endpoint), {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(body),
		signal
	});
	const raw = await res.json().catch(() => null);
	const data = typeof raw === "object" && raw !== null ? raw : {};
	const error = typeof data.error === "string" ? data.error : void 0;
	if (data.code === "KEY_CHECK_UNAVAILABLE") return {
		ok: false,
		kind: "checkUnavailable",
		error
	};
	if (!res.ok || data.ok !== true) return {
		ok: false,
		kind,
		error
	};
	if (kind === "apiKey") return {
		ok: true,
		kind
	};
	return typeof data.accessCode === "string" && data.accessCode !== "" ? {
		ok: true,
		kind,
		accessCode: data.accessCode
	} : {
		ok: false,
		kind,
		error
	};
}
//#endregion
//#region src/lib/components/settings/AiKeyManager.svelte
function AiKeyManager($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		const KEY_MESSAGES = {
			invalid: {
				apiKey: "That key didn't work. Double-check it and try again.",
				accessCode: "That doesn't look like a valid key or access code. Please try again.",
				retiredGeminiKey: "That looks like a Google Gemini key. Splotch now uses OpenAI — create a key at platform.openai.com and paste that one instead.",
				checkUnavailable: "We couldn't check that key just now. Please try again."
			},
			saveFailed: {
				apiKey: "Your key works, but could not be saved securely on this device. Close and reopen Splotch, then try again.",
				accessCode: "Your credential works, but could not be saved securely. Close and reopen Splotch, then try again."
			},
			accepted: {
				apiKey: "Your key works and has been accepted!",
				accessCode: "Access granted! You have special access — no API key needed."
			}
		};
		const KEY_STORAGE_NOTE = {
			ios: "Your key is saved in this device's iOS Keychain — encrypted by the system and kept only on this device.",
			android: "Your key is saved in this device's Android Keystore — encrypted by the system and kept only on this device.",
			web: "Your key is encrypted and stored only in this browser on this device."
		};
		const FORGET_FAILED_MESSAGES = {
			apiKey: "Your key could not be removed securely. Close and reopen Splotch, then try again.",
			accessCode: "Your access code could not be removed securely. Close and reopen Splotch, then try again."
		};
		let keyInput = "";
		let keyStatus = "idle";
		let keyMessage = "";
		let credentialKind = derived(aiCredentialKind);
		let hasApiKey = derived(() => credentialKind() === "apiKey");
		let aiLocked = derived(() => credentialKind() === "none");
		const freeGrant = derived(() => freeGenerationsState.grant);
		const latest = createLatestRequest();
		let maskedKey = derived(() => maskSecret(settingsState.aiUserApiKey));
		function maskSecret(value) {
			if (!value) return "";
			if (value.length <= 4) return "*".repeat(value.length);
			return "*".repeat(value.length - 4) + value.slice(-4);
		}
		const keyStorageNote = KEY_STORAGE_NOTE[getPlatform()];
		function resetKeyFeedback() {
			keyStatus = "idle";
			keyMessage = "";
		}
		function toggleAiImage(next) {
			if (!next) {
				latest.cancel();
				resetKeyFeedback();
			}
			setAiImage(next);
		}
		async function persistCredential(result, value, id) {
			const ownsRequest = () => latest.isCurrent(id);
			const persisted = result.kind === "apiKey" ? await setUserSubmittedAiUserApiKey(value, ownsRequest) : await setUserSubmittedAiAccessToken(result.accessCode, ownsRequest);
			if (!persisted && ownsRequest()) throw new Error("Credential write refused");
			return persisted;
		}
		async function submitKey() {
			const value = keyInput.trim();
			if (!value || keyStatus === "busy") return;
			const { id, signal } = latest.begin();
			keyStatus = "busy";
			keyMessage = "";
			try {
				const result = await verifyCredential(value, { signal });
				if (!latest.isCurrent(id)) return;
				if (!result.ok) {
					keyStatus = "error";
					keyMessage = result.error || KEY_MESSAGES.invalid[result.kind];
					return;
				}
				let persisted;
				try {
					persisted = await persistCredential(result, value, id);
				} catch {
					if (latest.isCurrent(id)) {
						keyStatus = "error";
						keyMessage = KEY_MESSAGES.saveFailed[result.kind];
					}
					return;
				}
				if (!persisted || !latest.isCurrent(id)) return;
				setAiImage(true);
				keyInput = "";
				keyStatus = "success";
				keyMessage = KEY_MESSAGES.accepted[result.kind];
			} catch {
				if (latest.isCurrent(id)) {
					keyStatus = "error";
					keyMessage = NETWORK_ERROR_MESSAGE;
				}
			}
		}
		async function forgetCredential(kind, clear) {
			try {
				if (!await clear()) throw new Error("Credential write refused");
			} catch {
				keyStatus = "error";
				keyMessage = FORGET_FAILED_MESSAGES[kind];
				return;
			}
			keyInput = "";
			resetKeyFeedback();
		}
		function forgetKey() {
			return forgetCredential("apiKey", () => setUserSubmittedAiUserApiKey(""));
		}
		function forgetAccessCode() {
			return forgetCredential("accessCode", () => setUserSubmittedAiAccessToken(""));
		}
		$$renderer.push(`<div class="ai-settings-stack svelte-1gbewem"><section class="setting-group ai-primary-toggle svelte-1gbewem"><div class="setting svelte-1gbewem">`);
		ToggleRow($$renderer, {
			icon: "wand-stars",
			label: AI_CREATE_LABEL,
			id: "aiImageToggle",
			checked: settingsState.aiImageEnabled,
			onToggle: toggleAiImage,
			help: settingsState.aiImageEnabled ? AI_CREATE_HELP.on : AI_CREATE_HELP.off
		});
		$$renderer.push(`<!----></div></section> `);
		if (!settingsState.aiImageEnabled) {
			$$renderer.push(`<!--[0--><div>`);
			AiValueProp($$renderer, {});
			$$renderer.push(`<!----></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (settingsState.aiImageEnabled) {
			$$renderer.push(`<!--[0--><div class="ai-enabled-settings svelte-1gbewem"><section class="setting-group svelte-1gbewem">`);
			if (aiLocked()) {
				$$renderer.push(`<!--[0--><div class="setting byok"><p class="byok-intro svelte-1gbewem">`);
				if (freeGrant().status === "loading") $$renderer.push(`<!--[0--><strong>Checking your free AI creations…</strong>`);
				else if (freeGrant().status === "available" && freeGrant().remaining > 0) $$renderer.push(`<!--[1--><strong>${escape_html(freeGrant().remaining)} free AI ${escape_html(freeGrant().remaining === 1 ? "creation" : "creations")} left.</strong> No setup is needed. After those are used, add your own OpenAI API key to keep creating.`);
				else if (freeGrant().status === "available") $$renderer.push(`<!--[2--><strong>Your ${escape_html(10)} free AI creations are used up.</strong> Add your
                own OpenAI API key to keep creating.`);
				else $$renderer.push(`<!--[-1-->Add your own OpenAI API key to create AI art while the free allowance is
                unavailable.`);
				$$renderer.push(`<!--]--> Your key is saved only on this device, used only for pictures made here, and billed to your
              OpenAI account. We never keep a copy of it.</p> `);
				OpenAiKeyHowTo($$renderer, {});
				$$renderer.push(`<!----> <label class="access-code-label svelte-1gbewem" for="aiKeyInput">OpenAI API Key</label> <div class="access-code-row svelte-1gbewem"><input id="aiKeyInput" class="access-code-input svelte-1gbewem" type="text" inputmode="text" autocomplete="off" autocapitalize="none" spellcheck="false" placeholder="Paste your OpenAI API key"${attr("value", keyInput)}/> `);
				Button($$renderer, {
					variant: "brand",
					class: "access-code-submit",
					onclick: submitKey,
					disabled: !keyInput.trim() || keyStatus === "busy",
					children: ($$renderer) => {
						$$renderer.push(`<!---->${escape_html(keyStatus === "busy" ? "Checking…" : "Save")}`);
					},
					$$slots: { default: true }
				});
				$$renderer.push(`<!----></div> <p class="byok-storage-note svelte-1gbewem">`);
				Icon($$renderer, {
					name: "lock",
					class: "byok-storage-icon"
				});
				$$renderer.push(`<!---->${escape_html(keyStorageNote)}</p></div>`);
			} else {
				$$renderer.push(`<!--[-1--><div class="setting byok byok-active svelte-1gbewem">`);
				if (hasApiKey()) {
					$$renderer.push(`<!--[0--><p class="byok-intro svelte-1gbewem">You're using <strong>your own OpenAI API key</strong>. Usage is billed to your
                OpenAI account. Forget the key any time to switch it off.</p> <label class="access-code-label svelte-1gbewem" for="aiKeyActive">OpenAI API Key</label> <div class="access-code-row svelte-1gbewem"><input id="aiKeyActive" class="access-code-input svelte-1gbewem" type="text" readonly="" aria-label="Saved OpenAI API key (masked)"${attr("value", maskedKey())}/> `);
					Button($$renderer, {
						variant: "danger",
						class: "access-code-submit",
						onclick: forgetKey,
						children: ($$renderer) => {
							$$renderer.push(`<!---->Forget`);
						},
						$$slots: { default: true }
					});
					$$renderer.push(`<!----></div> <p class="byok-storage-note svelte-1gbewem">`);
					Icon($$renderer, {
						name: "lock",
						class: "byok-storage-icon"
					});
					$$renderer.push(`<!---->${escape_html(keyStorageNote)}</p>`);
				} else {
					$$renderer.push(`<!--[-1--><p class="byok-intro svelte-1gbewem">You have <strong>special access</strong> via an access code — AI art is on us, no API
                key needed. Forget the code any time to remove it.</p> <label class="access-code-label svelte-1gbewem" for="aiCodeActive">Access Code</label> <div class="access-code-row svelte-1gbewem"><input id="aiCodeActive" class="access-code-input svelte-1gbewem" type="text" readonly="" aria-label="Saved access code"${attr("value", settingsState.aiAccessToken)}/> `);
					Button($$renderer, {
						variant: "danger",
						class: "access-code-submit",
						onclick: forgetAccessCode,
						children: ($$renderer) => {
							$$renderer.push(`<!---->Forget`);
						},
						$$slots: { default: true }
					});
					$$renderer.push(`<!----></div>`);
				}
				$$renderer.push(`<!--]--></div>`);
			}
			$$renderer.push(`<!--]--> `);
			if (keyMessage) {
				$$renderer.push("<!--[0-->");
				StatusMessage($$renderer, {
					status: keyStatus === "error" ? "error" : "success",
					class: "key-status",
					children: ($$renderer) => {
						$$renderer.push(`<!---->${escape_html(keyMessage)}`);
					},
					$$slots: { default: true }
				});
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></section> `);
			AiFeatureToggles($$renderer, {});
			$$renderer.push(`<!----></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div>`);
	});
}
//#endregion
//#region src/lib/components/settings/ParentCenterSection.svelte
function ParentCenterSection($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		const MODE_LABELS = {
			always: "Every time",
			session: "Per session",
			never: "Never"
		};
		const MODE_OPTIONS = PARENTAL_GATE_MODES.map((mode) => ({
			value: mode,
			label: MODE_LABELS[mode]
		}));
		const PROTECTED_FEATURES = {
			aiImage: {
				label: "Generating an AI image",
				help: "Before a drawing is sent to OpenAI for image generation."
			},
			imageReport: {
				label: "Reporting an AI result",
				help: "Before a drawing and either a generated picture or safety refusal are sent for review."
			},
			externalLinks: {
				label: "Viewing external links",
				help: "Before a link opens another website or app."
			},
			feedback: {
				label: "Sending feedback",
				help: "Before a report is sent to Splotch's issue tracker."
			},
			parentCenter: {
				label: "Opening Parent Center",
				help: "Before anyone can change these protections."
			}
		};
		const platform = getPlatform();
		const parentCenterUnprotected = derived(isParentCenterUnprotected);
		function optionsFor(feature) {
			return MODE_OPTIONS.map((option) => ({
				...option,
				disabled: !isParentalGateModeAvailable(feature, option.value, platform)
			}));
		}
		function chooseMode(feature, mode) {
			if (endsParentCenterProtection(feature, mode));
			else setParentalGateMode(feature, mode);
		}
		function confirmUnprotected() {
			setParentalGateMode("parentCenter", "never");
		}
		function cancelUnprotected() {}
		$$renderer.push(`<section class="setting-group parent-center"><p class="parent-center-intro svelte-1nye42e">Choose when Splotch should ask for a grown-up check. Each action includes a short explanation so
    you can see what the protection is for.</p> <div class="policy-list svelte-1nye42e"><div class="policy-header svelte-1nye42e" aria-hidden="true"><span>Action</span> <div class="policy-header-modes svelte-1nye42e"><!--[-->`);
		const each_array = ensure_array_like(PARENTAL_GATE_MODES);
		for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
			let mode = each_array[$$index];
			$$renderer.push(`<span>${escape_html(MODE_LABELS[mode])}</span>`);
		}
		$$renderer.push(`<!--]--></div></div> <!--[-->`);
		const each_array_1 = ensure_array_like(PARENTAL_GATE_FEATURES);
		for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
			let featureId = each_array_1[$$index_1];
			const feature = PROTECTED_FEATURES[featureId];
			const helpId = `parental-gate-${featureId}-help`;
			const unavailableHelpId = isParentalGateModeAvailable(featureId, "never", platform) ? void 0 : `parental-gate-${featureId}-unavailable`;
			const warningId = featureId === "parentCenter" && parentCenterUnprotected() ? `parental-gate-${featureId}-warning` : void 0;
			$$renderer.push(`<article class="setting policy-card svelte-1nye42e"><div class="protection-copy svelte-1nye42e"><h3 class="svelte-1nye42e">${escape_html(feature.label)}</h3> <p${attr("id", helpId)} class="svelte-1nye42e">${escape_html(feature.help)}</p></div> `);
			SegmentedPicker($$renderer, {
				class: "policy-picker",
				label: `${feature.label} parental gate frequency`,
				describedBy: [
					helpId,
					unavailableHelpId,
					warningId
				].filter(Boolean).join(" "),
				options: optionsFor(featureId),
				selected: parentalGateState.policies[featureId],
				onSelect: (mode) => chooseMode(featureId, mode)
			});
			$$renderer.push(`<!----> `);
			if (unavailableHelpId) $$renderer.push(`<!--[0--><div${attr("id", unavailableHelpId)} class="unavailable-explanation svelte-1nye42e" role="note"><strong class="svelte-1nye42e">Why Never is unavailable on iOS</strong> <span class="svelte-1nye42e">Apple's Kids Category requires links that leave Splotch to stay behind a grown-up
              check. Choose Every time or Per session instead.</span></div>`);
			else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (warningId) $$renderer.push(`<!--[0--><div${attr("id", warningId)} class="protection-warning svelte-1nye42e" role="note"><strong class="svelte-1nye42e">This check is off</strong> <span class="svelte-1nye42e">Anyone using this device can open Parent Center and change Splotch's settings and protections.</span></div>`);
			else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></article>`);
		}
		$$renderer.push(`<!--]--></div> <div class="mode-note svelte-1nye42e"><p class="svelte-1nye42e"><strong class="svelte-1nye42e">Per session</strong> asks once until Splotch is closed.</p> <p class="svelte-1nye42e"><strong class="svelte-1nye42e">Never</strong> skips the grown-up check on this device where available.</p></div></section> <dialog class="unprotected-confirm confirm-card modal-dialog modal-fly-in modal-shell" aria-labelledby="parentCenterUnprotectedTitle"><div class="confirm-card-content"><div class="confirm-card-heading"><h3 id="parentCenterUnprotectedTitle">Turn off the Parent Center check?</h3> <p>Anyone using this device can open Parent Center and change Splotch's settings and protections.</p></div> <div class="unprotected-confirm-actions svelte-1nye42e">`);
		Button($$renderer, {
			size: "lg",
			onclick: cancelUnprotected,
			children: ($$renderer) => {
				$$renderer.push(`<!---->Keep it on`);
			},
			$$slots: { default: true }
		});
		$$renderer.push(`<!----> `);
		Button($$renderer, {
			variant: "danger",
			size: "lg",
			onclick: confirmUnprotected,
			children: ($$renderer) => {
				$$renderer.push(`<!---->Turn it off`);
			},
			$$slots: { default: true }
		});
		$$renderer.push(`<!----></div></div></dialog>`);
	});
}
//#endregion
//#region src/lib/iosShareButtonLocation.ts
function iosShareButtonLocation(viewportWidthPx, orientation) {
	return viewportWidthPx > 0 && viewportWidthPx < 600 && orientation === "portrait" ? "at the bottom of the screen" : "in the Safari toolbar";
}
//#endregion
//#region src/lib/components/settings/SetupInstructions.svelte
function lockSteps($$renderer, os) {
	if (os === "ios") $$renderer.push(`<!--[0--><ol class="steps svelte-8c5pxq"><li class="svelte-8c5pxq">Go to <strong>Settings → Accessibility → Guided Access</strong></li> <li class="svelte-8c5pxq">Turn on <strong>Guided Access</strong></li> <li class="svelte-8c5pxq">Set a passcode</li> <li class="svelte-8c5pxq">Open Splotch and triple-click the side button</li> <li class="svelte-8c5pxq">Tap <strong>Start</strong> to lock the app</li> <li class="svelte-8c5pxq">Triple-click and enter passcode to exit</li></ol>`);
	else if (os === "android") $$renderer.push(`<!--[1--><ol class="steps svelte-8c5pxq"><li class="svelte-8c5pxq">Go to <strong>Settings → Security → App Pinning</strong></li> <li class="svelte-8c5pxq">Turn on <strong>App Pinning</strong></li> <li class="svelte-8c5pxq">Open Splotch and tap the <strong>Recent Apps</strong> button</li> <li class="svelte-8c5pxq">Swipe up on Splotch and tap the <strong>Pin</strong> icon</li> <li class="svelte-8c5pxq">Tap <strong>Start</strong> to lock the app</li> <li class="svelte-8c5pxq">Long-press Back + Recent Apps to exit</li></ol>`);
	else $$renderer.push(`<!--[-1--><p class="steps-note svelte-8c5pxq">A computer has no Guided Access or App Pinning to turn on — nothing locks it to one app. These
      come closest:</p> <ul class="steps svelte-8c5pxq"><li class="svelte-8c5pxq">Install Splotch above, so it opens in its own window with no tabs or address bar</li> <li class="svelte-8c5pxq">Put the browser in full screen — <strong>F11</strong> on Windows and Linux, <strong>Control-Command-F</strong> on a Mac</li> <li class="svelte-8c5pxq">Stay nearby — a keyboard can leave the app at any time</li></ul>`);
	$$renderer.push(`<!--]-->`);
}
function SetupInstructions($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		const OS_LABEL = {
			ios: "iOS",
			android: "Android",
			desktop: "Desktop"
		};
		const LOCK_STEP_TITLE = {
			ios: "Enable Guided Access",
			android: "Enable App Pinning",
			desktop: "Keep kids in the app"
		};
		let installing = false;
		async function oneTapInstall() {
			installing = true;
			try {
				await promptInstall();
			} finally {
				installing = false;
			}
		}
		const deviceOs = installDeviceOs();
		const outsideSafari = isIosOutsideSafari();
		getPlatform();
		const shareLocation = derived(() => iosShareButtonLocation(layoutState.viewportWidth, layoutState.orientation));
		function installSteps($$renderer, os) {
			if (os === "ios") {
				$$renderer.push(`<!--[0--><ol class="steps svelte-8c5pxq">`);
				if (outsideSafari) $$renderer.push(`<!--[0--><li class="svelte-8c5pxq">Open this page in <strong>Safari</strong> — the steps below are Safari's</li>`);
				else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> <li class="svelte-8c5pxq">Tap the `);
				Icon($$renderer, {
					name: "share-ios",
					class: "step-icon",
					"aria-hidden": "true"
				});
				$$renderer.push(`<!----> <strong>Share</strong> button ${escape_html(shareLocation())}</li> <li class="svelte-8c5pxq">Scroll and tap <strong>"Add to Home Screen"</strong></li> <li class="svelte-8c5pxq">Tap <strong>"Add"</strong> in the top right</li> <li class="svelte-8c5pxq">Launch from your home screen for fullscreen mode</li></ol>`);
			} else if (os === "android") $$renderer.push(`<!--[1--><ol class="steps svelte-8c5pxq"><li class="svelte-8c5pxq">Tap the <strong>menu</strong> (three dots)</li> <li class="svelte-8c5pxq">Tap <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong></li> <li class="svelte-8c5pxq">Follow the prompts</li> <li class="svelte-8c5pxq">Launch from your home screen for fullscreen mode</li></ol>`);
			else $$renderer.push(`<!--[-1--><ol class="steps svelte-8c5pxq"><li class="svelte-8c5pxq">In Chrome or Edge, click the <strong>install</strong> icon at the end of the address bar —
        or open the browser <strong>menu</strong> and choose <strong>"Install Splotch"</strong></li> <li class="svelte-8c5pxq">In Safari on macOS Sonoma or later, choose <strong>File → Add to Dock</strong></li> <li class="svelte-8c5pxq">Follow the prompts</li> <li class="svelte-8c5pxq">Launch it from your dock, desktop, or taskbar for fullscreen mode</li></ol> <p class="steps-note svelte-8c5pxq">Firefox has no install of its own, so it keeps Splotch in a tab — that works too.</p>`);
			$$renderer.push(`<!--]-->`);
		}
		if (installState.mode === "oneTap") {
			$$renderer.push(`<!--[0--><div class="one-tap svelte-8c5pxq">`);
			Button($$renderer, {
				variant: "brand",
				onclick: oneTapInstall,
				disabled: installing,
				children: ($$renderer) => {
					Icon($$renderer, {
						name: "home",
						class: "one-tap-icon"
					});
					$$renderer.push(`<!----> Install Splotch`);
				},
				$$slots: { default: true }
			});
			$$renderer.push(`<!----> <p class="one-tap-hint svelte-8c5pxq">One tap — your browser will do the rest.</p></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		$$renderer.push(`<!--[-1--><section class="os-section svelte-8c5pxq">`);
		RuleLabel($$renderer, {
			as: "h3",
			strong: true,
			class: "os-heading",
			children: ($$renderer) => {
				$$renderer.push(`<!---->${escape_html(OS_LABEL[deviceOs])}`);
			},
			$$slots: { default: true }
		});
		$$renderer.push(`<!----> `);
		{
			function summary($$renderer) {
				$$renderer.push(`<span class="summary-text svelte-8c5pxq"><span class="section-number step-number svelte-8c5pxq">1</span> Install as App `);
				if (installState.installed) $$renderer.push(`<!--[0--><span class="install-check svelte-8c5pxq">✓</span>`);
				else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></span>`);
			}
			Disclosure($$renderer, {
				class: "help-section",
				summary,
				children: ($$renderer) => {
					installSteps($$renderer, deviceOs);
				},
				$$slots: {
					summary: true,
					default: true
				}
			});
		}
		$$renderer.push(`<!----> `);
		{
			function summary($$renderer) {
				$$renderer.push(`<span class="summary-text svelte-8c5pxq"><span class="section-number step-number svelte-8c5pxq">2</span> ${escape_html(LOCK_STEP_TITLE[deviceOs])}</span>`);
			}
			Disclosure($$renderer, {
				class: "help-section",
				summary,
				children: ($$renderer) => {
					lockSteps($$renderer, deviceOs);
				},
				$$slots: {
					summary: true,
					default: true
				}
			});
		}
		$$renderer.push(`<!----></section>`);
		$$renderer.push(`<!--]-->`);
	});
}
function CurrentReleaseNotes($$renderer, $$props) {
	let { headingLevel, visibleSections = 3 } = $$props;
	if (visibleSections >= 1) {
		$$renderer.push("<!--[0-->");
		ReleaseSectionHeading($$renderer, {
			title: "New",
			level: headingLevel
		});
		$$renderer.push(`<!----> <ul><li>Pick sounds for each part of the app — plus a clear sound.</li> <li>Dottie the mascot now reacts on error screens.</li></ul>`);
	} else $$renderer.push("<!--[-1-->");
	$$renderer.push(`<!--]--> `);
	if (visibleSections >= 2) {
		$$renderer.push("<!--[0-->");
		ReleaseSectionHeading($$renderer, {
			title: "Improved",
			level: headingLevel
		});
		$$renderer.push(`<!----> <ul><li>AI pictures are opt-in, with clearer errors and retries.</li> <li>Playful motion: menus pop from buttons, undo spins, clearing sweeps to the trash.</li> <li>Crisper coloring pages that load faster.</li> <li>Smoother drawing on iPad and Android.</li> <li>App updates apply without interrupting drawing.</li></ul>`);
	} else $$renderer.push("<!--[-1-->");
	$$renderer.push(`<!--]--> `);
	if (visibleSections >= 3) {
		$$renderer.push("<!--[0-->");
		ReleaseSectionHeading($$renderer, {
			title: "Fixed",
			level: headingLevel
		});
		$$renderer.push(`<!----> <ul><li>Clear ring no longer reappears after release.</li> <li>Drawings recover when the app resumes.</li></ul>`);
	} else $$renderer.push("<!--[-1-->");
	$$renderer.push(`<!--]-->`);
}
//#endregion
//#region src/lib/components/settings/WhatsNewSection.svelte
function WhatsNewSection($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { sectionHeadingLevel, onSettled } = $$props;
		const RELEASE_HEADINGS = {
			2: {
				date: "h3",
				sections: 4
			},
			3: {
				date: "h4",
				sections: 5
			}
		};
		const releaseHeadings = derived(() => RELEASE_HEADINGS[sectionHeadingLevel]);
		const INITIAL_RELEASE_SECTION_COUNT = 1;
		const currentRelease = releases_default[0];
		let visibleReleaseSections = INITIAL_RELEASE_SECTION_COUNT;
		$$renderer.push(`<section class="setting-group">`);
		if (currentRelease) {
			$$renderer.push(`<!--[0--><div class="whats-new svelte-190hby4">`);
			element($$renderer, releaseHeadings().date, () => {
				$$renderer.push(` class="whats-new-heading svelte-190hby4"`);
			}, () => {
				$$renderer.push(`<span class="whats-new-date">${escape_html(currentRelease.dateLabel)}</span>`);
			});
			$$renderer.push(` <div class="whats-new-body svelte-190hby4">`);
			CurrentReleaseNotes($$renderer, {
				headingLevel: releaseHeadings().sections,
				visibleSections: visibleReleaseSections
			});
			$$renderer.push(`<!----></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <p class="all-releases svelte-190hby4"><a href="/changelog" class="svelte-190hby4">See all releases `);
		Icon($$renderer, {
			name: "chevron-right",
			class: "all-releases-icon",
			"aria-hidden": "true"
		});
		$$renderer.push(`<!----></a></p></section>`);
	});
}
//#endregion
//#region src/lib/reportClient.ts
function postFeedbackReport(body, signal) {
	return fetch(apiUrl("/api/report"), {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(body),
		signal
	});
}
function postImageReport({ kind, drawing, output, style }, headers, signal) {
	const field = IMAGE_REPORT_FORM_FIELDS;
	const form = new FormData();
	form.set(field.kind, kind);
	form.set(field.drawing, drawing, field.drawing);
	if (output) form.set(field.output, output, field.output);
	form.set(field.style, style ?? "");
	return fetch(apiUrl("/api/report-image"), {
		method: "POST",
		headers,
		body: form,
		signal
	});
}
function narrowReportReply(body) {
	if (typeof body !== "object" || body === null) return null;
	if ("ok" in body && body.ok === true) return "reportId" in body && typeof body.reportId === "string" ? {
		ok: true,
		reportId: body.reportId
	} : { ok: true };
	if ("error" in body && typeof body.error === "string") return {
		ok: false,
		error: body.error
	};
	return null;
}
/**
* Either report endpoint's reply, read from `unknown` into its declared shape.
* `null` means the body gave no usable answer — not JSON, `null`, or neither
* `ok: true` nor a string `error` — so the caller shows its own copy instead
* of a blank or misattributed line. A read the caller's own `signal` cut
* short rethrows: only the caller can tell its deadline from an unmount.
*/
async function readReportReply(response, signal) {
	let body;
	try {
		body = await response.json();
	} catch (error) {
		if (signal.aborted) throw error;
		return null;
	}
	return narrowReportReply(body);
}
//#endregion
//#region src/lib/components/settings/ReportForm.svelte
function ReportForm($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let kind = "bug";
		let message = "";
		let includeDevice = false;
		let honeypot = "";
		let fields;
		let status = "idle";
		let feedback = "";
		let submitting = derived(() => status === "busy");
		const latest = createLatestRequest();
		async function sendReport() {
			const text = message.trim();
			if (!text || submitting()) return;
			const attachDevice = attachesDevice(kind, includeDevice);
			const payload = {
				kind,
				message: text,
				["hp"]: honeypot
			};
			const { id, signal } = latest.begin();
			status = "busy";
			feedback = "";
			try {
				const device = attachDevice ? await fields.ensureDevice() : void 0;
				const res = await postFeedbackReport({
					...payload,
					device
				}, signal);
				const reply = await readReportReply(res, signal);
				if (!latest.isCurrent(id)) return;
				if (res.ok && reply?.ok) {
					status = "success";
					feedback = "Thanks for your feedback.";
					message = "";
				} else {
					status = "error";
					feedback = !reply ? "Could not read the server response." : reply.ok ? "Could not send your report. Please try again." : reply.error;
				}
			} catch {
				if (!latest.isCurrent(id)) return;
				status = "error";
				feedback = NETWORK_ERROR_MESSAGE;
			}
		}
		function submit(event) {
			requireParentalGate("feedback", () => void sendReport(), buttonCenter(event.currentTarget));
		}
		let $$settled = true;
		let $$inner_renderer;
		function $$render_inner($$renderer) {
			$$renderer.push(`<section class="setting-group svelte-1nriyqe">`);
			RuleLabel($$renderer, {
				as: "h3",
				strong: true,
				class: "report-heading",
				children: ($$renderer) => {
					$$renderer.push(`<!---->Send Feedback`);
				},
				$$slots: { default: true }
			});
			$$renderer.push(`<!----> <p class="report-intro svelte-1nriyqe">Found a bug or have an idea? Tell us here — it opens a private support issue that only the
    Splotch maintainer can read. No account needed.</p> <div class="setting report-card svelte-1nriyqe">`);
			ReportFields($$renderer, {
				get kind() {
					return kind;
				},
				set kind($$value) {
					kind = $$value;
					$$settled = false;
				},
				get message() {
					return message;
				},
				set message($$value) {
					message = $$value;
					$$settled = false;
				},
				get includeDevice() {
					return includeDevice;
				},
				set includeDevice($$value) {
					includeDevice = $$value;
					$$settled = false;
				},
				get honeypot() {
					return honeypot;
				},
				set honeypot($$value) {
					honeypot = $$value;
					$$settled = false;
				}
			});
			$$renderer.push(`<!----> `);
			Button($$renderer, {
				variant: "brand",
				class: "report-submit",
				onclick: submit,
				disabled: !message.trim(),
				busy: submitting(),
				children: ($$renderer) => {
					$$renderer.push(`<!---->${escape_html(submitting() ? "Sending…" : "Send report")}`);
				},
				$$slots: { default: true }
			});
			$$renderer.push(`<!----></div> `);
			if (feedback) {
				$$renderer.push("<!--[0-->");
				StatusMessage($$renderer, {
					status: status === "error" ? "error" : "success",
					class: "report-status",
					children: ($$renderer) => {
						$$renderer.push(`<!---->${escape_html(feedback)}`);
					},
					$$slots: { default: true }
				});
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></section>`);
		}
		do {
			$$settled = true;
			$$inner_renderer = $$renderer.copy();
			$$render_inner($$inner_renderer);
		} while (!$$settled);
		$$renderer.subsume($$inner_renderer);
	});
}
//#endregion
//#region src/lib/components/settings/AboutSection.svelte
function AboutSection($$renderer) {
	$$renderer.push(`<section class="setting-group"><div class="about-brand svelte-y69ck6">`);
	SplotchyIcon($$renderer, {
		class: "about-icon",
		"aria-label": "Splotch",
		role: "img"
	});
	$$renderer.push(`<!----> <p class="about-tagline svelte-y69ck6">A joyful, kid-friendly drawing app</p></div> <div class="about-links svelte-y69ck6"><p class="svelte-y69ck6"><a href="/privacy" class="svelte-y69ck6">Privacy Policy</a></p> <p class="github-link svelte-y69ck6"><a${attr("href", GITHUB_REPO_URL)} target="_blank" rel="noopener noreferrer" class="svelte-y69ck6">`);
	Icon($$renderer, {
		name: "github",
		class: "github-icon",
		"aria-hidden": "true"
	});
	$$renderer.push(`<!----> View on GitHub`);
	ExternalMark($$renderer, { variant: "standalone" });
	$$renderer.push(`<!----></a></p> <p class="version-text svelte-y69ck6">Version ${escape_html(APP_VERSION)}</p></div></section>`);
}
//#endregion
//#region src/lib/components/settings/SectionBody.svelte
var SECTION_CONTENT = {
	appearance: AppearanceSection,
	sound: SoundSection,
	saving: SavingSection,
	coloring: ColoringSection,
	controls: ControlsSection,
	accessibility: AccessibilitySection,
	ai: AiKeyManager,
	parentCenter: ParentCenterSection,
	setup: SetupInstructions,
	whatsnew: WhatsNewSection,
	feedback: ReportForm,
	about: AboutSection
};
function SectionBody($$renderer, $$props) {
	/** Forwarded to the one section that keeps staging content after it mounts. */
	let { id, sectionHeadingLevel, onSettled } = $$props;
	const Content = derived(() => SECTION_CONTENT[id]);
	if (Content()) {
		$$renderer.push("<!--[-->");
		Content()($$renderer, {
			onSettled,
			sectionHeadingLevel
		});
		$$renderer.push("<!--]-->");
	} else {
		$$renderer.push("<!--[!-->");
		$$renderer.push("<!--]-->");
	}
}
//#endregion
//#region src/lib/components/settings/CompactShell.svelte
function CompactShell($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		const showOrientationControls = derived(() => orientationLockApplies(fullscreenState.active));
		$$renderer.push(`<div class="settings-header-compact svelte-x07oaz">`);
		DialogHeader($$renderer, {
			onclose: settingsModal.hide,
			closeFeedback: true,
			children: ($$renderer) => {
				$$renderer.push(`<h2 class="svelte-x07oaz">Settings</h2>`);
			},
			$$slots: { default: true }
		});
		$$renderer.push(`<!----></div> <div class="quick-toggles-scroll svelte-x07oaz"><div class="quick-toggles svelte-x07oaz"><div class="setting">`);
		ToggleRow($$renderer, {
			icon: settingsState.soundEnabled ? "volume-on" : "volume-off",
			label: "Sound",
			id: "quickSoundToggle",
			checked: settingsState.soundEnabled,
			onToggle: setSound
		});
		$$renderer.push(`<!----></div> <div class="setting">`);
		ToggleRow($$renderer, {
			icon: resolvedTheme() === "dark" ? "theme-dark" : "theme-light",
			label: "Night Mode",
			id: "quickNightToggle",
			checked: resolvedTheme() === "dark",
			onToggle: (next) => setResolvedTheme(next ? "dark" : "light")
		});
		$$renderer.push(`<!----></div> <div class="setting">`);
		ToggleRow($$renderer, {
			icon: "dashboard-customize",
			label: "Tool drawer",
			id: "quickToolDrawerToggle",
			checked: settingsState.toolDrawerEnabled,
			onToggle: setToolDrawerEnabled
		});
		$$renderer.push(`<!----></div> `);
		if (showOrientationControls()) {
			$$renderer.push(`<!--[0--><div class="setting orientation-cell svelte-x07oaz">`);
			OrientationPicker($$renderer, {});
			$$renderer.push(`<!----></div>`);
		} else {
			$$renderer.push(`<!--[-1--><div class="setting about-cell svelte-x07oaz">`);
			SplotchyIcon($$renderer, {
				class: "about-cell-icon",
				"aria-label": "Splotch",
				role: "img"
			});
			$$renderer.push(`<!----> <span class="about-cell-version svelte-x07oaz">Version ${escape_html(APP_VERSION)}</span></div>`);
		}
		$$renderer.push(`<!--]--></div> `);
		ScrollCue($$renderer, {});
		$$renderer.push(`<!----></div> <p class="portrait-note svelte-x07oaz">`);
		Icon($$renderer, {
			name: "mobile-portrait",
			class: "portrait-note-icon"
		});
		$$renderer.push(`<!----> Switch to portrait for the full settings.</p>`);
	});
}
//#endregion
//#region src/lib/components/settings/ParentCenterLock.svelte
function ParentCenterLock($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { onUnlock } = $$props;
		$$renderer.push(`<div class="setting-group"><div class="setting parent-center-lock svelte-7v6lu0"><p class="svelte-7v6lu0">Parent Center decides when Splotch asks for a grown-up check, so it waits behind one itself.</p> `);
		Button($$renderer, {
			variant: "brand",
			onclick: (event) => onUnlock(event.currentTarget),
			children: ($$renderer) => {
				$$renderer.push(`<!---->Unlock these settings`);
			},
			$$slots: { default: true }
		});
		$$renderer.push(`<!----></div></div>`);
	});
}
//#endregion
//#region src/lib/components/settings/stagedSections.svelte.ts
var SECTIONS_PER_FRAME = 1;
function createStagedSections(total, openingCount) {
	let mountedCount = settingsModal.open ? openingCount : 0;
	let presentedCount = 0;
	let stagedContentSettled = false;
	const fullyMounted = derived(() => mountedCount >= total && stagedContentSettled);
	function mountAtLeast(count) {
		const next = Math.min(count, total);
		if (run(() => mountedCount) >= next) return false;
		mountedCount = next;
		return true;
	}
	function presentAtLeast(count) {
		const next = Math.min(count, total);
		mountAtLeast(next);
		if (run(() => presentedCount) >= next) return false;
		presentedCount = next;
		return true;
	}
	function resetPresentation() {
		presentedCount = 0;
	}
	function markStagedContentSettled() {
		stagedContentSettled = true;
	}
	function fillAfterFlyIn(flyIn) {
		let stopPump;
		let cancelled = false;
		Promise.all(flyIn.map((animation) => animation.finished.catch(() => void 0))).then(() => {
			if (cancelled) return;
			const breather = requestAnimationFrame(() => {
				if (!cancelled) stopPump = pumpRemainingSections();
			});
			stopPump = () => cancelAnimationFrame(breather);
		});
		return () => {
			cancelled = true;
			stopPump?.();
		};
	}
	function pumpRemainingSections() {
		let frame = 0;
		const presentNext = () => {
			frame = presentAtLeast(run(() => presentedCount) + SECTIONS_PER_FRAME) ? requestAnimationFrame(presentNext) : 0;
		};
		frame = requestAnimationFrame(presentNext);
		return () => {
			if (frame) cancelAnimationFrame(frame);
		};
	}
	function stageWhileClosed() {}
	return {
		get mountedCount() {
			return mountedCount;
		},
		get presentedCount() {
			return presentedCount;
		},
		get fullyMounted() {
			return fullyMounted();
		},
		mountAtLeast,
		presentAtLeast,
		resetPresentation,
		markStagedContentSettled,
		fillAfterFlyIn,
		stageWhileClosed
	};
}
//#endregion
//#region src/lib/state/sectionsSeen.svelte.ts
function readSeenStamps() {
	const raw = readString(STORAGE_KEYS.parentSectionsSeen, null);
	if (!raw) return {};
	try {
		const parsed = JSON.parse(raw);
		if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
		const stamps = {};
		for (const [id, stamp] of Object.entries(parsed)) if (isSectionId(id) && typeof stamp === "string") stamps[id] = stamp;
		return stamps;
	} catch {
		return {};
	}
}
function createSectionsSeen(sessionCounters) {
	let seenStamps = readSeenStamps();
	function isSectionUnseen(id) {
		return seenStamps[id] !== sectionContentStamp(id);
	}
	return {
		isSectionUnseen,
		hasSectionActivity(id) {
			return sessionCounters.sessionCount("settingsActivity") >= 6 && isSectionUnseen(id);
		},
		markSectionSeen(id) {
			run(() => {
				const contentStamp = sectionContentStamp(id);
				if (seenStamps[id] === contentStamp) return;
				seenStamps[id] = contentStamp;
				writeString(STORAGE_KEYS.parentSectionsSeen, JSON.stringify(seenStamps));
			});
		},
		reloadSectionsSeen() {
			seenStamps = readSeenStamps();
		}
	};
}
var sectionsSeenState = createSectionsSeen(sessionCountersState);
var { hasSectionActivity, markSectionSeen } = sectionsSeenState;
onDurableRestore(sectionsSeenState.reloadSectionsSeen);
//#endregion
//#region src/lib/components/settings/WideShell.svelte
function WideShell($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		/** Where the pane parks on each open — the deep-linked section, else the first. */
		/** Advances on each open transition, as the dialog action reports it to SettingsModal. */
		let { landingSection, openGeneration } = $$props;
		let spiedSection = SECTIONS[0].id;
		let parentCenterUnlocked = false;
		let parentCenterRevealed = derived(() => parentCenterUnlocked || !requiresParentalGate("parentCenter"));
		const OPENING_SECTION_COUNT = SECTIONS.findIndex((section) => section.id === "sound") + 1;
		const staging = createStagedSections(SECTIONS.length, OPENING_SECTION_COUNT);
		const mountedSections = derived(() => SECTIONS.slice(0, staging.mountedCount));
		const navItems = derived(() => SECTIONS.map((section) => ({
			id: section.id,
			label: section.label,
			icon: section.icon,
			unseen: hasSectionActivity(section.id)
		})));
		const sectionEls = {};
		const sectionHeadingId = (id) => `settingsSection-${id}`;
		const sectionIndex = (id) => SECTIONS.findIndex((section) => section.id === id);
		function jumpBehavior() {
			if (!staging.fullyMounted) return "auto";
			return prefersReducedMotion() ? "auto" : "smooth";
		}
		function scrollToSection(id, behavior) {
			sectionEls[id];
		}
		staging.stageWhileClosed();
		function unlockParentCenter(trigger, then) {
			requireParentalGate("parentCenter", () => {
				parentCenterUnlocked = true;
				markSectionSeen("parentCenter");
				then?.();
			}, buttonCenter(trigger));
		}
		async function jumpToSection(id, trigger) {
			if (staging.presentAtLeast(sectionIndex(id) + 1)) await /* @__PURE__ */ tick();
			const behavior = jumpBehavior();
			const hold = !staging.fullyMounted;
			if (id !== "parentCenter" || parentCenterRevealed()) {
				markSectionSeen(id);
				if (hold);
				scrollToSection(id, behavior);
				return;
			}
			unlockParentCenter(trigger, () => {
				if (hold && !staging.fullyMounted);
				scrollToSection(id, behavior);
			});
		}
		$$renderer.push(`<div class="settings-split svelte-1aua7zj"><div class="settings-nav svelte-1aua7zj">`);
		SidebarToc($$renderer, {
			items: navItems(),
			active: spiedSection,
			label: "Settings sections",
			onSelect: jumpToSection
		});
		$$renderer.push(`<!----></div> `);
		{
			function children($$renderer, end) {
				$$renderer.push(`<div class="settings-pane svelte-1aua7zj"${attr("aria-busy", !staging.fullyMounted)}><div class="settings-zoom"><!--[-->`);
				const each_array = ensure_array_like(mountedSections());
				for (let index = 0, $$length = each_array.length; index < $$length; index++) {
					let section = each_array[index];
					$$renderer.push(`<section${attr_class("settings-section svelte-1aua7zj", void 0, { "staged": index >= staging.presentedCount })}${attr("data-section", section.id)}${attr("aria-labelledby", sectionHeadingId(section.id))}><h3 class="settings-pane-title svelte-1aua7zj"${attr("id", sectionHeadingId(section.id))}>${escape_html(sectionHeading(section.id))}</h3> `);
					if (section.id === "parentCenter" && !parentCenterRevealed()) {
						$$renderer.push("<!--[0-->");
						ParentCenterLock($$renderer, { onUnlock: unlockParentCenter });
					} else {
						$$renderer.push("<!--[-1-->");
						SectionBody($$renderer, {
							id: section.id,
							sectionHeadingLevel: 3,
							onSettled: staging.markStagedContentSettled
						});
					}
					$$renderer.push(`<!--]--></section>`);
				}
				$$renderer.push(`<!--]--></div> `);
				end($$renderer);
				$$renderer.push(`<!----></div>`);
			}
			ScrollCue($$renderer, {
				contentPending: !staging.fullyMounted || staging.presentedCount < SECTIONS.length,
				children,
				$$slots: { default: true }
			});
		}
		$$renderer.push(`<!----></div>`);
	});
}
//#endregion
//#region src/lib/components/settings/HubList.svelte
function HubList($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { onopen } = $$props;
		/** Rides in the thumb where the switch has no label of its own beside it. */
		const HUB_TOGGLES = {
			appearance: {
				id: "hubNightToggle",
				label: "Night Mode",
				checked: () => resolvedTheme() === "dark",
				onToggle: (next) => setResolvedTheme(next ? "dark" : "light"),
				thumbIcon: () => resolvedTheme() === "dark" ? "theme-dark" : "theme-light"
			},
			sound: {
				id: "hubSoundToggle",
				label: "Sound",
				checked: () => settingsState.soundEnabled,
				onToggle: setSound
			}
		};
		const firstDrillIn = SECTIONS.findIndex((section) => !HUB_TOGGLES[section.id]);
		const groupBreakIndex = firstDrillIn > 0 ? firstDrillIn : -1;
		$$renderer.push(`<ul class="hub-list svelte-td1ztj"><!--[-->`);
		const each_array = ensure_array_like(SECTIONS);
		for (let index = 0, $$length = each_array.length; index < $$length; index++) {
			let section = each_array[index];
			const toggle = HUB_TOGGLES[section.id];
			const unseen = hasSectionActivity(section.id);
			$$renderer.push(`<li${attr_class("svelte-td1ztj", void 0, { "group-break": index === groupBreakIndex })}><div class="hub-tile svelte-td1ztj"><button class="hub-row svelte-td1ztj"${attr("data-section", section.id)}><span class="hub-icon svelte-td1ztj">`);
			SectionIcon($$renderer, {
				icon: section.icon,
				class: "hub-icon-svg"
			});
			$$renderer.push(`<!----> <span${attr_class("section-activity-dot svelte-td1ztj", void 0, { "unseen": unseen })}></span></span> <span class="hub-text svelte-td1ztj"><span class="hub-title svelte-td1ztj">${escape_html(section.label)}</span> <span class="hub-subtitle svelte-td1ztj">${escape_html(sectionSubtitle(section.id))}</span></span> `);
			if (unseen) {
				$$renderer.push("<!--[0-->");
				VisuallyHidden($$renderer, {
					children: ($$renderer) => {
						$$renderer.push(`<!---->new`);
					},
					$$slots: { default: true }
				});
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></button> `);
			if (toggle) {
				$$renderer.push(`<!--[0--><span class="hub-action svelte-td1ztj"><span class="hub-split svelte-td1ztj"></span> `);
				ToggleSwitch($$renderer, {
					id: toggle.id,
					label: toggle.label,
					checked: toggle.checked(),
					onToggle: toggle.onToggle,
					thumbIcon: toggle.thumbIcon?.()
				});
				$$renderer.push(`<!----></span>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div></li>`);
		}
		$$renderer.push(`<!--]--></ul>`);
	});
}
//#endregion
//#region src/lib/components/settings/settingsMediaQuery.svelte.ts
function createSettingsMediaQueries(queries) {
	let wide = false;
	let compact = false;
	return {
		get wide() {
			return wide;
		},
		get compact() {
			return compact;
		}
	};
}
//#endregion
//#region src/lib/components/SettingsModal.svelte
function SettingsModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		const shell = createSettingsMediaQueries({
			wide: `(min-width: 700px)`,
			compact: PHONE_LANDSCAPE_QUERY
		});
		let view = "hub";
		let activeSection = derived(() => view === "hub" ? SECTIONS[0].id : view);
		let dialogEl;
		let openGeneration = 0;
		let sectionHeadingEl = void 0;
		async function landFocus(target) {
			await /* @__PURE__ */ tick();
			const retiring = [...document.querySelectorAll(`dialog[open].${DIALOG_CLOSING_CLASS}`)].filter((dialog) => dialog !== dialogEl);
			await Promise.all(retiring.map(waitForDialogRetirement));
			target()?.focus();
		}
		function drillInto(section) {
			markSectionSeen(section);
			view = section;
			landFocus(() => sectionHeadingEl);
		}
		function openSection(id, trigger) {
			if (id !== "parentCenter") {
				drillInto(id);
				return;
			}
			requireParentalGate("parentCenter", () => drillInto(id), buttonCenter(trigger));
		}
		function backToHub() {
			if (view === "hub") return;
			const from = view;
			view = "hub";
			landFocus(() => dialogEl.querySelector(`button[data-section="${from}"]`));
		}
		$$renderer.push(`<dialog${attr_class(`settings-modal modal-dialog modal-fly-in modal-shell ${view === "ai" ? "ai-section" : ""}`, "svelte-1wk5kq2", {
			"resizing": uiState.resizingActionButtons,
			"wide": shell.wide,
			"compact": shell.compact
		})}${attr("id", SETTINGS_MODAL_ID)} aria-label="Settings"><div class="settings-content svelte-1wk5kq2">`);
		if (shell.compact) {
			$$renderer.push("<!--[0-->");
			CompactShell($$renderer, {});
		} else if (shell.wide) {
			$$renderer.push(`<!--[1--><div class="settings-header svelte-1wk5kq2">`);
			DialogHeader($$renderer, {
				onclose: settingsModal.hide,
				closeFeedback: true,
				children: ($$renderer) => {
					$$renderer.push(`<h2 class="svelte-1wk5kq2">Settings</h2>`);
				},
				$$slots: { default: true }
			});
			$$renderer.push(`<!----></div> `);
			WideShell($$renderer, {
				landingSection: activeSection(),
				openGeneration
			});
			$$renderer.push(`<!---->`);
		} else if (view === "hub") {
			$$renderer.push(`<!--[2--><div class="settings-header svelte-1wk5kq2">`);
			DialogHeader($$renderer, {
				onclose: settingsModal.hide,
				closeFeedback: true,
				children: ($$renderer) => {
					$$renderer.push(`<h2 class="svelte-1wk5kq2">Settings</h2>`);
				},
				$$slots: { default: true }
			});
			$$renderer.push(`<!----></div> `);
			{
				function children($$renderer, end) {
					$$renderer.push(`<div class="settings-scroll svelte-1wk5kq2"><div class="settings-zoom">`);
					HubList($$renderer, { onopen: openSection });
					$$renderer.push(`<!----></div> `);
					end($$renderer);
					$$renderer.push(`<!----></div>`);
				}
				ScrollCue($$renderer, {
					children,
					$$slots: { default: true }
				});
			}
			$$renderer.push(`<!---->`);
		} else {
			$$renderer.push(`<!--[-1--><div class="settings-header settings-header-sub svelte-1wk5kq2">`);
			DialogHeader($$renderer, {
				backClass: "settings-back",
				onback: backToHub,
				onclose: settingsModal.hide,
				closeFeedback: true,
				children: ($$renderer) => {
					$$renderer.push(`<h2 tabindex="-1" class="svelte-1wk5kq2">${escape_html(sectionHeading(activeSection()))}</h2>`);
				},
				$$slots: { default: true }
			});
			$$renderer.push(`<!----></div> `);
			{
				function children($$renderer, end) {
					$$renderer.push(`<div class="settings-scroll svelte-1wk5kq2"><div class="settings-zoom">`);
					SectionBody($$renderer, {
						id: activeSection(),
						sectionHeadingLevel: 2
					});
					$$renderer.push(`<!----></div> `);
					end($$renderer);
					$$renderer.push(`<!----></div>`);
				}
				ScrollCue($$renderer, {
					children,
					$$slots: { default: true }
				});
			}
			$$renderer.push(`<!---->`);
		}
		$$renderer.push(`<!--]--></div></dialog>`);
	});
}
//#endregion
export { iosShareButtonLocation as a, readReportReply as i, postFeedbackReport as n, postImageReport as r, SettingsModal as t };
