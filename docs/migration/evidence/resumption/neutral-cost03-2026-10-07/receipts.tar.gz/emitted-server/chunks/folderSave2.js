import { c as writeBool, f as STORAGE_KEYS, r as readBool } from "./storage.js";
import { r as requestPersistentStorage, t as idbKvStore } from "./idb.js";
//#region src/lib/drawing/folderSave.ts
var DB_NAME = "splotch-fs";
var STORE = "handles";
var HANDLE_KEY = "saveDir";
var reservedFilenames = /* @__PURE__ */ new WeakMap();
var handleStore = idbKvStore(DB_NAME, STORE);
var handlePromise = null;
var folderClearedListener = null;
function setSaveFolderClearedListener(listener) {
	folderClearedListener = listener;
}
async function readHandleFromIdb() {
	if (!readBool(STORAGE_KEYS.saveFolderChosen, false)) return null;
	try {
		return await handleStore.get(HANDLE_KEY) ?? null;
	} catch {
		return null;
	}
}
async function loadHandle() {
	const requestedHandlePromise = handlePromise ??= readHandleFromIdb();
	const handle = await requestedHandlePromise;
	return requestedHandlePromise === handlePromise ? handle : loadHandle();
}
async function storeHandle(handle) {
	await handleStore.put(HANDLE_KEY, handle);
}
/** Whether the browser exposes the File System Access directory picker. */
function folderSaveSupported() {
	return false;
}
/** The name of the remembered destination folder, or null if none is set. */
async function getSaveFolderName() {
	if (!folderSaveSupported()) return null;
	return (await loadHandle())?.name ?? null;
}
async function chooseSaveFolder() {
	if (!folderSaveSupported()) return null;
	let handle;
	try {
		handle = await window.showDirectoryPicker({
			mode: "readwrite",
			startIn: "pictures"
		});
		if (await handle.requestPermission({ mode: "readwrite" }) !== "granted") return null;
	} catch (err) {
		if (err instanceof DOMException && err.name === "AbortError") return null;
		console.warn("Choosing a save folder failed:", err);
		return null;
	}
	handlePromise = Promise.resolve(handle);
	writeBool(STORAGE_KEYS.saveFolderChosen, true);
	try {
		await storeHandle(handle);
		requestPersistentStorage();
	} catch (err) {
		console.warn("Persisting the save folder failed:", err);
	}
	return handle.name;
}
/** Forget the chosen folder, so web saves revert to plain downloads. */
async function clearSaveFolder() {}
async function createUniqueFile(dir, filename) {
	const reserved = reservedFilenames.get(dir) ?? /* @__PURE__ */ new Set();
	reservedFilenames.set(dir, reserved);
	const dot = filename.lastIndexOf(".");
	const stem = dot === -1 ? filename : filename.slice(0, dot);
	const ext = dot === -1 ? "" : filename.slice(dot);
	for (let i = 0;; i++) {
		const candidate = i === 0 ? filename : `${stem} (${i})${ext}`;
		if (reserved.has(candidate)) continue;
		reserved.add(candidate);
		try {
			try {
				await dir.getFileHandle(candidate);
			} catch (err) {
				if (err instanceof DOMException && err.name === "NotFoundError") return await dir.getFileHandle(candidate, { create: true });
				throw err;
			}
		} finally {
			reserved.delete(candidate);
		}
	}
}
async function ensureWritePermission(handle, allowPrompt) {
	let permission = await handle.queryPermission({ mode: "readwrite" });
	if (permission !== "granted" && allowPrompt) permission = await handle.requestPermission({ mode: "readwrite" });
	return permission === "granted";
}
async function forgetStaleFolder() {
	await clearSaveFolder();
	folderClearedListener?.();
}
async function saveBlobToFolder(blob, filename, opts) {
	if (!folderSaveSupported()) return null;
	const allowPrompt = opts?.allowPrompt ?? false;
	let handle = null;
	try {
		handle = await loadHandle();
		if (!handle) return null;
		if (!await ensureWritePermission(handle, allowPrompt)) return null;
		const writable = await (await createUniqueFile(handle, filename)).createWritable();
		await writable.write(blob);
		await writable.close();
		return handle.name;
	} catch (err) {
		if (err instanceof DOMException && err.name === "NotFoundError") {
			if (await loadHandle() === handle) await forgetStaleFolder();
		}
		return null;
	}
}
//#endregion
export { saveBlobToFolder as a, getSaveFolderName as i, clearSaveFolder as n, setSaveFolderClearedListener as o, folderSaveSupported as r, chooseSaveFolder as t };
