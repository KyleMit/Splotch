import { t as SettingsModal } from "./SettingsModal.js";
export { SettingsModal as default };
