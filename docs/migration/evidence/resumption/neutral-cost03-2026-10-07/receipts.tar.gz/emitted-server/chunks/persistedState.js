import "./platform.js";
import { t as hydrateDurableStorage } from "./storage.js";
import { k as settingsState } from "./settings.svelte.js";
import { n as fullscreenState, t as persistedStateStatus } from "./persistedStateStatus.svelte.js";
import { a as hydrateSaveFolder, n as recordSession, o as hydrateApiKey, u as hydrateAiAccessToken } from "./sessionCounters.svelte.js";
async function applyDeviceOrientationPreference(choice, fullscreenActive) {}
//#endregion
//#region src/lib/boot/persistedState.ts
async function hydrateSettingsStores() {
	hydrateSaveFolder();
	const restored = await hydrateDurableStorage();
	recordSession("settingsActivity");
	if (restored) applyDeviceOrientationPreference(settingsState.orientationChoice(), fullscreenState.active);
}
async function hydrateCredentials(status) {
	const hydrations = await Promise.allSettled([hydrateApiKey(), hydrateAiAccessToken()]);
	for (const hydration of hydrations) if (hydration.status === "rejected") console.warn("Secure credential hydration failed", hydration.reason);
	status.markHydrated();
}
/**
* Settings only. Resolves as soon as the stores a route needs in order to
* decide what to do are usable; credential hydration continues in the
* background and still flips `persistedStateStatus.hydrated` when it lands.
*
* This is what the drawing route's boot gate wants:
* `installColoringPackDownloads` reads `settings.coloringBookEnabled` and
* nothing credential-shaped, so waiting on a secure-storage round trip held it
* behind work it does not depend on.
*/
async function hydrateSettings() {
	await hydrateSettingsStores();
	hydrateCredentials(persistedStateStatus);
}
/**
* Settings *and* credentials. The Settings modal renders the stored key and
* access code, so it must not open before those have loaded.
*/
async function hydratePersistedState(status = persistedStateStatus) {
	await hydrateSettingsStores();
	await hydrateCredentials(status);
}
//#endregion
export { hydrateSettings as n, hydratePersistedState as t };
