import { s as setNoDownloadedColoringBooks } from "./coloringPacks2.svelte.js";
export { setNoDownloadedColoringBooks };
