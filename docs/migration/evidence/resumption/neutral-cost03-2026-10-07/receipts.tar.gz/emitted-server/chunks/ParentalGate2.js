import { t as ParentalGate } from "./ParentalGate.js";
export { ParentalGate as default };
