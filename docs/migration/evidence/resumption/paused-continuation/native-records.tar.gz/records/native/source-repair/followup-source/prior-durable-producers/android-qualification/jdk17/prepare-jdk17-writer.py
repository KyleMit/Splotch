import gzip
import hashlib
import json
import os
import stat
import tarfile
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DESTINATION = ROOT / 'reviewed-jdk17-materialization'
ARCHIVE = ROOT / 'OpenJDK17U-jdk_aarch64_mac_hotspot_17.0.20.1_1.tar.gz'
ARCHIVE_BYTES = 185851019
ARCHIVE_SHA256 = '196d13ba5f10414bef7f6a05a9b3f00edacb18ebacef2b99485db9e2ee18f0e8'
ROWS_SHA256 = '009b18c3ee578a50479660bfa6c59058106fa1199c0645753f3721b2ac9faa72'
PREFIX = 'jdk-17.0.20.1+1'
READ_CHUNK_BYTES = 1024 * 1024
DEADLINE_SECONDS = 120
START = time.monotonic()
STARTED_AT = datetime.now(timezone.utc).isoformat()


def remaining():
    if time.monotonic() - START >= DEADLINE_SECONDS:
        raise ValueError('Finite JDK writer120second deadline exceeded')


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while block := stream.read(READ_CHUNK_BYTES):
            remaining()
            value.update(block)
    return value.hexdigest()


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')


def verify_inode(path, row):
    info = path.lstat()
    valid = stat.S_ISDIR(info.st_mode) if row['kind'] == 'directory' else stat.S_ISREG(info.st_mode)
    if not valid or info.st_uid != os.getuid() or info.st_gid != os.getgid() or (row['kind'] == 'file' and info.st_nlink != 1):
        raise ValueError('Owned JDK inode type/ownership differs')
    if stat.S_IMODE(info.st_mode) != int(row['mode'], 8):
        raise ValueError('Owned JDK producer mode differs')
    if row['kind'] == 'file' and (info.st_size != row['bytes'] or digest(path) != row['sha256']):
        raise ValueError('Owned JDK regular bytes differ')
    return info


def refusal(label, action, reason):
    try:
        action()
    except ValueError as error:
        if reason not in str(error):
            raise ValueError('Wrong finite JDK refusing-control reason') from error
        return {'label': label, 'reason': str(error), 'expectedReason': reason}
    raise ValueError('Finite JDK refusing control unexpectedly passed')


def main():
    profile = json.loads((ROOT / 'prepared-jdk17-writer-profile.json').read_text())
    if digest(__file__) != profile['producerSha256']:
        raise ValueError('Reviewed JDK writer source differs')
    for source in profile['readerInputs']:
        if digest(ROOT.parent / source['path']) != source['sha256']:
            raise ValueError('Reviewed finite JDK snapshot reader differs')
    if ARCHIVE.stat().st_size != ARCHIVE_BYTES or digest(ARCHIVE) != ARCHIVE_SHA256:
        raise ValueError('Authenticated exact JDK archive differs')
    rowfile = ROOT / 'archive-complete-members.json.gz'
    if digest(rowfile) != ROWS_SHA256:
        raise ValueError('Reviewed JDK complete member rows differ')
    rows = json.loads(gzip.decompress(rowfile.read_bytes()))
    if len(rows) != 551 or sum(row['kind'] == 'file' for row in rows) != 459 or sum(row['kind'] == 'directory' for row in rows) != 92:
        raise ValueError('Actual finite JDK member/type set differs')
    names = set()
    for row in rows:
        path = row['path']
        if path != PREFIX and not path.startswith(PREFIX + '/'):
            raise ValueError('Actual finite JDK root differs')
        if '\\' in path or any(part in ['', '.', '..'] for part in path.split('/')) or row['kind'] not in ['directory','file']:
            raise ValueError('Reviewed JDK member path/type differs')
        if path in names:
            raise ValueError('Reviewed JDK member collision')
        names.add(path)
        mode = int(row['mode'], 8)
        if (row['kind'] == 'directory' and mode != 0o2755) or (row['kind'] == 'file' and mode not in [0o444, 0o644, 0o755]):
            raise ValueError('Reviewed JDK producer privilege mode differs')
    verifier = ROOT / 'verifier-route' / 'reviewed-runtime'
    crypto = json.loads((verifier / 'signature-qualification.json').read_text())
    if (crypto.get('exactSignerFingerprint') != '3B04D753C9050D9A5D343F39843C48A565F8F04B' or
        crypto.get('positiveExit') != 0 or crypto.get('signatureValueOnlyNegativeExit') != 1 or
        crypto.get('restoredPositiveExit') != 0 or crypto.get('allExactBytesUnchanged') is not True or
        crypto.get('allOwnedChildrenReleased') is not True):
        raise ValueError('Exact JDK publisher signature qualification is required')
    for label, status in [('signature-positive',0),('signature-bad-value',1),('signature-restored',0)]:
        command = json.loads((verifier / (label + '.command.json')).read_text())
        if (command['exitCode'] != status or command['timedOut'] or not command['ownedChildReleased'] or
            command['argv'][-1] != str(ARCHIVE)):
            raise ValueError('Exact JDK signature command provenance differs')
        for channel in ['stdout','stderr']:
            if digest(verifier / (label + '.' + channel + '.txt')) != command[channel + 'Sha256']:
                raise ValueError('Exact JDK signature complete output differs')
    if digest(ROOT / (ARCHIVE.name + '.sig')) != '49fe9c24a448e8cb29e42d5c65ef1bb6403c9c0fca0741c96a93cc6d0b3c6edc':
        raise ValueError('Exact verified JDK signature bytes differ')
    if digest(ROOT / 'signature' / 'publisher-key.asc') != 'a46d5d3ab75c3c86dddf1bfd2957a067a24b1c6b2d2ed2bc69294bf970c5160b':
        raise ValueError('Exact verified publisher certificate differs')
    publication = json.loads((verifier / 'publication.json').read_text())
    for member in publication['members']:
        if digest(member['ownedPath']) != member['sha256']:
            raise ValueError('Exact verified tool/library bytes differ')
    if publication['keySha256'] != 'a46d5d3ab75c3c86dddf1bfd2957a067a24b1c6b2d2ed2bc69294bf970c5160b':
        raise ValueError('JDK publisher key input differs')
    if DESTINATION.exists() or DESTINATION.is_symlink():
        raise ValueError('Owned JDK destination must be absent')
    info = ROOT.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid():
        raise ValueError('Owned JDK parent type/ownership differs')
    import sys
    sys.path.insert(0, str(ROOT.parent))
    from acquire import snapshot
    before = snapshot()
    save('jdk-writer-running.json', {'pid': os.getpid(), 'pgid': os.getpgrp(), 'startedAt': STARTED_AT, 'deadlineSeconds': DEADLINE_SECONDS, 'producerSha256': digest(__file__), 'archiveSha256': ARCHIVE_SHA256, 'destination': str(DESTINATION)})
    DESTINATION.mkdir(mode=0o700)
    os.chown(DESTINATION, -1, os.getgid())
    by_name = {row['path']: row for row in rows}
    for row in sorted(rows, key=lambda row: (row['path'].count('/'), row['path'])):
        if row['kind'] != 'directory': continue
        (DESTINATION / row['path']).mkdir(mode=0o700)
    with tarfile.open(ARCHIVE, 'r|gz') as archive:
        seen = set()
        for item in archive:
            remaining()
            name = item.name.rstrip('/')
            row = by_name.get(name)
            if row is None or name in seen or item.size != row['bytes'] or item.mode != int(row['mode'],8):
                raise ValueError('Actual JDK tar member disagrees with reviewed rows')
            seen.add(name)
            if row['kind'] == 'directory':
                if not item.isdir(): raise ValueError('Actual JDK tar directory type differs')
                continue
            if not item.isfile(): raise ValueError('Actual JDK tar regular type differs')
            target = DESTINATION / name
            info = target.parent.lstat()
            if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid():
                raise ValueError('Owned JDK regular parent differs')
            mode = int(row['mode'],8)
            fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode)
            with os.fdopen(fd, 'wb') as output, archive.extractfile(item) as content:
                while block := content.read(READ_CHUNK_BYTES):
                    remaining()
                    output.write(block)
                os.fchmod(output.fileno(),mode)
            verify_inode(target,row)
        if seen != names: raise ValueError('Actual JDK tar member set differs')
    for row in sorted(rows, key=lambda row: row['path'].count('/'), reverse=True):
        if row['kind'] == 'directory': (DESTINATION / row['path']).chmod(int(row['mode'],8))
    def verify_complete():
        found = set()
        for directory, dirs, files in os.walk(DESTINATION, followlinks=False):
            for name in dirs + files:
                remaining()
                found.add(str((Path(directory)/name).relative_to(DESTINATION)))
        if found != names: raise ValueError('Owned JDK complete path set differs')
        return [{**row, 'ownedInode': verify_inode(DESTINATION / row['path'], row).st_ino} for row in rows]
    verify_complete()
    controls = []
    row = next(row for row in rows if row['path'].endswith('/release'))
    path = DESTINATION / row['path']
    original = path.read_bytes()
    changed = bytearray(original)
    changed[0] ^= 1
    path.chmod(0o644)
    path.write_bytes(changed)
    path.chmod(int(row['mode'],8))
    try: controls.append(refusal('actual-release-byte',lambda:verify_inode(path,row),'Owned JDK regular bytes differ'))
    finally:
        path.chmod(0o644)
        path.write_bytes(original)
        path.chmod(int(row['mode'],8))
    verify_inode(path,row)
    path.chmod(0o755 if int(row['mode'],8) != 0o755 else 0o644)
    try: controls.append(refusal('actual-release-mode',lambda:verify_inode(path,row),'Owned JDK producer mode differs'))
    finally: path.chmod(int(row['mode'],8))
    directory = next(row for row in rows if row['path'] == PREFIX)
    path = DESTINATION / PREFIX
    path.chmod(0o755)
    try: controls.append(refusal('actual-directory-setgid',lambda:verify_inode(path,directory),'Owned JDK producer mode differs'))
    finally: path.chmod(0o2755)
    final = verify_complete()
    if before != snapshot(): raise ValueError('Preserved native source changed during JDK writer')
    save('jdk-writer-result.json', {'rows':final,'controls':controls,'restoredCompletePositive':True,'exactDirectorySetgidPreserved':True,'archiveUidGidNotApplied':True,'sourcePreserved':True,'elapsedSeconds':time.monotonic()-START,'scope':'Exact owned JDK filesystem materialization only; no JVM, Gradle or app execution','finishedAt':datetime.now(timezone.utc).isoformat()})


if __name__ == '__main__':
    try: main()
    except BaseException as error:
        save('jdk-writer-failure.json',{'error':str(error),'intendedRejectingControl':False,'ownedDestinationPreserved':str(DESTINATION),'finishedAt':datetime.now(timezone.utc).isoformat()})
        raise
