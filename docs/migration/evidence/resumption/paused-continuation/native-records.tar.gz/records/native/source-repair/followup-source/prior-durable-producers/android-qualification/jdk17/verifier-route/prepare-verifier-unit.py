import datetime
import hashlib
import json
import os
import re
import signal
import stat
import subprocess
import sys
import tarfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUNTIME = ROOT / 'reviewed-runtime'
DEADLINE_SECONDS = 120
COMMAND_TIMEOUT_SECONDS = 30
START = time.monotonic()
FINGERPRINT = '3B04D753C9050D9A5D343F39843C48A565F8F04B'
JDK_ARCHIVE = 'OpenJDK17U-jdk_aarch64_mac_hotspot_17.0.20.1_1.tar.gz'
JDK_SHA256 = '196d13ba5f10414bef7f6a05a9b3f00edacb18ebacef2b99485db9e2ee18f0e8'
SIGNATURE_SHA256 = '49fe9c24a448e8cb29e42d5c65ef1bb6403c9c0fca0741c96a93cc6d0b3c6edc'
KEY_SHA256 = 'a46d5d3ab75c3c86dddf1bfd2957a067a24b1c6b2d2ed2bc69294bf970c5160b'
CHILDREN = []


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while block := stream.read(1024 * 1024):
            value.update(block)
    return value.hexdigest()


def save(name, value):
    (RUNTIME / name).write_text(json.dumps(value, indent=2) + '\n')


def command(label, argv, environment):
    timeout = min(COMMAND_TIMEOUT_SECONDS, DEADLINE_SECONDS - (time.monotonic() - START))
    if timeout <= 0:
        raise ValueError('Reviewed verifier unit deadline exceeded')
    child = subprocess.Popen(argv, cwd=RUNTIME, env=environment, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    row = {'argv': argv, 'environment': environment, 'pid': child.pid, 'pgid': child.pid,
           'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'timeoutSeconds': timeout}
    CHILDREN.append(row)
    try:
        out, err = child.communicate(timeout=timeout)
        timed_out = False
    except subprocess.TimeoutExpired:
        os.killpg(child.pid, signal.SIGKILL)
        out, err = child.communicate()
        timed_out = True
    (RUNTIME / (label + '.stdout.txt')).write_bytes(out)
    (RUNTIME / (label + '.stderr.txt')).write_bytes(err)
    row.update({'exitCode': child.returncode, 'timedOut': timed_out, 'ownedChildReleased': child.poll() is not None,
                'finishedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'stdoutSha256': hashlib.sha256(out).hexdigest(), 'stderrSha256': hashlib.sha256(err).hexdigest()})
    save(label + '.command.json', row)
    return row, out, err


def main():
    profile = json.loads((ROOT / 'selected-verifier-route.json').read_text())
    if digest(__file__) != profile['preparedExecutionProducerSha256']:
        raise ValueError('Prepared verifier execution source changed from reviewed profile')
    publications = profile['fixedPublicationMembers']
    expected_members = {
        ('sqv-arm64-tahoe.bottle.tar.gz', 'sequoia-sqv/1.5.0/bin/sqv', 'bin/sqv'),
        ('openssl4-arm64-tahoe.bottle.tar.gz', 'openssl@4/4.0.3/lib/libcrypto.4.dylib', 'lib/libcrypto.4.dylib'),
        ('openssl4-arm64-tahoe.bottle.tar.gz', 'openssl@4/4.0.3/lib/libssl.4.dylib', 'lib/libssl.4.dylib'),
    }
    if len(publications) != 3 or {(row['archive'], row['member'], row['destination']) for row in publications} != expected_members:
        raise ValueError('Profile differs from the three finite reviewed publication owners')
    archive = ROOT.parent / JDK_ARCHIVE
    signature = ROOT.parent / (JDK_ARCHIVE + '.sig')
    key = ROOT.parent / 'signature' / 'publisher-key.asc'
    if archive.stat().st_size != 185851019 or digest(archive) != JDK_SHA256 or digest(signature) != SIGNATURE_SHA256 or digest(key) != KEY_SHA256:
        raise ValueError('Reviewed exact archive, signature or publisher key input changed')
    if RUNTIME.exists():
        raise ValueError('Reviewed verifier runtime root must be absent')
    version = subprocess.run(['/usr/bin/sw_vers', '-productVersion'], capture_output=True, check=True).stdout.decode().strip()
    arch = subprocess.run(['/usr/bin/arch'], capture_output=True, check=True).stdout.decode().strip()
    if arch != 'arm64' or int(version.split('.')[0]) < 26:
        raise ValueError('Selected exact OpenSSL4 arm64_tahoe binary floor not met')
    RUNTIME.mkdir(mode=0o700)
    for subdir in ['bin', 'lib', 'keyring']:
        (RUNTIME / subdir).mkdir(mode=0o700)
    published = []
    for row in publications:
        bottle = ROOT / row['archive']
        if digest(bottle) != row['archiveSha256']:
            raise ValueError('Reviewed public bottle hash changed')
        with tarfile.open(bottle, 'r:*') as stream:
            member = stream.getmember(row['member'])
            if not member.isfile() or member.size != row['bytes'] or member.mode != int(row['mode'], 8):
                raise ValueError('Reviewed finite publication member type, size or producer mode changed')
            raw = stream.extractfile(member).read()
        if hashlib.sha256(raw).hexdigest() != row['sha256']:
            raise ValueError('Reviewed finite member bytes changed')
        destination = RUNTIME / row['destination']
        with destination.open('xb') as output:
            output.write(raw)
        destination.chmod(member.mode)
        info = destination.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_nlink != 1 or digest(destination) != row['sha256']:
            raise ValueError('Reviewed finite member publication lost exact owned regular identity')
        published.append(dict(row, ownedPath=str(destination), ownedInode=info.st_ino))
    owned_key = RUNTIME / 'keyring' / 'publisher-key.asc'
    owned_key.write_bytes(key.read_bytes())
    owned_key.chmod(0o444)
    reference_time = datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0).isoformat().replace('+00:00', 'Z')
    environment = {'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C',
                   'DYLD_LIBRARY_PATH': str(RUNTIME / 'lib'), 'DYLD_FALLBACK_LIBRARY_PATH': '',
                   'SEQUOIA_CRYPTO_POLICY': '', 'OPENSSL_CONF': '/dev/null',
                   'OPENSSL_MODULES': str(RUNTIME / 'unpublished-modules'), 'OPENSSL_ENGINES': str(RUNTIME / 'unpublished-engines')}
    executable = str(RUNTIME / 'bin' / 'sqv')
    save('publication.json', {'members': published, 'keySha256': digest(owned_key), 'keyringModel': 'One exact publisher certificate file, no imported/global keyring or trust settings.',
                              'referenceTimeUtc': reference_time, 'sourceProducerSha256': digest(__file__), 'profileSha256': digest(ROOT / 'selected-verifier-route.json')})
    row, out, err = command('loader-version', [executable, '--version'], dict(environment, DYLD_PRINT_LIBRARIES='1'))
    if row['exitCode'] != 0 or row['timedOut'] or b'sqv 1.5.0' not in out:
        raise ValueError('Owned verifier loader/version setup positive failed; no cryptographic acceptance or negative')
    loaded = []
    for line in err.decode().splitlines():
        if line.startswith('dyld['):
            match = re.search(r'(/[^\n]+)$', line)
            if match:
                loaded.append(match.group(1))
    for path in [str(RUNTIME / 'lib' / 'libssl.4.dylib'), str(RUNTIME / 'lib' / 'libcrypto.4.dylib')]:
        if path not in loaded:
            raise ValueError('Actual loader output did not prove the owned exact OpenSSL4 libraries')
    if any(not path.startswith((str(RUNTIME) + '/', '/usr/lib/', '/System/Library/')) for path in loaded):
        raise ValueError('Actual loader selected an unqualified non-OS library image')
    common = [executable, '--verbose', '--keyring', str(owned_key), '--signatures', '1', '--time', reference_time]
    expected_stdout = (FINGERPRINT + '\n').encode()
    positive, stdout, stderr = command('signature-positive', common + ['--signature-file', str(signature), str(archive)], environment)
    if positive['exitCode'] != 0 or positive['timedOut'] or stdout != expected_stdout or b'1 of 1 signatures are valid (threshold is: 1).' not in stderr:
        raise ValueError('Actual exact signature positive failed; no cryptographic negative may be accepted')
    original = signature.read_bytes()
    changed = bytearray(original)
    changed[309] ^= 1
    if changed[:309] != original[:309] or hashlib.sha256(changed).hexdigest() != profile['signatureValueOnlyNegative']['sha256']:
        raise ValueError('Prepared negative changed the signature structure rather than only the final RSA value byte')
    bad_signature = RUNTIME / 'signature-value-only-negative.sig'
    bad_signature.write_bytes(changed)
    negative, stdout, stderr = command('signature-bad-value', common + ['--signature-file', str(bad_signature), str(archive)], environment)
    if negative['exitCode'] != 1 or negative['timedOut'] or stdout != b'' or b'Verifying signature:' not in stderr or b'Message has been manipulated' not in stderr or b'0 of 1 signatures are valid (threshold is: 1).' not in stderr:
        raise ValueError('Signature-value-only negative failed for an unexpected reason; halt dependent acceptance')
    restored, stdout, stderr = command('signature-restored', common + ['--signature-file', str(signature), str(archive)], environment)
    if restored['exitCode'] != 0 or restored['timedOut'] or stdout != expected_stdout or b'1 of 1 signatures are valid (threshold is: 1).' not in stderr:
        raise ValueError('Exact signature restored positive failed')
    if digest(archive) != JDK_SHA256 or digest(signature) != SIGNATURE_SHA256 or digest(key) != KEY_SHA256 or any(digest(row['ownedPath']) != row['sha256'] for row in published):
        raise ValueError('Exact archive, signature, key or tool/library bytes changed across controls')
    save('signature-qualification.json', {'exactSignerFingerprint': FINGERPRINT, 'positiveExit': positive['exitCode'],
                                         'signatureValueOnlyNegativeExit': negative['exitCode'], 'actualNegativeReason': 'Sequoia BadSignature: Message has been manipulated',
                                         'restoredPositiveExit': restored['exitCode'], 'allExactBytesUnchanged': True,
                                         'actualLoadedImages': loaded, 'referenceTimeUtc': reference_time,
                                         'allOwnedChildrenReleased': all(row['ownedChildReleased'] for row in CHILDREN),
                                         'noJdkOrNativeCandidateExecution': True})


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        if RUNTIME.exists():
            save('unaccepted-execution-frontier.json', {'error': str(error), 'children': CHILDREN, 'signatureAccepted': False})
        raise
