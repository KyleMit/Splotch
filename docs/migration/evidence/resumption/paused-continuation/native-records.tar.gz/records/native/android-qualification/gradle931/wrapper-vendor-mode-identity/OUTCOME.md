# Recorded wrapper outcome qualification result

The exact approved read-only reader exited 0 at 2026-10-06T22:27:11.199433Z after
1.154720 seconds. It launched no JVM, producer main, downloaded code or installer.
Its full stdout and stderr are preserved with the actual process identity in
`reader.execution.json`. Independent targeted observation released reader/controller
80645/80644 and identity observer80646 at 22:27:57.269208Z; all three PIDs and groups
were absent. The release query81257 also exited and its owned group was absent.
No process was stopped and no cleanup occurred.

`recorded-outcome-qualification.json` is the complete 483,326-byte result, SHA256
b4798a54162a71e09e3b8bd7c1b54cd8390526c813fb6be1565ab22d30fd52a9.
It requalified all original75 file,7 directory and5 external bindings, full140
source rows,320 authenticated Gradle rows,551 JDK rows,59 immutable failure files,
700 final runtime output rows and all three actual command frames/channels. The
actual wrapper calls retain exits0/1/0. Both full positives retain exact copied
Jansi and actual same-PID Java/native-platform/curses successful loads. All four
captured rejecting controls, the actual copied-Jansi one-byte refusal and full
restoration, and the released-wrapper checksum refusal/ZIP deletion/exact restored
properties/archive/install predicates passed. The corrected production vendor view
has320 rows including base`.` and319 children. Only the original private terminal
validator's wrong0644 expectation for actual `bin/gradle`0755 was changed.

This is a separate successful qualification eligible for independent parent
acceptance. The original runtime stage remains failed and immutable. The causal
limit is that its terminal validator changed after execution while actual released
consumers, environments, tested inputs, command channels and final output stayed
exact. No unchanged JVM call was repeated. Complete DYLD coverage remains
failed/open. Current78d composition, F1/N1 source, tasks/plugins/Maven/compiler,
native product and comparative performance acceptance remain separate.
