import ast
import datetime
import hashlib
import json
import os
import re
import signal
import stat
import time
from pathlib import Path

READONLY_START = time.monotonic()
signal.signal(signal.SIGALRM, lambda *_: (_ for _ in ()).throw(TimeoutError('Read-only outcome whole120 deadline')))
signal.setitimer(signal.ITIMER_REAL, 120)
Q = Path('/private/tmp/splotch-resume-01a111b0/native/android-qualification')
ROOT = Q / 'gradle931/wrapper-jansi-copy-identity'
RECEIPT = Q / 'execution/gradle931-wrapper-jansi-copy-identity-receipt'
profile = json.loads((ROOT / 'wrapper-profile.json').read_text())
external = json.loads((ROOT / 'external-stage-profile.json').read_text())
complete = json.loads((RECEIPT / 'complete.json').read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bound(expected):
    path = Path(expected['path'])
    info = path.lstat()
    actual = {'path': str(path), 'realPath': str(path.resolve(strict=True)), 'bytes': info.st_size,
              'device': info.st_dev, 'inode': info.st_ino, 'uid': info.st_uid, 'gid': info.st_gid,
              'mode': oct(stat.S_IMODE(info.st_mode)), 'sha256': sha(path)}
    assert actual == expected and stat.S_ISREG(info.st_mode) and info.st_nlink == 1
    return actual


inputs = [bound(row) for row in profile['inputs']]
for row in profile['directoryInputs']:
    path = Path(row['path'])
    info = path.lstat()
    actual = {'path': str(path), 'device': info.st_dev, 'inode': info.st_ino, 'uid': info.st_uid,
              'gid': info.st_gid, 'mode': oct(stat.S_IMODE(info.st_mode))}
    assert actual == row and stat.S_ISDIR(info.st_mode) and path.resolve(strict=True) == path
for name in ['producer', 'profile', 'supervisor', 'recorder', 'python']:
    bound(external[name])
assert complete['exitCode'] == 1 and complete['allOwnedGroupsGone'] and complete['inputsUnchanged']
assert complete['completeStartedChildExitRecords'] and not complete['timedOut']
for name, row in complete['sourceInputs'].items():
    assert sha(Path(row['path'])) == row['sha256']
for name in ['stdout', 'stderr']:
    row = complete[name]
    assert (RECEIPT / row['path']).stat().st_size == row['bytes'] and sha(RECEIPT / row['path']) == row['sha256']

source = ROOT / 'qualify-wrapper-identity.py'
assert sha(source) == profile['producerSha256']
corrected_source = Q / 'gradle931/wrapper-vendor-mode-identity/corrected-vendor-mode-source.py'
original_raw = source.read_text()
assert original_raw.count("mode = 0o755 if row['path'].endswith('/bin/gradle') else 0o644") == 1
assert corrected_source.read_text() == original_raw.replace("mode = 0o755 if row['path'].endswith('/bin/gradle') else 0o644", "mode = 0o755 if row['path'] == 'bin/gradle' else 0o644", 1)
mode_profile_path = corrected_source.parent / 'qualification-profile.json'
mode_profile = json.loads(mode_profile_path.read_text())
for name, expected in mode_profile['bindings'].items():
    bound(expected)
assert sha(Path(__file__).resolve()) == mode_profile['readerSha256']
assert mode_profile['wholeDeadlineSeconds'] == 120
mirror = json.loads(Path(mode_profile['bindings']['immutableFailureMirror']['path']).read_text())
for row in mirror['rows']:
    path = Path(row['source'])
    info = path.lstat()
    assert path.resolve(strict=True) == path and stat.S_ISREG(info.st_mode) and info.st_nlink == 1
    assert info.st_dev == row['sourceDevice'] and info.st_ino == row['sourceInode']
    assert info.st_size == row['bytes'] and oct(stat.S_IMODE(info.st_mode)) == row['mode'] and sha(path) == row['sha256']
graph = json.loads(Path(mode_profile['bindings']['immutableRuntimeGraph']['path']).read_text())
runtime_root = Path(graph['root'])
root_info = runtime_root.lstat()
assert runtime_root.resolve(strict=True) == runtime_root and stat.S_ISDIR(root_info.st_mode)
assert root_info.st_uid == profile['actorUid'] and root_info.st_gid == profile['ownedGid'] and stat.S_IMODE(root_info.st_mode) == 0o700
assert {str((Path(folder) / name).relative_to(runtime_root)) for folder, dirs, files in os.walk(runtime_root, followlinks=False) for name in dirs + files} == {row['path'] for row in graph['rows']}
for row in graph['rows']:
    path = runtime_root / row['path']
    info = path.lstat()
    assert path.resolve(strict=True) == path and info.st_dev == row['device'] and info.st_ino == row['inode']
    assert info.st_uid == row['uid'] and info.st_gid == row['gid'] and info.st_nlink == row['nlink'] and oct(stat.S_IMODE(info.st_mode)) == row['mode']
    if row['kind'] == 'file':
        assert stat.S_ISREG(info.st_mode) and info.st_size == row['bytes'] and sha(path) == row['sha256']
    else:
        assert row['kind'] == 'directory' and stat.S_ISDIR(info.st_mode)
mode_controls = json.loads(Path(mode_profile['bindings']['capturedModeControlResult']['path']).read_text())
assert mode_controls['correctedSourceSha256'] == sha(corrected_source) and mode_controls['restoredCapturedPositive']
assert mode_controls['modeOnlyRefusal']['actualReason'] == mode_controls['modeOnlyRefusal']['expectedActualReason']
assert mode_controls['actualOtherReleasedScriptMode0644Positive'] and not mode_controls['JVMMainOrConsumerExecuted']
parsed = ast.parse(corrected_source.read_text())
selected = {'remaining', 'sha', 'verify_tree', 'source70', 'jvm_identity', 'positive', 'copied_jansi', 'cache_graph'}
namespace = {'Path': Path, 'os': os, 'stat': stat, 're': re, 'json': json, 'hashlib': hashlib, 'time': time,
             'START': READONLY_START, 'WHOLE_DEADLINE_SECONDS': 120, 'CHUNK_BYTES': 1048576}
functions = [node for node in parsed.body if isinstance(node, ast.FunctionDef) and node.name in selected]
assert {node.name for node in functions} == selected
exec(compile(ast.Module(body=functions, type_ignores=[]), str(corrected_source), 'exec'), namespace)
gradle_rows = json.loads(Path(profile['gradleResult']).read_text())['installedRows']
java_rows = json.loads(Path(profile['jdkWriterResult']).read_text())['rows']
gradle = namespace['verify_tree'](Path(profile['gradleTree']), gradle_rows, profile['actorUid'], profile['ownedGid'])
java = namespace['verify_tree'](Path(profile['javaTree']), java_rows, profile['actorUid'], profile['javaTreeGid'])
sources = namespace['source70'](profile)
commands = []
observed = {}
for label, home_name in [('wrapper-positive', 'positive-home'), ('wrapper-checksum-negative', 'negative-home'), ('wrapper-restored', 'negative-home')]:
    command_path = ROOT / (label + '.command.json')
    command = json.loads(command_path.read_text())
    stdout = (ROOT / (label + '.stdout.txt')).read_text()
    stderr = (ROOT / (label + '.stderr.txt')).read_text()
    assert hashlib.sha256(stdout.encode()).hexdigest() == command['stdoutSha256']
    assert hashlib.sha256(stderr.encode()).hexdigest() == command['stderrSha256']
    frame = command['wholeSourceRuntimeInputsBeforeAndAfter']
    assert frame['inputs'] == profile['directoryInputs'] + inputs
    assert frame['trees'] == {'gradle': gradle, 'jdk': java} and frame['source70'] == sources
    home = ROOT / 'owned-runtime' / home_name
    observed[label] = namespace['positive'](stdout, stderr, command, home, profile) if label != 'wrapper-checksum-negative' else namespace['jvm_identity'](stderr, command, home, profile)
    commands.append({'label': label, 'exitCode': command['exitCode'], 'actualPid': command['pid'],
                     'commandSha256': sha(command_path), 'stdoutSha256': command['stdoutSha256'], 'stderrSha256': command['stderrSha256'],
                     'readOnlyActualCapturedProductionPredicateMatched': True})
assert [row['exitCode'] for row in commands] == [0, 1, 0]
controls = json.loads((ROOT / 'captured-native-load-controls.json').read_text())
assert len(controls['controls']) == 4 and controls['exactRawAndInputRestoredPositive']
jansi_control = json.loads((ROOT / 'copied-jansi-control.json').read_text())
assert jansi_control['expectedActualReason'] == jansi_control['actualReason'] == 'Actual copied Jansi differs from authenticated member bytes/hash'
assert jansi_control['restored'] and jansi_control['priorActualWrapperGroupGone'] and not jansi_control['JVMInvokedWhileMemberChanged']
assert jansi_control['before'] == jansi_control['restoredReadback'] == observed['wrapper-positive']['copiedJansiMember']
original = (ROOT / 'copied-jansi-original.bin').read_bytes()
changed = (ROOT / 'copied-jansi-byte-changed.bin').read_bytes()
assert len(original) == len(changed) == jansi_control['before']['bytes']
assert [index for index, (left, right) in enumerate(zip(original, changed)) if left != right] == [0]
assert hashlib.sha256(original).hexdigest() == jansi_control['before']['sha256']
assert hashlib.sha256(changed).hexdigest() == jansi_control['changedSha256']
negative = json.loads((ROOT / 'checksum-negative.json').read_text())
negative_stderr = (ROOT / 'wrapper-checksum-negative.stderr.txt').read_text()
assert all(message in negative_stderr for message in negative['requiredActualVendorMessages'])
assert negative['actualZipDeletedByReleasedChecksumOwner'] and negative['distributionNotInstalled']
properties = ROOT / 'owned-runtime/negative-project/gradle/wrapper/gradle-wrapper.properties'
assert properties.read_bytes() == Path(profile['wrapperProperties']).read_bytes()

home = ROOT / 'owned-runtime/negative-home'
cache = home / 'wrapper/dists/gradle-9.3.1-bin' / profile['releasedUrlMd5Base36']
vendor = cache / 'gradle-9.3.1'
assert not (cache / 'gradle-9.3.1-bin.zip').exists() and not (cache / 'gradle-9.3.1-bin.zip').is_symlink()
assert (cache / 'gradle-9.3.1-bin.zip.ok').read_bytes() == b''
contents = [dict(row, path=row['path'].removeprefix('gradle-9.3.1/')) for row in gradle_rows if row['path'] != 'gradle-9.3.1']
assert {str((Path(folder) / name).relative_to(vendor)) for folder, dirs, files in os.walk(vendor, followlinks=False) for name in dirs + files} == {row['path'] for row in contents}
corrected_production_vendor_rows = namespace['verify_tree'](vendor, contents, profile['actorUid'], profile['ownedGid'], False, True, 0o755)
assert len(corrected_production_vendor_rows) == 320
vendor_rows = []
incorrect_mode_expectations = []
for row in contents:
    path = vendor / row['path']
    info = path.lstat()
    actual_mode = stat.S_IMODE(info.st_mode)
    released_expected_mode = (0o755 if row['path'] == 'bin/gradle' else 0o644) if row['kind'] == 'file' else 0o755
    failed_expected_mode = (0o755 if row['path'].endswith('/bin/gradle') else 0o644) if row['kind'] == 'file' else 0o755
    assert path.resolve(strict=True) == path and info.st_uid == profile['actorUid'] and info.st_gid == profile['ownedGid']
    assert actual_mode == released_expected_mode
    assert stat.S_ISREG(info.st_mode) if row['kind'] == 'file' else stat.S_ISDIR(info.st_mode)
    if row['kind'] == 'file':
        assert info.st_nlink == 1 and info.st_size == row['bytes'] and sha(path) == row['sha256']
    observed_row = {'path': row['path'], 'kind': row['kind'], 'device': info.st_dev, 'inode': info.st_ino,
                    'uid': info.st_uid, 'gid': info.st_gid, 'mode': oct(actual_mode), 'bytes': row['bytes'], 'sha256': row.get('sha256')}
    vendor_rows.append(observed_row)
    if actual_mode != failed_expected_mode:
        incorrect_mode_expectations.append({'path': row['path'], 'actualMode': oct(actual_mode), 'failedPredicateExpectedMode': oct(failed_expected_mode), 'exactReleasedOwnerExpectedMode': oct(released_expected_mode)})
assert incorrect_mode_expectations == [{'path': 'bin/gradle', 'actualMode': '0o755', 'failedPredicateExpectedMode': '0o644', 'exactReleasedOwnerExpectedMode': '0o755'}]
result = {'observedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'scope': 'Separate read-only corrected-terminal-validator qualification over immutable original actual consumer calls/channels/controls/current source/runtime/final graph; original runtime stage remains failed, no JVM/main/consumer rerun',
          'originalRuntimeStageRemainsFailed': True, 'eligibleForIndependentRecordedOutcomeAcceptance': True, 'parentAcceptanceNotInferred': True, 'integrationOrN1Accepted': False, 'intendedRejectingFailure': False, 'current75Inputs7Directories5ExternalUnchanged': True,
          'fullGradle320PlusRootUnchanged': True, 'fullJdk551PlusRootUnchanged': True, 'fullOriginal70Repaired70Unchanged': True,
          'capturedProductionPredicatesReplayedWithoutJVMOrMainExecution': True, 'actualCommands': commands,
          'actualPositive': observed['wrapper-positive'], 'actualChecksumRefusal': observed['wrapper-checksum-negative'],
          'actualRestoredPositive': observed['wrapper-restored'], 'capturedLoadControlCount': 4, 'copiedJansiControl': jansi_control,
          'correctVendorChecksumRefusalAndExactPropertiesRestoration': True, 'restoredActualMarkerPresentEmptyAndZipAbsent': True,
          'restoredFullVendorInstalledRows': vendor_rows, 'onlyFailedModeExpectation': incorrect_mode_expectations,
          'positiveCacheGraph': namespace['cache_graph'](ROOT / 'owned-runtime/positive-home', profile),
          'restoredCacheGraph': namespace['cache_graph'](home, profile), 'producerSha256': sha(source),
          'profileSha256': sha(ROOT / 'wrapper-profile.json'), 'completeSha256': sha(RECEIPT / 'complete.json'),
          'releaseSha256': sha(RECEIPT / 'release.json'), 'failureSha256': sha(ROOT / 'wrapper-identity-failure.json'),
          'qualifiedValidatorSha256': sha(corrected_source), 'validatorDeltaSha256': sha(corrected_source.parent / 'validator.diff'),
          'correctedProductionVendorRows': corrected_production_vendor_rows,
          'fullImmutableFailureMirror59FilesUnchanged': True, 'full700RuntimeOutputRowsUnchanged': True,
          'modeOnlyProductionPredicateControls': mode_controls, 'readOnlyWholeElapsedSeconds': time.monotonic() - READONLY_START,
          'causalLimit': 'One private terminal validator expression changed; actual released wrapper/JDK/Gradle/JNI consumers, environments, three original captured calls, original runtime producer/profile and every original channel remain immutable. Read-only corrected validation reuses those exact results and does not relabel the failed original stage.',
          'releasedOwner': {'path': profile['installOwner'], 'sha256': sha(Path(profile['installOwner'])), 'selection': 'setExecutablePermissions: new File(gradleHome, bin/gradle), chmod755'},
          'completeDyldStatus': 'Failed/open; narrow loads/copied bytes cannot close it', 'JVMGradleNativeCompilerRerun': False}
output = corrected_source.parent / 'recorded-outcome-qualification.json'
assert time.monotonic() - READONLY_START < 120
with output.open('x') as stream:
    stream.write(json.dumps(result, indent=2) + '\n')
print(json.dumps({'output': str(output), 'sha256': sha(output), 'parentAcceptanceNotInferred': True,
                  'actualCommandExits': [row['exitCode'] for row in commands], 'onlyFailedModeExpectation': incorrect_mode_expectations,
                  'restoredVendorRows': len(vendor_rows), 'sourceFramesUnchanged': True}))

signal.setitimer(signal.ITIMER_REAL, 0)
