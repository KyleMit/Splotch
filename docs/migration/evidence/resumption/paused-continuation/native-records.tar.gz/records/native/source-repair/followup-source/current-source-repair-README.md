# N1 corrected source and trust inputs

This owned source composition uses accepted base 794448fbf76276b76a910c167b5c2e0c4e1ea538.
Production/tools/package/lock owners remain those of f14966ee98563e3c569fbcb90beea6d9c684614a;
incoming accepted docs/evidence are retained. `frozen-source-manifest.json` binds the current source
tree, complete 70 rows, exact Node24 bytes, prepared producers and review provenance. `source.diff`
is the complete binary-capable diff from accepted base; `original70-repair.diff` isolates changes
from the preserved intake. This is an unaccepted source unit. F1 is unaccepted and its source was
not imported; candidate JavaScript is unchanged. All 70 original intake bytes/modes remain preserved
at dc08a90abc67b53124146bf288c80de0f9ffd1dd.

## Original review and bounded repairs

The original Claude conversation 7c940639-09e2-4236-961f-1122171cb5d8 actually resumed for
substantive round two. It reviewed snapshot 54238add5e3aa6ab8a2971aa7175483657b6fe2d, whose complete
source tree is d0dc567f83fd602457e0a7cfbfefa62b7f911a9b. Complete structured report, session,
completion, ledger and exact reviewed source/capsule/producers are immutable under `review-round2/`.
The result resolved all eight original findings and raised two suggestions and one formatter nit.
Source/trust observations do not establish executable trust, installation, native compilation or
mount.

Two rounds are spent and one remains. The original 93cd ledger is unchanged; the actual
source-review key c2725d19511d43e8cbad5a98e5a6ff64 holds the resumed original identity and rounds 2.
Future PR-key adoption must carry that identity and budget. No fresh reviewer or budget reset is
permitted. `ledger-adoption-plan.json` records the actual transition and future adoption
requirement.

The bounded follow-up repairs are:

* The maintained Apple bundle phase checks the reviewed version from `NATIVE_CONTRACT.nodeVersion`.
  The source contract and real phase controls reject version drift and restore a positive. A version
  forwarding fixture keeps this source selector test runnable on root Node22; native bundling
  remains stubbed. Exact real Node24 path/bytes and effective native consumer identity are later
  Release gates, not established by this fixture.
* The disposable Apple environment producer pins Node24 first on the future pod PATH, captures
  `command -v node`, version and byte identity, clears `EX_UPDATES_NATIVE_DEBUG`, and refuses
  `.xcode.env.updates`. `apple-caller-contract.json` binds ten actual released consumers and
  requires complete generated-project deltas and both environment files before/after generation and
  Release. The final bundle caller must prove exact prepared `NODE_BINARY` path and digest. No pod
  caller has executed.
* Four candidate formatter re-includes precede general build/node_modules/Markdown/SVG exclusions.
  Real candidate JSON remains formatted, shipping native remains excluded, and actual owned build,
  Markdown, SVG and node_modules fixture files stay excluded.

The eight original repairs remain bounded: distinct omission/symlink restoration; precise formatter
ownership; lint and recipe quoting without output change; Git owner-executable class versus exact
producer modes under a real restrictive checkout; removal of speculative generated-directory
allowlists; two-file Xcode regeneration ownership; effective bundle-selector and legitimate pinned
Hermes compiler checks; and exact registry0BSD versus archiveMIT license preservation. No rule/cap
or platform floor was weakened and no candidate feature was added.

## Source execution evidence

Historical `checks/commands.json` and `test-control-inventory.json.txt` authenticate all 111 scoped
controls on original d0dc, the source checker, pinned-template regeneration/idempotence, and scoped
lint/format. These receipts are retained history and cannot certify the changed follow-up source.
The frozen c8a78 source runner finished in 15.527175 seconds within its 120-second lease.
`followup-checks/` binds actual changed recipe regeneration, both 112-control Node24/Node22 suite
passes, source checker, real materializer idempotence, scoped lint/format, dynamic 112-name
collection, complete exits/full outputs and unchanged source/borrowed dependency readback. All owned
groups are proven gone; the lease released at 18:49:09.685823Z. Separate passive version readbacks
bind both actual runtime bytes. `followup-controls.json` links exact new rejection reasons, restored
positives and producer controls that remain unexecuted. The complete current source tree is
7da00012890a72e46eb5cdc390dab8c63f0035a3; source acceptance/full gates remain pending.

Rival sandboxed Bash/tests in its worktree were permitted by the actual wrapper. Its clipped
head/tail pipelines and requested 300000 ms timeout do not supply the campaign's complete <=120s
owned-group receipt. `round2-autonomous-command-limit.json` keeps those observations as limited
review diagnostics; independent complete source receipts retain their own scope. No wrapper policy
violation is claimed.

`observed-setup-errors.json` and `initial-tool-visible-excerpts.txt` retain the observed initial
fixture/lint failures. A skipped backup after a shell glob error led to overwritten initial command
files. Those excerpts are transcribed tool-visible output, not authenticated original stdout bytes;
no complete initial receipt or initial frozen revision is claimed. Setup failures are not rejecting
controls.

## Finite prepared trust boundaries

All four producers remain unexecuted. Their exact source/profile hashes and AST syntax records are
separate from executable acceptance. Original round-two producer bytes remain immutable under
`review-round2/prepared-inputs/`.

* `../android-qualification/prepare-ndk-writer.py` authenticates one exact owned archive descriptor,
  passes that same object through layout parsing, source copying and independent second member
  readback, then checks the same descriptor's identity and SHA256/SHA1 again. Exact path/mode/inode
  readback retains all 9177 members, including AppleDouble bytes and 23 contained links. Four real
  byte/mode/escape/cycle controls restore the complete positive. The dormant top-level-link base is
  corrected with `posixpath.dirname`. Existing XML/archive/reader controls are reused only on exact
  unchanged relevant inputs. No publisher per-file SHA or independent NDK signature is implied.
* `../android-qualification/jdk17/verifier-route/prepare-verifier-unit.py` publishes only the exact
  three Sequoia/OpenSSL bottle members with unchanged bytes/modes. Process-local loader trace,
  publisher fingerprint, exact signature positive, RSA-value-only BadSignature refusal and restored
  positive remain required executed gates. Distribution HTTPS/hashes, ad-hoc Mach-O signing,
  incomplete bottle builder graph, publisher authority and signature-time key liveness remain
  explicit limits.
* `../android-qualification/jdk17/prepare-jdk17-writer.py` requires complete exact
  sqv/key/signature/ archive argv under shared `--time`, exact producer/profile hashes and exactly
  three published member identities. Actual-receipt key/time/producer/extra-member controls must
  refuse and restore. Only the authenticated 551-member JDK may materialize; bytes/modes/UID/single
  inodes are checked. Directory 02755 proves publisher-mode bookkeeping only, with no macOS
  group-inheritance or privilege claim. No Java/Gradle execution occurs in the filesystem writer.
* `prepare-apple-environment.py` prepares two exact files in a verified independent disposable
  source copy. Actual pod generation, locks, project deltas, effective Node/compiler identity and
  native Release consumers remain distinct pending gates.

These finite writers require a trusted host with no concurrent same-UID input or parent-directory
mutation. Complete before/after realpath/inode/mode/regular-byte checks detect persistent changes;
final-component no-follow checks do not provide adversarial parent-swap protection. The NDK's exact
archive authenticity is separately bound to its one file descriptor. No general installer,
framework, new dependency, global tool/keyring/license setting or archived ownership is introduced.

Parent disposition of these bounded original-round-two repairs and a distinct execution lease
precede downloaded-code trust work. Required final-source full gates, F1 acceptance, final-head CI
and independent acceptance precede source integration. The next runtime unit remains the smallest
optimized Android Release after relevant toolchain/source gates, with effective flags, full Hermes
payload validity/consumption, modules/permissions and actual mount/draw/input. Apple optimized
compilation and floors remain required. Simulator mechanics and shipping Capacitor compilation
cannot discharge those gates.

Raw rival conversations/tool streams remain host-local ignored evidence. A future public technical
capsule may include complete structured findings/session/completion/ledger and qualified command
receipts; it must not export raw conversations or authentication state. The host-local durable
mirror is distinct from such a public capsule.
