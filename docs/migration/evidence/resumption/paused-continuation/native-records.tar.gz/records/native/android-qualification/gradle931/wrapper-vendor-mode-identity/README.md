# Recorded wrapper outcome requalification

The original d1d2 producer/ca0e profile stage remains failed and immutable. All
three actual released wrapper/JVM calls exited0/1/0 with full channels preserved.
The actual consumers, environments and authenticated runtime inputs did not
change. The failure was the terminal validator's suffix test: its caller strips
`gradle-9.3.1/`, leaving `bin/gradle`, which cannot end with `/bin/gradle`. It expected
0644 for the correct0755 output. Released Install.java selects exact `bin/gradle`
and calls chmod755. Both the complete source owner and authenticated published
Install.class bytes remain in the preceding diagnosis.

`corrected-vendor-mode-source.py` differs from the failed private producer in ONE
expression, exact `row['path'] == 'bin/gradle'`. It has not run as a producer or main.
Its pure extracted actual production mode/guard predicate was qualified against
the existing actual restored executable. Captured0755 passes, captured0644 alone
refuses for the exact original guard reason, restored0755 passes. The actual
`bin/gradle.bat`0644 also passes. These controls change only an in-memory captured
field; no filesystem byte/mode or JVM input was changed.

The proposed separate read-only reader selects only existing pure filesystem/log
predicates from this corrected source by AST. It cannot invoke the producer main,
subprocess, JVM, installer or downloaded code. Its whole120 timer starts before
input hashing. It binds the original source/profile/external, failed result,
release, readback, full700-row output graph and59-file immutable failure mirror,
plus the corrected validator/delta and mode controls. It checks every current
relevant input, all75+7+external5 bindings, full140 source/320Gradle/551JDK and each
of the three original command frames/channels. It requires unchanged full output
membership/bytes/modes/inodes and the corrected production predicate's full
320-member vendor view. Unrelated stale inputs or missing obligations refuse.

Both full positives must still show exact copied Jansi and same-PID successful
Java/native-platform/curses loads. All four already executed captured controls,
the one-byte copied-Jansi correct refusal/full restoration, the actual checksum
refusal/ZIP deletion and exact restored properties/archive/install remain required.
The original frozen control flow checked positive-cache byte/mode/inode equality
before reaching the recorded checksum call. The terminal validator change cannot
alter those actual released calls or their tested inputs.

The reader has not run; its fresh qualification output is absent. A complete
successful receipt could support independent acceptance of this narrow recorded
outcome while preserving the failed original stage. Parent acceptance remains
separate. No unchanged JVM probe needs repetition unless a relevant input or
unmet predicate emerges. The causal limitation is explicit: the terminal validator
changed after execution; the actual consumer and all recorded results remain exact.

After parent source disposition, the sole proposed read-only command is:

```sh
/opt/homebrew/opt/python@3.14/bin/python3.14 -B /private/tmp/splotch-resume-01a111b0/native/android-qualification/gradle931/wrapper-vendor-mode-identity/qualify-recorded-outcome.py
```

Complete DYLD stays failed/open. This does not accept current78d composition,
F1/N1 source, Gradle tasks/plugins/Maven/compiler/native product or performance.
Private source7da/historical794 and all actual source70 inputs remain exact. Later
composition must use current78d accepted owners and regenerate the topology
contract. Original Claude7c940639-09e2-4236-961f-1122171cb5d8 stays two rounds used/one
remaining. No review round or further runtime stage was started.
