import datetime
import hashlib
import json
import os
import plistlib
import stat
import sys
import time
from pathlib import Path

START=time.monotonic()
ROOT=Path(__file__).resolve().parent
PROFILE_PATH=ROOT/'filesystem-profile.json'
PROFILE=json.loads(PROFILE_PATH.read_text())
BUNDLE=Path(PROFILE['bundleRoot'])
HOME=Path(PROFILE['selectedHome'])


def signature(info):
    return (info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid,info.st_nlink,info.st_size,info.st_mtime_ns,info.st_ctime_ns)


def descriptor(path):
    before=path.lstat()
    if not stat.S_ISREG(before.st_mode): raise ValueError('JDK21_BOUND_INPUT_NOT_REGULAR: '+str(path))
    digest=hashlib.sha256()
    descriptor=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    try:
        opened=os.fstat(descriptor)
        if signature(before)!=signature(opened): raise ValueError('JDK21_BOUND_INPUT_CHANGED_BEFORE_READ: '+str(path))
        while raw:=os.read(descriptor,1024*1024): digest.update(raw)
        if signature(opened)!=signature(os.fstat(descriptor)): raise ValueError('JDK21_BOUND_INPUT_CHANGED_DURING_READ: '+str(path))
    finally: os.close(descriptor)
    if signature(before)!=signature(path.lstat()): raise ValueError('JDK21_BOUND_INPUT_CHANGED_AFTER_READ: '+str(path))
    return {'path':str(path),'bytes':before.st_size,'sha256':digest.hexdigest(),'mode':oct(stat.S_IMODE(before.st_mode)),'uid':before.st_uid,'gid':before.st_gid,'nlink':before.st_nlink,'device':before.st_dev,'inode':before.st_ino,'mtimeNs':before.st_mtime_ns,'ctimeNs':before.st_ctime_ns}


def inputs():
    rows=[]
    for expected in PROFILE['inputs']:
        actual=descriptor(Path(expected['path']))
        for name,value in expected.items():
            if actual[name]!=value: raise ValueError('JDK21_FROZEN_INPUT_DIFFERS: '+expected['path']+' field='+name)
        rows.append(actual)
    return rows


def tree():
    if BUNDLE.resolve(strict=True)!=BUNDLE or HOME.resolve(strict=True)!=HOME or not HOME.is_relative_to(BUNDLE):
        raise ValueError('JDK21_SELECTED_ROOT_NOT_CANONICAL_CONTAINED')
    paths=[BUNDLE]
    for folder,dirs,files in os.walk(BUNDLE,followlinks=False):
        dirs.sort(); files.sort()
        paths.extend(Path(folder)/name for name in dirs+files)
    rows=[]
    for path in sorted(paths,key=lambda item:item.relative_to(BUNDLE).as_posix()):
        before=path.lstat(); relative=path.relative_to(BUNDLE).as_posix()
        if any(value in relative for value in ['\n','\r','\t','\0']): raise ValueError('JDK21_UNSAFE_MEMBER_PATH: '+repr(relative))
        row={'path':relative,'mode':oct(stat.S_IMODE(before.st_mode)),'uid':before.st_uid,'gid':before.st_gid,'nlink':before.st_nlink,'device':before.st_dev,'inode':before.st_ino,'bytes':before.st_size,'mtimeNs':before.st_mtime_ns,'ctimeNs':before.st_ctime_ns}
        if stat.S_ISDIR(before.st_mode):
            row['type']='directory'; row['names']=sorted(os.listdir(path))
        elif stat.S_ISREG(before.st_mode):
            row.update(descriptor(path)); row['path']=relative; row['type']='file'
        elif stat.S_ISLNK(before.st_mode):
            row['type']='symlink'; row['target']=os.readlink(path)
            resolved=path.resolve(strict=True)
            if not resolved.is_relative_to(BUNDLE): raise ValueError('JDK21_SYMLINK_ESCAPES_SELECTED_BUNDLE: '+relative)
            resolved_info=resolved.lstat()
            if not stat.S_ISREG(resolved_info.st_mode) and not stat.S_ISDIR(resolved_info.st_mode):
                raise ValueError('JDK21_SYMLINK_TARGET_TYPE_UNQUALIFIED: '+relative)
            row['resolvedRelativePath']=resolved.relative_to(BUNDLE).as_posix()
            row['resolvedType']='file' if stat.S_ISREG(resolved_info.st_mode) else 'directory'
            if signature(before)!=signature(path.lstat()): raise ValueError('JDK21_SYMLINK_CHANGED: '+relative)
        else: raise ValueError('JDK21_UNQUALIFIED_MEMBER_TYPE: '+relative)
        if row['uid']!=PROFILE['bundleUid'] or row['gid']!=PROFILE['bundleGid']:
            raise ValueError('JDK21_MEMBER_OWNER_DIFFERS: '+relative)
        if row['type']!='symlink' and stat.S_IMODE(before.st_mode)&0o022:
            raise ValueError('JDK21_MEMBER_GROUP_OR_WORLD_WRITABLE: '+relative)
        if signature(before)!=signature(path.lstat()): raise ValueError('JDK21_MEMBER_CHANGED: '+relative)
        rows.append(row)
    by_path={row['path']:row for row in rows}
    for row in rows:
        if row['type']=='symlink' and row['resolvedRelativePath'] not in by_path:
            raise ValueError('JDK21_SYMLINK_CLOSURE_MISSING: '+row['path'])
    for selected in ['Contents/Home/release','Contents/Home/lib/modules','Contents/Home/bin/java','Contents/Home/bin/keytool','Contents/Home/bin/jlink','Contents/Home/jmods/java.base.jmod']:
        if by_path.get(selected,{}).get('type')!='file': raise ValueError('JDK21_REQUIRED_MEMBER_MISSING: '+selected)
    return rows


def write(name,value):
    with (ROOT/name).open('x') as stream: stream.write(json.dumps(value,indent=2)+'\n')


def main():
    before_inputs=inputs()
    first=tree()
    write('filesystem-manifest.json',{'root':str(BUNDLE),'selectedHome':str(HOME),'rows':first,'scope':'Complete local selected bundle filesystem bytes/modes/types/ownership/link closure; no distribution authentication or executable acceptance'})
    second=tree()
    if first!=second: raise ValueError('JDK21_COMPLETE_TREE_CHANGED_BETWEEN_FULL_PASSES')
    after_inputs=inputs()
    if before_inputs!=after_inputs: raise ValueError('JDK21_BOUND_INPUT_CHANGED_BETWEEN_FULL_PASSES')
    release=(HOME/'release').read_text()
    fields={}
    for line in release.splitlines():
        key,separator,value=line.partition('=')
        if separator: fields[key]=value.strip('"')
    if fields.get('JAVA_RUNTIME_VERSION')!=PROFILE['declaredRuntimeVersion'] or fields.get('OS_ARCH')!=PROFILE['declaredArchitecture'] or fields.get('IMPLEMENTOR')!='Eclipse Adoptium':
        raise ValueError('JDK21_RELEASE_DECLARATION_DIFFERS')
    receipts=[]
    for path in PROFILE['localInstallReceiptPaths']:
        selected=Path(path); row=descriptor(selected)
        if selected.suffix=='.plist': row['declaredPlist']=plistlib.loads(selected.read_bytes())
        receipts.append(row)
    counts={kind:sum(row['type']==kind for row in first) for kind in ['file','directory','symlink']}
    result={'scope':'Filesystem qualification only, no Java/keytool/JVM/jlink/Gradle/native/device/signing execution','bundleRoot':str(BUNDLE),'selectedHome':str(HOME),'producerPid':os.getpid(),'producerPpid':os.getppid(),'producerPgid':os.getpgrp(),'pythonExecutable':descriptor(Path(sys.executable).resolve()),'producer':descriptor(Path(__file__).resolve()),'profile':descriptor(PROFILE_PATH),'counts':counts,'regularBytes':sum(row['bytes'] for row in first if row['type']=='file'),'allJmods':[row['path'] for row in first if row['type']=='file' and row['path'].startswith('Contents/Home/jmods/')],'allNativeLibraries':[row['path'] for row in first if row['type']=='file' and row['path'].endswith(('.dylib','.jnilib','.so'))],'declaredReleaseFields':fields,'releaseBytesSha256':hashlib.sha256(release.encode()).hexdigest(),'infoPlist':plistlib.loads((BUNDLE/'Contents/Info.plist').read_bytes()),'frozenInputsBeforeAndAfter':before_inputs,'completeTwoPassEquality':True,'localInstallReceipts':receipts,'manifestSha256':hashlib.sha256((ROOT/'filesystem-manifest.json').read_bytes()).hexdigest(),'elapsedSeconds':time.monotonic()-START,'limits':['Installed release/plist/package receipts declare identity, they do not authenticate associated installed files or publisher signature.','Opaque BOM bytes are retained; no parsed BOM-to-current-tree or package signature association claimed.','Original availability selected member hashes are matched; full file rows are newly observed local inputs, not remotely authenticated artifacts.','No same-UID concurrent parent-swap defense; trusted host/no concurrent mutation with exact before/after membership, file-descriptor and metadata checks.','L0Java21 and N1Java17 consumers remain distinct; original review budgets unchanged.']}
    write('filesystem-qualification.json',result)
    print(json.dumps({'counts':counts,'regularBytes':result['regularBytes'],'manifestSha256':result['manifestSha256'],'elapsedSeconds':result['elapsedSeconds'],'consumerExecuted':False}),flush=True)


if __name__=='__main__':
    try: main()
    except BaseException as error:
        write('filesystem-failure.json',{'errorType':type(error).__name__,'error':str(error),'elapsedSeconds':time.monotonic()-START,'scope':'Accidental changed/unsafe/missing input or qualification error; no substitute/no execution acceptance'})
        raise
