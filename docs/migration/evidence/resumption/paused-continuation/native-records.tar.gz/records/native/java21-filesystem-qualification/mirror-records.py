from pathlib import Path
import os,stat,hashlib,json,datetime
source=Path('/private/tmp/splotch-resume-01a111b0/native/java21-filesystem-qualification')
target=Path('/Users/kylemit/Code/Splotch/logs/migration-resumption-01a111b0/native/java21-filesystem-qualification')
def identity(s):
 return (s.st_mode,s.st_dev,s.st_ino,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
files=sorted(x for x in source.rglob('*') if x.is_file())
rows=[]
for x in files:
 s=x.lstat()
 assert stat.S_ISREG(s.st_mode) and not x.is_symlink() and s.st_uid==os.getuid() and s.st_nlink==1
 b=x.read_bytes()
 assert identity(s)==identity(x.lstat())
 y=target/x.relative_to(source)
 y.parent.mkdir(parents=True,exist_ok=True)
 if y.exists() or y.is_symlink():
  ys=y.lstat()
  assert stat.S_ISREG(ys.st_mode) and ys.st_uid==os.getuid() and ys.st_nlink==1
  assert y.read_bytes()==b and stat.S_IMODE(ys.st_mode)==stat.S_IMODE(s.st_mode)
 else:
  fd=os.open(y,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,stat.S_IMODE(s.st_mode))
  with os.fdopen(fd,'wb') as f:
   f.write(b)
   f.flush()
   os.fsync(f.fileno())
   os.fchmod(f.fileno(),stat.S_IMODE(s.st_mode))
 ys=y.lstat()
 assert y.read_bytes()==b and stat.S_IMODE(ys.st_mode)==stat.S_IMODE(s.st_mode)
 assert (ys.st_dev,ys.st_ino)!=(s.st_dev,s.st_ino)
 assert identity(x.lstat())==identity(s) and x.read_bytes()==b
 rows.append({'relativePath':str(x.relative_to(source)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':oct(stat.S_IMODE(s.st_mode)),'sourceDevice':s.st_dev,'sourceInode':s.st_ino,'mirrorDevice':ys.st_dev,'mirrorInode':ys.st_ino,'independent':True})
r={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':str(source),'mirror':str(target),'scope':'Finite source/evidence records only; no JDK tree scan, code execution or original result mutation','identityFields':'mode/device/inode/UID/GID/nlink/size/mtimeNs/ctimeNs and exact bytes/hash; access-time bookkeeping excluded','rows':rows}
raw=(json.dumps(r,indent=2)+'\n').encode()
for x in [source/'mirror-receipt.json.txt',target/'mirror-receipt.json.txt']:
 fd=os.open(x,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o644)
 with os.fdopen(fd,'wb') as f:
  f.write(raw)
  f.flush()
  os.fsync(f.fileno())
assert (source/'mirror-receipt.json.txt').read_bytes()==(target/'mirror-receipt.json.txt').read_bytes()
print(json.dumps({'files':len(rows),'bytes':sum(x['bytes'] for x in rows),'receiptSha256':hashlib.sha256(raw).hexdigest(),'mirror':str(target),'allIndependentByteModeMatches':True},indent=2))

