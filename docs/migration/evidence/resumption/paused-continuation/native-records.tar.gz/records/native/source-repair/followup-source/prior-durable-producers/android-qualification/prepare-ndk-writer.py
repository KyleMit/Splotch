import errno
import gzip
import hashlib
import importlib.util
import json
import os
import posixpath
import stat
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DESTINATION = ROOT / 'reviewed-ndk-materialization'
ARCHIVE_NAME = 'android-ndk-r27b-darwin.zip'
ARCHIVE_SHA256 = 'cf9b9eef50841f409f586e7ae12901007c7f545722612065bd63afbab1844152'
ARCHIVE_BYTES = 836151734
PREFIX = 'android-ndk-r27b'
DEADLINE_SECONDS = 900
READ_CHUNK_BYTES = 1024 * 1024
START = time.monotonic()
STARTED_AT = datetime.now(timezone.utc).isoformat()


def remaining():
    if time.monotonic() - START >= DEADLINE_SECONDS:
        raise ValueError('Finite NDK writer900second deadline exceeded')


def digest(path, algorithm='sha256'):
    value = hashlib.new(algorithm)
    with Path(path).open('rb') as stream:
        while block := stream.read(READ_CHUNK_BYTES):
            remaining()
            value.update(block)
    return value.hexdigest()


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')


def verify_inode(path, kind, mode=None):
    info = path.lstat()
    actual = 'link' if stat.S_ISLNK(info.st_mode) else 'directory' if stat.S_ISDIR(info.st_mode) else 'file' if stat.S_ISREG(info.st_mode) else None
    if (actual != kind or info.st_uid != os.getuid() or
        (path.is_relative_to(DESTINATION) and info.st_gid != os.getgid()) or
        (kind == 'file' and info.st_nlink != 1)):
        raise ValueError('Owned NDK inode type/ownership differs: ' + str(path))
    if mode is not None and stat.S_IMODE(info.st_mode) != mode:
        raise ValueError('Owned NDK producer mode differs: ' + str(path))
    return info


def verify_regular(path, row):
    verify_inode(path, 'file', int(row['mode'], 8))
    if path.stat().st_size != row['bytes'] or digest(path) != row['sha256']:
        raise ValueError('Owned NDK regular bytes differ: ' + str(path))


def verify_link(path, row):
    verify_inode(path, 'link')
    target = os.readlink(path)
    lexical = posixpath.normpath(posixpath.join(row['relative'].rsplit('/', 1)[0], target))
    if target.startswith('/') or '\\' in target or lexical == '..' or lexical.startswith('../'):
        raise ValueError('Owned NDK link escapes package')
    try:
        resolved = path.resolve(strict=True)
    except (RuntimeError, OSError) as error:
        if isinstance(error, RuntimeError) or error.errno == errno.ELOOP:
            raise ValueError('Owned NDK link cycle') from error
        raise
    if not resolved.is_relative_to(DESTINATION.resolve()) or not resolved.is_file():
        raise ValueError('Owned NDK link target is not contained regular content')
    if target != row['target'] or str(resolved.relative_to(DESTINATION)) != row['resolvedRelative']:
        raise ValueError('Owned NDK exact link graph differs')


def refusal(label, action, reason):
    try:
        action()
    except ValueError as error:
        if reason not in str(error):
            raise ValueError('Wrong finite NDK refusing-control reason: ' + label) from error
        return {'label': label, 'reason': str(error), 'expectedReason': reason}
    raise ValueError('Finite NDK refusing control unexpectedly passed: ' + label)


def main():
    profile = json.loads((ROOT / 'prepared-ndk-writer-profile.json').read_text())
    if digest(__file__) != profile['producerSha256']:
        raise ValueError('Reviewed NDK writer source differs')
    archive = ROOT / 'archives' / ARCHIVE_NAME
    if archive.stat().st_size != ARCHIVE_BYTES or digest(archive) != ARCHIVE_SHA256 or digest(archive, 'sha1') != profile['vendorSha1']:
        raise ValueError('Authenticated exact NDK archive differs')
    for source in profile['readerInputs']:
        if digest(ROOT / source['path']) != source['sha256']:
            raise ValueError('Reviewed finite NDK reader input differs')
    import sys
    sys.path.insert(0, str(ROOT))
    from acquire import snapshot
    before = snapshot()
    spec = importlib.util.spec_from_file_location('fixed_ndk_reader', ROOT / 'qualify-light.py')
    reader = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(reader)
    frozen = json.loads(gzip.decompress((ROOT / 'archive-members.json.gz').read_bytes()))['ndk;27.1.12297006']['rows']
    actual = reader.inspect(archive)
    if actual != frozen or len(actual) != 9177 or sum(row['kind'] == 'symlink' for row in actual) != 23:
        raise ValueError('Fixed actual NDK member/link layout differs')
    if any(row['path'] != PREFIX and not row['path'].startswith(PREFIX + '/') for row in actual):
        raise ValueError('Fixed actual NDK package prefix differs')
    if DESTINATION.exists() or DESTINATION.is_symlink():
        raise ValueError('Owned NDK destination must be absent')
    verify_inode(ROOT, 'directory')
    save('ndk-writer-running.json', {'pid': os.getpid(), 'pgid': os.getpgrp(), 'startedAt': STARTED_AT, 'deadlineSeconds': DEADLINE_SECONDS, 'producerSha256': digest(__file__), 'archiveSha256': ARCHIVE_SHA256, 'destination': str(DESTINATION)})
    DESTINATION.mkdir(mode=0o700)
    os.chown(DESTINATION, -1, os.getgid())
    mapped = []
    for original in actual:
        if original['path'] == PREFIX:
            continue
        row = dict(original, relative=original['path'][len(PREFIX) + 1:])
        if row['kind'] == 'symlink':
            row['resolvedRelative'] = row['resolvedTarget'][len(PREFIX) + 1:]
        mapped.append(row)
    directories = {row['relative']: row for row in mapped if row['kind'] == 'directory'}
    for row in mapped:
        for parent in Path(row['relative']).parents:
            if str(parent) != '.':
                directories.setdefault(str(parent), {'mode': '0o755'})
    for name in sorted(directories, key=lambda name: (name.count('/'), name)):
        remaining()
        target = DESTINATION / name
        verify_inode(target.parent, 'directory')
        target.mkdir(mode=0o700)
    with zipfile.ZipFile(archive) as source:
        for row in mapped:
            if row['kind'] != 'file':
                continue
            target = DESTINATION / row['relative']
            verify_inode(target.parent, 'directory')
            mode = int(row['mode'], 8)
            value = hashlib.sha256()
            fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode)
            with os.fdopen(fd, 'wb') as output, source.open(row['path']) as content:
                while block := content.read(READ_CHUNK_BYTES):
                    remaining()
                    value.update(block)
                    output.write(block)
                os.fchmod(output.fileno(), mode)
            row['sha256'] = value.hexdigest()
            verify_regular(target, row)
    for row in mapped:
        if row['kind'] == 'symlink':
            verify_inode((DESTINATION / row['relative']).parent, 'directory')
            os.symlink(row['target'], DESTINATION / row['relative'])
    for name in sorted(directories, key=lambda name: name.count('/'), reverse=True):
        (DESTINATION / name).chmod(int(directories[name]['mode'], 8))
    def verify_complete():
        found = set()
        for directory, dirs, files in os.walk(DESTINATION, followlinks=False):
            for name in dirs + files:
                remaining()
                found.add(str((Path(directory) / name).relative_to(DESTINATION)))
        if found != set(directories) | {row['relative'] for row in mapped}:
            raise ValueError('Owned NDK complete path set differs')
        for name, row in directories.items():
            verify_inode(DESTINATION / name, 'directory', int(row['mode'], 8))
        for row in mapped:
            if row['kind'] == 'file': verify_regular(DESTINATION / row['relative'], row)
            elif row['kind'] == 'symlink': verify_link(DESTINATION / row['relative'], row)
    verify_complete()
    controls = []
    metadata = next(row for row in mapped if row['relative'].endswith('/._libsimpleperf_readelf.a'))
    path = DESTINATION / metadata['relative']
    original = path.read_bytes()
    changed = bytearray(original)
    changed[100] ^= 1
    path.write_bytes(changed)
    try: controls.append(refusal('actual-metadata-byte', lambda: verify_regular(path, metadata), 'Owned NDK regular bytes differ'))
    finally: path.write_bytes(original)
    verify_regular(path, metadata)
    path.chmod(0o755)
    try: controls.append(refusal('actual-metadata-mode', lambda: verify_regular(path, metadata), 'Owned NDK producer mode differs'))
    finally: path.chmod(0o644)
    verify_regular(path, metadata)
    link = next(row for row in mapped if row['kind'] == 'symlink')
    path = DESTINATION / link['relative']
    path.unlink()
    os.symlink('../../../../../../../../outside', path)
    try: controls.append(refusal('actual-escaping-link', lambda: verify_link(path, link), 'Owned NDK link escapes package'))
    finally: path.unlink(); os.symlink(link['target'], path)
    verify_link(path, link)
    path.unlink()
    os.symlink(path.name, path)
    try: controls.append(refusal('actual-self-link-cycle', lambda: verify_link(path, link), 'Owned NDK link cycle'))
    finally: path.unlink(); os.symlink(link['target'], path)
    verify_complete()
    if before != snapshot():
        raise ValueError('Preserved native source changed during NDK writer')
    save('ndk-writer-result.json', {'regularRows': [row for row in mapped if row['kind'] == 'file'], 'directoryRows': directories, 'linkRows': [row for row in mapped if row['kind'] == 'symlink'], 'controls': controls, 'restoredCompletePositive': True, 'sourcePreserved': True, 'metadataPreserved': True, 'elapsedSeconds': time.monotonic() - START, 'scope': 'Exact owned NDK filesystem publication only; package registration and native compile/runtime remain separate gates', 'finishedAt': datetime.now(timezone.utc).isoformat()})


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        save('ndk-writer-failure.json', {'error': str(error), 'intendedRejectingControl': False, 'ownedDestinationPreserved': str(DESTINATION), 'finishedAt': datetime.now(timezone.utc).isoformat()})
        raise
