# Current-owner N1 composition proposal

This finite source-only proposal is bound to accepted 78d844ce36845e13690e2ca4ee7fcd645eb128d0,
tree ae69ebf1849dd6cfab317b4da7123e037fc0fb3a, with parents 709fadd68ecb802aa2c9daa3fc197ce8d072b23c
and 34dc4650bf43a9fb12e7378bf4d73b6bc68ebb70. Its preserved repaired source identity
7da00012890a72e46eb5cdc390dab8c63f0035a3 is a Git tree in the owned private source database;
it is not a canonical commit. `composition-profile.json` binds accepted blobs/modes,
private source bytes/modes/blobs, original source preservation, prior 709 proposal and
complete structured review/technical history. `read-commands.json` records the finite
read-only Git commands and complete output digests. No repository/source/Git write,
install, native/wrapper execution or new review occurred.

Only `package.json` and `tools/migration/README.md` among the ten registration owners
changed between 709 and 78d. The other seven present owners have exact prior 709 bytes;
`native-registration.test.mjs` remains absent. All sixty maintained native/tool/source
intake paths and the new registration test are absent at78d. Transfer only the 61 paths
listed in `exactSourceTransfers`, from their exact preserved private bytes and modes;
do not transfer the other nine historical root snapshots. The existing 70-member
capsule and original/current 140 source rows remain unchanged. Gradlew retains its
actual 0755 filesystem mode and 100755 Git executable bit.

The narrow accepted-owner patch is `registration-and-contract.diff`. Its five
registration changes are the two native package scripts/descriptions, one mandatory
Quality source-check step immediately after topology, the matching local mirror
command, formatter re-includes before unrelated later exclusions, and the native
source/materializer paragraphs inside the existing native README section. The native
materializer remains manual. Preserve the current retained CI job/callers, hosted
postbuild/export scripts and README prose, Node strip-types flags, current title and
all other accepted owners. Keep accepted Git-ignore/dprint/ESLint/stylelint unchanged.
No candidate entry, dependency, lock, configuration or scene feature grows here.

The package addition necessarily changes the current production contract's complete
root-manifest hash. The sixth proposed owner delta changes ONLY `rootManifestSha256`
from efa4f1b8cb58803e2b09f91304f4507978047ca1c8dcf45044c620e45a4d5249
to 2f34502e3f9f63adcec04e04cb94387f1a282f6e4d797861351ba17b3db831fc.
All other contract fields and complete artifact arrays are exact 78d bytes. The actual
released generator and deriving owner are bound; this proposal did not run them or
parse/install a new lock. The exact candidate nine owners plus lock/workspace are
byte-identical between private 7da and accepted 78d, and package dependency/engine/pnpm
owners match. The candidate-exclusive artifact output remains exact because its
owning lock did not change. After real composition, run the released
`gen:migration:topology-proof-inputs`, require its actual derived output to equal the
proposed one-field result, and review any additional delta before acceptance.
Historical hosted/topology execution records stay unchanged; later hosted proof
would require fresh exact inputs rather than relabeling those receipts.

F1 source e4e9fc044d46d49c3565379a3e6419e8eff4af9d remains held and is neither accepted
nor transplanted. Original Claude 7c940639-09e2-4236-961f-1122171cb5d8 stays two substantive
rounds used/one remaining. Keep original 93cd ledger and its actual round-two source-key
adoption intact. Reserve the final round for executed final-source/current-composition
acceptance and actual PR-keyed adoption. The preceding actual wrapper calls are not
repeated; the separate passed recorded-outcome qualification is referenced with its
own parent-disposition boundary. Its original runtime stage remains failed, and
complete DYLD coverage remains failed/open.

The next gate is parent disposition of this exact proposal. Dependent N1 source
acceptance/feature expansion remains held by F1 independent acceptance. When cleared,
create/reuse an explicitly owned isolated checkout at the then-accepted ref, rebind
any incoming owner changes, transfer the exact61 paths and apply these narrow owner
deltas, run the actual topology-input generator, then freeze resulting Git commit,
tree, diff, all source/caller/installed graph inputs and regenerated contract. Run
registration/formatter and materializer/source positive/rejecting/restored controls,
applicable final Quality/Browserless/floor/CI gates under parent host leases, and give
actual final-source evidence to the original remaining Claude round. The existing
corrected `../PLAN.md` still owns the finite tool/plugin/configuration and optimized
Android/iOS build/mount gates. Qualified artifact/JDK/SDK/wrapper identities do not
prove AGP/Kotlin/Gradle configuration compatibility, React Native compilation,
mount/draw/input, required floors, whole-screen fidelity, product or physical speed.
No additional review budget or native execution grant follows from this proposal.

The initial source-only packet assembly used an incorrect local capsule filename and
stopped before its reference record completed. Its producer/error are retained;
the exact existing followup source capsule was then bound. The successful initial
proposal is also retained before the final README whitespace/stable-owner readback
amendment. These preparation/setup records are not intended rejecting controls or
source/runtime acceptance evidence.
