import datetime
import hashlib
import json
import stat
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PROFILE=json.loads((ROOT/'recorded-outcome-profile.json').read_text())
ORIGINAL=Path(PROFILE['originalRoot'])


def bound(row):
    path=Path(row['path']); info=path.lstat(); raw=path.read_bytes()
    actual={'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':oct(stat.S_IMODE(info.st_mode)),'device':info.st_dev,'inode':info.st_ino}
    if not stat.S_ISREG(info.st_mode) or actual!=row: raise ValueError('JDK21_RECORDED_INPUT_DIFFERS: '+str(path))
    return actual


def main():
    inputs=[bound(row) for row in PROFILE['inputs']]
    manifest=json.loads((ORIGINAL/'filesystem-manifest.json').read_text())
    complete=json.loads((ORIGINAL/'execution/java21-filesystem-receipt/complete.json').read_text())
    failure=json.loads((ORIGINAL/'filesystem-failure.json').read_text())
    release=json.loads((ORIGINAL/'execution/java21-filesystem-receipt/release.json').read_text())
    source=(ORIGINAL/'qualify-filesystem.py').read_text()
    stderr=(ORIGINAL/'execution/java21-filesystem-receipt/producer.stderr.txt').read_text()
    observed=json.loads((ORIGINAL/'observed-install-receipt.json').read_text())
    if complete['exitCode']!=1 or complete['timedOut'] or not complete['inputsUnchanged'] or not complete['allOwnedGroupsGone'] or not complete['completeStartedChildExitRecords']:
        raise ValueError('JDK21_ORIGINAL_FAILURE_RECEIPT_DIFFERS')
    if failure['errorType']!='TypeError' or failure['error']!='Object of type datetime is not JSON serializable':
        raise ValueError('JDK21_EXPECTED_SERIALIZATION_BOUNDARY_DIFFERS')
    if not release['allTargetPidsAbsent'] or not all(row['absent'] for row in release['actualGroupProbes']):
        raise ValueError('JDK21_ORIGINAL_RELEASE_INCOMPLETE')
    for name,row in complete['sourceInputs'].items():
        if hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()!=row['sha256']: raise ValueError('JDK21_EXECUTED_SOURCE_TOOL_DIFFERS: '+name)
    for name in ['stdout','stderr']:
        row=complete[name]; raw=(ORIGINAL/'execution/java21-filesystem-receipt'/row['path']).read_bytes()
        if len(raw)!=row['bytes'] or hashlib.sha256(raw).hexdigest()!=row['sha256']: raise ValueError('JDK21_ORIGINAL_CHANNEL_DIFFERS: '+name)
    required_trace=['write(\'filesystem-qualification.json\',result)','Object of type datetime is not JSON serializable','when serializing dict item \'InstallDate\'','when serializing dict item \'localInstallReceipts\'']
    if not all(value in stderr for value in required_trace): raise ValueError('JDK21_SERIALIZATION_TRACE_CONTEXT_MISSING')
    if "if first!=second: raise ValueError('JDK21_COMPLETE_TREE_CHANGED_BETWEEN_FULL_PASSES')" not in source or "if before_inputs!=after_inputs: raise ValueError('JDK21_BOUND_INPUT_CHANGED_BETWEEN_FULL_PASSES')" not in source:
        raise ValueError('JDK21_EXECUTED_COMPARISON_SOURCE_DIFFERS')
    if set(manifest)!=set(['root','selectedHome','rows','scope']) or manifest['root']!=PROFILE['bundleRoot'] or manifest['selectedHome']!=PROFILE['selectedHome']:
        raise ValueError('JDK21_RAW_MANIFEST_HEADER_DIFFERS')
    rows=manifest['rows']; paths=[row['path'] for row in rows]
    if len(paths)!=len(set(paths)) or paths!=sorted(paths): raise ValueError('JDK21_RECORDED_MEMBERSHIP_DUPLICATE_OR_ORDER')
    by_path={row['path']:row for row in rows}
    common={'path','mode','uid','gid','nlink','device','inode','bytes','mtimeNs','ctimeNs','type'}
    for row in rows:
        path=Path(row['path'])
        if path.is_absolute() or '..' in path.parts or row['type'] not in ['file','directory','symlink']:
            raise ValueError('JDK21_RECORDED_MEMBER_PATH_OR_TYPE_INVALID')
        expected=common|({'sha256'} if row['type']=='file' else {'names'} if row['type']=='directory' else {'target','resolvedRelativePath','resolvedType'})
        if set(row)!=expected: raise ValueError('JDK21_RECORDED_MEMBER_SCHEMA_DIFFERS: '+row['path'])
        if row['uid']!=0 or row['gid']!=0: raise ValueError('JDK21_RECORDED_MEMBER_OWNER_DIFFERS')
        if row['type']=='file' and (len(row['sha256'])!=64 or any(ch not in '0123456789abcdef' for ch in row['sha256'])):
            raise ValueError('JDK21_RECORDED_FILE_DIGEST_INVALID')
        if row['type']=='directory':
            children=sorted(Path(candidate).name for candidate in paths if candidate!='.' and Path(candidate).parent==path)
            if children!=row['names']: raise ValueError('JDK21_RECORDED_DIRECTORY_CHILD_SET_DIFFERS: '+row['path'])
        if row['type']=='symlink' and row['resolvedRelativePath'] not in by_path:
            raise ValueError('JDK21_RECORDED_LINK_CLOSURE_MISSING')
    counts={kind:sum(row['type']==kind for row in rows) for kind in ['file','directory','symlink']}
    if counts!=PROFILE['recordedCounts']: raise ValueError('JDK21_RECORDED_COUNTS_DIFFERS')
    for path in PROFILE['requiredMembers']:
        if by_path.get(path,{}).get('type')!='file': raise ValueError('JDK21_RECORDED_REQUIRED_MEMBER_MISSING: '+path)
    if observed['InstallDateType']!='datetime.datetime' or not observed['InstallDateNaive']:
        raise ValueError('JDK21_CAPTURED_INSTALL_DATE_TYPE_DIFFERS')
    parsed_date=datetime.datetime.fromisoformat(observed['InstallDateIso'])
    if parsed_date.isoformat()!=observed['InstallDateIso']: raise ValueError('JDK21_CAPTURED_ISO_DATE_NOT_EXACT')
    serialized=json.dumps(observed['completeParsedFields'],sort_keys=True)
    inputs_after=[bound(row) for row in PROFILE['inputs']]
    if inputs_after!=inputs: raise ValueError('JDK21_RECORD_INPUTS_CHANGED')
    result={'scope':'PURE original record/schema/channel/date qualification; no filesystem scan or JDK/library/code execution','originalStageAccepted':False,'recordedFirstManifestSchemaQualified':True,'counts':counts,'nativeAndJdkConsumerExecuted':False,'capturedReceiptSerializationPositive':serialized,'allOriginalGroupsReleased':True,'sourceBoundTraceInference':'Exact failed source and stderr show the final write serialization was reached after both full-scan/equality guards and frozen-input equality guards. Actual second rows/equality output were not persisted. This inference does not substitute for a separately exported witness.','missingStrictPredicate':['No persisted second-manifest rows or explicit completed-two-pass/input readback witness; source-bound control-flow inference only.','Local BOM/plist/release declarations are not authenticated associated publisher provenance.'],'eligibleForRuntimeTrustAcceptance':False,'unchangedRecords':inputs}
    with (ROOT/'recorded-partial-qualification.json').open('x') as stream: stream.write(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'recordedFirstManifestSchemaQualified':True,'counts':counts,'originalStageAccepted':False,'eligibleForRuntimeTrustAcceptance':False}))


if __name__=='__main__':main()
