import datetime
import hashlib
import json
import os
import stat
from pathlib import Path

ROOT=Path(__file__).resolve().parent
D=Path('/Users/kylemit/Code/Splotch/logs/migration-resumption-01a111b0/native/next-runtime')
rows=[]
for source in sorted(p for p in ROOT.rglob('*') if p.is_file()):
 relative=source.relative_to(ROOT);target=D/relative;info=source.lstat();data=source.read_bytes();digest=hashlib.sha256(data).hexdigest()
 if not stat.S_ISREG(info.st_mode):raise ValueError('Finite next-runtime evidence source is not regular')
 target.parent.mkdir(parents=True,exist_ok=True)
 if os.path.lexists(target):
  if not target.is_file() or target.is_symlink() or target.read_bytes()!=data:raise ValueError('Immutable next-runtime evidence differs')
 else:
  with target.open('xb') as output:output.write(data)
  target.chmod(stat.S_IMODE(info.st_mode))
 other=target.lstat()
 if ((info.st_dev,info.st_ino)==(other.st_dev,other.st_ino) or hashlib.sha256(target.read_bytes()).hexdigest()!=digest or stat.S_IMODE(other.st_mode)!=stat.S_IMODE(info.st_mode)):
  raise ValueError('Next-runtime durable inode/hash/mode mismatch')
 rows.append({'path':str(relative),'bytes':len(data),'sha256':digest,'mode':oct(stat.S_IMODE(info.st_mode)),
              'sourceDevice':info.st_dev,'sourceInode':info.st_ino,'durableDevice':other.st_dev,'durableInode':other.st_ino})
receipt={'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fileCount':len(rows),'bytes':sum(r['bytes'] for r in rows),'rows':rows,
 'fullBytesModesAndIndependentInodes':True,'source70OrSdkOrEarlierPacketsChanged':False,'noNewRuntimeInstallCompilerRivalNativeExecuted':True}
with (ROOT/'durable-mirror.json').open('x') as output:output.write(json.dumps(receipt,indent=2)+'\n')
with (D/'durable-mirror.json').open('xb') as output:output.write((ROOT/'durable-mirror.json').read_bytes())
print(json.dumps({k:receipt[k] for k in ['fileCount','bytes','fullBytesModesAndIndependentInodes']}))
