from pathlib import Path
import datetime, hashlib, json, os, stat, subprocess, time
root = Path(__file__).resolve().parent
execution = json.loads((root / 'reader.execution.json').read_text())
pids = sorted({execution['observerPid'], execution['readerPid'], execution['identityObserver']['pid']})
argv = ['/bin/sh', '-c', 'exec /bin/ps -ww -p "$1,$$" -o pid=,ppid=,pgid=,lstart=,command=', 'owned-readonly-release', ','.join(map(str, pids))]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
query = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True, env={'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C'})
stdout, stderr = query.communicate(timeout=10)
(root / 'reader.release.stdout.txt').write_bytes(stdout)
(root / 'reader.release.stderr.txt').write_bytes(stderr)
rows = []
for line in stdout.decode().splitlines():
    parts = line.split(None, 8)
    assert len(parts) == 9, 'Targeted release OS row shape differs'
    rows.append({'pid': int(parts[0]), 'ppid': int(parts[1]), 'pgid': int(parts[2]), 'startLocal': ' '.join(parts[3:8]), 'argv': parts[8]})
def gone(group):
    try:
        os.killpg(group, 0)
        return False
    except ProcessLookupError:
        return True
own = [row for row in rows if row['pid'] == query.pid]
assert query.returncode == 0 and not stderr and len(own) == 1 and own[0]['ppid'] == os.getpid() and own[0]['pgid'] == query.pid and gone(query.pid), 'Owned targeted release query failed'
assert not any(row['pid'] in pids for row in rows) and all(gone(pid) for pid in pids), 'Recorded reader process/group remains'
assert execution['exitCode'] == 0 and execution['wholeDeadlineMet']
for name in ['stdout', 'stderr', 'identity.stdout', 'identity.stderr']:
    row = execution[name]
    raw = Path(row['path']).read_bytes()
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256'], 'Complete reader channel differs'
profile = json.loads((root / 'qualification-profile.json').read_text())
for row in profile['bindings'].values():
    path = Path(row['path'])
    info = path.lstat()
    actual = {'path': str(path), 'realPath': str(path.resolve(strict=True)), 'bytes': info.st_size, 'device': info.st_dev, 'inode': info.st_ino, 'uid': info.st_uid, 'gid': info.st_gid, 'mode': oct(stat.S_IMODE(info.st_mode)), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    assert actual == row and stat.S_ISREG(info.st_mode) and info.st_nlink == 1, 'Frozen qualification binding differs'
assert hashlib.sha256((root / 'qualify-recorded-outcome.py').read_bytes()).hexdigest() == execution['readerSha256']
assert hashlib.sha256((root / 'qualification-profile.json').read_bytes()).hexdigest() == execution['profileSha256']
result = json.loads((root / 'recorded-outcome-qualification.json').read_text())
assert result['originalRuntimeStageRemainsFailed'] and result['eligibleForIndependentRecordedOutcomeAcceptance'] and result['parentAcceptanceNotInferred'] and not result['integrationOrN1Accepted']
assert len(result['actualCommands']) == 3 and [row['exitCode'] for row in result['actualCommands']] == [0, 1, 0]
assert result['fullImmutableFailureMirror59FilesUnchanged'] and result['full700RuntimeOutputRowsUnchanged'] and not result['JVMGradleNativeCompilerRerun']
source = Path('/private/tmp/splotch-resume-01a111b0/native/source-repair')
manifest = json.loads((source / 'frozen-source-manifest.json').read_text())
def verify(base, expected):
    actual = []
    for row in expected:
        path = base / row['path']
        info = path.lstat()
        raw = path.read_bytes()
        observed = {'path': row['path'], 'bytes': len(raw), 'mode': oct(stat.S_IMODE(info.st_mode)), 'sha256': hashlib.sha256(raw).hexdigest()}
        assert observed == row and stat.S_ISREG(info.st_mode), 'Source preservation identity differs'
        actual.append(observed)
    return actual
current = verify(source / 'source', manifest['sourceRows'])
original = verify(Path('/Users/kylemit/.codex/worktrees/migration-native-source/Splotch'), manifest['originalIntakePreservation']['sourceRows'])
release = {'startedAt': started, 'finishedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'elapsedSeconds': time.monotonic() - clock, 'toolHandle': 22959, 'readerWholeDeadlineSeconds': 120, 'readerCompleteSha256': hashlib.sha256((root / 'reader.execution.json').read_bytes()).hexdigest(), 'qualificationSha256': hashlib.sha256((root / 'recorded-outcome-qualification.json').read_bytes()).hexdigest(), 'targetedPids': pids, 'argv': argv, 'observerPid': query.pid, 'observerActualOSIdentity': own[0], 'observerExitCode': query.returncode, 'observerGroupGone': gone(query.pid), 'allRegisteredPidsAndGroupsGone': True, 'fullChannelsUnchanged': True, 'all12FrozenQualificationInputsUnchanged': True, 'sourceTree': manifest['sourceTree'], 'current70SourceRows': current, 'original70IntakeRows': original, 'originalIntakeAndCurrentSourceUnchanged': True, 'parentAcceptanceNotInferred': True, 'originalRuntimeStageRemainsFailed': True, 'JVMOrMainOrInstalledConsumerExecuted': False, 'cleanupActions': []}
(root / 'reader.release.json').write_text(json.dumps(release, indent=2) + '\n')
print(json.dumps({key: value for key, value in release.items() if key not in ['current70SourceRows', 'original70IntakeRows']}, indent=2))
