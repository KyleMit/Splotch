import ast
import hashlib
import json
import stat
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent
PROFILE = json.loads((ROOT.parent / 'wrapper-jansi-copy-identity/wrapper-profile.json').read_text())
SOURCE = ROOT / 'corrected-vendor-mode-source.py'
function = next(node for node in ast.parse(SOURCE.read_text()).body if isinstance(node, ast.FunctionDef) and node.name == 'verify_tree')
loop = next(node for node in function.body if isinstance(node, ast.For))
mode = next(node for node in loop.body if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name) and node.targets[0].id == 'mode')
vendor = next(node for node in loop.body if isinstance(node, ast.If) and 'vendor_modes' in ast.unparse(node.test))
guard = next(node for node in loop.body if isinstance(node, ast.If) and any(isinstance(item, ast.Raise) for item in node.body))
predicate = compile(ast.Module(body=[mode, vendor, guard], type_ignores=[]), str(SOURCE), 'exec')
rows = json.loads(Path(PROFILE['gradleResult']).read_text())['installedRows']
base = ROOT.parent / 'wrapper-jansi-copy-identity/owned-runtime/negative-home/wrapper/dists/gradle-9.3.1-bin' / PROFILE['releasedUrlMd5Base36'] / 'gradle-9.3.1'


def actual(member):
    original = next(row for row in rows if row['path'] == 'gradle-9.3.1/' + member)
    row = dict(original, path=member)
    path = base / member
    info = path.lstat()
    return {'row': row, 'path': path, 'info': info, 'uid': PROFILE['actorUid'], 'gid': PROFILE['ownedGid'],
            'vendor_modes': True, 'expected_inodes': False, 'expected_inode': None, 'kind': stat.S_ISREG(info.st_mode),
            'stat': stat, 'sha': lambda path: hashlib.sha256(path.read_bytes()).hexdigest()}


baseline = actual('bin/gradle')
exec(predicate, dict(baseline))
wrong = dict(baseline)
info = baseline['info']
wrong['info'] = SimpleNamespace(st_mode=(info.st_mode & ~0o777) | 0o644, st_uid=info.st_uid, st_gid=info.st_gid,
                                st_ino=info.st_ino, st_nlink=info.st_nlink, st_size=info.st_size)
reason = 'Wrapper full runtime installed byte/mode/inode/owner differs: ' + str(baseline['path'])
try:
    exec(predicate, wrong)
except ValueError as error:
    assert str(error) == reason
else:
    raise ValueError('Actual captured vendor-mode rejecting predicate did not refuse')
exec(predicate, dict(baseline))
batch = actual('bin/gradle.bat')
exec(predicate, dict(batch))
assert stat.S_IMODE(baseline['path'].lstat().st_mode) == 0o755
assert stat.S_IMODE(batch['path'].lstat().st_mode) == 0o644
result = {'scope': 'Pure extracted production mode/guard predicate over actual captured restored members; no filesystem mutation/JVM/main execution',
          'correctedSourceSha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(), 'productionGuardAstSha256': hashlib.sha256(ast.dump(ast.Module(body=[mode, vendor, guard], type_ignores=[])).encode()).hexdigest(),
          'actualExecutable': {'path': str(baseline['path']), 'relativePath': baseline['row']['path'], 'mode': '0o755', 'bytes': info.st_size, 'sha256': baseline['row']['sha256']},
          'modeOnlyRefusal': {'changedCapturedField': 'st_mode permission bits0755 ->0644', 'expectedActualReason': reason, 'actualReason': reason},
          'restoredCapturedPositive': True, 'actualOtherReleasedScriptMode0644Positive': True,
          'actualFilesystemAndRuntimeInputsUnchanged': True, 'JVMMainOrConsumerExecuted': False}
with (ROOT / 'captured-mode-controls.json').open('x') as output:
    output.write(json.dumps(result, indent=2) + '\n')
print(json.dumps({'positive': True, 'modeOnlyExactRefusal': True, 'restored': True, 'otherReleasedScriptPositive': True}))
