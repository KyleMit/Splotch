# Native structural execution plan

Owner: `native_structural`, accountable to the parent integrator. Revised2026-10-06 following
original Claude source/plan rounds one and two. Full validated findings and source-backed
qualifications live in `ROUND-1-DISPOSITIONS.md`; original plan bytes are `PLAN.round1-input.md`. No
source expansion/install/download/native workload is authorized by this revision alone.

## Exact frontier and ownership

Preserved native checkpoint remains untouched at
`/Users/kylemit/.codex/worktrees/migration-native-source/Splotch`, base
dc08a90abc67b53124146bf288c80de0f9ffd1dd. Its maintained60/registration10 and recovered archive20
match every roster byte/mode. `plan-inputs.json` binds those inputs. Claude source snapshot
61da0b643c6aa5e7d71d5616ea86e02dd33bb8b8 independently matches all70 preserved source rows. Reviewer
conversation7c940639-09e2-4236-961f-1122171cb5d8 has actually resumed and completed round two: two
substantive rounds used, one remains. The original eight findings were resolved on d0dc; bounded
follow-up source/trust repairs remain subject to parent disposition and current-source gates. No
native compile/mount/draw/performance claim.

After F1 acceptance, parent supplies an isolated current-base managed unit worktree and qualified
frozen dependency graph. Record actual base/head and changed registration owners before copying.
This owner carries N1, its execution/evidence and review repairs; parent accepts cross-unit
integration and phase exits. Source-only preservation is independent of implementation acceptance.

N1 may write only maintained60 paths plus their ten registration owners; semantically compose
package/CI/README over actual accepted owners. No root dependency/lock/workspace/engine, root
Capacitor/store version/ID or ruler change. Root integration records and other units remain parent
owned. Removing speculative fences is within those same reviewed source/registration boundaries.

Artifacts are `/private/tmp/splotch-resume-01a111b0/native`; published evidence uses a reviewed
`docs/migration/evidence/` root, `*.log.txt` names and exact source/environment/command bindings.
Preserve original failure reasons, source identities and review provenance before cleanup.

## N1: fix and accept maintained source

Dependencies: accepted F1 import-boundary disposition/current parent, source repair plan challenge,
qualified frozen JS graph. No SDK tools or device activity are needed for these repairs.

1. Restore pristine ordered provenance before the actual symlink control; prove the intended
   source-symlink failure, keeping omission/replay rejection distinct.
2. Put shipping exclusions and four candidate-only Prettier re-includes before general
   build/Markdown/SVG exclusions. Preserve unrelated ignored trees. Declare exact recipe/formatter
   ownership rather than claiming all native formats are Prettier-owned. Remove the six speculative
   generated-native-directory fences and their shared constant/registration assertions: native tools
   use disposable copies only.
3. Fix actual lint failures and format tools/tests. The useless-escape edit must leave emitted
   Gradle bytes identical. Markdown uses dprint. No direct reformat of provenance-owned native
   source; regenerate through reviewed recipes when output changes.
4. Source reader enforces Git's owner-executable class, with a real umask027 checkout positive and
   executable-drift negatives. The materializer still writes exact modes independent of umask and
   checks exact producer modes before reporting success/idempotence. Update the missing-fchmod
   inversion accordingly; a corrected Git source predicate cannot weaken producer guarantees.
5. Require all native/IDE/pod execution in owned independent disposable source/install copies.
   Unexpected in-tree source inputs name their path and this constraint. Introduce contextual
   generated inputs only with their actual later writer, outside original template provenance.
6. Document `.xcode.env*` regeneration and the future Apple owner. Pre-creating only the base file
   is insufficient. Both owned files will contain the reviewed absolute Node24 path; no upstream
   Ruby monkeypatch or false absence claim.
7. Strengthen the actual Apple phase/contract for effective USE_HERMES and real packager/config/
   Node selectors. Preserve the legitimate generated Hermes V1 compiler setting and validate it
   against the qualified resolved compiler, rather than blanket-forbidding HERMES_CLI_PATH. Derive
   changed maintained project/provenance with the real producer in an absent owned source target.
   Final Release callers independently validate output/identity; source predicates do not constitute
   optimized-build proof.
8. State registry0BSD versus archive MIT LICENSE truth and preserve both records.

Preserve the root Node22 floor and qualify scoped source guards on Node22 and reviewed candidate
Node24; phase version-selector fixtures do not certify actual Node24 bytes or runtime. First read
`npm run info`, then run source checker and all five native suites. Source changes require
appropriate formatter, check/lint/Quality/full tiers and final-head CI under parent scheduling.
Original round two reviewed the actual d0dc executed revision; bounded follow-up changes retain the
final round for meaningful later executed-evidence acceptance. Open a small N1 PR into integration
only with corrected source/test evidence; no new ZIP parser or SDK provisioning in this PR.

Reuse real-template evidence narrowly. Round1 already executed pinned-archive absent creation,
idempotence and byte-identical45-file output. Commands/output and surviving output bytes are bound
by round1 receipts. Preserve the eight observed refusals with their recorded limits: individual
original exit codes and full per-control preservation snapshots are incomplete. Do not repeat
unchanged archive authenticity/recipe probes solely because a new agent integrates. Changed mode/
source predicates and changed Apple recipe require their relevant current-source controls and
final-output materialization. Tests run unpiped with original exit codes; no wrong-reason negative.

## N2: smallest qualified Android Release

The next falsification target is an actual optimized Android Release in a disposable copy.
Archive20, yauzl3.4 and the larger provisioner plan are retained preparation, not mandatory
prerequisites. No new parser/dependency is selected merely because it has been prepared.

The proposed smaller route uses fixed official artifacts, independent whole-byte authentication,
finite existing system archive tools, owned versioned SDK registration and actual installed/vendor
recognition. Preserve the corrected profile: Node24.16.0, complete Temurin17.0.20.1+1, Gradle9.3.1,
cmdline20.0, platform36 revision2, build-tools36.0.0, NDK27.1.12297006, CMake3.30.5. Root shipping
Node22/Java21 and global SDK remain separate.

Before implementation/execution, qualify these few real boundaries:

* Bind exact official metadata URLs/size/checksum and licensing for the authenticated cmdline20
  bootstrap. Use selected package revisions and stable URLs, never latest resolution. Review actual
  finite archive layout, links/modes and installed bytes. Existing system listing/extraction tools
  need positive/rejecting path/type/output controls before publication. No generic archive runner.
* Check the exact authenticated20 downloader/installer classes and their
  installed-root/cache/license consumers. Host-observed passive javap already contradicts blanket
  cold-checksum assurance: LegacyDownloader verifies only an existing download, not its fresh
  branch. Do not accept vendor-only package revisions/tree hashes as compressed-archive provenance.
* Prefer supported vendor installation if independently authenticated inputs can be consumed with a
  bounded caller. Otherwise finite extraction of exact approved official payloads plus SDK
  registration and vendor recognition is the smaller route. Retain independently verified raw
  archives or a complete immutable authenticated capture before any tool can delete them. A new
  local SHA256 binds a receipt; it is not an upstream signature when Google's retained pin is SHA1.
* Terms are exact required ID/body/normalization/accepted-line facts. Only reviewed required terms
  may create owned SDK acceptance state; no global lines, catalog-wide `--licenses`, HOME
  reassignment, global SDK/Java mutation or automatic Gradle installation.

Stop this route and reconsider the bounded archive20 parser only if real existing-tool/vendor
qualification fails to preserve a necessary exact-byte/layout/link/identity guarantee. A separate
package lock/tool workspace is not selected. Source challenge precedes the bootstrap execution
boundary; actual source/whole-archive/member/install receipts precede tool/build acceptance.

Keep tooling small: one named manual Android Release caller with only helpers required by its real
qualify/copy/spawn/output receipt consumers. Reuse accepted source/identity/wrapper/property owners.
Stage independent source and qualified installed files with contained links; never hardlink or share
writable participating build outputs with the accepted dependency tree. Record immutable original
package bytes, actual generated-output paths and before/after identities.

Select profile Node24 first on finite PATH, qualified full Java17, canonical equal SDK roots and
owned Android-user/Gradle/project/temp/signing state, preserving genuine HOME. Keep the
authenticated Gradle wrapper/JAR/distribution caller and prepopulate only owned wrapper cache from
checked bytes; fail if absent. Disable automatic SDK/JDK downloads at their actual released
consumers. Reject relevant ambient Gradle project/Java/Expo overrides and late effective changes.

Qualify real Maven/plugin/RN/Hermes inputs via explicitly reviewed provisional capture, then strict
hash-bound dependency verification. Capture is not verification. One final `:app:assembleRelease`
requires exit0, same-run effective Java17/Kotlin/module/SDK/NDK/CMake/Release assertions, declared
ABI outputs, R8/resource shrinking, candidate signer, merged permissions/privacy, floor24/target36
and embedded assets. The actual selected bundle must be Hermes bytecode with qualified
compiler/runtime identity and effective optimized flags. Magic alone cannot certify file
validity/version or correct payload. No Debug/Metro substitute.

If the unmodified candidate fails configure/compile, preserve the actual owner/error and make a
bounded source/tool correction. Do not expand generic tooling to rename an untested candidate
passing. Compilation is a structural artifact gate; mounting, static graphics, draw/input and
physical timing remain subsequent gates. Platform-specific Android false rejection does not
automatically invalidate independent Apple structure; parent controls the disposition.

## N3: Android mount/static scene and earliest real transaction

After actual Release artifacts qualify, apply start-capture-session preflight and parent
native/device lease before enumeration/reservation. Qualify separately API24/current-OS
tooling/device identity, release install/runtime flags and actual native presentation. Add audited
Skia/Ganesh/static geometry and attached receiver/collector in bounded source units with real
dependency callers. Module mounting alone is not drawing. Keep audio smoke and collector changes
proportionate and separately reviewable.

Prove default/unbuffered samples and native ownership/no redundant MOVE. At earliest
collector/placement slice prove one export cut and page-plus-undo transaction with delayed
work/known output before full crayon/Magic investment. Record first usable ink with an attached
receiver and exact geometry/policy; no launch-before-view claim. No simulator/emulator timing
becomes physical comparative evidence.

## N4: corrected Apple tooling and Release

Gate expensive Apple provisioning on Android structural evidence unless a genuine independent Apple
risk warrants parallel work. Preserve Node24.16.0, owned Ruby3.4.11/bundled Bundler2.6.9,
CocoaPods1.16.2/xcodeproj1.27.0; explicitly document incompatible RN-reference xcodeproj-cap
departure. Keep upstream app compatibility/library requirements and reviewed full Gemfile.lock
CHECKSUMS, Podfile.lock sources/native extensions/Release integration. Resolve/audit provisional
locks before frozen/deployment reproduction. No Homebrew/system Ruby/global gems or HOME rewrite.

Qualify actual Ruby/default gems/OpenSSL/private-libyaml/provider paths. Finite owned GEM/BUNDLE/CP/
cache/temp selectors and owned NETRC directory/empty .netrc control actual CDN fallback. Reject
conflicting ambient selectors. Node24 leads pod PATH; absolute NODE_BINARY owns Xcode bundling.
Pre-create both exact owned `.xcode.env` and `.local` in the disposable copy and verify them before/
after pod preparation and Release. Capture exact command-v Node/path/digest, clear
EX_UPDATES_NATIVE_DEBUG, refuse .xcode.env.updates, and review the complete generated project delta
against released owners. The actual bundle caller must prove its NODE_BINARY equals the prepared
path/bytes. Their generation is context ownership, never template provenance.

Use per-process DEVELOPER_DIR for Xcode27, owned DerivedData, Release simulator SDK and embedded
qualified Hermes bytecode with effective settings/compiled module/privacy/permissions. The legit
Hermes V1 HERMES_CLI_PATH comes from reviewed generated pod config; compare actual path/bytes rather
than rejecting it for being nonempty. Correct node/compiler/packager selectors at their actual
owners.

SDK27 scene adoption already exists in Native70. Actual cold/current-OS launch,
background/foreground, cold/warm custom/universal links and once-only delivery are separate from
compile. Exact16.4/20E247 needs qualified official side-by-side Xcode26.6/runtime/authentication or
a supported floor device; Xcode27 deployment target16.4 does not prove its mount. Keep independent
structural work moving if that resource is unavailable; report the exact missing dependency without
substitute timing/assurance.

## Probe acceptance and claim boundaries

| Probe / released owner                | Expected positive                                                                                   | Rejecting control / limit                                                                                                                                |
| ------------------------------------- | --------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Canonical source/Git/producer         | Correct bytes+Git executable class; exact producer mode; intended CLI/error and formatter ownership | Ordered provenance, symlink, executable drift, missing fchmod, unsupported in-tree inputs and ignore inversions reject distinctly; no native certificate |
| Fixed official tool inputs            | Independently checked raw archive + actual layout/licensing/installed recognition                   | Cold checksum corruption, wrong revision/root/link/output or license state fails at owning boundary; tree hash cannot replace raw provenance             |
| Effective Android Release             | Qualified same-run tool/module/floor/settings/Maven/bundle/ABI/signer and exit0                     | Missing tool/probe, downloads-off inversion, late Hermes/DSL overrides or wrong bytecode/payload rejects; compile is not mount/performance               |
| Actual mount/graphics/collector       | Expected released pixels/geometry/input/ordering under qualified runtime                            | Known wrong pixels, stale geometry, missing/doubled stream and delayed transaction failures; no thin-scene product parity                                |
| Apple generated context/Release/scene | Exact Node files/locks/compiler and embedded bytecode; once-only real scene behavior                | Ambient/.local/config/compiler substitution, stale locks, double owner/skip bundle reject; currentOS pass does not certify16.4                           |

A magic-header assertion is a cheap plain-JS rejecting control; use complete native consumption and
qualified Release source/runtime for the stronger claim. Claude challenges false passes/rejections
and alternatives, then reviews the actual executed revision/evidence. Evidence resolves empirical
claims. Source plan and current-head review remain within the original conversation's round budget.

## Lease and tooling retirement register

No native/device resources are owned. Retained-control host lease excludes full/native/performance/
device workloads; only passive source/inventory work continues. Parent issues explicit owner, unused
port/device, process/tool handles and success/failure release condition for later execution. Stop
only recorded owned handles. Device enumeration follows capture preflight.

| Tooling owner                            | Update/failure trigger                                            | Retirement condition                                                                |
| ---------------------------------------- | ----------------------------------------------------------------- | ----------------------------------------------------------------------------------- |
| Template/recipes/provenance/source guard | Actual template/scene/identity/floor or generated-context delta   | Candidate retired or supported final native owner inherits origin/contracts         |
| Topology/import/Forge/production guards  | New caller/pin/peer/layout or F1/integration source change        | Candidate retired or final isolation/security owner carries equivalent obligations  |
| Unaccepted archive20/yauzl preparation   | Existing-tool route cannot meet a demonstrated guarantee          | Dormant while unneeded; no obligation transfers from unexecuted preparation         |
| Small Android qualifier/Release caller   | Changed actual payload/plugin/compiler/output mapping or override | Final supported build owns exact identity/settings/artifact proofs                  |
| Apple locks/context/scene owners         | Changed tool/default gem/CDN/pod/Xcode/runtime or actual failure  | Final supported toolchain/lifecycle owner assumes floor/service/privacy obligations |
| Shipping Capacitor toolchain/services    | Any released control or supported upgrade dependency              | Only accepted final architecture transfers all upgrade/release/service evidence     |

Whole-screen physical visible/readiness calibration and matched product comparison stay parent
owned. No source unit, bootstrap, compiler, reviewer agreement or thin scene selects a destination.
The full migration contract and all applicable product/continuity/signed/release/final review gates
remain open.

## Corrected-source frontier

The original d0dc567f83fd602457e0a7cfbfefa62b7f911a9b source packet on accepted
794448fbf76276b76a910c167b5c2e0c4e1ea538 passed all 111 scoped controls and was actually reviewed in
original round two. Immutable input/provenance copies remain under `source-repair/review-round2/`.
The complete report resolved all eight original findings; two source suggestions, one formatter nit
and finite writer observations earned bounded follow-up repairs. The changed source is frozen at
7da00012890a72e46eb5cdc390dab8c63f0035a3; actual pinned-template regeneration, both 112-control
Node24/Node22 suites, scoped source/lint/format/idempotence and complete identity readback passed
within 15.527175 seconds. See `source-repair/README.md`, current frozen manifest and distinct
follow-up scoped receipts. Old execution receipts remain historical and full source/CI acceptance is
pending. Original native70 remains preserved.

The follow-up phase version guard, portable root-floor selector controls, formatter order/real
fixtures, PATH-first disposable Apple environment and complete caller delta contract are source
corrections only. NDK authentication uses one descriptor across hash/parse/copy/independent member
readback/posthash. JDK signature receipts require exact argv/shared time/producer/three members;
macOS setgid proves mode bookkeeping. All prepared producers explicitly require a trusted host with
no concurrent same-UID input/parent mutation and check complete before/after path/input identities;
no adversarial parent-swap guarantee is claimed. They remain unexecuted.

Conversation7c940639-09e2-4236-961f-1122171cb5d8 actually resumed as round2 under source-review
keyc2725d19511d43e8cbad5a98e5a6ff64, two used/one left. The original 93cd ledger is unchanged;
future actual PR adoption retains this budget and identity. Parent source disposition and explicit
lease precede downloaded trust execution. F1 remains unaccepted and gates candidate
growth/integration. No downloaded verifier/JDK/NDK execution, app compilation, mount or performance
is established.
