import datetime
import hashlib
import json
import os
import runpy
import subprocess
import sys
from pathlib import Path

REAL_POPEN = subprocess.Popen
SELECTORS = ['PATH','LANG','LC_ALL','DYLD_LIBRARY_PATH','DYLD_FALLBACK_LIBRARY_PATH','DYLD_PRINT_LIBRARIES','SEQUOIA_CRYPTO_POLICY','OPENSSL_CONF','OPENSSL_MODULES','OPENSSL_ENGINES']


def emit(value,output):
    value['recordedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (output/'children.jsonl').open('a') as stream:
        stream.write(json.dumps(value)+'\n')
        stream.flush()
        os.fsync(stream.fileno())


def group_gone(group):
    try:
        os.killpg(group,0)
        return False
    except ProcessLookupError:
        return True


def query_identity(pid,output):
    argv=['/bin/sh','-c','exec /bin/ps -ww -p "$1,$$" -o pid=,ppid=,pgid=,lstart=,command=','owned-identity',str(pid)]
    query=REAL_POPEN(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C'})
    emit({'event':'identity-query-start','pid':query.pid,'pgid':query.pid,'observerPid':os.getpid(),'targetPid':pid,'argv':argv,'deadlineSeconds':5},output)
    timed_out=False
    try:
        stdout,stderr=query.communicate(timeout=5)
    except subprocess.TimeoutExpired:
        query.kill()
        stdout,stderr=query.communicate()
        timed_out=True
    channels={}
    for channel,raw in [('stdout',stdout),('stderr',stderr)]:
        file=output/(str(query.pid)+'.identity.'+channel+'.txt');file.write_bytes(raw)
        channels[channel]={'path':file.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    identities={};parse_error=None
    try:
        for line in stdout.decode().splitlines():
            parts=line.split(None,8)
            if len(parts)!=9:
                raise ValueError('Actual targeted OS identity output shape differs')
            ident={'pid':int(parts[0]),'ppid':int(parts[1]),'pgid':int(parts[2]),'startLocal':' '.join(parts[3:8]),'argv':parts[8]}
            identities[ident['pid']]=ident
    except (ValueError,UnicodeDecodeError) as error:
        parse_error=str(error)
    own=identities.get(query.pid);gone=group_gone(query.pid)
    emit({'event':'identity-query-exit','pid':query.pid,'exitCode':query.returncode,'osIdentity':own,'groupGone':gone,'channels':channels,'timedOut':timed_out,'parseError':parse_error},output)
    if timed_out:
        raise ValueError('Owned direct OS query handle exceeded5s; target child untouched, no ownership claim')
    if parse_error is not None:
        raise ValueError(parse_error)
    if (query.returncode!=0 or not gone or own is None or own['ppid']!=os.getpid() or own['pgid']!=query.pid):
        raise ValueError('Actual targeted OS observer ownership/exit differs')
    return identities.get(pid)


def main():
    producer=Path(sys.argv[1]);output=Path(sys.argv[2])
    class RecordedPopen(REAL_POPEN):
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs)
            self.recorded_exit=False;self.recorded_output=False
            environment=kwargs.get('env')
            emit({'event':'start','producer':str(producer),'producerPid':os.getpid(),'pid':self.pid,'argv':self.args,'cwd':str(kwargs.get('cwd') or Path.cwd()),'explicitEnvironmentSelectors':{name:environment[name] for name in SELECTORS if environment and name in environment},'startNewSession':bool(kwargs.get('start_new_session',False))},output)
            identity=query_identity(self.pid,output)
            if identity is None:
                status=super().poll()
                if status is None:
                    raise ValueError('Live direct child lacks actual OS identity; halt setup')
                self.record_exit(status)
                emit({'event':'spawn-exited-complete','pid':self.pid,'exitCode':status,'cleanupCandidate':False,'identityClaim':'Direct Popen child exited before targeted OS read; no live ownership or kill claim'},output)
            elif identity['ppid']!=os.getpid():
                raise ValueError('Actual spawned child parent differs; no cleanup ownership')
            else:
                emit({'event':'spawn-identity','pid':self.pid,'osIdentity':identity},output)

        def record_exit(self,status):
            if status is not None and not self.recorded_exit:
                self.recorded_exit=True
                emit({'event':'exit','pid':self.pid,'exitCode':status},output)

        def poll(self):
            status=super().poll();self.record_exit(status);return status

        def wait(self,*args,**kwargs):
            status=super().wait(*args,**kwargs);self.record_exit(status);return status

        def communicate(self,*args,**kwargs):
            values=super().communicate(*args,**kwargs);self.record_exit(self.returncode)
            if not self.recorded_output:
                self.recorded_output=True;row={'event':'output','pid':self.pid,'channels':{}}
                for channel,value in zip(['stdout','stderr'],values):
                    if value is None:continue
                    raw=value.encode() if isinstance(value,str) else value
                    file=output/(str(self.pid)+'.'+channel+'.txt');file.write_bytes(raw)
                    row['channels'][channel]={'path':file.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'decodedByOriginalCaller':isinstance(value,str)}
                emit(row,output)
            return values
    subprocess.Popen=RecordedPopen
    emit({'event':'producer-start','pid':os.getpid(),'pgid':os.getpgrp(),'producer':str(producer),'producerSha256':hashlib.sha256(producer.read_bytes()).hexdigest(),'recorderSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Finite subprocess observer; actual argv/environment/cwd/session and returned output/status unchanged; no SDK/native/source patch'},output)
    try:
        runpy.run_path(str(producer),run_name='__main__')
    finally:
        emit({'event':'producer-finished','pid':os.getpid()},output)


if __name__=='__main__':main()
