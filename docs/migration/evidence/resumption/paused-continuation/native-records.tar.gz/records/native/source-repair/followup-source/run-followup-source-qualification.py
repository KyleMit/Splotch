import datetime
import hashlib
import json
import os
import shutil
import signal
import stat
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source'
OUTPUT = ROOT / 'followup-checks'
REGENERATED = ROOT / 'followup-regenerated-source'
NODE24 = Path('/Users/kylemit/.nvm/versions/node/v24.16.0/bin/node')
NODE22 = Path('/Users/kylemit/.nvm/versions/node/v22.23.2/bin/node')
TEMPLATE = ROOT.parent.parent / 'records/native/template-archive.tgz'
DEADLINE_SECONDS = 120
START = time.monotonic()
TOOLS = ['check-native-candidate.mjs','materialize-native-candidate.mjs','lib/native-apple-scene.mjs','lib/native-source-contract.mjs','lib/native-source-files.mjs','lib/native-template-transforms.mjs','lib/native-template.mjs','tests/native-apple-scene.test.mjs','tests/native-registration.test.mjs','tests/native-source-contract.test.mjs','tests/native-template.test.mjs','tests/native-provenance.test.mjs']
PATHS = ['tools/migration/' + path for path in TOOLS]
RECORDER = []
CHILDREN = []


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def row(root,path):
    file = root / path
    info = file.lstat()
    if not stat.S_ISREG(info.st_mode):
        raise ValueError('Expected exact regular source/input: ' + str(file))
    return {'path':path,'bytes':info.st_size,'mode':oct(stat.S_IMODE(info.st_mode)),'sha256':sha(file)}


def save(name,value):
    (OUTPUT / name).write_text(json.dumps(value,indent=2)+'\n')


def command(name,argv,cwd=SOURCE,node=NODE24):
    timeout = DEADLINE_SECONDS - (time.monotonic() - START)
    if timeout <= 0:
        raise ValueError('Follow-up source total deadline exceeded')
    environment = dict(os.environ,PATH=str(node.parent)+':'+os.environ.get('PATH','/usr/bin:/bin'))
    record = {'name':name,'argv':[str(value) for value in argv],'cwd':str(cwd),'nodePath':str(node),'nodeSha256':sha(node),'PATH':environment['PATH'],'startedAt':now(),'deadlineSeconds':timeout,'scope':'Serial source-only qualification; no native/toolchain/downloaded code execution'}
    with (OUTPUT / (name+'.stdout.txt')).open('xb') as out,(OUTPUT / (name+'.stderr.txt')).open('xb') as err:
        child = subprocess.Popen(record['argv'],cwd=cwd,env=environment,stdout=out,stderr=err,start_new_session=True)
        record.update(pid=child.pid,pgid=child.pid)
        CHILDREN.append(record)
        save('running.json',{'producerPid':os.getpid(),'producerPgid':os.getpgrp(),'producerSha256':sha(__file__),'producerStartedAt':PRODUCER_STARTED_AT,'totalDeadlineSeconds':DEADLINE_SECONDS,'currentChild':record})
        try:
            status = child.wait(timeout=timeout)
            timed_out = False
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGKILL)
            status = child.wait(timeout=10)
            timed_out = True
    record.update(exitCode=status,timedOut=timed_out,finishedAt=now())
    try:
        os.killpg(child.pid,0)
        record['groupReleased']=False
    except ProcessLookupError:
        record['groupReleased']=True
    for channel in ['stdout','stderr']:
        path = OUTPUT / (name+'.'+channel+'.txt')
        record[channel]={'path':path.name,'bytes':path.stat().st_size,'sha256':sha(path)}
    RECORDER.append(record)
    save('commands.json',RECORDER)
    print(name,status,'released',record['groupReleased'],flush=True)
    if status != 0 or timed_out or not record['groupReleased']:
        raise ValueError('Scoped source command failed/timed out/not released: '+name)


def installed_inputs(label):
    paths=['.modules.yaml','.pnpm/lock.yaml','vitest/package.json','prettier/package.json','eslint/package.json','expo/package.json','react-native/package.json','hermes-compiler/package.json']
    rows=[]
    for path in paths:
        actual=(SOURCE/'node_modules'/path).resolve(strict=True)
        raw=actual.read_bytes()
        target=OUTPUT/(label+'-'+path.replace('/','_')+'.txt')
        target.write_bytes(raw)
        rows.append({'path':path,'realPath':str(actual),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
    return rows


def main():
    OUTPUT.mkdir()
    composition=json.loads((ROOT/'composition-inputs.json').read_text())
    original=Path('/Users/kylemit/.codex/worktrees/migration-native-source/Splotch')
    original_rows=[row(original,value['path']) for value in composition['originalSourceRows']]
    if original_rows != composition['originalSourceRows']:
        raise ValueError('Original native70 preservation changed before source qualification')
    installed_before=installed_inputs('installed-before')
    tools=PATHS+['tools/lib/proc.mjs','tools/lib/native-candidate.mjs','tools/migration/lib/archive-inventory.mjs','tools/migration/inputs/native-template-manifest.json','tools/migration/inputs/expo-template-bare-minimum-57.0.28.metadata.json.txt']
    for path in tools+['experiments/native-architecture/package.json','experiments/native-architecture/alignment.json','experiments/native-architecture/src/index.ts']:
        source=SOURCE/path;target=REGENERATED/path
        target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as output:
            output.write(source.read_bytes())
        target.chmod(stat.S_IMODE(source.lstat().st_mode))
    (REGENERATED/'package.json').write_text('{"type":"module"}\n')
    (REGENERATED/'node_modules').symlink_to((SOURCE/'node_modules').resolve(),target_is_directory=True)
    save('frozen-regeneration-inputs.json',{'template':row(TEMPLATE.parent,TEMPLATE.name),'sourceInputs':[row(SOURCE,path) for path in sorted(set(tools))],'original70Preservation':original_rows,'installedInputs':installed_before})
    command('regenerate-pinned-template',[NODE24,'tools/migration/materialize-native-candidate.mjs','--archive='+str(TEMPLATE)],cwd=REGENERATED)
    target='experiments/native-architecture'
    provenance=json.loads((REGENERATED/target/'native-template-provenance.json').read_text())
    output_rows=[];changed=[]
    for member in provenance['records']:
        if not member['target']:
            continue
        path=target+'/'+member['target'];actual=row(REGENERATED,path)
        if actual['sha256'] != member['targetSha256'] or actual['mode'] != member['mode']:
            raise ValueError('Changed recipe output/provenance mismatch')
        current=SOURCE/path
        if sha(current) != actual['sha256']:
            changed.append(path)
        output_rows.append(actual)
    expected=[target+'/ios/HelloWorld.xcodeproj/project.pbxproj']
    if changed != expected or len(output_rows) != 45:
        raise ValueError('Unexpected changed native output set')
    for path in expected+[target+'/native-template-provenance.json']:
        shutil.copyfile(REGENERATED/path,SOURCE/path)
        (SOURCE/path).chmod(stat.S_IMODE((REGENERATED/path).lstat().st_mode))
    save('regeneration-composition.json',{'changedMaintainedPaths':expected+[target+'/native-template-provenance.json'],'actualOutputRows':output_rows,'scope':'Authenticated actual pinned template regeneration; only changed PBX and canonical receipt composed into existing source'})
    command('format-code',[NODE24,'node_modules/prettier/bin/prettier.cjs','--write',*PATHS])
    command('format-md',[SOURCE/'node_modules/.bin/dprint','fmt','experiments/native-architecture/NATIVE-SOURCES.md','tools/migration/README.md'])
    tests=['migration/'+path for path in TOOLS if path.startswith('tests/')]
    for node,name in [(NODE24,'node24'),(NODE22,'node22')]:
        command('source-tests-'+name,['npm','run','test:tools','--',*tests,'--maxWorkers=1','--no-file-parallelism'],node=node)
    command('source-check',['npm','run','check:migration:native-candidate'])
    command('materializer-idempotence',['npm','run','gen:migration:native-candidate','--','--archive='+str(TEMPLATE)])
    command('scoped-lint',[NODE24,'node_modules/eslint/bin/eslint.js',*PATHS])
    command('scoped-format-check',[NODE24,'node_modules/prettier/bin/prettier.cjs','--check',*PATHS,'package.json','.github/workflows/test.yml','tools/ci-mirror/run-quality-checks.mjs','experiments/native-architecture'])
    command('test-inventory',[NODE24,'node_modules/vitest/vitest.mjs','list','--config','tools/vitest.config.mjs',*tests,'--maxWorkers=1','--no-file-parallelism','--json','--no-staticParse'])
    installed_after=installed_inputs('installed-after')
    if installed_after != installed_before or [row(original,value['path']) for value in composition['originalSourceRows']] != original_rows:
        raise ValueError('Borrowed installed inputs or original native70 changed')
    save('result.json',{'finishedAt':now(),'elapsedSeconds':time.monotonic()-START,'original70Preserved':True,'borrowedInstalledInputsUnchanged':True,'allOwnedGroupsReleased':all(value['groupReleased'] for value in RECORDER),'fullGatesExecuted':False,'nativeTrustOrRuntimeExecuted':False,'sourceAccepted':False,'sourceRows':[row(SOURCE,value['path']) for value in composition['originalSourceRows']]})


PRODUCER_STARTED_AT=now()
if __name__=='__main__':
    try:
        main()
    except BaseException as error:
        if OUTPUT.exists():
            save('unaccepted-failure.json',{'error':str(error),'intendedRejectingControl':False,'children':CHILDREN,'recordedAt':now()})
        raise
