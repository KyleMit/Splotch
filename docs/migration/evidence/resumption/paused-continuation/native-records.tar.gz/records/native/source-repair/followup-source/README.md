# N1 round-two follow-up source

This directory preserves the changed source on accepted base
794448fbf76276b76a910c167b5c2e0c4e1ea538, tree
7da00012890a72e46eb5cdc390dab8c63f0035a3. The original d0dc packet and its parent verification
remain unchanged in the durable parent source-repair root and `../review-round2/`.

`frozen-source-manifest.json` binds all70 source rows, exact producers and original Claude identity
(two rounds used, one remains). `source-packet.tar.gz` has exactly those70 regular files/modes and
is independently reread by `source-packet-qualification.json`. Complete accepted-base diff and
round-two-only diff are separate. No F1 source or candidate feature growth is included.

`../followup-checks/commands.json` and complete outputs bind actual pinned-template regeneration,
only PBX/provenance composition, both112-control suites under actual Node24.16.0/Node22.23.2, source
checker/idempotence, scoped lint/format, dynamic112-name collection and unchanged original70/borrowed
input readback. All groups released after15.527175 seconds within the120-second source lease.
Node22.23.2 is the tested major line; this is not minimum22.13 floor proof. New source controls and
unexecuted trust predicates are separated in `followup-controls.json`.

The actual maintained checkout remains the owned sibling `../source/`. Trust writers/profiles are
under `../../android-qualification/`; their complete original-round-two bytes remain under
`../review-round2/prepared-inputs/`. The finite external trust supervisor is prepared and awaiting
parent review/lease. No downloaded verifier/JDK/NDK execution, native build/mount/device/performance
or source acceptance is established. Required full-source gates/F1/CI and independent executed
acceptance remain pending.

Raw reviewer conversations/tool streams are host-local ignored evidence. This durable host-local
mirror is not a public technical capsule.
