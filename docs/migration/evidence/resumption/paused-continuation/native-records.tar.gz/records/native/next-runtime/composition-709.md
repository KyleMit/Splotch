# Current-owner composition amendment

This additive amendment reuses `PLAN.md`; its frozen bytes and runtime profile remain
unchanged. The historical private tree is7da00012890a72e46eb5cdc390dab8c63f0035a3
over794448fbf76276b76a910c167b5c2e0c4e1ea538. The current accepted integration ref
locally resolves to709fadd68ecb802aa2c9daa3fc197ce8d072b23c. `composition-709.json`
binds the ten actual registration owners and the source-only overlap assessment.

The smallest source unit transfers the sixty repaired maintained intake paths and
the new native registration test, then composes five narrow owner deltas: two
package scripts plus their descriptions; one mandatory Quality workflow step; the
same local mirror command after topology; the reviewed formatter re-includes in
their correct order; and the native source/materialization README paragraphs.
These are source repairs and registration only; the label scene, dependencies,
locks and candidate entry/config remain unchanged. No feature growth is included.

Preserve the current retained job, hosted scripts, postbuild strip-types selector,
retained typecheck, README title/retained section and all accepted docs/evidence.
Keep current ESLint, stylelint, dprint and Git-ignore owners rather than copying
the private historical snapshots. ESLint received retained-host changes since794;
N1 needs no ESLint delta. The workflow/package/README overlap is resolved by these
finite additions, not whole-file restoration. Insert the native README paragraph
inside its native topology section before the retained section.

F1 sourcee4e9fc044d46d49c3565379a3e6419e8eff4af9d remains held and is neither
accepted nor included by this proposal. A later accepted F1 guard composes through
its actual current owner; do not transplant its held version or call709 already
F1-complete. Original Claude7c940639-09e2-4236-961f-1122171cb5d8 remains two rounds
used/one remaining. The final round covers the executed final composition and
receipts, not this amendment.

After parent source disposition and frontier clearance, use a fresh isolated
source checkout at the then-accepted exact ref; leave the dirty dc08 native intake
intact. Freeze resulting Git tree/diff/base, original/repaired manifests, complete
installed graph and incoming owner identities before scoped qualification. Reuse
matching artifact/toolchain receipts only where full inputs and scope still match.
Changed registration/context invalidates prior source/full-gate acceptance; run
registration formatter/CI controls, source/materializer rejecting/restored controls,
applicable final Quality/Browserless/floor checks and eventual final-head CI under
parent leases. Native configuration/Release/mount follows the original PLAN gates
and its separate executable trust grants. No application, installation, runtime
execution, compile or acceptance occurs in this amendment.
