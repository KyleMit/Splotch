import datetime
import hashlib
import json
import os
import pwd
import re
import stat
import subprocess
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / 'owned-runtime'
WHOLE_DEADLINE_SECONDS = 120
CHUNK_BYTES = 1024 * 1024
JANSI_CONTROL_BYTE_OFFSET = 0
JANSI_CONTROL_XOR = 1
START = time.monotonic()


def remaining():
    if time.monotonic() - START >= WHOLE_DEADLINE_SECONDS:
        raise ValueError('Wrapper identity whole120 deadline exceeded')


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while block := stream.read(CHUNK_BYTES):
            remaining()
            value.update(block)
    return value.hexdigest()


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')


def directory(path, profile, mode):
    info = path.lstat()
    if (path.resolve(strict=True) != path or not stat.S_ISDIR(info.st_mode) or info.st_uid != profile['actorUid'] or
        info.st_gid != profile['ownedGid'] or stat.S_IMODE(info.st_mode) != mode):
        raise ValueError('Wrapper owned canonical directory type/owner/mode differs: ' + str(path))
    return info


def mkdir(path, profile, mode=0o755):
    directory(path.parent, profile, 0o700 if path.parent == OUTPUT else 0o755)
    path.mkdir(mode=mode)
    path.chmod(mode)
    directory(path, profile, mode)


def copy_regular(source, target, mode, profile):
    directory(target.parent, profile, 0o755)
    info = source.lstat()
    if source.resolve(strict=True) != source or not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise ValueError('Wrapper copy source is not canonical regular content')
    fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode)
    with os.fdopen(fd, 'wb') as output, source.open('rb') as content:
        while block := content.read(CHUNK_BYTES):
            remaining()
            output.write(block)
        os.fchmod(output.fileno(), mode)
    if sha(source) != sha(target):
        raise ValueError('Wrapper owned copy differs from exact authenticated source')


def frozen_inputs(profile):
    result = []
    for expected in profile['directoryInputs']:
        path = Path(expected['path'])
        info = path.lstat()
        actual = {'path': str(path), 'device': info.st_dev, 'inode': info.st_ino, 'uid': info.st_uid,
                  'gid': info.st_gid, 'mode': oct(stat.S_IMODE(info.st_mode))}
        if path.resolve(strict=True) != path or not stat.S_ISDIR(info.st_mode) or actual != expected:
            raise ValueError('Wrapper frozen canonical input directory identity differs: ' + str(path))
        result.append(actual)
    for expected in profile['inputs']:
        path = Path(expected['path'])
        info = path.lstat()
        actual = {'path': str(path), 'realPath': str(path.resolve(strict=True)), 'bytes': info.st_size,
                  'device': info.st_dev, 'inode': info.st_ino, 'uid': info.st_uid, 'gid': info.st_gid,
                  'mode': oct(stat.S_IMODE(info.st_mode)), 'sha256': sha(path)}
        if actual != expected or not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise ValueError('Wrapper frozen source/tool/receipt identity differs: ' + str(path))
        result.append(actual)
    if sha(__file__) != profile['producerSha256'] or profile['wholeDeadlineSeconds'] != WHOLE_DEADLINE_SECONDS:
        raise ValueError('Wrapper parent-read source/deadline binding differs')
    return result


def source70(profile):
    manifest = json.loads(Path(profile['sourceManifest']).read_text())
    results = []
    for base, expected in [(Path(profile['repairedSource']), manifest['sourceRows']),
                           (Path(profile['originalSource']), manifest['originalIntakePreservation']['sourceRows'])]:
        actual_rows = []
        for row in expected:
            path = base / row['path']
            info = path.lstat()
            actual = {'path': row['path'], 'bytes': info.st_size, 'mode': oct(stat.S_IMODE(info.st_mode)), 'sha256': sha(path)}
            if path.resolve(strict=True) != path or not stat.S_ISREG(info.st_mode) or actual != row:
                raise ValueError('Wrapper original/repaired source70 differs')
            actual_rows.append(actual)
        results.append({'root': str(base), 'rows': actual_rows})
    return results


def verify_tree(base, rows, uid, gid, expected_inodes=True, vendor_modes=False, root_mode=0o700):
    root_info = base.lstat()
    if (base.resolve(strict=True) != base or not stat.S_ISDIR(root_info.st_mode) or root_info.st_uid != uid or
        root_info.st_gid != gid or stat.S_IMODE(root_info.st_mode) != root_mode):
        raise ValueError('Wrapper runtime root canonical type/owner differs: ' + str(base))
    expected = {row['path'] for row in rows}
    actual = {str((Path(folder) / name).relative_to(base)) for folder, dirs, files in os.walk(base, followlinks=False) for name in dirs + files}
    if actual != expected:
        raise ValueError('Wrapper full runtime installed path set differs: ' + str(base))
    observed = [{'path': '.', 'kind': 'directory', 'device': root_info.st_dev, 'inode': root_info.st_ino,
                 'uid': root_info.st_uid, 'gid': root_info.st_gid, 'mode': oct(stat.S_IMODE(root_info.st_mode)), 'bytes': 0, 'sha256': None}]
    for row in rows:
        remaining()
        path = base / row['path']
        info = path.lstat()
        mode = int(row['mode'], 8)
        if vendor_modes and row['kind'] == 'file':
            mode = 0o755 if row['path'] == 'bin/gradle' else 0o644
        kind = stat.S_ISDIR(info.st_mode) if row['kind'] == 'directory' else stat.S_ISREG(info.st_mode)
        expected_inode = row.get('ownedInode', row.get('inode'))
        if (path.resolve(strict=True) != path or not kind or info.st_uid != uid or info.st_gid != gid or
            stat.S_IMODE(info.st_mode) != mode or (expected_inodes and info.st_ino != expected_inode) or
            (row['kind'] == 'file' and (info.st_nlink != 1 or info.st_size != row['bytes'] or sha(path) != row['sha256']))):
            raise ValueError('Wrapper full runtime installed byte/mode/inode/owner differs: ' + str(path))
        observed.append({'path': row['path'], 'kind': row['kind'], 'device': info.st_dev, 'inode': info.st_ino,
                         'uid': info.st_uid, 'gid': info.st_gid, 'mode': oct(stat.S_IMODE(info.st_mode)),
                         'bytes': row['bytes'], 'sha256': row.get('sha256')})
    return observed


def input_trees(profile, gradle_rows, java_rows):
    gradle = verify_tree(Path(profile['gradleTree']), gradle_rows, profile['actorUid'], profile['ownedGid'])
    java = verify_tree(Path(profile['javaTree']), java_rows, profile['actorUid'], profile['javaTreeGid'])
    return {'gradle': gradle, 'jdk': java}


def cache_location(home, profile):
    number = int.from_bytes(hashlib.md5(profile['distributionUrl'].encode()).digest(), 'big')
    encoded = ''
    alphabet = '0123456789abcdefghijklmnopqrstuvwxyz'
    while number:
        number, remainder = divmod(number, 36)
        encoded = alphabet[remainder] + encoded
    if encoded != profile['releasedUrlMd5Base36']:
        raise ValueError('Wrapper released cache-location URL mapping differs')
    for path in [home / 'wrapper', home / 'wrapper/dists', home / 'wrapper/dists/gradle-9.3.1-bin',
                 home / 'wrapper/dists/gradle-9.3.1-bin' / encoded]:
        mkdir(path, profile)
    return home / 'wrapper/dists/gradle-9.3.1-bin' / encoded


def context(path, profile):
    mkdir(path, profile)
    mkdir(path / 'gradle', profile)
    mkdir(path / 'gradle/wrapper', profile)
    for source, relative, mode in [(profile['gradlew'], 'gradlew', 0o755), (profile['wrapperJar'], 'gradle/wrapper/gradle-wrapper.jar', 0o644),
                                   (profile['wrapperProperties'], 'gradle/wrapper/gradle-wrapper.properties', 0o644)]:
        copy_regular(Path(source), path / relative, mode, profile)
    return path / 'gradle/wrapper/gradle-wrapper.properties'


def environment(home, profile):
    java = Path(profile['javaHome'])
    return {'HOME': os.environ['HOME'], 'PATH': str(Path(profile['node24']).parent) + ':' + str(java / 'bin') + ':/usr/bin:/bin',
            'JAVA_HOME': str(java), 'GRADLE_USER_HOME': str(home), 'TMPDIR': str(OUTPUT / 'tmp'), 'LANG': 'C', 'LC_ALL': 'C',
            'JAVA_OPTS': '-XshowSettings:properties -Xlog:os=info,library=info:stderr:pid,level,tags -XX:-UsePerfData -Djava.io.tmpdir=' + str(OUTPUT / 'tmp') +
                         ' -Dorg.gradle.java.installations.auto-download=false -Dorg.gradle.java.installations.auto-detect=false',
            'DYLD_LIBRARY_PATH': '', 'DYLD_FALLBACK_LIBRARY_PATH': ''}


def capture(label, project, home, profile, gradle_rows, java_rows):
    remaining()
    input_frame = {'trees': input_trees(profile, gradle_rows, java_rows), 'inputs': frozen_inputs(profile), 'source70': source70(profile)}
    argv = [str(project / 'gradlew'), '--no-daemon', '--version']
    env = environment(home, profile)
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    child = subprocess.Popen(argv, cwd=project, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             start_new_session=True, umask=0o022)
    stdout, stderr = child.communicate()
    for channel, raw in [('stdout', stdout), ('stderr', stderr)]:
        (ROOT / (label + '.' + channel + '.txt')).write_bytes(raw)
    row = {'argv': argv, 'cwd': str(project), 'environment': env, 'pid': child.pid, 'pgid': child.pid, 'exitCode': child.returncode,
           'startedAt': started, 'finishedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'stdoutSha256': hashlib.sha256(stdout).hexdigest(), 'stderrSha256': hashlib.sha256(stderr).hexdigest()}
    after_frame = {'trees': input_trees(profile, gradle_rows, java_rows), 'inputs': frozen_inputs(profile), 'source70': source70(profile)}
    if input_frame != after_frame:
        raise ValueError('Wrapper exact whole source/runtime inputs changed across consumer')
    row['wholeSourceRuntimeInputsBeforeAndAfter'] = input_frame
    save(label + '.command.json', row)
    if 'Downloading ' in stdout.decode() or 'Downloading ' in stderr.decode():
        raise ValueError('Wrapper attempted undeclared network receive; setup failure')
    return stdout.decode(), stderr.decode(), row


def jvm_identity(stderr, command, home, profile):
    properties = {}
    for line in stderr.splitlines():
        match = re.fullmatch(r'\s+([A-Za-z0-9_.]+) = (.*)', line)
        if match:
            if match[1] in properties:
                raise ValueError('Wrapper JVM property occurs more than once')
            properties[match[1]] = match[2]
    for name, value in profile['expectedJavaProperties'].items():
        if properties.get(name) != value:
            raise ValueError('Actual wrapper JVM identity differs: ' + name)
    project = Path(command['cwd'])
    if (properties.get('java.class.path') != str(project / 'gradle/wrapper/gradle-wrapper.jar') or
        properties.get('user.dir') != str(project) or properties.get('user.home') != os.environ['HOME']):
        raise ValueError('Actual wrapper JVM context/classpath/HOME differs')
    loaded = []
    for line in stderr.splitlines():
        match = re.fullmatch(r'\[(\d+)\]\[info *\]\[(os|library) *\] (.*)', line)
        if match is None:
            continue
        message = re.fullmatch(r'shared library load of (/.+) was successful', match[3]) if match[2] == 'os' else re.fullmatch(r'Loaded library (/.+), handle 0x[0-9A-Fa-f]+', match[3])
        if message is None:
            continue
        if int(match[1]) != command['pid']:
            raise ValueError('Actual wrapper native load PID differs from actual launch')
        path = Path(message[1])
        expected = next((row for row in profile['jdkNativeLibraryRows'] if row['absolutePath'] == str(path)), None)
        if expected is None:
            expected = next((row for row in profile['nativeLibraryMembers'] if row['cacheRelativePath'] is not None and home / row['cacheRelativePath'] == path), None)
        if expected is None:
            raise ValueError('Actual wrapper successful native load has undeclared path')
        info = path.lstat()
        if (path.resolve(strict=True) != path or not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or
            info.st_size != expected['bytes'] or sha(path) != expected['sha256'] or
            info.st_uid != profile['actorUid'] or info.st_gid != (profile['javaTreeGid'] if path.is_relative_to(Path(profile['javaHome'])) else profile['ownedGid']) or
            stat.S_IMODE(info.st_mode) != int(expected['ownedMode'], 8)):
            raise ValueError('Actual wrapper native load differs from authenticated member bytes/mode/owner')
        loaded.append({'pid': int(match[1]), 'tag': match[2], 'path': str(path), 'bytes': info.st_size,
                       'sha256': expected['sha256'], 'device': info.st_dev, 'inode': info.st_ino,
                       'uid': info.st_uid, 'gid': info.st_gid, 'mode': oct(stat.S_IMODE(info.st_mode))})
    if not set(profile['requiredJdkLoadPaths']).issubset({row['path'] for row in loaded}):
        raise ValueError('Actual wrapper native trace lacks required qualified Java loads')
    return {'properties': properties, 'successfulNativeLoadRecords': loaded,
            'observable': 'Same-run successful explicit HotSpot/JVM native loads; no complete dyld/transitive/pre-VM image claim'}


def native_publications(profile):
    for row in profile['nativeLibraryMembers']:
        with zipfile.ZipFile(row['jar']) as archive:
            if archive.namelist().count(row['path']) != 1:
                raise ValueError('Declared native publication member is not unique')
            raw = archive.read(row['path'])
        if len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
            raise ValueError('Declared native publication member differs from authenticated JAR bytes')
    qualified_java = json.loads(Path(profile['jdkWriterResult']).read_text())['rows']
    for expected in profile['jdkNativeLibraryRows']:
        row = next((item for item in qualified_java if Path(profile['javaTree']) / item['path'] == Path(expected['absolutePath'])), None)
        if row is None or row['bytes'] != expected['bytes'] or row['sha256'] != expected['sha256'] or row['mode'] != expected['ownedMode']:
            raise ValueError('Declared Java native publication differs from qualified JDK member')


def captured_load_controls(stderr, command, home, profile):
    target = profile['requiredJdkLoadPaths'][0]
    parsed = jvm_identity(stderr, command, home, profile)
    lines = stderr.splitlines(keepends=True)
    success = lambda line: ('shared library load of ' + target + ' was successful') in line or ('Loaded library ' + target + ', handle ') in line
    matching = [line for line in lines if success(line)]
    if not matching:
        raise ValueError('Captured native-load control lacks actual successful target record')
    missing = ''.join(line for line in lines if not success(line))
    path_changed = stderr.replace(matching[0], matching[0].replace(target, str(OUTPUT / 'undeclared-library-control.dylib'), 1), 1)
    pid_changed = stderr.replace(matching[0], matching[0].replace('[' + str(command['pid']) + ']', '[' + str(command['pid'] + 1) + ']', 1), 1)
    wrong_member = json.loads(json.dumps(profile))
    member = next(row for row in wrong_member['jdkNativeLibraryRows'] if row['absolutePath'] == target)
    member['sha256'] = ('0' if member['sha256'][0] != '0' else '1') + member['sha256'][1:]
    controls = []
    for name, raw, inputs, reason in [
        ('actual-record-removed', missing, profile, 'Actual wrapper native trace lacks required qualified Java loads'),
        ('actual-record-path-only-changed', path_changed, profile, 'Actual wrapper successful native load has undeclared path'),
        ('actual-record-pid-only-changed', pid_changed, profile, 'Actual wrapper native load PID differs from actual launch'),
        ('declared-member-digest-only-changed', stderr, wrong_member, 'Actual wrapper native load differs from authenticated member bytes/mode/owner'),
    ]:
        try:
            jvm_identity(raw, command, home, inputs)
        except ValueError as error:
            if str(error) != reason:
                raise ValueError('Captured native-load refusal reached unintended reason: ' + name) from error
        else:
            raise ValueError('Captured native-load rejecting control did not refuse: ' + name)
        controls.append({'name': name, 'expectedActualReason': reason, 'rawSha256': hashlib.sha256(raw.encode()).hexdigest()})
    if jvm_identity(stderr, command, home, profile) != parsed:
        raise ValueError('Exact actual native-load raw/input restoration differs')
    return {'actualRawSha256': hashlib.sha256(stderr.encode()).hexdigest(), 'actualCommandPid': command['pid'],
            'target': target, 'controls': controls, 'exactRawAndInputRestoredPositive': True,
            'scope': 'Actual captured-record predicate controls; not JVM refusal of changed executable bytes'}


def copied_jansi(home, profile):
    expected = next(row for row in profile['nativeLibraryMembers'] if row['path'] == 'org/fusesource/jansi/internal/native/Mac/arm64/libjansi.jnilib')
    path = home / expected['cacheRelativePath']
    info = path.lstat()
    if (path.resolve(strict=True) != path or not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or
        info.st_uid != profile['actorUid'] or info.st_gid != profile['ownedGid'] or
        stat.S_IMODE(info.st_mode) != int(expected['ownedMode'], 8)):
        raise ValueError('Actual copied Jansi canonical path/type/nlink/owner/mode differs')
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'rb') as stream:
        opened = os.fstat(stream.fileno())
        identity = lambda value: (value.st_dev, value.st_ino, value.st_mode, value.st_nlink, value.st_uid, value.st_gid, value.st_size)
        if identity(opened) != identity(info):
            raise ValueError('Actual copied Jansi opened descriptor identity differs')
        raw = stream.read()
        if identity(os.fstat(stream.fileno())) != identity(opened) or identity(path.lstat()) != identity(opened):
            raise ValueError('Actual copied Jansi descriptor/path changed during readback')
    if len(raw) != expected['bytes'] or hashlib.sha256(raw).hexdigest() != expected['sha256']:
        raise ValueError('Actual copied Jansi differs from authenticated member bytes/hash')
    return {'path': str(path), 'kind': 'file', 'device': info.st_dev, 'inode': info.st_ino,
            'nlink': info.st_nlink, 'uid': info.st_uid, 'gid': info.st_gid, 'mode': oct(stat.S_IMODE(info.st_mode)),
            'bytes': len(raw), 'sha256': expected['sha256'], 'observable': 'Exact released-owner copied output; no positive Jansi load claim'}


def copied_jansi_control(home, command, profile):
    try:
        os.killpg(command['pgid'], 0)
    except ProcessLookupError:
        pass
    else:
        raise ValueError('Copied Jansi control requires actual prior wrapper group release')
    before = copied_jansi(home, profile)
    path = Path(before['path'])
    with os.fdopen(os.open(path, os.O_RDWR | os.O_NOFOLLOW), 'r+b') as stream:
        info = os.fstat(stream.fileno())
        if info.st_dev != before['device'] or info.st_ino != before['inode'] or path.lstat().st_dev != info.st_dev or path.lstat().st_ino != info.st_ino:
            raise ValueError('Copied Jansi control descriptor does not bind actual qualified output')
        original = stream.read()
        if len(original) != before['bytes'] or hashlib.sha256(original).hexdigest() != before['sha256']:
            raise ValueError('Copied Jansi control original bytes changed before mutation')
        changed = bytes([original[JANSI_CONTROL_BYTE_OFFSET] ^ JANSI_CONTROL_XOR]) + original[1:]
        for name, raw in [('copied-jansi-original.bin', original), ('copied-jansi-byte-changed.bin', changed)]:
            with (ROOT / name).open('xb') as artifact:
                artifact.write(raw)
        reason = 'Actual copied Jansi differs from authenticated member bytes/hash'
        control = {'scope': 'Actual owned copied-member predicate only; no corrupted-library execution',
                   'before': before, 'priorActualWrapperPid': command['pid'], 'priorActualWrapperGroupGone': True,
                   'byteOffset': JANSI_CONTROL_BYTE_OFFSET, 'changedByteCount': 1,
                   'changedSha256': hashlib.sha256(changed).hexdigest(), 'expectedActualReason': reason,
                   'restored': False, 'JVMInvokedWhileMemberChanged': False}
        save('copied-jansi-control.json', control)
        try:
            if os.pwrite(stream.fileno(), changed[:1], JANSI_CONTROL_BYTE_OFFSET) != 1:
                raise ValueError('Copied Jansi control one-byte write did not complete')
            os.fsync(stream.fileno())
            if os.pread(stream.fileno(), len(changed), 0) != changed:
                raise ValueError('Copied Jansi control actual changed bytes differ')
            try:
                copied_jansi(home, profile)
            except ValueError as error:
                control['actualReason'] = str(error)
                if str(error) != reason:
                    raise ValueError('Copied Jansi control reached unintended refusal reason') from error
            else:
                raise ValueError('Copied Jansi byte rejecting control did not refuse')
        finally:
            if os.pwrite(stream.fileno(), original[:1], JANSI_CONTROL_BYTE_OFFSET) != 1:
                raise ValueError('Copied Jansi control original-byte restoration did not complete')
            os.fsync(stream.fileno())
            restored = copied_jansi(home, profile)
            if os.pread(stream.fileno(), len(original), 0) != original or restored != before:
                raise ValueError('Copied Jansi exact bytes/identity restoration differs')
            control.update(restored=True, restoredReadback=restored)
            save('copied-jansi-control.json', control)
    return control


def positive(stdout, stderr, command, home, profile):
    if command['exitCode'] != 0:
        raise ValueError('Actual wrapper version setup failed')
    if (re.search(r'^Gradle 9\.3\.1$', stdout, re.MULTILINE) is None or
        re.search(r'^Revision:\s+' + re.escape(profile['gradleBuildCommit']) + '$', stdout, re.MULTILINE) is None):
        raise ValueError('Actual pinned wrapper effective Gradle release identity differs')
    launcher = re.search(r'^Launcher JVM:\s+(.+)$', stdout, re.MULTILINE)
    daemon = re.search(r'^Daemon JVM:\s+(.+)$', stdout, re.MULTILINE)
    if launcher is None or not launcher[1].startswith('17.0.20.1 ') or 'Eclipse Adoptium 17.0.20.1+1' not in launcher[1] or daemon is None or profile['javaHome'] not in daemon[1]:
        raise ValueError('Actual Gradle launcher/daemon JVM selection differs')
    observed = jvm_identity(stderr, command, home, profile)
    required = {str(home / row['cacheRelativePath']) for row in profile['nativeLibraryMembers'] if row['requiresPositiveLoad']}
    if not required.issubset({row['path'] for row in observed['successfulNativeLoadRecords']}):
        raise ValueError('Actual wrapper native trace lacks required declared Gradle JNI loads')
    observed['copiedJansiMember'] = copied_jansi(home, profile)
    return observed


def cache_graph(home, profile):
    rows = []
    for folder, dirs, files in os.walk(home, followlinks=False):
        for name in dirs + files:
            path = Path(folder) / name
            info = path.lstat()
            kind = 'directory' if stat.S_ISDIR(info.st_mode) else 'file' if stat.S_ISREG(info.st_mode) else None
            if (path.resolve(strict=True) != path or kind is None or info.st_uid != profile['actorUid'] or
                info.st_gid != profile['ownedGid'] or (kind == 'file' and info.st_nlink != 1) or stat.S_IMODE(info.st_mode) & 0o022):
                raise ValueError('Wrapper generated cache type/owner/mode differs')
            relative = str(path.relative_to(home))
            if relative == 'daemon' or relative.startswith('daemon/') or relative.endswith('.part'):
                raise ValueError('Wrapper version gate produced undeclared daemon/download output')
            row = {'path': relative, 'kind': kind, 'device': info.st_dev, 'inode': info.st_ino, 'uid': info.st_uid,
                   'gid': info.st_gid, 'mode': oct(stat.S_IMODE(info.st_mode))}
            if kind == 'file':
                row.update(bytes=info.st_size, sha256=sha(path))
                if not relative.startswith('wrapper/dists/') and path.suffix in ['.jar', '.class', '.dylib', '.jnilib', '.so', '.dll']:
                    expected = next((item for item in profile['nativeLibraryMembers'] if item['cacheRelativePath'] == relative), None)
                    if expected is None or row['sha256'] != expected['sha256'] or row['bytes'] != expected['bytes'] or row['mode'] != expected['ownedMode']:
                        raise ValueError('Wrapper generated executable cache path/member bytes are unqualified')
            rows.append(row)
    return sorted(rows, key=lambda row: row['path'])


def main():
    profile = json.loads((ROOT / 'wrapper-profile.json').read_text())
    if os.environ.get('HOME') != pwd.getpwuid(os.getuid()).pw_dir or os.getuid() != profile['actorUid']:
        raise ValueError('Wrapper genuine HOME/actor differs')
    if directory(ROOT, profile, 0o755).st_ino != profile['preparationRootInode']:
        raise ValueError('Wrapper preparation root inode differs')
    before_inputs = frozen_inputs(profile)
    native_publications(profile)
    before_sources = source70(profile)
    gradle_rows = json.loads(Path(profile['gradleResult']).read_text())['installedRows']
    java_rows = json.loads(Path(profile['jdkWriterResult']).read_text())['rows']
    before_trees = input_trees(profile, gradle_rows, java_rows)
    archive = Path(profile['archive'])
    if sha(archive) != profile['archiveSha256']:
        raise ValueError('Wrapper authenticated distribution archive input differs')
    if OUTPUT.exists() or OUTPUT.is_symlink():
        raise ValueError('Wrapper owned runtime must be absent')
    OUTPUT.mkdir(mode=0o700)
    directory(OUTPUT, profile, 0o700)
    for name in ['tmp', 'positive-project', 'negative-project', 'positive-home', 'negative-home']:
        if name.endswith('-project'):
            context(OUTPUT / name, profile)
        else:
            mkdir(OUTPUT / name, profile)
    positive_home = OUTPUT / 'positive-home'
    negative_home = OUTPUT / 'negative-home'
    positive_cache = cache_location(positive_home, profile)
    negative_cache = cache_location(negative_home, profile)
    for row in sorted(gradle_rows, key=lambda row: (row['path'].count('/'), row['path'])):
        target = positive_cache / row['path']
        if row['kind'] == 'directory':
            mkdir(target, profile, int(row['mode'], 8))
        else:
            copy_regular(Path(profile['gradleTree']) / row['path'], target, int(row['mode'], 8), profile)
    positive_zip = positive_cache / 'gradle-9.3.1-bin.zip'
    negative_zip = negative_cache / 'gradle-9.3.1-bin.zip'
    for target in [positive_zip, negative_zip]:
        copy_regular(archive, target, 0o600, profile)
    marker = positive_cache / 'gradle-9.3.1-bin.zip.ok'
    marker.write_bytes(b'')
    marker.chmod(0o644)
    save('running.json', {'pid': os.getpid(), 'pgid': os.getpgrp(), 'wholeDeadlineSeconds': WHOLE_DEADLINE_SECONDS,
         'sourceTree': profile['sourceTree'], 'actor': {'uid': os.getuid(), 'gid': os.getgid(), 'groups': os.getgroups()},
         'authenticatedSourceTreesBefore': before_trees, 'source70Before': before_sources})
    gradle_contents = [dict(row, path=row['path'].removeprefix('gradle-9.3.1/')) for row in gradle_rows if row['path'] != 'gradle-9.3.1']
    positive_installed = verify_tree(positive_cache / 'gradle-9.3.1', gradle_contents,
         profile['actorUid'], profile['ownedGid'], False, root_mode=0o755)
    out, err, command = capture('wrapper-positive', OUTPUT / 'positive-project', positive_home, profile, gradle_rows, java_rows)
    observed_positive = positive(out, err, command, positive_home, profile)
    captured_controls = captured_load_controls(err, command, positive_home, profile)
    save('captured-native-load-controls.json', captured_controls)
    jansi_control = copied_jansi_control(positive_home, command, profile)
    positive_after = verify_tree(positive_cache / 'gradle-9.3.1',
         gradle_contents,
         profile['actorUid'], profile['ownedGid'], False, root_mode=0o755)
    if positive_after != positive_installed or sha(positive_zip) != profile['archiveSha256']:
        raise ValueError('Wrapper cached positive changed authenticated installed bytes/inodes/ZIP')
    properties = OUTPUT / 'negative-project/gradle/wrapper/gradle-wrapper.properties'
    original = properties.read_bytes()
    old = profile['archiveSha256'].encode()
    wrong = profile['wrongArchiveSha256'].encode()
    if original.count(old) != 1:
        raise ValueError('Wrapper exact checksum property control is not unique')
    changed = original.replace(old, wrong, 1)
    properties.write_bytes(changed)
    if (negative_cache / 'gradle-9.3.1').exists() or (negative_cache / 'gradle-9.3.1-bin.zip.ok').exists() or sha(negative_zip) != profile['archiveSha256']:
        raise ValueError('Wrapper checksum control lacks authentic fresh cache precondition')
    out, err, command = capture('wrapper-checksum-negative', OUTPUT / 'negative-project', negative_home, profile, gradle_rows, java_rows)
    required = ['Verification of Gradle distribution failed!', 'Distribution Url: ' + profile['distributionUrl'],
                'Download Location: ' + str(negative_zip), "Expected checksum: '" + profile['wrongArchiveSha256'] + "'",
                "Actual checksum:   '" + profile['archiveSha256'] + "'"]
    if command['exitCode'] == 0 or not all(text in err for text in required):
        raise ValueError('Actual released wrapper checksum refusal missing or wrong reason')
    observed_negative = jvm_identity(err, command, negative_home, profile)
    if negative_zip.exists() or negative_zip.is_symlink() or (negative_cache / 'gradle-9.3.1').exists() or (negative_cache / 'gradle-9.3.1-bin.zip.ok').exists():
        raise ValueError('Actual wrapper checksum refusal deletion/no-install boundary differs')
    save('checksum-negative.json', {'commandExitCode': command['exitCode'], 'requiredActualVendorMessages': required,
          'propertiesOriginalSha256': hashlib.sha256(original).hexdigest(), 'propertiesChangedSha256': hashlib.sha256(changed).hexdigest(),
          'actualZipDeletedByReleasedChecksumOwner': True, 'distributionNotInstalled': True, 'actualJvmIdentity': observed_negative})
    properties.write_bytes(original)
    copy_regular(archive, negative_zip, 0o600, profile)
    if properties.read_bytes() != original or sha(negative_zip) != profile['archiveSha256']:
        raise ValueError('Wrapper exact checksum/ZIP restoration failed')
    out, err, command = capture('wrapper-restored', OUTPUT / 'negative-project', negative_home, profile, gradle_rows, java_rows)
    observed_restored = positive(out, err, command, negative_home, profile)
    vendor_rows = verify_tree(negative_cache / 'gradle-9.3.1',
         gradle_contents,
         profile['actorUid'], profile['ownedGid'], False, True, 0o755)
    restored_marker = negative_cache / 'gradle-9.3.1-bin.zip.ok'
    if negative_zip.exists() or negative_zip.is_symlink() or not restored_marker.is_file() or restored_marker.read_bytes() != b'':
        raise ValueError('Actual wrapper restored install marker/ZIP deletion boundary differs')
    after_trees = input_trees(profile, gradle_rows, java_rows)
    after_inputs = frozen_inputs(profile)
    after_sources = source70(profile)
    if before_trees != after_trees or before_inputs != after_inputs or before_sources != after_sources:
        raise ValueError('Wrapper full authenticated source/runtime inputs changed')
    save('wrapper-identity-result.json', {'actualCopiedJansiControl': jansi_control, 'actualCapturedLoadControls': captured_controls, 'actualPositive': observed_positive, 'actualChecksumRefusal': observed_negative,
         'actualRestoredPositive': observed_restored, 'sourceTreesBeforeAndAfter': before_trees,
         'source70BeforeAndAfter': before_sources, 'inputsBeforeAndAfter': before_inputs,
         'positiveCacheInstalledBeforeAndAfter': positive_after, 'restoredVendorInstalledRows': vendor_rows,
         'positiveCacheGraph': cache_graph(positive_home, profile), 'restoredCacheGraph': cache_graph(negative_home, profile),
         'profileSha256': sha(ROOT / 'wrapper-profile.json'), 'producerSha256': sha(__file__),
         'restoredPositive': True, 'wholeElapsedSeconds': time.monotonic() - START, 'GradleTaskPluginMavenCompilerNativeAppExecuted': False,
         'claimLimits': profile['claimLimits']})


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        save('wrapper-identity-failure.json', {'error': str(error), 'intendedRejectingControl': False,
             'accepted': False, 'scope': 'Preserved wrapper runtime/identity setup failure; no dependent acceptance'})
        raise
