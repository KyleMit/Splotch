import datetime
import hashlib
import json
import os
import stat
from pathlib import Path

ROOT=Path(__file__).resolve().parent
NATIVE=ROOT.parent
REPAIR=NATIVE/'source-repair'
SOURCE=REPAIR/'source'
Q=NATIVE/'android-qualification'
RECORDS=NATIVE.parent/'records'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def row(path):
 info=path.lstat()
 if not stat.S_ISREG(info.st_mode):raise ValueError('Finite next-stage input is not regular: '+str(path))
 return {'path':str(path),'realPath':str(path.resolve(strict=True)),'bytes':info.st_size,'sha256':sha(path),'mode':oct(stat.S_IMODE(info.st_mode)),'device':info.st_dev,'inode':info.st_ino}
def save(path,value):
 with path.open('x') as output:output.write(json.dumps(value,indent=2)+'\n')
manifest=json.loads((REPAIR/'frozen-source-manifest.json').read_text())
for base,rows in [(SOURCE,manifest['sourceRows']),(Path('/Users/kylemit/.codex/worktrees/migration-native-source/Splotch'),manifest['originalIntakePreservation']['sourceRows'])]:
 for expected in rows:
  p=base/expected['path'];actual=row(p)
  if {k:actual[k] for k in ['bytes','sha256','mode']}!={k:expected[k] for k in ['bytes','sha256','mode']}:raise ValueError('Source70 preservation differs')
context_paths=['package.json','pnpm-lock.yaml','pnpm-workspace.yaml','experiments/native-architecture/package.json','experiments/native-architecture/alignment.json','experiments/native-architecture/metro.config.cjs','experiments/native-architecture/babel.config.cjs','experiments/native-architecture/src/index.ts','experiments/native-architecture/src/ProbeApp.tsx','experiments/native-architecture/android/gradle/wrapper/gradle-wrapper.jar','experiments/native-architecture/android/gradle/wrapper/gradle-wrapper.properties','experiments/native-architecture/android/app/build.gradle','experiments/native-architecture/android/settings.gradle','experiments/native-architecture/ios/Podfile','experiments/native-architecture/ios/Podfile.properties.json','experiments/native-architecture/ios/HelloWorld.xcodeproj/project.pbxproj']
packages=['react-native','@react-native/gradle-plugin','expo','expo-modules-autolinking','expo-modules-core','hermes-compiler']
versions=[{'name':name,'version':json.loads((SOURCE/'node_modules'/name/'package.json').read_text())['version'],'input':row(SOURCE/'node_modules'/name/'package.json')} for name in packages]
release_paths=['@react-native/gradle-plugin/gradle/libs.versions.toml','@react-native/gradle-plugin/react-native-gradle-plugin/src/main/kotlin/com/facebook/react/utils/JdkConfiguratorUtils.kt','@react-native/gradle-plugin/react-native-gradle-plugin/src/main/kotlin/com/facebook/react/utils/DependencyUtils.kt','@react-native/gradle-plugin/react-native-gradle-plugin/src/main/kotlin/com/facebook/react/utils/PropertyUtils.kt','react-native/gradle/libs.versions.toml','react-native/ReactAndroid/build.gradle.kts','react-native/ReactAndroid/gradle.properties','react-native/sdks/hermes-engine/version.properties','react-native/sdks/hermes-engine/hermes-engine.podspec','react-native/scripts/react_native_pods.rb','react-native/scripts/react-native-xcode.sh','expo-modules-autolinking/android/expo-gradle-plugin/expo-autolinking-settings-plugin/src/main/kotlin/expo/modules/plugin/ExpoAutolinkingSettingsExtension.kt','expo-modules-autolinking/android/expo-gradle-plugin/expo-autolinking-plugin/src/main/kotlin/expo/modules/plugin/ExpoRootProjectPlugin.kt','expo-modules-autolinking/android/expo-gradle-plugin/build.gradle.kts','expo-modules-core/android/build.gradle']
owners=[]
for name in release_paths:
 path=SOURCE/'node_modules'/name;identity=row(path);target=ROOT/'released-owners'/name;target.parent.mkdir(parents=True,exist_ok=True)
 with target.open('xb') as output:output.write(path.read_bytes())
 target.chmod(stat.S_IMODE(path.stat().st_mode))
 if sha(target)!=identity['sha256'] or (target.stat().st_dev,target.stat().st_ino)==(path.stat().st_dev,path.stat().st_ino):raise ValueError('Released-owner export differs or shares inode')
 owners.append({**identity,'export':str(target.relative_to(ROOT))})
current_constraints=json.loads((Q/'constraints-and-tools.json').read_text())
unchanged_released=[]
for old in current_constraints['actualSourceOwners']:
 if '/node_modules/' not in old['path']:continue
 observed=row(Path(old['path']))
 if observed['sha256']!=old['sha256']:raise ValueError('Actual released owner changed since source challenge: '+old['path'])
 unchanged_released.append(observed)
stage_paths={
 'publisherSignature':Q/'jdk17/verifier-route/reviewed-runtime/signature-qualification.json',
 'jdkFilesystem':Q/'jdk17/jdk-writer-result.json',
 'java17Runtime':Q/'jdk17/runtime-identity/java17-identity-result.json',
 'ndkFilesystem':Q/'ndk-writer-result.json',
 'sdkRegistration':Q/'sdk-registration-parser-followup/sdk-registration-result.json',
}
receipts=[row(path) for path in stage_paths.values()]
sdk=json.loads(stage_paths['sdkRegistration'].read_text())
known_sources=[REPAIR/'frozen-source-manifest.json',REPAIR/'apple-caller-contract.json',REPAIR/'prepare-apple-environment.py',REPAIR/'ledger-adoption-plan.json',REPAIR/'original-93cd-ledger.json',Q/'execution/sdk-registration-parser-followup-receipt/complete.json',Q/'execution/sdk-registration-parser-followup-receipt/release.json',Q/'execution/sdk-parser-outcome-durable-mirror.json',RECORDS/'native/corrected-toolchain-handoff.md',RECORDS/'native/android-compile-plan.md',RECORDS/'future/native/apple/current/IOS-ENVIRONMENT.md',RECORDS/'future/native/apple/current/RUBY-BOUNDARY-INDEPENDENT-REVIEW.md']
profile={'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only exact-source next-runtime plan/provenance freeze; no tools/archive acquisition, imports of candidate/Ruby/gem/Gradle code, install/compiler/native/device execution',
 'sourceTree':manifest['sourceTree'],'acceptedContext':'794448fbf76276b76a910c167b5c2e0c4e1ea538','currentAndOriginalSource70Preserved':True,'contextOwners':[row(SOURCE/name) for name in context_paths],
 'releasedPackages':versions,'releasedOwners':owners,'unchangedActualReleasedConstraintOwners':unchanged_released,'sourceAndReviewInputs':[row(path) for path in known_sources],'toolchainReceipts':receipts,
 'sdkInstalledGraph':{'result':row(stage_paths['sdkRegistration']),'rows':len(sdk['completeSdkGraphAfter']),'stableRowsSha256':hashlib.sha256(json.dumps(sdk['completeSdkGraphAfter'],sort_keys=True,separators=(',',':')).encode()).hexdigest(),'actualFiveRestored':sdk['actualFiveRestored'],'sourceSdkRoot':sdk['ownedSdkRootBeforeAndAfter'],'newSdkNdkParent':sdk['registeredParentBoundary']},
 'candidateSPMSourceBoundary':{'projectSource':row(SOURCE/'experiments/native-architecture/ios/HelloWorld.xcodeproj/project.pbxproj'),'hasRemoteSwiftPackageReferences':'XCRemoteSwiftPackageReference' in (SOURCE/'experiments/native-architecture/ios/HelloWorld.xcodeproj/project.pbxproj').read_text(),'candidateGemfilePresent':(SOURCE/'experiments/native-architecture/Gemfile').exists(),'candidatePodfileLockPresent':(SOURCE/'experiments/native-architecture/ios/Podfile.lock').exists(),'generatedWorkspacePresent':(SOURCE/'experiments/native-architecture/ios/HelloWorld.xcworkspace').exists(),'generatedGraphStillRequired':True},
 'primarySourceReferences':[{'url':'https://gradle.org/release-checksums/','scope':'Official9.3.1bin+wrapper hashes read via web; whole HTTP source not an authenticated artifact receipt'},{'url':'https://raw.githubusercontent.com/gradle/gradle/v9.3.1/platforms/core-runtime/wrapper-shared/src/main/java/org/gradle/wrapper/PathAssembler.java','scope':'Exact tag consumer source read; cache MD5/base36 mapping'},{'url':'https://raw.githubusercontent.com/gradle/gradle/v9.3.1/platforms/core-runtime/wrapper-shared/src/main/java/org/gradle/wrapper/Install.java','scope':'Exact tag checksum/extraction/cachedmarker source read; executable byte qualification still required'},{'url':'https://developer.android.com/build/releases/agp-8-12-0-release-notes','scope':'Minimum/default Gradle8.13/JDK17; no assertion that newer version fails'},{'url':'https://kotlinlang.org/docs/gradle-configure-project.html','scope':'KGP2.1.20 support-table uncertainty, not executed incompatibility'},{'url':'https://docs.gradle.org/current/userguide/dependency_verification.html','scope':'Current9.8conceptualreference only;9.3.1docs web retrieval failed, version-specific consumer must be qualified'}],
 'originalClaude':{'identity':'7c940639-09e2-4236-961f-1122171cb5d8','roundsUsed':2,'roundsRemaining':1,'reservedFor':'Executed revision/evidence/source acceptance; eventual actualPRkeyadoption'},'F1AcceptancePending':True,'sourceGrowthAllowed':False,'executionGranted':False,'plan':row(ROOT/'PLAN.md')}
save(ROOT/'input-profile.json',profile)
disposition={'recordedAt':profile['recordedAt'],'sourceTree':profile['sourceTree'],'executed':'Publisher artifact signature, JDK/NDK exact filesystem/control qualification, Java17runtime and SDK20fiveinstalledview qualified in separate leases','scopeLimits':'No RN compile/mount/draw/input/floor/performance/product claim','actualSDKPackages':sdk['actualFiveRestored'],'SDKlicensePathPresent':(Q/'sdk/licenses').exists() or (Q/'sdk/licenses').is_symlink(),'qualifiedSDKRuntimeJava':'21.0.11','candidateJava17':'17.0.20.1+1','actualOwners':{'sourceNDK':'501:20/0700','SDKandregisteredNDK':'501:0/0755'},'pending':['F1 independent acceptance/budget exception','Current accepted context composition and applicable full source/CI/independent acceptance','Gradle9.3.1actualarchive/runtime/wrapper identity','CMake/Ninja/NDK/Hermes effective utility/runtime identities','Provisional Maven/plugin graph and fresh strict verification','Disposable Release signing and optimized Android build/artifact proof','Owned Ruby/OpenSSL/libyaml/default gems and locked gem/pod graphs','Complete generated Apple project/environment/Release proof','Mount/staticoutput/input/modules/permissions and exactAPI24/iOS16.4floors'],'receipts':receipts,'allNativeSource70Preserved':True,'noNewRuntimeExecuted':True}
save(ROOT/'toolchain-disposition.json',disposition)
print(json.dumps({'sourceTree':profile['sourceTree'],'releasedOwnerExports':len(owners),'sdkRows':len(sdk['completeSdkGraphAfter']),'inputProfile':row(ROOT/'input-profile.json'),'toolchainDisposition':row(ROOT/'toolchain-disposition.json'),'executionGranted':False},indent=2))
