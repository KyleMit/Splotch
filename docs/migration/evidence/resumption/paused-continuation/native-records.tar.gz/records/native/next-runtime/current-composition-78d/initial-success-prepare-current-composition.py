from pathlib import Path
import datetime, difflib, hashlib, json, os, signal, stat, subprocess, time
ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/kylemit/.codex/worktrees/3218/Splotch')
PRIVATE = Path('/private/tmp/splotch-resume-01a111b0/native/source-repair/source')
RECORDS = PRIVATE.parent
BASE = '78d844ce36845e13690e2ca4ee7fcd645eb128d0'
PREVIOUS = '709fadd68ecb802aa2c9daa3fc197ce8d072b23c'
HISTORICAL = '794448fbf76276b76a910c167b5c2e0c4e1ea538'
SOURCE_TREE = '7da00012890a72e46eb5cdc390dab8c63f0035a3'
START = time.monotonic()
signal.signal(signal.SIGALRM, lambda *_: (_ for _ in ()).throw(TimeoutError('Finite source-only composition preparation whole120 exceeded')))
signal.setitimer(signal.ITIMER_REAL, 120)
commands = []
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def git(repo, *args):
    argv = ['/usr/bin/git', '-C', str(repo), *args]
    child = subprocess.run(argv, capture_output=True, timeout=30, check=False)
    commands.append({'argv': argv, 'exitCode': child.returncode, 'stdoutBytes': len(child.stdout), 'stdoutSha256': sha(child.stdout), 'stderr': child.stderr.decode()})
    assert child.returncode == 0 and not child.stderr, 'Read-only Git command failed: ' + str(argv)
    return child.stdout
def blob(repo, ref, path):
    return git(repo, 'show', ref + ':' + path)
def listing(repo, ref):
    rows = {}
    for raw in git(repo, 'ls-tree', '-r', '-z', ref).split(b'\0'):
        if raw:
            prefix, path = raw.split(b'\t', 1)
            mode, kind, identity = prefix.decode().split()
            rows[path.decode()] = {'gitMode': mode, 'gitType': kind, 'blob': identity}
    return rows
assert ROOT.resolve(strict=True) == ROOT
assert git(REPO, 'show', '--no-patch', '--format=%H%n%T%n%P', BASE).decode().strip().splitlines() == [BASE, 'ae69ebf1849dd6cfab317b4da7123e037fc0fb3a', PREVIOUS + ' 34dc4650bf43a9fb12e7378bf4d73b6bc68ebb70']
assert git(PRIVATE, 'cat-file', '-t', SOURCE_TREE).decode().strip() == 'tree'
before_status = git(REPO, 'status', '--porcelain=v1', '-z')
manifest_path = RECORDS / 'frozen-source-manifest.json'
assert sha(manifest_path.read_bytes()) == '7c356ed82573e4218bf9d29a93666a7ace831fe1584d5e2ffe0113e321074aa5'
manifest = json.loads(manifest_path.read_text())
assert manifest['sourceTree'] == SOURCE_TREE
prior_path = ROOT.parent / 'composition-709.json'
assert sha(prior_path.read_bytes()) == '6b56dddf94a86a48e0a32949dfb05f1f17a40e43de4e5dfa141e76bef7453fdd'
prior = json.loads(prior_path.read_text())
registration = [row['path'] for row in prior['registrationRows']]
base_rows = listing(REPO, BASE)
previous_rows = listing(REPO, PREVIOUS)
private_rows = listing(PRIVATE, SOURCE_TREE)
accepted = {}
registration_rows = []
transfers = []
for row in manifest['sourceRows']:
    path = PRIVATE / row['path']; info = path.lstat(); raw = path.read_bytes()
    observed = {'path': row['path'], 'bytes': len(raw), 'mode': oct(stat.S_IMODE(info.st_mode)), 'sha256': sha(raw)}
    assert observed == row and stat.S_ISREG(info.st_mode) and path.resolve(strict=True) == path
    assert blob(PRIVATE, SOURCE_TREE, row['path']) == raw, 'Private Git tree/current source bytes differ'
    if row['path'] not in registration or row['path'] == 'tools/migration/tests/native-registration.test.mjs':
        assert row['path'] not in base_rows, 'Transferred source unexpectedly already has an accepted owner'
        transfers.append({**row, 'source': str(path), **private_rows[row['path']], 'targetAbsentAtAcceptedBase': True})
assert len(transfers) == 61
for row in manifest['originalIntakePreservation']['sourceRows']:
    path = Path('/Users/kylemit/.codex/worktrees/migration-native-source/Splotch') / row['path']
    info = path.lstat(); raw = path.read_bytes()
    assert {'path': row['path'], 'bytes': len(raw), 'mode': oct(stat.S_IMODE(info.st_mode)), 'sha256': sha(raw)} == row and stat.S_ISREG(info.st_mode)
for path in registration:
    if path in base_rows:
        raw = blob(REPO, BASE, path); previous = blob(REPO, PREVIOUS, path)
        accepted[path] = raw
        old = next(row for row in prior['registrationRows'] if row['path'] == path)
        assert sha(previous) == old['acceptedSha256']
        registration_rows.append({'path': path, 'acceptedPresent': True, **base_rows[path], 'bytes': len(raw), 'acceptedSha256': sha(raw), 'previous709Sha256': sha(previous), 'changedSince709': raw != previous})
    else:
        assert path == 'tools/migration/tests/native-registration.test.mjs' and path not in previous_rows
        registration_rows.append({'path': path, 'acceptedPresent': False, 'changedSince709': False, 'action': 'Transfer exact repaired source from private7da tree'})
assert [row['path'] for row in registration_rows if row['changedSince709']] == ['package.json', 'tools/migration/README.md']
proposed = {}
path = 'package.json'
raw = accepted[path].decode()
private_package = json.loads((PRIVATE / path).read_text())
for key in ['check:migration:native-candidate', 'gen:migration:native-candidate']:
    assert key not in json.loads(raw)['scripts'] and key not in json.loads(raw)['scripts-info']
script_anchor = '    "check:migration:native-topology:evidence": "node tools/migration/check-native-topology-evidence.mjs",\n'
script_delta = ''.join('    ' + json.dumps(key) + ': ' + json.dumps(private_package['scripts'][key]) + ',\n' for key in ['check:migration:native-candidate', 'gen:migration:native-candidate'])
assert raw.count(script_anchor) == 1
raw = raw.replace(script_anchor, script_anchor + script_delta, 1)
info_anchor = '    "check:migration:native-topology:evidence": ' + json.dumps(private_package['scripts-info']['check:migration:native-topology:evidence']) + ',\n'
info_delta = ''.join('    ' + json.dumps(key) + ': ' + json.dumps(private_package['scripts-info'][key]) + ',\n' for key in ['check:migration:native-candidate', 'gen:migration:native-candidate'])
assert raw.count(info_anchor) == 1
raw = raw.replace(info_anchor, info_anchor + info_delta, 1)
original_package = json.loads(accepted[path]); composed_package = json.loads(raw)
for section in ['scripts', 'scripts-info']:
    assert {key:value for key,value in composed_package[section].items() if key not in ['check:migration:native-candidate','gen:migration:native-candidate']} == original_package[section]
assert {key:value for key,value in composed_package.items() if key not in ['scripts','scripts-info']} == {key:value for key,value in original_package.items() if key not in ['scripts','scripts-info']}
proposed[path] = raw.encode()
path = '.github/workflows/test.yml'
anchor = '      - name: Native candidate topology\n        run: npm run check:migration:native-topology\n\n'
assert accepted[path].decode().count(anchor) == 1
proposed[path] = accepted[path].decode().replace(anchor, anchor + '      - name: Maintained native candidate sources\n        run: npm run check:migration:native-candidate\n\n', 1).encode()
path = 'tools/ci-mirror/run-quality-checks.mjs'
anchor = "  'npm run check:migration:native-topology',\n"
assert accepted[path].decode().count(anchor) == 1
proposed[path] = accepted[path].decode().replace(anchor, anchor + "  'npm run check:migration:native-candidate',\n", 1).encode()
path = '.prettierignore'
original = accepted[path].decode()
assert original.count('\nandroid/\n') == 1 and original.count('\nios/\n') == 1
proposed[path] = ('android/\nios/\n!experiments/native-architecture/android/\n!experiments/native-architecture/android/**\n!experiments/native-architecture/ios/\n!experiments/native-architecture/ios/**\n' + original.replace('\nandroid/\nios/\n', '\n', 1)).encode()
assert proposed[path] == (PRIVATE / path).read_bytes()
path = 'tools/migration/README.md'
private_readme = (PRIVATE / path).read_text()
marker = '\n\n`check:migration:native-candidate`'
assert private_readme.count(marker) == 1
addition = marker + private_readme.split(marker, 1)[1]
anchor = '\n## Retained web host control\n'
assert accepted[path].decode().count(anchor) == 1
proposed[path] = accepted[path].decode().replace(anchor, addition + anchor, 1).encode()
contract_path = 'docs/migration/evidence/netlify-install/production-install-contract.json'
contract_raw = blob(REPO, BASE, contract_path)
contract = json.loads(contract_raw)
context_paths = ['pnpm-lock.yaml', 'pnpm-workspace.yaml', 'netlify.toml', 'tools/migration/gen-topology-proof-inputs.mjs', 'tools/migration/lib/production-install-contract.mjs', 'docs/migration/evidence/native-topology-05/candidate-exclusive-artifacts.json', 'tools/migration/lib/netlify-topology-report.mjs', 'tools/netlify-topology-witness.mjs', 'tools/migration/lib/native-identity.mjs', 'tools/migration/check-native-topology.mjs', 'tools/migration/gen-hosted-topology.mjs', 'tools/migration/check-hosted-topology.mjs'] + sorted(path for path in base_rows if path.startswith('experiments/native-architecture/'))
context = {}
for path in context_paths:
    raw = blob(REPO, BASE, path)
    context[path] = {'path': path, **base_rows[path], 'bytes':len(raw), 'sha256':sha(raw), 'changedSince709': base_rows.get(path) != previous_rows.get(path)}
for key,path in [('rootManifestSha256','package.json'),('lockSha256','pnpm-lock.yaml'),('candidateManifestSha256','experiments/native-architecture/package.json'),('workspaceSha256','pnpm-workspace.yaml'),('netlifyConfigSha256','netlify.toml')]:
    assert contract[key] == (sha(accepted[path]) if path in accepted else context[path]['sha256']), 'Accepted production contract source field differs'
assert composed_package['packageManager'] == contract['packageManager']
old_hash = contract['rootManifestSha256']; new_hash = sha(proposed['package.json'])
needle = '"rootManifestSha256": "' + old_hash + '"'
assert contract_raw.decode().count(needle) == 1
proposed[contract_path] = contract_raw.decode().replace(needle, '"rootManifestSha256": "' + new_hash + '"', 1).encode()
new_contract = json.loads(proposed[contract_path])
assert {key:value for key,value in new_contract.items() if key!='rootManifestSha256'} == {key:value for key,value in contract.items() if key!='rootManifestSha256'}
accepted[contract_path] = contract_raw
for group,data in [('accepted-owners',accepted),('proposed-owners',proposed)]:
    for path,raw in data.items():
        output = ROOT / group / path
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes(raw)
        assert output.read_bytes() == raw
patch = ''.join(''.join(difflib.unified_diff(accepted[path].decode().splitlines(keepends=True), raw.decode().splitlines(keepends=True), fromfile='a/'+path, tofile='b/'+path)) for path,raw in proposed.items())
(ROOT / 'registration-and-contract.diff').write_text(patch)
references = [manifest_path, prior_path, ROOT.parent/'composition-709.md', ROOT.parent/'PLAN.md', ROOT.parent/'input-profile.json', ROOT.parent/'toolchain-disposition.json', RECORDS/'followup-source/source-packet.tar.gz', RECORDS/'original-93cd-ledger.json', RECORDS/'ledger-adoption-plan.json', RECORDS/'review-round2/session.json', RECORDS/'review-round2/done.json', RECORDS/'review-round2/findings.json', RECORDS/'review-round2/actual-ledger-round2.json', Path('/private/tmp/splotch-resume-01a111b0/native/android-qualification/gradle931/wrapper-vendor-mode-identity/recorded-outcome-qualification.json')]
reference_rows=[]
for path in references:
    info=path.lstat(); raw=path.read_bytes()
    assert path.resolve(strict=True)==path and stat.S_ISREG(info.st_mode)
    reference_rows.append({'path':str(path),'bytes':len(raw),'mode':oct(stat.S_IMODE(info.st_mode)),'sha256':sha(raw),'device':info.st_dev,'inode':info.st_ino})
record = {'scope':'Read-only current-owner composition proposal; private owner copies/diff only, no candidate/repository/Git mutation/install/runtime/review execution', 'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exactAcceptedBase':BASE, 'acceptedTree':'ae69ebf1849dd6cfab317b4da7123e037fc0fb3a', 'acceptedParents':[PREVIOUS,'34dc4650bf43a9fb12e7378bf4d73b6bc68ebb70'], 'historicalPrivateContext':HISTORICAL, 'privateSourceTree':SOURCE_TREE, 'privateSourceIdentityType':'tree in preserved owned private Git object database; not a canonical commit', 'F1HeldSource':'e4e9fc044d46d49c3565379a3e6419e8eff4af9d', 'F1AcceptedOrIncluded':False, 'rival':{'originalConversation':'7c940639-09e2-4236-961f-1122171cb5d8','roundsUsed':2,'roundsRemaining':1,'newReviewStarted':False,'finalRoundGate':'Executed final-source/current-composition independent acceptance with actual PR-keyed adoption'}, 'registrationRows':registration_rows, 'exactSourceTransfers':transfers, 'nativeSourceTransferCount':60, 'newRegistrationTestTransferCount':1, 'changedAcceptedOwnerProposalRows':[{'path':path,'acceptedSha256':sha(accepted[path]),'proposedSha256':sha(raw),'proposedBytes':len(raw)} for path,raw in proposed.items()], 'proofContractProposal':{'path':contract_path,'onlyChangedField':'rootManifestSha256','before':old_hash,'after':new_hash,'releasedGeneratorExecuted':False,'otherFieldsAndAllArtifactArraysExact':True,'actualReleasedRegenerationRequiredBeforeAcceptance':True,'candidateExclusiveArtifactsOutputUnchangedBecauseLockExact':True}, 'contextRows':list(context.values()), 'preservedReferences':reference_rows, 'allOriginal70AndRepaired70Unchanged':True, 'previous709ProposalUnchanged':True, 'dependenciesLockEntryConfigSceneUnchanged':True, 'proposedDiffSha256':sha(patch.encode()), 'repositorySourceOrGitMutated':False, 'proposedGitTreeCreated':False, 'nextGate':'Parent exact78d composition disposition; F1 independent acceptance remains prerequisite to candidate source expansion/dependent acceptance; then explicitly owned fresh accepted-base source checkout, finite source transfers/owner deltas/released topology-input regeneration and new source/full-gate receipts before original final review and separately leased tool/plugin/configuration/optimized build/mount gates', 'elapsedSeconds':time.monotonic()-START}
assert git(REPO,'status','--porcelain=v1','-z') == before_status
(ROOT/'composition-profile.json').write_text(json.dumps(record,indent=2)+'\n')
(ROOT/'read-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
print(json.dumps({'acceptedBase':BASE,'sourceTransfers':len(transfers),'changedRegistrationOwnersSince709':[row['path'] for row in registration_rows if row['changedSince709']],'changedAcceptedOwnerProposals':len(proposed),'contractRootManifestBefore':old_hash,'contractRootManifestAfter':new_hash,'proposedDiffSha256':record['proposedDiffSha256'],'elapsedSeconds':record['elapsedSeconds'],'repositorySourceOrGitMutated':False},indent=2))
