import argparse
import datetime
import hashlib
import json
import os
import signal
import subprocess
import runpy
import sys
import threading
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
QUALIFICATION=ROOT.parent
STAGES={'java21-recorded-outcome':('qualify-recorded-partial.py','recorded-outcome-profile.json','producerSha256',60)}
RECORDER=ROOT/'record-python-children.py'
START=time.monotonic()
STARTED_AT=datetime.datetime.now(datetime.timezone.utc).isoformat()
IDENTITY=runpy.run_path(str(RECORDER),run_name='owned_identity_reader')['query_identity']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def trace(output):
    file=output/'children.jsonl'
    return [json.loads(line) for line in file.read_text().splitlines()] if file.exists() else []


def group_gone(group):
    try:
        os.killpg(group,0)
        return False
    except ProcessLookupError:
        return True


def stop_owned(child,output,producer_identity):
    events=trace(output)
    finished={value['pid'] for value in events if value['event'] in ['exit','identity-query-exit','spawn-exited-complete']}
    identities={value['pid']:value['osIdentity'] for value in events if value['event'] in ['spawn-identity','identity-query-exit']}
    active=[value for value in events if value['event'] in ['start','identity-query-start'] and value['pid'] not in finished]
    refusals=[];stopped=[]
    for value in active:
        expected=identities.get(value['pid'])
        current=IDENTITY(value['pid'],output)
        owner=value.get('producerPid',value.get('observerPid'))
        if expected is None or current is None or current!=expected or owner not in [child.pid,os.getpid()] or current['ppid']!=owner:
            refusals.append({'record':value,'expectedIdentity':expected,'currentIdentity':current})
            continue
        if current['pgid']!=child.pid:
            os.killpg(current['pgid'],signal.SIGKILL)
            stopped.append({'record':value,'matchingActualIdentity':current})
    if child.poll() is None:
        current=IDENTITY(child.pid,output)
        if producer_identity is None or current is None or current!=producer_identity or current['ppid']!=os.getpid():
            refusals.append({'producerPid':child.pid,'expectedIdentity':producer_identity,'currentIdentity':current})
        else:
            os.killpg(child.pid,signal.SIGKILL)
            child.wait(timeout=10)
    return {'stoppedOwnedChildren':stopped,'unresolvedIdentityRefusals':refusals}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('stage',choices=STAGES)
    args=parser.parse_args()
    source_name,profile_name,hash_key,deadline=STAGES[args.stage]
    output=ROOT/(args.stage+'-receipt')
    output.mkdir()
    state={'child':None,'producerIdentity':None}
    def whole_deadline():
        result={'stage':args.stage,'wholeDeadlineSeconds':deadline,'startedAt':STARTED_AT,'expiredAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsedSeconds':time.monotonic()-START,'accepted':False,'scope':'External whole-stage timeout includes hashing, preparation, OS queries, downloaded verifier commands and receipt finishing.'}
        try:
            if state['child'] is not None:
                result.update(stop_owned(state['child'],output,state['producerIdentity']))
        except BaseException as error:
            result['ownershipCleanupError']=str(error)
        finally:
            (output/'whole-deadline-expired.json').write_text(json.dumps(result,indent=2)+'\n')
            os._exit(124)
    watchdog=threading.Timer(max(0,deadline-(time.monotonic()-START)),whole_deadline)
    watchdog.daemon=True
    watchdog.start()
    producer=QUALIFICATION/source_name;profile_path=QUALIFICATION/profile_name
    profile=json.loads(profile_path.read_text())
    if sha(producer) != profile[hash_key]:
        raise ValueError('Exact parent-read trust producer/profile digest differs')
    inputs={'producer':{'path':str(producer),'sha256':sha(producer)},'profile':{'path':str(profile_path),'sha256':sha(profile_path)},'supervisor':{'path':str(Path(__file__).resolve()),'sha256':sha(__file__)},'recorder':{'path':str(RECORDER),'sha256':sha(RECORDER)},'python':{'path':str(Path(sys.executable).resolve()),'sha256':sha(sys.executable)}}
    argv=[sys.executable,'-B',str(RECORDER),str(producer),str(output)]
    remaining=deadline-(time.monotonic()-START)
    if remaining <= 0:
        raise ValueError('Whole trust deadline exhausted during preparation')
    with (output/'producer.stdout.txt').open('xb') as out,(output/'producer.stderr.txt').open('xb') as err:
        child=subprocess.Popen(argv,cwd=producer.parent,stdout=out,stderr=err,start_new_session=True)
        state['child']=child
        state['producerIdentity']=IDENTITY(child.pid,output)
        if state['producerIdentity'] is None and child.poll() is None:
            raise ValueError('Live owned producer lacks actual OS birth identity; halt setup')
        if state['producerIdentity'] is not None and (state['producerIdentity']['ppid']!=os.getpid() or state['producerIdentity']['pgid']!=child.pid):
            raise ValueError('Actual owned producer parent/group differs; no cleanup ownership')
        receipt={'stage':args.stage,'sourceInputs':inputs,'argv':argv,'cwd':str(producer.parent),'supervisorPid':os.getpid(),'supervisorPgid':os.getpgrp(),'startedAt':STARTED_AT,'deadlineSeconds':deadline,'producerPid':child.pid,'producerPgid':child.pid,'producerOSIdentity':state['producerIdentity'],'nativeOrJvmExecution':False,'instrumentationScope':'Finite existing producer subprocess observer; inputs, source code, tool bytes, arguments/environment and returned outputs remain unchanged'}
        (output/'running.json').write_text(json.dumps(receipt,indent=2)+'\n')
        try:
            status=child.wait(timeout=remaining)
            timed_out=False
        except subprocess.TimeoutExpired:
            stop_owned(child,output,state['producerIdentity'])
            status=child.returncode
            timed_out=True
    events=trace(output)
    starts=[value for value in events if value['event'] in ['start','identity-query-start']]
    exits={value['pid']:value['exitCode'] for value in events if value['event'] in ['exit','identity-query-exit','spawn-exited-complete']}
    identities={value['pid']:value.get('osIdentity') for value in events if value['event'] in ['spawn-identity','identity-query-exit']}
    rows=[dict(value,osIdentity=identities.get(value['pid']),exitCode=exits.get(value['pid']),groupGone=group_gone(identities[value['pid']]['pgid']) if identities.get(value['pid']) else value['pid'] in exits) for value in starts]
    receipt.update(exitCode=status,timedOut=timed_out,elapsedSeconds=time.monotonic()-START,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),producerGroupGone=group_gone(child.pid),children=rows,completeStartedChildExitRecords=all(value['pid'] in exits for value in starts),allOwnedGroupsGone=group_gone(child.pid) and all(value['groupGone'] for value in rows))
    for channel in ['stdout','stderr']:
        file=output/('producer.'+channel+'.txt');receipt[channel]={'path':file.name,'bytes':file.stat().st_size,'sha256':sha(file)}
    receipt['inputsUnchanged']=sha(producer)==inputs['producer']['sha256'] and sha(profile_path)==inputs['profile']['sha256'] and sha(RECORDER)==inputs['recorder']['sha256']
    (output/'complete.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'stage':args.stage,'exitCode':status,'timedOut':timed_out,'elapsedSeconds':receipt['elapsedSeconds'],'allOwnedGroupsGone':receipt['allOwnedGroupsGone'],'recordedChildCount':len(starts),'artifactRoot':str(output)}),flush=True)
    if status != 0 or timed_out or receipt['elapsedSeconds'] >= deadline or not receipt['allOwnedGroupsGone'] or not receipt['completeStartedChildExitRecords'] or not receipt['inputsUnchanged']:
        raise ValueError('Trust stage failed or receipt/release incomplete; halt dependent acceptance')
    watchdog.cancel()


if __name__=='__main__':
    main()
