import argparse
import hashlib
import json
import os
import stat
import subprocess
from datetime import datetime, timezone
from pathlib import Path

NODE = Path('/Users/kylemit/.nvm/versions/node/v24.16.0/bin/node')


def input_path_identity(paths):
    directories = set()
    for path in paths:
        directories.update(path.parents)
    result = []
    for path in sorted(directories | set(paths)):
        info = path.lstat()
        directory = path in directories
        if path.resolve(strict=True) != path or not (stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode)):
            raise ValueError('Apple preparation input path type/alias differs')
        if not directory and (info.st_uid != os.getuid() or info.st_nlink != 1):
            raise ValueError('Apple preparation input owner/inode differs')
        row = {'path':str(path),'device':info.st_dev,'inode':info.st_ino,'uid':info.st_uid,
               'gid':info.st_gid,'mode':oct(stat.S_IMODE(info.st_mode))}
        if not directory:
            row.update(bytes=info.st_size,mtimeNs=info.st_mtime_ns,ctimeNs=info.st_ctime_ns,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        result.append(row)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--copy', type=Path, required=True)
    parser.add_argument('--source-manifest', type=Path, required=True)
    args = parser.parse_args()
    copy = args.copy.resolve(strict=True)
    manifest = json.loads(args.source_manifest.read_text())
    if copy == Path('/private/tmp/splotch-resume-01a111b0/native/source-repair/source').resolve() or not copy.is_relative_to(Path('/private/tmp/splotch-resume-01a111b0/native')):
        raise ValueError('Apple environment requires an owned independent disposable source copy')
    if NODE.resolve() != NODE or hashlib.sha256(NODE.read_bytes()).hexdigest() != manifest['node24Sha256'] or not os.access(NODE,os.X_OK):
        raise ValueError('Reviewed absolute executable Node24 bytes differ')
    environment = dict(os.environ, PATH=str(NODE.parent) + ':' + os.environ.get('PATH', '/usr/bin:/bin'), NODE_BINARY=str(NODE))
    environment.pop('EX_UPDATES_NATIVE_DEBUG', None)
    node_command = ['/bin/sh', '-c', 'command -v node']
    selected = subprocess.run(node_command, env=environment, capture_output=True, timeout=10)
    if selected.returncode != 0 or selected.stdout.decode().strip() != str(NODE):
        raise ValueError('Pod generation PATH does not select the reviewed Node24')
    version_command = [str(NODE), '--version']
    version = subprocess.run(version_command, env=environment, capture_output=True, timeout=10)
    if version.returncode != 0 or version.stdout.decode().strip() != manifest['reviewedNodeVersion']:
        raise ValueError('Reviewed Node24 version differs')
    for row in manifest['sourceRows']:
        source = copy / row['path']
        if not source.resolve(strict=True).is_relative_to(copy):
            raise ValueError('Disposable source path escapes owned copy')
        info = source.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_nlink != 1 or stat.S_IMODE(info.st_mode) != int(row['mode'],8) or hashlib.sha256(source.read_bytes()).hexdigest() != row['sha256']:
            raise ValueError('Disposable source differs from frozen repaired input: ' + row['path'])
    ios = copy / 'experiments/native-architecture/ios'
    if ios.is_symlink() or not stat.S_ISDIR(ios.lstat().st_mode) or ios.lstat().st_uid != os.getuid():
        raise ValueError('Disposable Apple directory type/owner differs')
    updates = ios / '.xcode.env.updates'
    if updates.exists() or updates.is_symlink():
        raise ValueError('Disposable Apple updates environment is forbidden')
    input_paths = [NODE,args.source_manifest.resolve(),Path(__file__).resolve(),
                   *[copy / row['path'] for row in manifest['sourceRows']]]
    path_inputs_before = input_path_identity(input_paths)
    value = ('export NODE_BINARY=' + str(NODE) + '\n').encode()
    paths = [ios / name for name in ['.xcode.env','.xcode.env.local']]
    if any(path.exists() or path.is_symlink() for path in paths):
        raise ValueError('Both owned Apple environment files must be absent before preparation')
    for path in paths:
        fd = os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o644)
        with os.fdopen(fd,'wb') as stream:
            stream.write(value)
            os.fchmod(stream.fileno(),0o644)
    rows = []
    for path in paths:
        info = path.lstat()
        if info.st_nlink != 1 or info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) != 0o644 or path.read_bytes() != value:
            raise ValueError('Prepared Apple environment producer identity differs')
        rows.append({'path':str(path),'sha256':hashlib.sha256(value).hexdigest(),'mode':oct(stat.S_IMODE(info.st_mode)),'inode':info.st_ino})
    if path_inputs_before != input_path_identity(input_paths):
        raise ValueError('Apple preparation path/byte inputs changed')
    print(json.dumps({'pathInputsBeforeAndAfter':path_inputs_before,'parentRaceClaimLimit':'Trusted host and no concurrent same-UID input/parent mutation required. Final-component O_NOFOLLOW and complete before/after path/byte identities do not prevent adversarial parent swaps.','files':rows,'node':{'path':str(NODE),'sha256':manifest['node24Sha256'],'version':manifest['reviewedNodeVersion']},'podEnvironment':{'PATH':environment['PATH'],'NODE_BINARY':environment['NODE_BINARY'],'EX_UPDATES_NATIVE_DEBUG':'absent'},'nodeSelectionCommand':{'argv':node_command,'exitCode':selected.returncode,'stdout':selected.stdout.decode(),'stderr':selected.stderr.decode()},'nodeVersionCommand':{'argv':version_command,'exitCode':version.returncode,'stdout':version.stdout.decode(),'stderr':version.stderr.decode()},'generatedProjectBeforeSha256':hashlib.sha256((ios/'HelloWorld.xcodeproj/project.pbxproj').read_bytes()).hexdigest(),'requiredAfterGenerationAndRelease':['Exact prepared environment files, path, modes and Node executable bytes; no .xcode.env.updates','Actual bundle-phase NODE_BINARY equals this exact prepared path/digest','Complete generated project delta reviewed against released Pod owners; maintained bundle phase preserved'],'scope':'Owned Node environment preparation only; pod generation, generated project and Release consumers remain separate gates','recordedAt':datetime.now(timezone.utc).isoformat()}))


if __name__ == '__main__': main()
