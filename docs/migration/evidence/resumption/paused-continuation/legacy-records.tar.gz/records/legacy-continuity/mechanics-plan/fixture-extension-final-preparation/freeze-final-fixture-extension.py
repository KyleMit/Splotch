from pathlib import Path
import datetime,difflib,hashlib,json,os,subprocess

REPO=Path('/Users/kylemit/.codex/worktrees/migration-legacy-continuity/Splotch')
SOURCE=Path('/private/tmp/splotch-resume-01a111b0/legacy-continuity-source')
MECHANICS=SOURCE/'mechanics-plan'
OLD=MECHANICS/'fixture-extension-source-freeze'
OUT=MECHANICS/'fixture-extension-final-freeze'
FORMAT=MECHANICS/'fixture-extension-test-format'
CHANGED=['tools/migration/legacy-continuity/tests/debug-signing.test.mjs','tools/migration/legacy-continuity/tests/fixture-controls.test.mjs']
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO,timeout=15)
def identity(path):
 b=path.read_bytes();s=path.stat()
 return {'path':str(path),'realpath':str(path.resolve()),'bytes':len(b),'sha256':sha(b),'mode':oct(s.st_mode&0o777),'inode':[s.st_dev,s.st_ino]}
def write(name,value):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2)+'\n')
def ps(pid,group=False):
 args=['/bin/ps','-ww','-g'if group else'-p',str(pid),'-o','pid=','-o','ppid=','-o','pgid=','-o','lstart=','-o','args=']
 p=subprocess.run(args,capture_output=True,timeout=2)
 return {'argv':args,'exitCode':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()}

OUT.mkdir(exist_ok=False)
old_bytes=(OLD/'source-manifest.json.txt').read_bytes();assert sha(old_bytes)=='068e33649fe3f7ee9d043be1939b68858cc87e65715ed35ad5f5655a5b140963'
old=json.loads(old_bytes)
assert git('rev-parse','HEAD').decode().strip()==old['head']and git('rev-parse','MERGE_HEAD').decode().strip()==old['mergeHead']
assert git('write-tree').decode().strip()==old['stagedTree']
rows=[]
for expected in old['files']:
 path=expected['path'];actual=identity(REPO/path);actual['path']=path;rows.append(actual)
 if path not in CHANGED:assert all(actual[k]==expected[k]for k in ['bytes','sha256','mode']),path
 else:
  p=OUT/'source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((REPO/path).read_bytes());os.chmod(p,0o444)
git('add','--',*CHANGED)
tree=git('write-tree').decode().strip()
assert sorted(git('diff','--name-only',old['stagedTree'],tree).decode().splitlines())==sorted(CHANGED)
assert not git('diff','--binary')and not git('ls-files','--others','--exclude-standard','-z')
stage=git('ls-files','--stage','-z');status=git('status','--porcelain=v1','-z')
owned=git('diff','--cached','--binary','HEAD','--','tools/migration/legacy-continuity','package.json','knip.json','docs/migration/CAMPAIGN.md','docs/migration/evidence/legacy-continuity/README.md','docs/migration/evidence/netlify-install/production-install-contract.json')
delta=git('diff','--binary',old['stagedTree'],tree);(OUT/'two-test.delta.diff.txt').write_bytes(delta)
manifest={**old,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Final unexecuted bounded fixture source freeze before requested stopping point; only two test files changed since74-row freeze; existing real b3/78d pending merge preserved','stagedTree':tree,'semanticIndexSha256':sha(stage),'statusSha256':sha(status),'ownedDiffSha256':sha(owned),'files':rows,'totalBytes':sum(r['bytes']for r in rows),'parentSourceManifest':str(OLD/'source-manifest.json.txt'),'parentSourceManifestSha256':sha(old_bytes),'onlyChangesSinceAssertionFreeze':CHANGED,'unchangedSourceRecordRoot':str(OLD/'source'),'changedSourceRecordRoot':str(OUT/'source'),'selectedSourceRecordRule':'Changed two test files resolve at changedSourceRecordRoot; every other selected record resolves at unchangedSourceRecordRoot, byte/mode verified here. Current paths always resolve at REPO.'}
write('source-manifest.json.txt',manifest)
for name,b in [('semantic-index.bin.txt',stage),('status.bin.txt',status),('owned-source.diff.txt',owned)]: (OUT/name).write_bytes(b)
formatter=json.loads((FORMAT/'after.json.txt').read_bytes());calls=formatter['calls']
assert len(calls)==1and calls[0]['exitCode']==0and calls[0]['groupAbsent']and not calls[0].get('failure')and not calls[0].get('unresolvedOwnership')
for row in formatter['artifacts']:
 b=(FORMAT/row['path']).read_bytes();assert len(b)==row['bytes']and sha(b)==row['sha256']and row['complete']and row['streamCompletion']=='natural-eof'
pids=sorted(set([r['pid']for r in calls]+[r['targetPid']for r in calls]+[r['identity']['ppid']for r in calls]))
observations=[{'pid':p,'process':ps(p),'group':ps(p,True)}for p in pids]
assert all(r['process']['exitCode']==r['group']['exitCode']==1and not r['process']['stdout']and not r['group']['stdout']for r in observations)
write('format-release.json.txt',{'scope':'Only two changed test files formatted; no tests/native commands; old successfulformatting not repeated','actualExitCodes':[r['exitCode']for r in calls],'calls':calls,'completeChannels':formatter['artifacts'],'independentAbsence':observations})
challenge=(OLD/'test-source-challenge.json.txt').read_bytes()
write('source-challenge-disposition.json.txt',{'report':str(OLD/'test-source-challenge.json.txt'),'reportSha256':sha(challenge),'reviewScope':'Finite independent read-only source review; reviewer disclosed supplied rather than independently recomputed hashes; no runtime execution','findings':[
 {'id':'T1','kind':'concrete assertion false pass','repair':'Both refusal/plugin marker positions are asserted nonnegative before ordering; controlled omission must throw L0_TEST_REFUSAL_MARKER_MISSING; restored actual composition remains positive','source':'tests/debug-signing.test.mjs','execution':'pending'},
 {'id':'T2','kind':'scope clarification','disposition':'Unchanged raw reader Promise.all consumes later done rejection after request failure; it may call db.close and return rejection before delayed abort. Successful raw reads still await transaction completion; no terminal-abort-before-return/close guarantee is claimed for refused reads. Refused reads cannot retire the marker. No production change.'},
 {'id':'T3','kind':'truthful test wording','repair':'Titles distinguish actual seedHeld Blob helper and finite product-writer double; summaries retain finite IO/source-only limits','source':'tests/fixture-controls.test.mjs','execution':'pending'}],
 'productionSixCorrectionBytesUnchanged':True,'unchangedCurrentRows':len(rows)-2,'reviewRoundsUsed':2,'reviewRoundsRemaining':1,'nativeExecuted':False})
prior=SOURCE/'run-scoped-tools-fixture-extension.py';updated=prior.read_text()
updated=updated.replace("MANIFEST=SOURCE/'mechanics-plan/fixture-extension-source-freeze/source-manifest.json.txt'","MANIFEST=SOURCE/'mechanics-plan/fixture-extension-final-freeze/source-manifest.json.txt'")
updated=updated.replace(repr(sha(old_bytes)),repr(sha((OUT/'source-manifest.json.txt').read_bytes())))
producer=SOURCE/'run-scoped-tools-fixture-extension-final.py';producer.write_text(updated);os.chmod(producer,0o444)
(OUT/'run-scoped-tools-fixture-extension-final.py.txt').write_bytes(producer.read_bytes())
runner_delta=''.join(difflib.unified_diff(prior.read_text().splitlines(True),updated.splitlines(True),fromfile=prior.name,tofile=producer.name));(OUT/'supervisor.delta.diff.txt').write_text(runner_delta)
profile=json.loads((OLD/'scoped-profile.json.txt').read_bytes())
profile.update({'producer':str(producer),'producerSha256':sha(producer.read_bytes()),'derivedFrom':str(prior),'derivedFromSha256':sha(prior.read_bytes()),'supervisorDiffSha256':sha(runner_delta.encode()),'sourceManifest':str(OUT/'source-manifest.json.txt'),'sourceManifestSha256':sha((OUT/'source-manifest.json.txt').read_bytes()),'sourceBytes':manifest['totalBytes'],'stagedTree':tree,'semanticIndexSha256':sha(stage),'sourceChallengeDisposition':str(OUT/'source-challenge-disposition.json.txt'),'sourceChallengeDispositionSha256':sha((OUT/'source-challenge-disposition.json.txt').read_bytes()),'stoppingInstruction':'Only bounded scoped suite/check/lint if explicitly leased, halt onfailure; then preserve pausedfrontier. No full/native/Gitcommit/push/merge/rival.'})
write('scoped-profile.json.txt',profile)
print(json.dumps({'output':str(OUT),'sourceRows':len(rows),'sourceBytes':manifest['totalBytes'],'manifestSha256':sha((OUT/'source-manifest.json.txt').read_bytes()),'stagedTree':tree,'semanticIndexSha256':sha(stage),'twoTestDiffSha256':sha(delta),'twoTestDiffBytes':len(delta),'producer':str(producer),'producerSha256':profile['producerSha256'],'profileSha256':sha((OUT/'scoped-profile.json.txt').read_bytes()),'supervisorDeltaBytes':len(runner_delta.encode()),'supervisorDeltaSha256':sha(runner_delta.encode()),'testsExecuted':False,'nativeExecuted':False}))
