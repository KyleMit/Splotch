from pathlib import Path
import hashlib,json,os

SOURCE=Path('/private/tmp/splotch-resume-01a111b0/legacy-continuity-source/mechanics-plan')
DURABLE=Path('/Users/kylemit/Code/Splotch/logs/migration-resumption-01a111b0/legacy-continuity/mechanics-plan/fixture-extension-preparation')
sha=lambda b:hashlib.sha256(b).hexdigest()
files=sorted([p for directory in ['fixture-extension-source-freeze','fixture-extension-format']for p in (SOURCE/directory).rglob('*')if p.is_file()and p.name!='test-source-challenge.json.txt']+[SOURCE/name for name in ['format-fixture-extension.mjs','freeze-fixture-extension.py','prepare-fixture-extension-supervisor.py','mirror-fixture-extension-preparation.py']])
assert sha((SOURCE/'fixture-extension-source-freeze/source-manifest.json.txt').read_bytes())=='068e33649fe3f7ee9d043be1939b68858cc87e65715ed35ad5f5655a5b140963'
assert not DURABLE.exists()
DURABLE.mkdir(parents=True)
rows=[]
for p in files:
 assert p.is_file()and not p.is_symlink(),str(p)
 rel=p.relative_to(SOURCE);assert '..'not in rel.parts and not rel.is_absolute()
 b=p.read_bytes();target=DURABLE/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 os.chmod(p,0o444);os.chmod(target,0o444)
 a=p.stat();d=target.stat();assert(a.st_dev,a.st_ino)!=(d.st_dev,d.st_ino)
 assert target.read_bytes()==b and sha(p.read_bytes())==sha(b)
 rows.append({'path':str(rel),'bytes':len(b),'sha256':sha(b),'mode':'0444','sourceInode':[a.st_dev,a.st_ino],'durableInode':[d.st_dev,d.st_ino]})
manifest={'scope':'Complete finite source-only fixture extension preparation and actual formatting/release receipts; no tests/native/commit/merge/rival execution','sourceRoot':str(SOURCE),'durableRoot':str(DURABLE),'relativePathConvention':'Every member path resolves from sourceRoot or durableRoot respectively, including source-freeze and format sibling directories','members':rows,'count':len(rows),'totalBytes':sum(r['bytes']for r in rows),'producer':str(Path(__file__)),'producerSha256':sha(Path(__file__).read_bytes()),'testSourceChallengePending':True}
text=json.dumps(manifest,indent=2)+'\n'
for p in [SOURCE/'fixture-extension-source-freeze/mirror-manifest.json.txt',DURABLE/'mirror-manifest.json.txt']:
 p.write_text(text);os.chmod(p,0o444)
print(json.dumps({'durableRoot':str(DURABLE),'members':len(rows),'bytes':manifest['totalBytes'],'manifestSha256':sha(text.encode()),'sourceManifestSha256':'068e33649fe3f7ee9d043be1939b68858cc87e65715ed35ad5f5655a5b140963','allBytesModesIndependentInodesVerified':True,'testSourceChallengePending':True}))
