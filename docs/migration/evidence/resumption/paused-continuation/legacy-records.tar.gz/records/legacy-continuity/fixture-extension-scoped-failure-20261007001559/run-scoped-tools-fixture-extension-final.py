from pathlib import Path
import subprocess,json,hashlib,datetime,time,os,signal,re,sys

REPO=Path('/Users/kylemit/.codex/worktrees/migration-legacy-continuity/Splotch')
SOURCE=Path('/private/tmp/splotch-resume-01a111b0/legacy-continuity-source')
MANIFEST=SOURCE/'mechanics-plan/fixture-extension-final-freeze/source-manifest.json.txt'
REUSE_PROFILE=SOURCE/'accepted-composition-78d/install-reuse/qualification.json.txt'
REUSE_PROFILE_SHA='b9ad160661fa428d4539ccbdf127790c967e2b6287108ef879b2c324475afeb6'
NODE=Path('/Users/kylemit/.nvm/versions/node/v24.16.0/bin/node')
PNPM=Path('/Users/kylemit/.nvm/versions/node/v24.16.0/lib/node_modules/corepack/dist/pnpm.js')
NPM=Path('/Users/kylemit/.nvm/versions/node/v24.16.0/lib/node_modules/npm/bin/npm-cli.js')
WHOLE_DEADLINE_SECONDS=600
TEARDOWN_SECONDS=2
IDENTITY_SECONDS=2
GIT_QUERY_SECONDS=15
FINALIZATION_RESERVE_SECONDS=60
POLL_SECONDS=.1
ART=SOURCE/('tools-fixture-extension-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S'))
PREVIOUS=SOURCE/'tools-gates-20261006200650'
PREVIOUS_RECEIPT_SHA='bf6bf2ccc51b4b1435ae0d56061d274d6adf8274e713cc82106420fd1b77a765'

ENV={**os.environ,'PATH':str(NODE.parent)+':'+os.environ['PATH'],'LC_ALL':'C'}
rows=[]
whole_start=time.monotonic()

def whole_remaining():
 remaining=WHOLE_DEADLINE_SECONDS-(time.monotonic()-whole_start)
 if remaining<=0:raise TimeoutError('L0_WHOLE_TOOLS_DEADLINE')
 return remaining

def whole_alarm(signum,frame):raise TimeoutError('L0_WHOLE_TOOLS_DEADLINE')
signal.signal(signal.SIGALRM,whole_alarm)
signal.setitimer(signal.ITIMER_REAL,WHOLE_DEADLINE_SECONDS)

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(data):
 whole_remaining();value=hashlib.sha256(data).hexdigest();whole_remaining();return value
def write(name,value):
 whole_remaining();(ART/name).write_text(json.dumps(value,indent=2)+'\n');whole_remaining()
def file_identity(path):
 whole_remaining();b=path.read_bytes();st=path.stat();whole_remaining()
 return {'path':str(path),'realpath':str(path.resolve()),'bytes':len(b),'sha256':sha(b),'mode':oct(st.st_mode&0o777),'inode':[st.st_dev,st.st_ino]}
def observe(pid):
 try:
  p=subprocess.run(['/bin/ps','-ww','-p',str(pid),'-o','pid=','-o','ppid=','-o','pgid=','-o','lstart=','-o','args='],capture_output=True,timeout=IDENTITY_SECONDS,env=ENV)
  raw=p.stdout.decode();m=re.fullmatch(r'\s*(\d+)\s+(\d+)\s+(\d+)\s+(\w{3}\s+\w{3}\s+\d+\s+\d{2}:\d{2}:\d{2}\s+\d{4})\s+([\s\S]+?)\s*',raw)
  value={'exitCode':p.returncode,'stdout':raw,'stderr':p.stderr.decode()}
  if not m or p.returncode: return {'status':'unavailable',**value}
  return {'status':'observed','pid':int(m[1]),'ppid':int(m[2]),'pgid':int(m[3]),'birth':m[4],'argv':m[5],**value}
 except Exception as e:return {'status':'unavailable','error':str(e)}
def exists(pid):
 try:os.killpg(pid,0);return True
 except ProcessLookupError:return False

def signal_owned(row,sig):
 live=observe(row['pid']);row.setdefault('signalChecks',[]).append({'at':now(),'live':live,'signal':signal.Signals(sig).name})
 initial=row['identity']
 assert live['status']=='observed' and initial['status']=='observed', 'L0_TOOL_LEADER_UNAVAILABLE_NO_SIGNAL'
 assert all(live[k]==initial[k] for k in ['pid','ppid','pgid','birth','argv']) and live['ppid']==os.getpid() and live['pgid']==row['pid'], 'L0_TOOL_OWNERSHIP_CHANGED_NO_SIGNAL'
 os.killpg(row['pid'],sig)

def release(row):
 if not exists(row['pid']):return
 signal_owned(row,signal.SIGTERM)
 deadline=time.monotonic()+TEARDOWN_SECONDS
 while exists(row['pid']) and time.monotonic()<deadline:time.sleep(POLL_SECONDS)
 if exists(row['pid']):signal_owned(row,signal.SIGKILL)
 deadline=time.monotonic()+TEARDOWN_SECONDS
 while exists(row['pid']) and time.monotonic()<deadline:time.sleep(POLL_SECONDS)
 assert not exists(row['pid']),'L0_TOOL_GROUP_REMAINS'

def run(label,argv,call_seconds=60,expected=0,reason=None):
 remaining=whole_remaining()-FINALIZATION_RESERVE_SECONDS
 assert remaining>0,'L0_WHOLE_TOOLS_DEADLINE'
 timeout=min(call_seconds,remaining)
 call_deadline=time.monotonic()+timeout
 row={'label':label,'argv':argv,'cwd':str(REPO),'startedAt':now(),'perCallDeadlineSeconds':call_seconds,'effectiveDeadlineSeconds':timeout,'expectedExit':expected,'expectedReason':reason}
 rows.append(row)
 with (ART/(label+'.stdout.raw.txt')).open('wb') as out,(ART/(label+'.stderr.raw.txt')).open('wb') as err:
  p=subprocess.Popen(argv,cwd=REPO,env=ENV,stdout=out,stderr=err,start_new_session=True)
  row['pid']=p.pid;row['identity']=observe(p.pid)
  write('commands.json.txt',rows)
  try:
   assert row['identity']['status']=='observed' and row['identity']['ppid']==os.getpid() and row['identity']['pgid']==p.pid, 'L0_TOOL_SPAWN_IDENTITY_UNQUALIFIED'
   remaining_call=call_deadline-time.monotonic()
   assert remaining_call>0,'L0_PER_CALL_TOOLS_DEADLINE'
   row['exitCode']=p.wait(timeout=remaining_call)
  except Exception as e:row['failure']=str(e);raise
  finally:
   try:release(row)
   except Exception as e:row['unresolvedOwnership']=str(e);raise
   finally:
    row['groupAbsent']=not exists(p.pid);row['endedAt']=now();write('commands.json.txt',rows)
 stdout=(ART/(label+'.stdout.raw.txt')).read_bytes();stderr=(ART/(label+'.stderr.raw.txt')).read_bytes()
 row['stdout']={'bytes':len(stdout),'sha256':sha(stdout)};row['stderr']={'bytes':len(stderr),'sha256':sha(stderr)}
 write('commands.json.txt',rows)
 assert row['exitCode']==expected,(label,'L0_UNEXPECTED_EXIT',row['exitCode'])
 if reason:assert reason.encode() in stderr,(label,'L0_WRONG_FAILURE_REASON')
 print(json.dumps({'label':label,'exitCode':row['exitCode'],'groupAbsent':row['groupAbsent'],'stdoutBytes':len(stdout),'stderrBytes':len(stderr)}),flush=True)
 return stdout

def git_bytes(*args):
 whole_remaining();value=subprocess.check_output(['git',*args],cwd=REPO,timeout=min(GIT_QUERY_SECONDS,whole_remaining()));whole_remaining();return value

def source_snapshot(label):
 manifest=json.loads(MANIFEST.read_bytes())
 assert sha(MANIFEST.read_bytes())=='0b0d18a33c2d4e7bc792e3de517ba9e65f8952cfec4f7463f4de3597839a7808','L0_SOURCE_MANIFEST_CHANGED'
 current=[file_identity(REPO/r['path']) for r in manifest['files']]
 for expected,actual in zip(manifest['files'],current):
  assert expected['sha256']==actual['sha256'] and expected['bytes']==actual['bytes'] and expected['mode']==actual['mode'],('L0_SOURCE_INPUT_CHANGED',expected['path'])
 index=Path(git_bytes('rev-parse','--git-path','index').decode().strip())
 if not index.is_absolute():index=REPO/index
 head=git_bytes('rev-parse','HEAD').decode().strip();merge=git_bytes('rev-parse','MERGE_HEAD').decode().strip()
 stash=git_bytes('rev-parse','--verify',manifest['stashRetained']+'^{commit}').decode().strip()
 stash_tree=git_bytes('rev-parse','--verify',stash+'^{tree}').decode().strip();assert stash_tree=='ad948198f89b3cff5b39b27b62e8d02deef60c68','L0_OWNED_RECOVERY_STASH_TREE_CHANGED'
 stash_tip=git_bytes('rev-parse','refs/stash').decode().strip();stash_list=git_bytes('stash','list','--format=%H');stash_commit=git_bytes('cat-file','commit',stash)
 assert stash==manifest['stashRetained'] and stash in stash_list.decode().splitlines(),'L0_OWNED_RECOVERY_STASH_NOT_RETAINED'
 assert sha(stash_commit)=='d1d705f3bea3713549f4eecc6d32e7cbdf50aa6e8c7ea48b0b9ae5d2247468d7' and hashlib.sha1(b'commit '+str(len(stash_commit)).encode()+b'\0'+stash_commit).hexdigest()==stash,'L0_OWNED_RECOVERY_STASH_OBJECT_CHANGED'
 for name,value in [('stash-ref-tip.txt',(stash_tip+'\n').encode()),('stash-list.txt',stash_list),('owned-stash.commit.txt',stash_commit)]:
  (ART/(label+'.'+name)).write_bytes(value);whole_remaining()
 staged=git_bytes('ls-files','--stage','-z');tree=git_bytes('write-tree').decode().strip()
 unstaged=git_bytes('diff','--binary');untracked=git_bytes('ls-files','--others','--exclude-standard','-z');status=git_bytes('status','--porcelain=v1','-z')
 owned=git_bytes('diff','--cached','--binary','HEAD','--','tools/migration/legacy-continuity','package.json','knip.json','docs/migration/CAMPAIGN.md','docs/migration/evidence/legacy-continuity/README.md','docs/migration/evidence/netlify-install/production-install-contract.json')
 for name,value in [('stage.bin.txt',staged),('unstaged.diff.txt',unstaged),('untracked.bin.txt',untracked),('status.bin.txt',status),('owned-source.diff.txt',owned)]:
  (ART/(label+'.'+name)).write_bytes(value);whole_remaining()
 assert not unstaged and not untracked,'L0_SOURCE_NOT_FULLY_STAGED'
 assert head==manifest['head'] and merge==manifest['mergeHead'] and stash==manifest['stashRetained'] and tree==manifest['stagedTree'] and sha(staged)==manifest['semanticIndexSha256'] and sha(status)==manifest['statusSha256'] and sha(owned)==manifest['ownedDiffSha256'],'L0_CURRENT_SOURCE_FREEZE_CHANGED'
 return {'base':head,'mergeHead':merge,'stashRetained':stash,'ownedStashCommitSha256':sha(stash_commit),'ownedStashTree':stash_tree,'sharedStashRefDiagnostic':{'tip':stash_tip,'listSha256':sha(stash_list),'ownedMember':True},'manifest':file_identity(MANIFEST),'selected':current,'rawIndex':file_identity(index),'semanticIndexSha256':sha(staged),'stagedTree':tree,'unstagedSha256':sha(unstaged),'untrackedSha256':sha(untracked),'ownedDiffSha256':sha(owned),'statusSha256':sha(status),'runtime':[file_identity(p) for p in [NODE,PNPM,NPM,Path('/bin/ps')]],'scope':'Current exact staged/composed source; raw index diagnostic, semantic stage/tree and working bytes govern acceptance'}

def qualify_install_reuse(snapshot):
 profile_bytes=REUSE_PROFILE.read_bytes();assert sha(profile_bytes)==REUSE_PROFILE_SHA,'L0_REUSE_PROFILE_CHANGED';profile=json.loads(profile_bytes)
 receipt_bytes=(PREVIOUS/'receipt.json.txt').read_bytes();assert sha(receipt_bytes)==PREVIOUS_RECEIPT_SHA,'L0_PREVIOUS_INSTALL_RECEIPT_CHANGED';receipt=json.loads(receipt_bytes)
 assert receipt['sourceAndIndexUnchanged'] and receipt['ownedCommandGroupsAbsent'] and receipt['before']['base']==receipt['after']['base']==profile['priorExecutedBase'],'L0_PREVIOUS_INSTALL_SCOPE_CHANGED'
 assert snapshot['base']==profile['currentHead'] and snapshot['mergeHead']==profile['currentMergeHead'],'L0_CURRENT_REUSE_COMPOSITION_CHANGED'
 for label in ['frozen-ignored-install','complete-installed-graph']:
  call=next(row for row in receipt['commands']if row['label']==label);assert call['exitCode']==0 and call['groupAbsent']and not call.get('unresolvedOwnership'),'L0_PREVIOUS_INSTALL_EXECUTION_UNQUALIFIED'
 prior_package=(REUSE_PROFILE.parent/'prior-install-package.json.txt').read_bytes();current_package=(REPO/'package.json').read_bytes()
 assert sha(prior_package)==profile['oldPackageSha256'] and sha(current_package)==profile['currentPackageSha256'],'L0_ROOT_MANIFEST_IDENTITY_CHANGED'
 prior=json.loads(prior_package);current=json.loads(current_package)
 assert {k:v for k,v in prior.items()if k not in ['scripts','scripts-info']}=={k:v for k,v in current.items()if k not in ['scripts','scripts-info']},'L0_INSTALL_DECLARATIONS_CHANGED'
 deltas={section:{key:{'prior':prior[section].get(key),'current':current[section].get(key)}for key in sorted(set(prior[section])|set(current[section]))if prior[section].get(key)!=current[section].get(key)}for section in ['scripts','scripts-info']}
 assert deltas==profile['scriptDeltas'],'L0_SCRIPT_METADATA_COMPOSITION_CHANGED'
 metadata=[]
 for rows in [profile['runtime'],profile['locksAndWorkspace'],profile['installedMetadata'],profile['installedLockAndLinker']]:
  for expected in rows:
   actual=file_identity(Path(expected['path']));assert all(actual[k]==expected[k]for k in ['path','realpath','bytes','sha256','mode','inode']),'L0_CURRENT_INSTALL_METADATA_CHANGED'
   if 'name'in expected:
    package=json.loads(Path(expected['path']).read_bytes());assert package['name']==expected['name']and package['version']==expected['version'],'L0_CURRENT_INSTALLED_LABEL_CHANGED'
   metadata.append(actual)
 assert snapshot['runtime']==profile['runtime'],'L0_REUSE_RUNTIME_CHANGED'
 graph=(PREVIOUS/'complete-installed-graph.stdout.raw.txt').read_bytes();graph_call=next(row for row in receipt['commands']if row['label']=='complete-installed-graph')
 assert len(graph)==profile['completePriorGraphBytes']==graph_call['stdout']['bytes'] and sha(graph)==profile['completePriorGraphSha256']==graph_call['stdout']['sha256'],'L0_COMPLETE_PRIOR_GRAPH_CHANGED'
 return {'priorArtifactRoot':str(PREVIOUS),'priorExecutedBase':profile['priorExecutedBase'],'profile':file_identity(REUSE_PROFILE),'completePriorGraphBytes':len(graph),'completePriorGraphSha256':sha(graph),'currentRootManifestSha256':sha(current_package),'scriptDeltas':deltas,'currentMetadata':metadata,'limits':profile['limits'],'scope':'Limited historical709 JS graph reuse after unchanged non-script declarations/locks/workspace/runtime/recorded installed metadata; no install/list/catalog, exhaustive package-source bytes or native SDK association'}

ART.mkdir(exist_ok=False)
write('lease.started.json.txt',{'owner':'L0','scope':'Limited historical709 graph reuse, changed actual fixture/source unit controls then check/lint on real pending b3+78d; no install/list/catalog/full/build/native/device/browser/performance/rival, no commit/merge','startedAt':now(),'wholeDeadlineSeconds':WHOLE_DEADLINE_SECONDS,'finalizationReserveSeconds':FINALIZATION_RESERVE_SECONDS,'gitQueryDeadlineSeconds':GIT_QUERY_SECONDS,'teardownPerSignalSeconds':TEARDOWN_SECONDS,'supervisor':observe(os.getpid()),'sourceManifest':file_identity(MANIFEST),'producer':file_identity(Path(__file__))})
print(json.dumps({'artifactRoot':str(ART),'leaseSeconds':WHOLE_DEADLINE_SECONDS}),flush=True)
failure=None;before=None;after=None;reuse_before=None;reuse_after=None
try:
 before=source_snapshot('before');write('before.json.txt',before)
 assert before['base']=='b3b16831557dd894186574b9ce3b0c1184b2aab7'and before['mergeHead']=='78d844ce36845e13690e2ca4ee7fcd645eb128d0','L0_IMPLEMENTATION_COMPOSITION_CHANGED'
 reuse_before=qualify_install_reuse(before);write('install-reuse.before.json.txt',reuse_before)
 run('scoped-guards',[str(NODE),str(NPM),'run','test:tools','--','migration/legacy-continuity/tests/'],120)
 run('check',[str(NODE),str(NPM),'run','check'],180)
 run('lint',[str(NODE),str(NPM),'run','lint'],120)

except Exception as e:
 failure=str(e);print(json.dumps({'failure':failure}),flush=True)
finally:
 try:
  after=source_snapshot('after');write('after.json.txt',after)
  if before:
   assert all(before[k]==after[k]for k in ['base','mergeHead','stashRetained','ownedStashCommitSha256','ownedStashTree','semanticIndexSha256','stagedTree','unstagedSha256','untrackedSha256','ownedDiffSha256','statusSha256']),'L0_SOURCE_SEMANTIC_INDEX_CHANGED'
   assert [(r['path'],r['sha256']) for r in before['runtime']]==[(r['path'],r['sha256']) for r in after['runtime']],'L0_RUNTIME_CHANGED'
  reuse_after=qualify_install_reuse(after);write('install-reuse.after.json.txt',reuse_after)
  if reuse_before:assert reuse_before==reuse_after,'L0_INSTALL_REUSE_INPUTS_CHANGED'
 except Exception as e:failure=(failure+'; ' if failure else '')+str(e)
 unresolved=[r for r in rows if not r.get('groupAbsent')]
 receipt={'completedAt':now(),'elapsedSeconds':time.monotonic()-whole_start,'scope':'Current approved fixture/source unit controls plus check/lint on real pending b3+78d with limited prior709 JS graph reuse; no intermediate full gates, commit, cf0 composition or native continuity/installed SDK/profile/channel acceptance','failure':failure,'unresolvedOwnership':unresolved,'commands':rows,'before':before,'after':after,'installReuseBefore':reuse_before,'installReuseAfter':reuse_after,'sourceAndSemanticIndexUnchanged':bool(before and after and all(before[k]==after[k]for k in ['base','mergeHead','stashRetained','ownedStashCommitSha256','ownedStashTree','semanticIndexSha256','stagedTree','unstagedSha256','untrackedSha256','ownedDiffSha256','statusSha256'])),'rawIndexBytesEqualDiagnostic':bool(before and after and before['rawIndex']['sha256']==after['rawIndex']['sha256']),'ownedCommandGroupsAbsent':not unresolved}
 try:
  write('receipt.json.txt',receipt)
  write('manifest.json.txt',{'files':[{**file_identity(p),'path':str(p.relative_to(ART))} for p in sorted(ART.rglob('*')) if p.is_file()]})
  receipt_sha=sha((ART/'receipt.json.txt').read_bytes());final_elapsed=time.monotonic()-whole_start
  assert final_elapsed<WHOLE_DEADLINE_SECONDS,'L0_FINALIZATION_EXCEEDED_WHOLE_DEADLINE'
  whole_remaining();signal.setitimer(signal.ITIMER_REAL,0)
  print(json.dumps({'artifactRoot':str(ART),'failure':failure,'unresolvedCount':len(unresolved),'receiptSha256':receipt_sha,'finalElapsedSeconds':final_elapsed,'wholeDeadlineSatisfied':True}),flush=True)
 except Exception as e:
  signal.setitimer(signal.ITIMER_REAL,0)
  failure=(failure+'; ' if failure else '')+str(e)
  emergency={'at':now(),'failure':failure,'elapsedSeconds':time.monotonic()-whole_start,'scope':'expiry/finalization failure only; no complete gate acceptance','commands':rows,'unresolvedOwnership':unresolved}
  (ART/'expiry-or-finalization-failure.json.txt').write_text(json.dumps(emergency,indent=2)+'\n')
  print(json.dumps({'artifactRoot':str(ART),'failure':failure,'wholeDeadlineSatisfied':False,'unresolvedCount':len(unresolved)}),flush=True)
if failure:sys.exit(1)

