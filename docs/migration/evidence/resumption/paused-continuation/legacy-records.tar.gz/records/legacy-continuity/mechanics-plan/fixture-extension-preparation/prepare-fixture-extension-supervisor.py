from pathlib import Path
import difflib,hashlib,json,os

SOURCE=Path('/private/tmp/splotch-resume-01a111b0/legacy-continuity-source')
OUT=SOURCE/'mechanics-plan/fixture-extension-source-freeze'
prior=SOURCE/'run-scoped-tools-r2-repairs-owned-stash.py'
producer=SOURCE/'run-scoped-tools-fixture-extension.py'
manifest=OUT/'source-manifest.json.txt'
sha=lambda b:hashlib.sha256(b).hexdigest()
original=prior.read_text();updated=original
changes=[
 ("MANIFEST=SOURCE/'source-repairs-round2/current-scoped-freeze/source-manifest.json.txt'", "MANIFEST=SOURCE/'mechanics-plan/fixture-extension-source-freeze/source-manifest.json.txt'"),
 ("ART=SOURCE/('tools-r2-repairs-'+", "ART=SOURCE/('tools-fixture-extension-'+"),
 ("'050acb8b70cdf6dcc28723124994ed982bf42e762e60cdb824b58f296af247b2'",repr(sha(manifest.read_bytes()))),
 ("Limited historical709 graph reuse, changed31 scoped controls/check/lint/current topology-input checker/three actual source roles/unknown-flag refusal/restoration; no install/list/catalog/full/build/native/device/browser/performance/rival", "Limited historical709 graph reuse, changed actual fixture/source unit controls then check/lint on real pending b3+78d; no install/list/catalog/full/build/native/device/browser/performance/rival, no commit/merge"),
 ("Current composed31 scoped controls/checklint/exact topology-input checker/role/flag gates with limited prior709 JS graph reuse; native continuity/installed SDK/profile/channel acceptance remains open", "Current approved fixture/source unit controls plus check/lint on real pending b3+78d with limited prior709 JS graph reuse; no intermediate full gates, commit, cf0 composition or native continuity/installed SDK/profile/channel acceptance"),
]
for a,b in changes:
 assert updated.count(a)==1,(a,updated.count(a));updated=updated.replace(a,b)
start=" run('current-topology-inputs',"
begin=updated.index(start);end=updated.index('\nexcept Exception as e:',begin)
removed=updated[begin:end]
assert "run('restored-flags'"in removed and "for role in ['released','held','reader']"in removed
updated=updated[:begin]+updated[end:]
producer.write_text(updated);os.chmod(producer,0o444)
(OUT/'run-scoped-tools-fixture-extension.py.txt').write_bytes(producer.read_bytes())
delta=''.join(difflib.unified_diff(original.splitlines(True),updated.splitlines(True),fromfile=prior.name,tofile=producer.name))
(OUT/'supervisor.delta.diff.txt').write_text(delta)
m=json.loads(manifest.read_text())
commands=[
 {'label':'scoped-guards','argv':['NODE','NPM','run','test:tools','--','migration/legacy-continuity/tests/'],'perCallSeconds':120},
 {'label':'check','argv':['NODE','NPM','run','check'],'perCallSeconds':180},
 {'label':'lint','argv':['NODE','NPM','run','lint'],'perCallSeconds':120},
]
profile={'scope':'Proposed intermediate source qualification only; execute only after parent lease','producer':str(producer),'producerSha256':sha(producer.read_bytes()),'derivedFrom':str(prior),'derivedFromSha256':sha(prior.read_bytes()),'supervisorDiffSha256':sha(delta.encode()),'sourceManifest':str(manifest),'sourceManifestSha256':sha(manifest.read_bytes()),'sourceRows':len(m['files']),'sourceBytes':m['totalBytes'],'head':m['head'],'actualMergeHead':m['mergeHead'],'stagedTree':m['stagedTree'],'semanticIndexSha256':m['semanticIndexSha256'],'ownedPaths':m['onlyChangesSinceScopedTree'],'currentReaderRevision':m['mergeHead'],'acceptedCf0NotComposed':True,'futureAcceptedReaderRevision':m['futureAcceptedReaderRevision'],'commands':commands,'wholeDeadlineSeconds':600,'finalizationReserveSeconds':60,'basis':'Three bounded120/180/120 source calls,420s sum, plus finite source/runtime/Git/reuse qualification and60s finalization reserve; earlier unchanged31-control/checklint/current-role stage completed successfully. Whole alarm begins before hashing and applies through final output manifest. Stop accidental/setup/wrong-control failure with no silent retry.','limitedHistoricalInstallReuse':{'profile':str(SOURCE/'accepted-composition-78d/install-reuse/qualification.json.txt'),'sha256':'b9ad160661fa428d4539ccbdf127790c967e2b6287108ef879b2c324475afeb6','priorCompleteReceipt':'bf6bf2ccc51b4b1435ae0d56061d274d6adf8274e713cc82106420fd1b77a765','scope':'Complete historical709 JS graph, source/root non-script declaration/lock/workspace/runtime/recorded installed metadata qualified before and after; newly selected actual TypeScript compiler bytes also source-bound. No install/list/catalog or native association.'},'applicableFullTier':'Final cf0 composition before push; no full tier repeated solely to qualify intermediate local merge commit','resourcePolicy':{'exclusiveHost':'requires separate explicit parent grant','port':None,'services':None,'signal':'Fresh exact direct-child leader PID/PPID/group/birth/fullargv before every signal; orphan/unavailable ownership refusal preserved; only owned groups','release':'actual all owned groups plus producer absence, complete channels and before/after source/semantic-index/runtime/installed-metadata evidence'},'forbidden':['install/list/catalog','native/JVM/Gradle/Xcode/signing/keytool/device','browser/performance/full suite','rival/review-ledger mutation','commit/merge','manual MERGE_HEAD','foreign process signals'],'review':m['originalReview']}
(OUT/'scoped-profile.json.txt').write_text(json.dumps(profile,indent=2)+'\n')
print(json.dumps({'producer':str(producer),'producerBytes':producer.stat().st_size,'producerSha256':profile['producerSha256'],'deltaBytes':len(delta.encode()),'deltaSha256':profile['supervisorDiffSha256'],'profileSha256':sha((OUT/'scoped-profile.json.txt').read_bytes()),'sourceManifestSha256':profile['sourceManifestSha256'],'testsExecuted':False}))
