# L0 next mechanics preparation

This packet is preparation only. Read MECHANICS-PLAN.md and the exact proposed
availability-preflight.py before granting any execution. The proposed availability invocation is:

```sh
python3 /private/tmp/splotch-resume-01a111b0/legacy-continuity-source/mechanics-plan/availability-preflight.py /private/tmp/splotch-resume-01a111b0/legacy-continuity-source/mechanics-plan/availability-run1
```

No invocation above has occurred. It starts a 60-second alarm before input hashing and executes no
child/tool process, installer, build, device, network or signing operation. Its selected path
metadata cannot certify executable availability, complete graph, origin/profile or compiled-source
association. N1's explicitly qualified owned SDK and the source's different default host SDK are
selected separately; source defaults do not inherit the owned SDK's package qualification.

The finite source readback froze 99 role-addressed Git files plus three installation-pseudonym
owners, with complete bytes, source modes/Git blobs/hashes and matching source line anchors. Their
0444 .txt projections retain the actual Git modes separately; executable modes are not inferred
from these record projections. Current 59 full-gated inputs were requalified by exact bytes/modes
without running a suite, generator, installed consumer or native tool. The collection stdout/stderr
were directly redirected to the two complete channel files, exit0; Git source outputs are completely
consumed into the selected projections and machine-readable identities. No new native negative
control was executed.

source-bindings.json.txt points to existing complete source/provider/SPM/toolchain/execution
receipts; those receipts are not duplicated or broadened. obligations-bindings.json.txt preserves
the exact current phase/upgrade/mobile guidance inputs. service-bindings.json.txt freezes the actual
three source service owners and explicitly leaves the installed Device implementation unqualified.
No raw platform identifier, user credentials or raw Claude conversation is selected.

Full current code gates remain tied to staged tree b2a86ef475f7ed8833baf6b2151104f1a11dc576 and
source manifest f087433a1fabb166c15aaaf5a1766b3f9daef9aba6b8f2f846a379599cfd7e83. The actual
full receipt is ../full-final-gates-r2-repairs-20261006231622/receipt.json.txt at
4b80c938c4b4b62a7e64366dc00536d6132fa78effd9b67a57fb31826f44b467, and release is
ce76b7b4e94b40e89284318ede4c0c15be81ac2da06d4171327372be3d29da9a. The complete independent
51-file execution mirror is c057181f340f0a3f277b09a6bfe86160e1399e9ceda09b034226360d6714f06e.

Original Claude 1b406e61 has two consumed rounds and one remaining. Current source-only scope,
native fixture execution, signed/source/channel acceptance, physical gates and migration completion
are distinct. The last round remains reserved for relevant executed evidence at the final accepted
base. No new conversation, ledger adoption/reset, dependency install, source commit or native run is
part of this packet.
