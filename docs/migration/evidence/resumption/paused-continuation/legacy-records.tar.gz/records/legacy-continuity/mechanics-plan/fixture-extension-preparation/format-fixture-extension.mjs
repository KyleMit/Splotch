import { readFileSync, writeFileSync, statSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
import { capturedCommand } from '/Users/kylemit/.codex/worktrees/migration-legacy-continuity/Splotch/tools/migration/legacy-continuity/command-evidence.mjs';

const root = '/Users/kylemit/.codex/worktrees/migration-legacy-continuity/Splotch';
const output = '/private/tmp/splotch-resume-01a111b0/legacy-continuity-source/mechanics-plan/fixture-extension-format';
const node = '/Users/kylemit/.nvm/versions/node/v24.16.0/bin/node';
const prefix = 'tools/migration/legacy-continuity/';
const mjs = ['contract.mjs', 'materialize.mjs', 'tests/fixture-controls.test.mjs', 'tests/debug-signing.test.mjs', 'tests/guards.test.mjs', 'tests/held-source.test.mjs'].map((path) => prefix + path);
const ts = ['fixture.ts.template', 'held-main.ts.template', 'held-released.ts.template'].map((path) => prefix + 'templates/' + path);
const paths = [...mjs, ...ts, prefix + 'templates/debug-signing.gradle.template', prefix + 'README.md'];
const identity = (path) => {
  const bytes = readFileSync(path);
  const stat = statSync(path);
  return { path, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex'), mode: stat.mode & 0o777, inode: [stat.dev, stat.ino] };
};
mkdirSync(output);
const context = { root: output, calls: [], artifacts: [] };
writeFileSync(join(output, 'before.json.txt'), JSON.stringify({
  inputs: paths.map((path) => identity(join(root, path))),
  runtime: [node, 'node_modules/prettier/bin/prettier.cjs', 'node_modules/dprint/bin.cjs', 'node_modules/dprint/dprint'].map((path) => identity(path.startsWith('/') ? path : join(root, path))),
  limits: 'Formatting only, no tests/Groovy/key production/native/device/installation',
}, null, 2) + '\n');
await capturedCommand(context, node, [join(root, 'node_modules/prettier/bin/prettier.cjs'), '--write', ...mjs.map((path) => join(root, path))]);
await capturedCommand(context, node, [join(root, 'node_modules/prettier/bin/prettier.cjs'), '--write', '--parser', 'typescript', ...ts.map((path) => join(root, path))]);
await capturedCommand(context, node, [join(root, 'node_modules/dprint/bin.cjs'), 'fmt', '--config', join(root, 'dprint.json'), join(root, prefix + 'README.md')]);
writeFileSync(join(output, 'after.json.txt'), JSON.stringify({ inputs: paths.map((path) => identity(join(root, path))), calls: context.calls, artifacts: context.artifacts }, null, 2) + '\n');
process.stdout.write(JSON.stringify({ output, exits: context.calls.map((call) => call.code), native: false, tests: false }) + '\n');
