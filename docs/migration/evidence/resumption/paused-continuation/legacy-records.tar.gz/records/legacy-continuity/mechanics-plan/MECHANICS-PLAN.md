# L0 local native mechanics: next bounded gates

This is an unexecuted continuation of the existing L0a/L0b plan. The actual source unit is PR2708,
original Claude conversation 1b406e61-641e-4cf8-86fb-2b1cd7548469, two substantive rounds consumed
and one remaining. Round two reviewed 709fadd68ecb802aa2c9daa3fc197ce8d072b23c through
b3b16831557dd894186574b9ce3b0c1184b2aab7 and found eight source defects. Their source repairs and
three further lifecycle/refusal defects passed the scoped 31-test/check/lint/topology/role controls
and the subsequent complete Quality and Browserless jobs. Those results do not compile or execute
the fixture native code.

The currently full-gated no-commit composition is b3 plus accepted
78d844ce36845e13690e2ca4ee7fcd645eb128d0. Its staged tree is
b2a86ef475f7ed8833baf6b2151104f1a11dc576; the 59-input source manifest is
f087433a1fabb166c15aaaf5a1766b3f9daef9aba6b8f2f846a379599cfd7e83. The parent will compose the
actually accepted records PR2709 before final independent acceptance. Only changed relevant
inputs invalidate their receipts. The original review range and historical source/evidence remain
immutable. This document authorizes no execution, download, installation, fixture source change,
review round, signing query or channel action.

## Start with the finite availability preflight

The proposed first invocation is only the accompanying `availability-preflight.py`: filesystem
metadata, selected public/local tool bytes and named package metadata, with a 60-second whole
deadline started before input hashing. It executes no Java, Gradle, Xcode, ADB, emulator, simctl,
SDK manager, installer or application. It does not inspect user app containers, host credentials,
debug keystores, .env files, local.xcconfig, signing accounts, ADB keys or arbitrary caches. Its
selected paths and exact producer hash must be read by the parent before a new grant. Missing
paths are explicit availability observations; a filesystem denial, deadline or incomplete list is
a setup failure. Neither is an intended rejecting control or proof that the machine lacks the
resource. Static metadata does not establish tool execution or a supported runtime.

Current qualified receipts are narrow:

* N1's actual five-package SDK view at its owned SDK root
  /private/tmp/splotch-resume-01a111b0/native/android-qualification/sdk binds command-line tools 20, Android platform 36 revision 2,
  build-tools 36.0.0, CMake 3.30.5 and NDK 27.1.12297006. It does not qualify platform-tools,
  emulator, any system image, AVD, licensing or this fixture's compiler graph.
  The actual registration profile binds that pathname; the shipping default
  /Users/kylemit/Library/Android/sdk is a different input. Preflight observes both selected roots
  distinctly. Prefer the qualified owned compiler SDK if its exact required package graph still
  matches; separately qualify any existing host emulator/image/tool before use, never infer it
  from the owned five-package receipt.
* N1's Java 17.0.20.1+1 and Gradle 9.3.1 observations belong to its RN toolchain. They cannot qualify
  this source-built Capacitor unit. Its SDK manager separately observed host Temurin
  21.0.11+10-LTS; that is an existing management-runtime receipt, not a Capacitor compile pass.
* No accepted local iOS simulator/runtime availability receipt was supplied by N1. Its proposed
  Xcode27/current-runtime route is preparation. The static preflight reads selected Xcode/SDK and
  installed runtime metadata; a later explicitly granted tool inventory must establish what can
  actually run. No physical device is polled during this preparation.

The immutable `source-bindings.json.txt` freezes each actual Git role's source, mode and line
anchors. The three roles remain distinct:

| Role | Exact source | Actual Android owners | Actual iOS SDK owner |
| --- | --- | --- | --- |
| Released | d8b86469f63c57a06a9de45664a42eea15b99eb0 | AGP8.13.0; Gradle8.14.3-all; wrapper properties omit distributionSha256Sum | capacitor-swift-pm8.5.1, revision6afa7424fd2fcd8ca1e577478e8a00af284b7e82 |
| Held | ef3d1eb2070c1bd0dee620ed42a2b14201c2a9b4 | AGP9.4.1; Gradle9.6.0-all; exact wrapper checksum87a2216cc1f9122192d4e0fe905ffdf1b4c72cff797e9f733b174e157cadd396 | capacitor-swift-pm8.5.2, revision0b6882e9a3288342aacf36348e5a94e4f1dd7b13 |
| Reader | 78d844ce36845e13690e2ca4ee7fcd645eb128d0, to be rebound after accepted-base composition | Same declared owners as held; actual installed graph still separate | Same declared SDK revision as held; actual checkout/selected binary slice still separate |

Both qualified Capacitor Android 8.5.1 and8.5.2 source owners set Java source/target compatibility to
VERSION_21 at lines 66–67. Use a qualified full JDK21; do not downgrade it to reuse N1's Java17
receipt. Preserve each wrapper/AGP/config rather than restoring older whole files. The released
wrapper's missing checksum requires external exact archive verification before an owned cache
consumer; it cannot be called a vendor checksum pass. Archive metadata/source equality is not
native executable trust.

## Sequential preparation and trust gates

Each step has a separately frozen producer, exact argv/environment/input manifest, actual PID/group
identity, complete raw channels, expected exit/reason, numeric whole deadline and parent grant.
One L0 owner carries repairs and evidence. These are proposed bounds, not elapsed-time acceptance:

| Stage | Whole bound and basis | Exit obligation |
| --- | --- | --- |
| Static availability | 60s including hashing and receipt | Complete finite selected metadata; no executable consumer |
| Role materialization | 300s, current materializer's two 120s command bounds plus 60s finalization | Fresh owned root, complete source Git blobs/modes, exact overlay and tool inputs |
| Frozen fixture JS installation | 600s per unique actual lock, following prior bounded install practice | Complete own ignored-script frozen install output, installed graph/SRI/script qualification; no borrowed reviewer graph |
| Static build and cap sync | 600s per role, separately revised after the first actual measurement | Source-owned lifecycle exits0, exact packaged literal route/config/registration and reviewed generated delta |
| Android configuration/resolution | 600s per unique role-native graph | Qualified wrapper/full JDK21/SDK, explicit repositories and complete resolved coordinates/artifacts; no implicit SDK/JDK download |
| Android or iOS first native compile | 1200s per role/OS, including 120s finalization; refine from first config measurement before invoking | Complete build/settings/source/binary graph/artifact verification; no silent retry or extension |
| Core in-place chain | 600s per source/OS, including60s evidence/release | Source seed/disk/source relaunch and reader reinstall/raw read; no reseed before readback |
| Core native refusals/restoration | 600s per OS, including60s evidence/release | Attributable real owner behavior and restored positives, not transport timeouts |
| Applicable held chain | 600s per OS, including60s evidence/release | Actual held writer, source relaunch, same-ID reader and byte-exact raw receipts |

No whole stage runs merely because a previous grant succeeded. The static preflight is the only
immediate proposed grant. Each compile/resource deadline is a harness ceiling, not app latency or
performance evidence. Expiry stops dependent acceptance and preserves complete observed outputs;
it does not authorize an automatic retry.

Materialize new roots through the tested CLI only after lease/source rebinding. Existing nine
historical materializations prove their then-source composition only. The fixture install graph is
not the L0 tools worktree's qualified historical709 graph. Each root must use its own committed
pnpm lock/workspace and actual CLI8.5.1 or8.5.2. Freeze all lifecycle owners before execution and
inspect the all-false allowBuilds policy rather than executing unknown downloaded scripts.

Use the actual `cap:sync` graph, including prebuild:cap/build:cap/postbuild:cap and the pinned CLI.
Preserve full static outputs, `legacy-continuity.html`, generated native config/plugin lists,
SPM manifest/lock and Android settings/registration. Compare the exact known overlay; unrelated
changes refuse. The fixture route may fail a genuine release budget or seam guard. Preserve the
actual failed owner and disposition it before another command; do not skip hooks, raise budgets,
strip source witnesses or claim a diagnostic build as release acceptance.

iOS source-built app artifacts link the two pinned precompiled Capacitor/Cordova XCFramework
targets. The qualified 904-byte upstream manifests and their four archive checksums remain the
owners. Later acquisition requires complete received archive bytes, checksum and safe member
qualification, exact SPM resolved checkout and binary-target metadata, selected simulator slice,
framework/interfaces/library hashes, link composition and actual loaded runtime identity. npm
source/version equality does not establish compiled-source association. The source-built app and
precompiled SDK identities must appear separately in the artifact manifest.

Android resolves each actual AGP, Capacitor/plugin and Maven graph in an owned cache. Keep role
Gradle wrappers and declared repositories. The first resolution is a provisional trust boundary;
freeze and challenge its exact source/artifact graph before treating a later strict build as
trusted. No inference from N1's different graph, missing license metadata or cached .ok marker.

## Fresh resource ownership and observability

Use a newly created AVD and a newly created simulator, both named `splotch-l0-<run>`; record actual
serial/UDID/runtime/OS/ABI and no preexisting art.splotch.app. The same production app ID is used
only in those owned installs. No default shared AVD, existing user simulator, user data, emulator
reboot, physical device, signing account or real credentials are eligible.

For Android propose unused emulator console/ADB ports 5570/5571, a separately owned ADB server
port 5047 and CDP port 5388; qualify all immediately before allocation. A conflict selects and
requalifies another unused port, never stops a foreign listener. Explicitly bind the actual server
socket to every ADB call and preserve its source/argv before use. Observe the AVD name, PID birth,
emulator process, installed single APK digest, package certificate, WebView provider and exact
https://localhost/legacy-continuity.html target. Refresh the app PID/startTicks lease after every
launch. Each existing `android-command` ADB target has a 10s bound; actual target PID/source argv
and exit remain distinct from its stable gate's full OS identity. Do not lengthen it after an
unexpected timeout without source/ownership review.

The first Android mechanics artifact is an explicit debug/observability app, using the actual
source cap-sync plus run-gradle helper. That supplies run-as and the real WebView CDP socket. Its
debug build cannot certify optimized release behavior. Generate one fresh owned nonproduction key
for both source and reader in a separately granted keytool step. The released Gradle source only
configures `signingConfigs.release`; it does not configure an owned debug key. Before building,
challenge a finite fixture-only Gradle init source that sets the actual debug signingConfig to the
owned key and passes the exact init path through the existing run-gradle helper. No host debug
keystore or genuine HOME reassignment is allowed; passwords stay in a 0600 owned property input,
not argv/logs. Verify actual packaged/installed signer equality. This small fixture composition is
still unimplemented and needs review; neither the current tools nor this plan already supplies it.

For iOS preserve the actual DEVELOPER_DIR, Xcode/SDK/simulator runtime binary identities and fresh
UDID. Use only simulator scope, no local.xcconfig, team or provisioning credential. Build with
explicit CODE_SIGNING_ALLOWED=NO and owned DerivedData/package cache as a reviewed departure from
the literal Debug ios:build command if necessary; retain its cap-sync lifecycle. Verify actual app
bundle, executable/framework files and effective entitlements/keychain attributes. An unsigned
simulator bundle may have no application-identifier/keychain entitlement; record that actual fact
and the observed local query scope rather than inventing a team. No physical keychain or channel
verdict follows from simulator behavior.

The existing iOS driver receives finite command/nonce/receipt arguments, waits 30s for page readiness
and awaits callAsyncJavaScript. A separately owned console host invocation has a 60s ceiling,
captures complete stdout/stderr and actual launched app PID, then retrieves only the two exact
owned tmp report basenames. The driver length/SHA frames and fflush boundary must actually work.
`ios-receipt` only verifies host files; it does not install, launch, establish artifact/profile
survival or prove disk acknowledgement. Those receipts remain separate.

Before EVERY install/launch, enumerate the owned app's coloring root offline, preserving missing vs
present-empty, full descendant paths/modes/bytes/hashes. L0a permits no descendants, jobs or packs.
On iOS the actual normal no-job launch creates the empty coloring root and backup exclusion;
preserve that expected mutation. Android WorkManager can initialize before Activity; released iOS
AppDelegate resumes before JS. A post-attach empty-root receipt cannot substitute for offline
prelaunch inventory. Any nonempty root or unexpected background launch refuses this core chain.

Stop only owned handles with freshly proved actual identities. A changed ADB forwarding map is
retained as unresolved ownership rather than removed. Prove every owned process/group, console
handle, forward and listener absent/released after complete findings/readback and durable copy.
Keep owned TMPDIR/device data until evidence is safe. Shut down/delete only the newly owned device
after final receipts; never erase between source and reader stages. Failed setup, genuine owner
refusal and successful restoration stay separate.

## L0a actual core chain and owner controls

The following finite argv shapes describe existing consumers; they are not executed instructions
or permission to run the whole sequence. A later frozen supervisor supplies absolute qualified
executables and actual owned selectors, not shell interpolation or an arbitrary command broker:

* CLI materialization: `migration:legacy-continuity -- materialize --source released|held|reader
  --output <new-owned-root>`; capture the actual source receipt before installing anything.
* Each fixture root: its actual `pnpm install --frozen-lockfile --ignore-scripts`, complete own graph
  export, then `npm run cap:sync` with all lifecycle hooks. No npm install or borrowed modules.
* Android build after reviewed owned signing init: actual Node invokes
  `tools/mobile/android/run-gradle.mjs --no-daemon --console=plain --init-script <owned-init>
  :app:assembleDebug`. Runtime/download/cache controls and exact resolved role graph must be frozen
  before this executable-trust stage; this shorthand does not itself qualify them.
* Android install: qualified ADB with explicit owned server socket and `-s <owned-serial> install -r
  <qualified-apk>`. It never invokes installDebug on an unspecified device. Core command: the existing
  `android-command --fixture <root> --lease <actual-json> --nonce <32hex> --command <finite-command>
  --output <new-owned-output>` with the actual PID/startTicks/artifact/port lease.
* iOS build after actual help/lock-policy qualification: cap-sync, then qualified xcodebuild with
  explicit project `ios/App/App.xcodeproj`, scheme App, Debug, generic iOS Simulator destination,
  owned DerivedData and package cache, CODE_SIGNING_ALLOWED=NO. Complete actual SPM resolution and
  refusal of changed resolved pins precede this build; unqualified version-specific flags are not
  assumed. The source's literal ios:build command and this explicit output/signing composition stay
  separately recorded.
* iOS install/launch on the newly created actual UDID: qualified simctl install, offline inventory,
  then `launch --console <udid> art.splotch.app --splotch-l0-nonce <32hex> --splotch-l0-command
  <finite-command> --splotch-l0-receipt <32hex>`. Complete console and exact tmp files feed existing
  `ios-receipt`; it never supplies an app-install or profile-survival claim.

Freeze a new 32-hex nonce and nonce-specific dummy secrets/sentinel before seeding. The source calls
its real storage/secure writers. Initial raw capture precedes mutation/import/settings module
initialization. It records inherited app.html storage reads/history cleanup, exact initial URL,
persistent data-store/profile, actual native observer registrations and no drawing-root/earlyBoot
surface. Raw native maps include every selected owned key/account. Nullable app getters cannot
certify absence.

1. Install the released fixture on its fresh device. Offline root inventory, then raw capture and
   actual seed: false sound,37 volume,dark theme,false advanced-controls/coloring,true inert AI,
   unique sentinel and both logical dummy secrets. AI remains isolated; no production API runs.
2. Writer Promise completion is memory-only. Capture actual native rows/types and independent
   Preferences/vault disk bytes within the preregistered5,000 ms writer-to-observation deadline.
   The Android `disk` command preserves primary/backup XML before parsing but enforces no5,000 ms
   deadline itself. Host timing must bind the actual acknowledgement/observation cuts. iOS records
   its owned container plist/cfprefsd boundary; do not kill cfprefsd or use arbitrary defaults.
3. Terminate only the freshly owned app PID through a qualified native process command, then
   offline inventory and relaunch the SOURCE for raw/local/native/vault readback. No hydrate or
   seed before that read. This isolates source persistence loss from reader reinstall. Android
   force-stop is not the preservation cut; reserve it for a separately labelled scheduler hazard.
4. Verify source and reader signer/scope and install reader in place without uninstall, clear,-d,
   profile reset or version edits. Offline inventory, launch exact fixture route, capture raw,
   then vault-read/preferences/one fresh-document parse and applicable hydrate. The reader cannot
   seed. Unique source sentinel, local strings, native rows, dummy secret bytes and actual profile
   must survive. All roles remain version 1.6.0/code 8: this is a same-version local update, not a
   real version-change or signed supported-source/channel pass.

| Uncertainty / actual owner | Required positive | Intended refusal and restored positive | Claim limit |
| --- | --- | --- | --- |
| Route/origin/profile; actual pinned SDK/server plus WebView | Exact literal packaged HTML, same effective source origin/persistent profile and unique sentinel after source relaunch/update | Actual host verifier refuses changed artifact/source lease or wrong observed route/profile before import; real altered-native-profile control requires separate reviewed overlay | Host input refusal is distinct from a runtime wrong-profile experiment; no simulated profile proof |
| Live/durable settings; role storage.ts + Preferences | Raw present local values remain authoritative, evicted selected local keys restore real durable strings; actual parserdark/37/false results | invalid-theme writesnight and parserfallsback; noncanonical-volume writes37abc and records actual lenient result; restore-settings givesdark/37 again | Untombstoned absence+durable ambiguity remains; no invented tombstone or complete policy mapping |
| Typed native settings; locked Preferences owner | Actual raw string row, disk/source relaunch and provider read | native-wrong-type storesactual int; Android must capture attributable provider handler exception/PID outcome, then raw/relaunch restore; iOS numeric coercion separate | CDP timeout, bridge setup error or crash without attributable native log is not the intended control |
| Vault; locked actual setter, namespace/cipher/OS query | Both real dummy secret setters and raw namespace data/status, decoded string plus source relaunch/update | vault-absent confirmsAndroid row AND aliasabsent/iOS qualifieditem-not-found; nonstring/date/invalidJSON distinct; Androidcipher/orphanalias and iOS malformedqueryeachactualcause; restore-vault and repeatraw/provider positives | Invalid query provesSecurityAPIrefusal, not physically lockeditem; provider null neverabsence |
| Command/output; stable gate and actual bridge/driver | Fast real ADB commands work with gateidentity/sourceboundtargetexit; full natural channels; iOSraw+resultframes+filehash andflush | Changed actual frame/byte/source/nonce refusals reuse host controls only when exactinputs match; nativeflush/bridgefailure requiresactualcause andrestoredpositive | Generic successful command or closed destination does not certify native continuity |

Corrupt only the owned accounts on the fresh device after preserving exact raw preimages. Use the
real source setters for restored positives. Existing cleanup removes selected core keys and both
logical dummy secrets plus Android orphan rows; it retains held records, legacy settings and
ownership/unrelated sentinels. No clear/delete-all/database removal or blanket source retirement.
Preserve disk and restored-source relaunch outcomes after each destructive control. Native
unavailability cannot be synthesized by breaking registration and then relabelled a vault control.

## Applicable held mechanics within this source unit

Use a separate fresh chain from the actual held source ef3, never seed its format into released d8b.
Seed through createUnsavedPictureStore().write, the exact PNG bytes frozen by the role source and
nonce-specific baseName/signature/outcome. After acknowledgement and source relaunch, raw native
WebView IDB read must preserve all fields, exact bytes/base64/length/SHA, MIME and owner recognizer.
Then install the reader in place and repeat without reseeding. Both engines must qualify actual
indexedDB.databases availability, no-db/no-record distinction, readonly completion and no creation
on absence. The desktop old-helper defect receipts and31host tests are not native execution.

Drive held-false-hint through the actual held source writeBool and preserve raw local/durable hint
before reading; the reader must still read exact bytes. The current finite tool has no direct
missing-hint command, no restoring held command after put(undefined), no stale asynchronous
destination writer, and no pending-removal delivery latch. Do not hand it arbitrary JS to fill
those holes. Use a separately fresh no-seed chain for absent-db/record and a separate owned chain
for present-undefined rejection. A real source-write restoration after undefined needs a finite
reviewed composition calling the actual writer; the existing held-seed command requires absence
and cannot serve as that restored positive. Freeze/challenge that narrow fixture extension before
execution or report the dependent control unexecuted. No new product implementation is authorized.

Missing hints, malformed raw forms, request failure/abort and a source changed between enumeration
and open remain distinct; unsupported transport refuses completeness. Never filtered success,
{}ArrayBuffer, absent-from-get-only, or transient JS Promise completion. Quiescent owned profile is
required; enumeration does not establish backing-file absence or ordering against other contexts.
Byte-exact raw read after same-ID reinstall is feasibility, not imported destination durability.

## Small local service read and its boundary

The minimum additional service read is the actual source installationId() pseudonym before/after
the same-ID update, through each role's real @capacitor/device getId implementation and unchanged
splotch-free-generation-v1 namespace. Record only the resulting pseudonym and success status, never
the raw platform identifier. This is an offline comparison; do not call allowance refresh or any
hosted API. The current finite fixture command vocabulary does not include it. A narrow reviewed
fixture-only command must lazy-import/call the actual owner only after raw capture and inspect its
complete import/initialization effects before execution. A positive requires privately observed
nonempty native input at the actual call boundary, dummy credentials inert and no HTTP. The released
function hashes its raw return without an explicit empty-string guard; do not claim that legacy
implementation already refuses empty input. Failed/empty input cannot be a successful local
identity comparison. Qualify the exact observation boundary or leave that dependent predicate open;
replacement failure policy remains its own obligation.
No read-only plan or matching source declaration already supplies this command.

The actual installed Device module/native owner and runtime result need their own lock/SRI/artifact
binding; the 102-file SecureStorage/Preferences/Keychain intake does not cover Device. Reuse complete
fixture installed-graph inputs, inspect just this real consumer, and challenge its actual boundary
before execution rather than expanding to all native dependencies. A successful local comparison
cannot prove spent server allowance, Android Play signer lineage, physical iOS vendor/team scope
or reinstall reset semantics. Native service Back/focus/lock/photo/orientation/Pencil/audio/network
product behavior remains later applicable service units; registration or simulator success is not
their acceptance. Parent may keep this narrow local service command as the next source slice if it
would enlarge PR2708's reviewed implemented scope; its exact acceptance state must remain explicit.

## L0b pack/job and ordered-transaction obligations remain separate

The current PR2708 commands implement no pack seeder, background-session coordinator transfer,
durable destination journal, atomic iOS hardening or pending-removal delivery latch. Full phase
continuity cannot be accepted by current core command success. These next meaningful units retain
L0 source/evidence ownership but need their own runnable source and proportional review; the
original final R3 cannot be spent prospectively approving unimplemented source.

For L0b first freeze a fixture-only static asset-base and owned HTTPS transport trust, outside the
legacy WebView origin. Seed completed files/markers and a persisted pending job through the actual
released facade using its real descriptors and verified released static bytes. Do not hand-create
job JSON/.installed markers, call status to discover source state, use production API or weaken
global trust. A held server response has separately recorded request arrival and real native job
persistence; discretionary iOS lack of request arrival is not absence. Capture full offline file
graph/job bytes and permitted OS scheduler/session observations before every launch/update.

Released Android/iOS status deletes old version directories. Released iOS AppDelegate.launch calls
resumePendingDownload before JS; job appVersion mismatch deletes its ENTIRE job version directory,
job and tasks. Current integration removes the mismatched job, and main cannot decode the released
job schema. Main Android worker rejects old jobs missing resolution/marker. Gate ALL relevant
launch/provider/background callbacks, not just Activity/status, until enumeration/preservation.
Observe actual unmet Android network constraints and package-scoped scheduler state; no raw
WorkManager database parsing. iOS session creation itself may start/resume work; unobservable
ownership stays unproved. Any unexpected background relaunch or unavailable gate halts that
scenario, core remains independent. Same-version core reinstall cannot prove appVersion-mismatch;
a real mismatch needs the existing native version owner and a separately reviewed disposable case.

Replacement import and ordered transactions wait for an actual native destination writer/journal
and in-place RN/hybrid reader that reaches the qualified legacy profile. Register real cuts:
source read→destination write→durable acknowledgement→destination readback→receipt→source retirement.
Kill the owned process at each actual cut, relaunch, prove idempotence and preserve source until
durable/readback receipt. Delay an older actual import while a newer destination/held picture is
written; old completion must neither replace new state nor clear new source. Pending-removal
fixtures must use actual main remove/write APIs and actual native delivery boundaries, union both
valid lists and re-read live state. No JS mock, epoch-only ordering, hand-authored journal or tiny
simulated transaction can discharge it. Atomic iOS SecItemUpdate must retain old data on actual
failure and verify the same namespace/accessibility; the released delete/add setter is not that
primitive. These implementation gates remain independent phase obligations, not unmet L0tool
functions renamed passing.

## What must precede original final round three

For a meaningful final review of this source unit require: final accepted-base source composition
and applicable full/CI gates; exact own fixture install/source/generated/artifact identities and separately bound SDK binary/runtime inputs;
actual Android and iOS observer/route/transport build and native command positives/refusals with
restored positives; core source disk/relaunch and same-ID reader reinstall; applicable actual held
writer/raw reader/hint controls owned by this unit; complete raw channels, outputs, failure
dispositions, resource release and portable selected evidence. Resolve material source/ownership or
native setup findings before consuming the last round. A hardware or unavailable toolchain blocker
leaves the dependent gate open; it cannot turn source-only guards into native acceptance.

Final R3 must name exact executed source/OS/runtime/graph/artifact scope, all remaining phase gates,
plausible false passes and false rejections, and the actual PR-keyed ledger. It does not reset the
two consumed rounds, reuse another unit's ledger or infer source acceptance from historical b3CI.
No fresh rival conversation is authorized. Parent owns integration and final-head CI verification.

After this narrow unit is accepted, PHASE-1 unit 6 still needs actual replacement/native reader and
applicable pack/job reconciliation, ordered import, full supported-source/signed-channel matrix,
installation allowance/service disposition and physical entitlement/lock accessibility. Product
Back/focus/settings/audio/network/photo/input/history/export, full floors and matched physical
performance/cutover remain their owners' obligations. Simulator/emulator mechanics neither score
comparative performance nor release physical protection, signed channels, minimum floors or full
campaign completion. Retire the fixture owner only after evidence transfers every applicable
obligation to accepted destination owners.
