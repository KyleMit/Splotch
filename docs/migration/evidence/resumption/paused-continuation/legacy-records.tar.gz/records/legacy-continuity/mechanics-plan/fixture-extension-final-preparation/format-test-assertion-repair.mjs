import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
import { capturedCommand } from '/Users/kylemit/.codex/worktrees/migration-legacy-continuity/Splotch/tools/migration/legacy-continuity/command-evidence.mjs';

const root = '/Users/kylemit/.codex/worktrees/migration-legacy-continuity/Splotch';
const output = '/private/tmp/splotch-resume-01a111b0/legacy-continuity-source/mechanics-plan/fixture-extension-test-format';
const files = ['debug-signing.test.mjs', 'fixture-controls.test.mjs'].map((name) => join(root, 'tools/migration/legacy-continuity/tests', name));
const input = () => files.map((path) => ({ path, sha256: createHash('sha256').update(readFileSync(path)).digest('hex') }));
mkdirSync(output);
const context = { root: output, calls: [], artifacts: [] };
writeFileSync(join(output, 'before.json.txt'), JSON.stringify(input(), null, 2) + '\n');
await capturedCommand(context, '/Users/kylemit/.nvm/versions/node/v24.16.0/bin/node', [join(root, 'node_modules/prettier/bin/prettier.cjs'), '--write', ...files]);
writeFileSync(join(output, 'after.json.txt'), JSON.stringify({ inputs: input(), calls: context.calls, artifacts: context.artifacts }, null, 2) + '\n');
process.stdout.write(JSON.stringify({ output, actualExitCodes: context.calls.map((call) => call.exitCode), native: false, tests: false }) + '\n');
