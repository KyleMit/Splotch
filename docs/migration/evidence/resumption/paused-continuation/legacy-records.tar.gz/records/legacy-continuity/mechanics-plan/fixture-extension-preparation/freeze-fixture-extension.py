from pathlib import Path
import datetime,hashlib,json,os,subprocess

REPO=Path('/Users/kylemit/.codex/worktrees/migration-legacy-continuity/Splotch')
SOURCE=Path('/private/tmp/splotch-resume-01a111b0/legacy-continuity-source')
MECHANICS=SOURCE/'mechanics-plan'
OUT=MECHANICS/'fixture-extension-source-freeze'
OLD=SOURCE/'final-r2-gates-preparation/source-manifest.json.txt'
CF0='cf0c4254d025094054d7ea7faab110da11c96243'
OLD_TREE='b2a86ef475f7ed8833baf6b2151104f1a11dc576'
OWNED=[f'tools/migration/legacy-continuity/{p}' for p in [
 'contract.mjs','materialize.mjs','templates/fixture.ts.template','templates/held-main.ts.template',
 'templates/held-released.ts.template','templates/debug-signing.gradle.template','tests/fixture-controls.test.mjs',
 'tests/debug-signing.test.mjs','tests/guards.test.mjs','tests/held-source.test.mjs','README.md']]
DEPENDENCIES=[
 'web/src/lib/storageKeys.ts','web/src/lib/secureStorage.ts','web/src/lib/storage.ts',
 'web/src/lib/saveNaming.ts','web/src/lib/drawing/unsavedPictureStore.ts','android/app/build.gradle',
 'android/app/src/main/java/art/splotch/app/MainActivity.java','ios/App/App/MainViewController.swift',
 'ios/App/App.xcodeproj/project.pbxproj','capacitor.config.json','web/static/favicon-96x96.png']
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(name,value):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(json.dumps(value,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO,timeout=15)
def identity(path):
 b=path.read_bytes();s=path.stat()
 return {'path':str(path),'realpath':str(path.resolve()),'bytes':len(b),'sha256':sha(b),'mode':oct(s.st_mode&0o777),'inode':[s.st_dev,s.st_ino]}
def ps(pid,group=False):
 args=['/bin/ps','-ww', '-g' if group else '-p',str(pid),'-o','pid=','-o','ppid=','-o','pgid=','-o','lstart=','-o','args=']
 p=subprocess.run(args,capture_output=True,timeout=2)
 return {'argv':args,'exitCode':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()}

OUT.mkdir(exist_ok=False)
formatter=MECHANICS/'fixture-extension-format'
calls=json.loads((formatter/'commands.json.txt').read_bytes())
after=json.loads((formatter/'after.json.txt').read_bytes())
assert len(calls)==3 and all(r['exitCode']==0 and r['groupAbsent'] and not r.get('failure') and not r.get('unresolvedOwnership') for r in calls)
for row in after['artifacts']:
 b=(formatter/row['path']).read_bytes()
 assert len(b)==row['bytes'] and sha(b)==row['sha256'] and row['complete'] and row['streamCompletion']=='natural-eof'
observations=[{'pid':pid,'process':ps(pid),'group':ps(pid,True)} for pid in [42694,42700,42702,42703,42705,42707,42709]]
assert all(v['process']['exitCode']==v['group']['exitCode']==1 and not v['process']['stdout'] and not v['group']['stdout'] for v in observations)
write('format-release-and-outcome.json.txt',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producer':identity(MECHANICS/'format-fixture-extension.mjs'),'commandsSha256':sha((formatter/'commands.json.txt').read_bytes()),'actualExitCodes':[r['exitCode']for r in calls],'completeChannels':after['artifacts'],'independentAbsence':observations,'outerProjectionDiagnostic':{'fieldUsed':'call.code','actualField':'call.exitCode','printedExits':[None,None,None],'noConsumerRepeated':True},'scope':'Formatting only; no fixture/test/native/signing acceptance'})
old=json.loads(OLD.read_bytes())
assert sha(OLD.read_bytes())=='f087433a1fabb166c15aaaf5a1766b3f9daef9aba6b8f2f846a379599cfd7e83'
assert git('rev-parse','HEAD').decode().strip()==old['head']
assert git('rev-parse','MERGE_HEAD').decode().strip()==old['mergeHead']
assert git('write-tree').decode().strip()==OLD_TREE
for row in old['files']:
 if row['path'] not in OWNED:
  actual=identity(REPO/row['path'])
  assert all(actual[k]==row[k]for k in ['bytes','sha256','mode']),row['path']
before_stage=git('ls-files','--stage','-z')
git('add','--',*OWNED)
tree=git('write-tree').decode().strip()
delta=git('diff','--name-only',OLD_TREE,tree).decode().splitlines()
assert sorted(delta)==sorted(OWNED),delta
assert not git('diff','--binary') and not git('ls-files','--others','--exclude-standard','-z')
selected=sorted(set(r['path']for r in old['files'])|set(OWNED)|set(DEPENDENCIES)|{'node_modules/typescript/lib/typescript.js'})
rows=[]
for path in selected:
 actual=identity(REPO/path);actual['path']=path;rows.append(actual)
 for_input=OUT/'source'/path;for_input.parent.mkdir(parents=True,exist_ok=True);for_input.write_bytes((REPO/path).read_bytes());os.chmod(for_input,0o444)
source_deps=[]
for path in DEPENDENCIES:
 role_versions=[]
 for revision in [old['mergeHead'],CF0]:
  b=git('show',f'{revision}:{path}');blob=git('rev-parse',f'{revision}:{path}').decode().strip();mode=git('ls-tree',revision,'--',path).decode().split()[0]
  assert b==(REPO/path).read_bytes(),path
  role_versions.append({'revision':revision,'path':path,'bytes':len(b),'sha256':sha(b),'blob':blob,'gitMode':mode})
 source_deps.append({'path':path,'actualCurrentEqualsBothOwners':True,'owners':role_versions})
accepted_paths=git('diff','--name-only',old['mergeHead'],CF0).decode().splitlines()
assert len(accepted_paths)==6
records=[]
for path in accepted_paths:
 b=git('show',f'{CF0}:{path}');blob=git('rev-parse',f'{CF0}:{path}').decode().strip();mode=git('ls-tree',CF0,'--',path).decode().split()[0]
 target=OUT/'accepted-cf0-records'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b);os.chmod(target,0o444)
 records.append({'revision':CF0,'path':path,'bytes':len(b),'sha256':sha(b),'blob':blob,'gitMode':mode})
stage=git('ls-files','--stage','-z');status=git('status','--porcelain=v1','-z')
owned=git('diff','--cached','--binary','HEAD','--','tools/migration/legacy-continuity','package.json','knip.json','docs/migration/CAMPAIGN.md','docs/migration/evidence/legacy-continuity/README.md','docs/migration/evidence/netlify-install/production-install-contract.json')
diff=git('diff','--binary',OLD_TREE,tree);(OUT/'current-source.delta.diff.txt').write_bytes(diff)
for name,b in [('semantic-index.bin.txt',stage),('status.bin.txt',status),('owned-source.diff.txt',owned),('before-stage.bin.txt',before_stage)]:
 (OUT/name).write_bytes(b)
manifest={**{k:v for k,v in old.items()if k!='files'},'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Approved six fixture source corrections, focused source controls and own README; real pending b3/78d merge retained; cf0 records contrast preparation only; no tests/native execution','stagedTree':tree,'semanticIndexSha256':sha(stage),'statusSha256':sha(status),'ownedDiffSha256':sha(owned),'onlyChangesSinceScopedTree':OWNED,'files':rows,'totalBytes':sum(r['bytes']for r in rows),'currentCodeNotReviewedByClaude':True,'originalReview':{'conversationId':'1b406e61-641e-4cf8-86fb-2b1cd7548469','roundsUsed':2,'roundsRemaining':1,'remainingRoundRequiresExecutedNativeEvidence':True},'futureAcceptedReaderRevision':CF0,'futureBaseNotComposed':True}
write('source-manifest.json.txt',manifest)
write('actual-owner-contrast.json.txt',{'scope':'Actual current test owner bytes equal historical78d and futurecf0 Git objects; no reader revision change or base composition performed','testSourceOwners':source_deps,'acceptedCf0RecordOwners':records,'cf0Commit':CF0,'cf0Parents':git('show','-s','--format=%P',CF0).decode().strip().split(),'cf0Tree':git('rev-parse',f'{CF0}^{{tree}}').decode().strip()})
write('pending-merge-flow.json.txt',{'scope':'Preparation only; no commit/merge execution authorization','actualHead':manifest['head'],'actualMergeHead':manifest['mergeHead'],'currentTree':tree,'approvedPaths':OWNED,'nextGate':['changed fixture unit suite','check','lint'],'thenParentCommitCompletesExistingMerge':True,'ordinaryCf0MergeAfterQualifiedCommit':True,'cf0RecordPaths':accepted_paths,'parentOwnsCampaignCrossUnitResolution':True,'readerChangeOnlyAtActualCf0Composition':True,'finalApplicableScopedAndFullGatesBeforePush':True,'forbidden':['manual MERGE_HEAD write','merge abort','blind stash/FF','new review budget','native execution before final current gates and lease']})
print(json.dumps({'output':str(OUT),'sourceRows':len(rows),'sourceBytes':manifest['totalBytes'],'manifestSha256':sha((OUT/'source-manifest.json.txt').read_bytes()),'stagedTree':tree,'semanticIndexSha256':sha(stage),'sourceDiffSha256':sha(diff),'sourceDiffBytes':len(diff),'head':manifest['head'],'mergeHead':manifest['mergeHead'],'testsExecuted':False,'nativeExecuted':False}))
