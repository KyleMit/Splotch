from pathlib import Path
import hashlib,json,os

SOURCE=Path('/private/tmp/splotch-resume-01a111b0/legacy-continuity-source')
ART=SOURCE/'tools-fixture-extension-20261007001559'
LAUNCH=SOURCE/'mechanics-plan/scoped-fixture-extension-launch-20261007001625'
DURABLE=Path('/Users/kylemit/Code/Splotch/logs/migration-resumption-01a111b0/legacy-continuity/fixture-extension-scoped-failure-20261007001559')
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha((ART/'receipt.json.txt').read_bytes())=='df8967df8f797e30de2eacd2565b06d27241518cc446935b0bf5c03d2c2ef82b'
assert sha((ART/'lease.released.json.txt').read_bytes())=='772e081155cc1e3bc696c1c0cfff761b67cef6997cda45231e4606025a96d810'
receipt=json.loads((ART/'receipt.json.txt').read_bytes());release=json.loads((ART/'lease.released.json.txt').read_bytes())
assert receipt['failure'] and receipt['sourceAndSemanticIndexUnchanged'] and receipt['before']['selected']==receipt['after']['selected'] and receipt['before']['runtime']==receipt['after']['runtime'] and receipt['installReuseBefore']==receipt['installReuseAfter'] and release['allRecordedPidsAndGroupsAbsent']
files=sorted([p for root in [ART,LAUNCH]for p in root.rglob('*')if p.is_file()]+[SOURCE/'run-scoped-tools-fixture-extension-final.py',Path(__file__)])
assert not DURABLE.exists();DURABLE.mkdir(parents=True)
rows=[]
for p in files:
 assert p.is_file() and not p.is_symlink()
 rel=p.relative_to(SOURCE);assert not rel.is_absolute() and '..'not in rel.parts
 b=p.read_bytes();target=DURABLE/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 os.chmod(p,0o444);os.chmod(target,0o444)
 a=p.stat();d=target.stat();assert(a.st_dev,a.st_ino)!=(d.st_dev,d.st_ino)
 assert p.read_bytes()==target.read_bytes()==b
 rows.append({'path':str(rel),'bytes':len(b),'sha256':sha(b),'mode':'0444','sourceInode':[a.st_dev,a.st_ino],'durableInode':[d.st_dev,d.st_ino]})
manifest={'scope':'Complete halted L0 scoped source suite failure, raw outer channels, retained inner controls, actual launch/owned release and prepared pausedfrontier; check/lint/full/native/commit/push/merge/reviewUNRUN; no intended-negative acceptance','sourceRoot':str(SOURCE),'durableRoot':str(DURABLE),'relativePathConvention':'Every member path resolves from sourceRoot or durableRoot respectively; actual artifact and launch are explicit sibling paths','members':rows,'count':len(rows),'totalBytes':sum(r['bytes']for r in rows),'producer':str(Path(__file__)),'producerSha256':sha(Path(__file__).read_bytes()),'sourceBeforeEqualsAfter':True,'runtimeBeforeEqualsAfter':True,'limitedInstallReuseBeforeEqualsAfter':True,'completeSourcePreparationMirrors':[{'root':'/Users/kylemit/Code/Splotch/logs/migration-resumption-01a111b0/legacy-continuity/mechanics-plan/fixture-extension-preparation','manifestSha256':'f745c78af9ab0044fcf2b26fa055b8490c7f1c507cddccf794b8d73cfc6b2c80'},{'root':'/Users/kylemit/Code/Splotch/logs/migration-resumption-01a111b0/legacy-continuity/mechanics-plan/fixture-extension-final-preparation','manifestSha256':'9c6f2bf4aaccf3494f3c72ad9296dae002c061620e362f22d0f0ba93bae7ba7e'}]}
text=json.dumps(manifest,indent=2)+'\n'
for p in [ART/'failure-mirror-manifest.json.txt',DURABLE/'mirror-manifest.json.txt']:
 p.write_text(text);os.chmod(p,0o444)
print(json.dumps({'durableRoot':str(DURABLE),'members':len(rows),'bytes':manifest['totalBytes'],'manifestSha256':sha(text.encode()),'allBytesModesIndependentInodesVerified':True,'preparedFrontier':str(DURABLE/'tools-fixture-extension-20261007001559/PAUSED-FRONTIER.json.txt'),'noRetry':True}))
