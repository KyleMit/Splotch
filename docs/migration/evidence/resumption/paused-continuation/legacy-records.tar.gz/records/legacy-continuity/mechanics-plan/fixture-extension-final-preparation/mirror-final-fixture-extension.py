from pathlib import Path
import hashlib,json,os

SOURCE=Path('/private/tmp/splotch-resume-01a111b0/legacy-continuity-source/mechanics-plan')
DURABLE=Path('/Users/kylemit/Code/Splotch/logs/migration-resumption-01a111b0/legacy-continuity/mechanics-plan/fixture-extension-final-preparation')
sha=lambda b:hashlib.sha256(b).hexdigest()
files=sorted([p for directory in ['fixture-extension-final-freeze','fixture-extension-test-format','fixture-extension-test-assertion-repair']for p in (SOURCE/directory).rglob('*')if p.is_file()]+[SOURCE/'fixture-extension-source-freeze/test-source-challenge.json.txt']+[SOURCE/name for name in ['format-test-assertion-repair.mjs','freeze-final-fixture-extension.py','mirror-final-fixture-extension.py']])
assert sha((SOURCE/'fixture-extension-final-freeze/source-manifest.json.txt').read_bytes())=='0b0d18a33c2d4e7bc792e3de517ba9e65f8952cfec4f7463f4de3597839a7808'
assert not DURABLE.exists();DURABLE.mkdir(parents=True)
rows=[]
for p in files:
 assert p.is_file() and not p.is_symlink()
 rel=p.relative_to(SOURCE);assert '..'not in rel.parts and not rel.is_absolute()
 b=p.read_bytes();target=DURABLE/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 os.chmod(p,0o444);os.chmod(target,0o444)
 a=p.stat();d=target.stat();assert(a.st_dev,a.st_ino)!=(d.st_dev,d.st_ino)
 assert target.read_bytes()==b and sha(p.read_bytes())==sha(b)
 rows.append({'path':str(rel),'bytes':len(b),'sha256':sha(b),'mode':'0444','sourceInode':[a.st_dev,a.st_ino],'durableInode':[d.st_dev,d.st_ino]})
manifest={'scope':'Finite final source correction/preparation mirror before requested stopping point; no scoped test/native/Gitcommit/push/merge/rival execution','sourceRoot':str(SOURCE),'durableRoot':str(DURABLE),'relativePathConvention':'Every member path resolves from sourceRoot or durableRoot respectively; source-freeze/helper/format are explicit sibling paths','members':rows,'count':len(rows),'totalBytes':sum(r['bytes']for r in rows),'producer':str(Path(__file__)),'producerSha256':sha(Path(__file__).read_bytes()),'reusedImmutableSourceCopies':{'priorDurableRoot':'/Users/kylemit/Code/Splotch/logs/migration-resumption-01a111b0/legacy-continuity/mechanics-plan/fixture-extension-preparation','priorMirrorSha256':'f745c78af9ab0044fcf2b26fa055b8490c7f1c507cddccf794b8d73cfc6b2c80','unchangedSourceRows':72,'changedSourceRows':2,'claim':'Current74 source rows are in final source manifest; unchanged72 exact source records remain in preserved prior mirror; changed2 independent source records included here.'}}
text=json.dumps(manifest,indent=2)+'\n'
for p in [SOURCE/'fixture-extension-final-freeze/mirror-manifest.json.txt',DURABLE/'mirror-manifest.json.txt']:
 p.write_text(text);os.chmod(p,0o444)
print(json.dumps({'durableRoot':str(DURABLE),'members':len(rows),'bytes':manifest['totalBytes'],'manifestSha256':sha(text.encode()),'allBytesModesIndependentInodesVerified':True,'original110MirrorPreserved':True}))
