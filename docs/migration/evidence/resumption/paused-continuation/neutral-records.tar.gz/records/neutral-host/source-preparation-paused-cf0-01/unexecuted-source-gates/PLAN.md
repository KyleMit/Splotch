# Neutral source gates on the composed accepted owners

This is an unexecuted source-gate proposal. The current source is HEAD
cf0c4254d025094054d7ea7faab110da11c96243 with the intended 50 files staged. The
original source-preparation caller failed after its short Git-add observation;
the read-only postqualification then refused changed complete installed
membership. Neither caller is a successful gate. Installed membership diagnosis
and its disposition are prerequisites for freezing this packet.

The source remains a conditional neutral React host probe. This execution does
not build or mount that host, select a framework, expand native source, or accept
product, deployed PWA, physical performance, or continuity behavior. The 75,000
byte lazy ceiling, six shipping postbuild owners, paired reference/control nonce
and neutral-only omission of the pinned nonce remain unchanged.

## Frozen inputs and reuse

Bind all 8,417 tracked filesystem rows, semantic index/membership/status, complete
staged binary patch, no unstaged/untracked source, package/lock, actual Node/npm
binary and launcher, all six incoming accepted records, protected Retained
source, unrelated ledger, immutable Retained publication, and the two preserved
stashes. Every staged index blob must equal its actual filesystem bytes. Bind the
fresh installed graph and owner inputs after the membership observation is
disposed; do not silently ignore cache paths or substitute old installed proof.

The actual registered `npm run info` already returned zero during the source
preparation. Its complete 99,618 byte stdout and exact command/package owner
scope remain usable because the root manifest and command owner have not changed.
It is a reused completed call, not a new gate or a reclassification of its failed
parent caller. The subsequent source gates are new executions.

The current inventory formatting changed raw bytes from the v2 receipt but its
complete JSON object is identical. Preserve the old raw receipt and bind the new
serialization separately. The current candidate-exclusive and production
contract remain byte-identical. No archive or install probe needs to repeat for
JSON whitespace or documentation composition.

## Serial commands and deadlines

Use the qualified absolute Node binary and npm-cli.js to invoke these actual
registered npm scripts. The only arguments passed to the targeted suite are the
13 literal paths already frozen in the composition scoped-gate plan:

1. `npm run test:tools --` followed by the nine web-host owner test paths and four
   actual discovery/lint/specifier-registration test paths: 180 seconds.
2. `npm run check`: 180 seconds.
3. `npm run lint`: 120 seconds.
4. `npm run check:quality`: 600 seconds, only after the scoped calls pass.
5. `npm run test:browserless`: 600 seconds, only after Quality passes.

Use one exclusive host lease and a named 2,100 second whole deadline covering
setup, complete source/installed observations, all child calls and finalization.
Capture the complete installed graph before and after using the existing frozen
physical qualifier and unchanged maintained live-target owners, with at most 90
seconds for each observation. Source capture and postqualification each have a
60 second bound; reserve 30 seconds for finalization. These bounds total 2,010
seconds before the 90 second whole-stage margin. No stage may silently extend
the whole deadline.

Immediately before Browserless, choose a fresh unused loopback port by binding a
socket to port zero, record its actual address/port and close it immediately
before child launch. Pass only that actual value as `SMOKE_PORT`; this observation
is not a reservation after close. `EADDRINUSE` is a distinct setup failure and
halts this frozen attempt. Never stop a foreign listener. The registered API
smoke owns its server lifecycle. Require the selected port to be bindable again
after Browserless and require every observed owned child/group to be released.

## Process and source evidence

Reuse the existing private supervisor functions with the necessary truthful
observer correction. The Popen invocation vector is known from the actual
creation call. An OS title such as `npm` is mutable and is not a full argument
vector. Store both facts distinctly; capture complete live arguments of eligible
long-lived consumer descendants when actually visible. Do not infer arguments
or exit status for an already completed short process.

For cleanup, use the owned Popen handle and reprove the actual live PID, birth,
direct parent and process group before TERM and again before KILL. Record the
observed title and its limit; do not require the title to equal an earlier mutable
title or treat it as original arguments. If the owned leader exited while an
observed group remains, preserve unresolved ownership and decline signaling from
a historical PID. This is a narrow correction to this private recorder, not a
new process framework or a maintained ownership guard change.

Capture separate complete binary stdout/stderr per command, actual elapsed
cost, actual exit status, source/index/install identities before and after, and
observed process/group release. No source edit may occur while a command runs.
Any unintended failure, wrong refusing reason, source/index drift, unexpected
installed graph change, timeout or unresolved ownership halts acceptance and
preserves that attempt. Successful unchanged local gates are source evidence;
they do not establish host runtime or comparative performance.

## Following gates

After applicable full source gates pass, commit/push the exact reviewable source
and open its own draft PR against `codex/native-migration`. Preserve old receipts.
Adopt only the actual PR/cwd-keyed ledger into original Claude conversation
8c229c08-f640-4bb6-bf08-6953253da0ee, one round used/two remaining; preserve the
unrelated old ledger and exhausted Retained conversation. Original round two
must challenge actual source and the explicit browser false-pass limits before
an expensive host build. Original round three must receive actual executed
source/evidence. Fresh fallback/reset/fourth rounds are not authorized.

The existing synthetic/retained browser cases can pass while React import fails
or the island is disposed. They do not prove actual neutral adoption or recovery,
all canvas/tile identities, exact pixels, history and commands. Modal focus/Back,
Settings/route lifecycle and palette/selection behavior remain unexercised. A
recovery counter alone is insufficient. A failed postbuild artifact is never
eligible for check/serve/browser; complete failure costs may be preserved without
becoming a release pass. The 193,523 byte runtime-only signal remains unresolved.
