# Neutral React web host

This unit investigates a React DOM boundary inside the real retained Svelte host. It does not select
React Native Web or React Strict DOM, perform a preliminary product rewrite, or establish release or
comparative performance acceptance. The governing obligations remain in [PHASE-1.md](PHASE-1.md) and
[WEB-CONTRACT.md](WEB-CONTRACT.md).

The source unit began from accepted integration 709fadd68ecb802aa2c9daa3fc197ce8d072b23c, whose tree
equals accepted Retained source 0c56e26309198082dfe76c99231fab24b23117cd. Current owner composition
includes accepted cf0c4254d025094054d7ea7faab110da11c96243 over
78d844ce36845e13690e2ca4ee7fcd645eb128d0, preserving the proof-only hosted exporter after the six
shipping postbuild guards. The isolated branch is `codex/migration-neutral-react-host`; the source
owner is retained_control and the parent retains integration, architecture and final acceptance.

The preserved neutral53 packet contains 53 maintained files, 284279 bytes and row digest
d656c12565bb542458f80ca7373c7e523c8ccc6e736b95ecdd5014b6af2ec7fd. It is source preparation.
Twenty-four additions and fifteen existing-owner deltas are composed over current Retained owners.
Eight stale differing packet files and six identical files remain current byte-exact owners. The
preservation record is [evidence/continuation/README.md](evidence/continuation/README.md).

The original Claude conversations c3b60f0b-dc33-46b4-b9c8-da28e68bc2d0,
b18f0f27-5687-45ab-baa6-b988b4c34a4a and 8c229c08-f640-4bb6-bf08-6953253da0ee each used one planning
round. None reviewed the final neutral53 source. The bounded Codex source reports disclose their
inherited authorship and no execution. Original 8c229 resumes for actual source round two and
executed-evidence round three; its two remaining rounds are not a reset of the other histories.

The source and exact four root dev declarations are composed; the actual lock delta retains all 1497
prior artifacts and adds only ReactDOM19.2.3 and ReactDOM-types19.2.3, with qualified Expo
optional-peer context changes. One frozen ignored-hook physical install took96.149 seconds for
complete observation, preserved the prior invalid graph and qualified fresh pins, links and the
existing Forge patch. This is narrow installation evidence. A later cached invocation of the actual
registry/archive owner and full inventory guard qualified 269 selected rows, including the two new
archive inputs. Nine intended rejecting controls and restored positives passed. The actual
registered generator derived all five input hashes and complete current production and
candidate-exclusive arrays, with exact physical graph preservation. The earlier unintended
metadata-script assertion failure remains preserved separately; cached responses do not establish a
live registry observation. Historical root reviews cover their original 267 rows, while source
acceptance of the two new rows remains pending original round two.

The current input owners are [script inventory](evidence/native-topology-05/script-inventory.json),
[production contract](evidence/netlify-install/production-install-contract.json) and
[candidate-exclusive artifacts](evidence/native-topology-05/candidate-exclusive-artifacts.json). The
accepted [narrow installation record](evidence/resumption/narrow-outcomes-2238.json.txt) records its
qualified scope. Current source review, types/tests, real production compiler/render, both Kit
passes, browser mechanisms and final-head CI remain pending. Prepared controls, archive
qualification and physical installation do not establish host acceptance.

The source uses one deferred React client entry and a build-time `renderToString` publication with
matching props and identifier prefix. The exact root-page overlay preserves the paper/input/tile
planes outside React. Production automatic JSX, contributing/loaded CJS checks, strict HTML
normalization, immutable publication and binding-local modal state retain their actual owners.

Reference/control share their accepted pinned nonce and exact output comparison, with no nonce
normalization. A neutral child omits that pin and records its ordinary unique emitted app-shell URL.
Shipping pin ownership stays restricted to the paired calibration copies. Actual emitted URLs,
complete output inventories, source/dependency inputs, process groups, browser registry and unique
invocation/report/cache owners remain guarded.

The root tooling pins are React/ReactDOM19.2.3, React types19.2.2 and ReactDOM types19.2.3. The
corrected last pin supersedes the old type-route proposal, whose bytes remain historical. Each has a
real private host caller. The actual lock delta, peer contexts, archive/lifecycle provenance and
installed graph must be qualified before candidate imports; no new framework or install-hook
permission is implied.

All six actual shipping postbuild owners remain hard gates. The 75000-byte raw lazy ceiling is
unchanged. The runtime-only 193523-byte experiment remains a failure signal requiring complete host
costs and an explicit causal disposition. A failed artifact stays failed and ineligible, and its
actual reader refuses check/serve/browser. A diagnostic mechanism lane cannot establish release
eligibility or silently change this status.

The current actual browser suite covers retained visible ink, one prehydration canvas identity and
three synthetic HTML boundary cases. It can pass despite a failed React import or disposed client.
An actual neutral mount, failed/disposed-client refusal, matching hydration and deliberate
text-mismatch recovery need distinct real witnesses; an unrelated recoverable-error counter cannot
prove that recovery. Exact accepted pixels, every relevant canvas/tile/history identity and command
behavior, worker cleanup, modal focus/refusal/Back, palette/selection, Settings and same-document
route-return controls remain required. The current modal adapter calls real owners, but those
behaviors remain unexercised and palette/selection consumers are absent from this thin chrome.
Existing build-child and browser time ceilings do not replace an outer whole-stage deadline.
Deployed CSP/PWA/API/admin/offline, physical/native/product fidelity and final architecture and
release gates remain in the migration contract. F1 source acceptance remains a separate gate.
