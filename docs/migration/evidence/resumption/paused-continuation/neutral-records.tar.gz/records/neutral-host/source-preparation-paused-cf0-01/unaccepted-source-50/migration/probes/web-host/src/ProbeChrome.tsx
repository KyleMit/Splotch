import { useEffect, useId, useSyncExternalStore } from 'react';
import { PROBE_DIALOG_ID, PROBE_DIALOG_OPENER_ID, type ProbeChromeProps } from './probeProps';

export function ProbeChrome({ store, initialPendingLabel, onAdopted }: ProbeChromeProps) {
  const snapshot = useSyncExternalStore(
    store.subscribe,
    store.getSnapshot,
    store.getServerSnapshot
  );
  const statusId = useId();
  useEffect(onAdopted, [onAdopted]);

  return (
    <div className="splotch-probe-chrome" aria-label="Web host probe">
      <span className="splotch-probe-swatch" aria-hidden="true" />
      <p className="splotch-probe-status" id={statusId} role="status">
        {snapshot.phase === 'pending'
          ? initialPendingLabel
          : `${snapshot.theme === 'dark' ? 'Night' : 'Light'} paper · ${snapshot.canvasEmpty ? 'Empty' : 'Ink'} · ${snapshot.strokeCount} committed strokes · ${snapshot.undoCount} undos · ${snapshot.canUndo ? 'Undo ready' : 'No undo'}`}
      </p>
      <div className="splotch-probe-actions">
        <button
          className="splotch-probe-button"
          type="button"
          disabled={snapshot.phase === 'pending'}
          onClick={store.toggleTheme}
          aria-describedby={statusId}
        >
          Change theme
        </button>
        <button
          className="splotch-probe-button"
          type="button"
          id={PROBE_DIALOG_OPENER_ID}
          aria-haspopup="dialog"
          aria-controls={PROBE_DIALOG_ID}
          disabled={snapshot.phase === 'pending'}
          onClick={(event) => store.openDialog(event.currentTarget)}
        >
          Open dialog
        </button>
      </div>
    </div>
  );
}
