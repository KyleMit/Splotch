import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import time
STARTED = time.monotonic()
WHOLE_SECONDS = 90
attempt = Path(__file__).parent / 'attempt-01'
assert not attempt.exists()
attempt.mkdir()
if os.getpgrp() != os.getpid():
    os.setsid()
def alarm(_signum, _frame):
    raise TimeoutError('Read-only source postqualification whole deadline')
signal.signal(signal.SIGALRM, alarm)
signal.setitimer(signal.ITIMER_REAL, 75)
inputs_path = Path('/private/tmp/splotch-resume-01a111b0/neutral-host/source-unit/source-preparation-cf0-01/inputs.json')
raw_inputs = inputs_path.read_bytes()
assert hashlib.sha256(raw_inputs).hexdigest() == '1be594a6a0e94ae6b52c67fecdaa1f5d7e8abed1d3cf4526015091f7be21910f'
inputs = json.loads(raw_inputs)
root = Path(inputs['worktree'])
record = {'state': 'starting', 'scope': 'Read-only actual source/index/physical input postqualification; original formatting recorder remains failed; no tests/compiler/build/rival', 'startedAtUtc': datetime.datetime.now(datetime.UTC).isoformat(), 'pid': os.getpid(), 'pgid': os.getpgrp()}
def now():
    return datetime.datetime.now(datetime.UTC).isoformat()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def remaining():
    return max(0.001, STARTED + WHOLE_SECONDS - time.monotonic())

def ps_rows():
    data = subprocess.run(['/bin/ps', '-ww', '-axo', 'pid=,ppid=,pgid=,lstart=,args='], capture_output=True, check=True, timeout=min(5, remaining())).stdout
    rows = []
    for line in data.decode().splitlines():
        fields = line.split(None, 8)
        if len(fields) == 9:
            rows.append({'pid': int(fields[0]), 'ppid': int(fields[1]), 'pgid': int(fields[2]), 'birth': ' '.join(fields[3:8]), 'argv': fields[8]})
    return rows

def identity(pid):
    return next((row for row in ps_rows() if row['pid'] == pid), None)

def git(*args):
    return subprocess.run(['/usr/bin/git', '--no-optional-locks', *args], cwd=root, capture_output=True, check=True, timeout=min(10, remaining())).stdout

def file_bind(row):
    path = Path(row['path'])
    assert path.is_file() and not path.is_symlink() and path.resolve(strict=True) == path
    data = path.read_bytes()
    assert stat.S_IMODE(path.lstat().st_mode) == row['mode'] and len(data) == row['bytes'] and sha(data) == row['sha256'], 'Changed frozen input: ' + str(path)

def index_map(data):
    result = {}
    for raw in data.split(b'\0'):
        if raw:
            header, path = raw.split(b'\t', 1)
            mode, oid, stage = header.split()
            assert stage == b'0'
            result[path.decode()] = (mode.decode(), oid.decode())
    return result

def installed_preserved(label):
    witness_path = Path('/private/tmp/splotch-resume-01a111b0/neutral-host/source-unit/current-inputs-preparation-v2/attempt-01/after-installed.json')
    data = witness_path.read_bytes()
    assert sha(data) == '75fd8d9e944bd473e66fd56bb01a1196432699bb565731a49f9f38648562a610'
    witness = json.loads(data)
    observations = []
    for context in witness['contexts']:
        directory = root / context['relativePath']
        if not context['present']:
            assert not directory.exists() and not directory.is_symlink()
            observations.append({'relativePath': context['relativePath'], 'present': False})
            continue
        info = directory.lstat()
        assert not directory.is_symlink() and str(info.st_dev) == context['rootIdentity']['device'] and str(info.st_ino) == context['rootIdentity']['inode']
        for row in context['files']:
            path = directory / row['path']
            actual = path.lstat()
            assert stat.S_IMODE(actual.st_mode) == row['mode'] and actual.st_size == row['bytes']
            if row['kind'] == 'symlink':
                assert path.is_symlink() and os.readlink(path) == row['link']
                assert os.path.relpath(path.resolve(strict=True), directory) == row['target']
                raw = os.readlink(path).encode()
            else:
                assert path.is_file() and not path.is_symlink()
                raw = path.read_bytes()
            assert sha(raw) == row['sha256'], 'Installed byte drift: ' + str(path)
        expected_files = {row['path'] for row in context['files']}
        expected_dirs = {row['path'] for row in context['directories']}
        actual_files, actual_dirs = set(), {'.'}
        for current, names, files in os.walk(directory, followlinks=False):
            for name in names.copy():
                path = Path(current) / name
                relative = str(path.relative_to(directory))
                if path.is_symlink():
                    actual_files.add(relative)
                    names.remove(name)
                else:
                    actual_dirs.add(relative)
            for name in files:
                actual_files.add(str((Path(current) / name).relative_to(directory)))
        assert actual_files == expected_files and actual_dirs == expected_dirs
        for row in context['directories']:
            path = directory if row['path'] == '.' else directory / row['path']
            assert path.is_dir() and not path.is_symlink() and stat.S_IMODE(path.lstat().st_mode) == row['mode']
        observations.append({'relativePath': context['relativePath'], 'present': True, 'rootIdentity': context['rootIdentity'], 'fileRowsRequalified': len(expected_files), 'directoryRowsRequalified': len(expected_dirs), 'completeMembershipEqual': True, 'baselineInventorySha256': context['inventorySha256']})
    receipt = {'scope': 'Byte/mode/link/membership equality with prior maintained full witness only; no new manager or relaxed graph acceptance', 'baselinePath': str(witness_path), 'baselineSha256': sha(data), 'contexts': observations}
    (attempt / (label + '-installed-preservation.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    return receipt

def metadata(label):
    result = {}
    for name, args in [('head', ['rev-parse', 'HEAD']), ('branch', ['branch', '--show-current']), ('index', ['ls-files', '--stage', '-z']), ('membership', ['ls-files', '-z']), ('status', ['status', '--porcelain=v1', '-z', '--untracked-files=all']), ('staged-diff', ['diff', '--cached', '--binary', '--no-ext-diff']), ('unstaged-diff', ['diff', '--binary', '--no-ext-diff'])]:
        data = git(*args)
        path = attempt / (label + '-' + name + '.bin')
        path.write_bytes(data)
        result[name] = {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}
    return result


def actual_sources(expected, previous=None):
    rows, deltas = [], []
    for old in expected:
        path = root / old['path']
        assert path.is_file() and not path.is_symlink()
        data = path.read_bytes()
        current = {'path': old['path'], 'mode': stat.S_IMODE(path.lstat().st_mode), 'bytes': len(data), 'sha256': sha(data), 'actualGitOid': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}
        assert current['mode'] == old['mode']
        if previous is not None:
            assert current == previous[old['path']], 'Postqualification changed source: ' + old['path']
        if any(current[k] != old[k] for k in ['mode','bytes','sha256']):
            assert old['path'] in inputs['ownedSourcePaths'], 'Unexpected source delta: ' + old['path']
            deltas.append({'path': old['path'], 'before': {k:old[k] for k in ['path','mode','bytes','sha256']}, 'after': current, 'scope': 'approved status update' if old['path']=='docs/migration/NEUTRAL-HOST.md' else 'selected existing formatter delta'})
        rows.append(current)
    return rows, deltas


try:
    record['identity'] = identity(os.getpid())
    assert record['identity']['pgid'] == os.getpid() and record['identity']['argv'].endswith(' -B '+str(Path(__file__).resolve()))
    record['beforeMetadata'] = metadata('before')
    assert git('rev-parse','HEAD').decode().strip() == 'cf0c4254d025094054d7ea7faab110da11c96243'
    assert git('branch','--show-current').decode().strip() == 'codex/migration-neutral-react-host'
    expected = json.loads(Path(inputs['sourceBefore']).read_bytes())
    rows, deltas = actual_sources(expected)
    (attempt/'current-source.json').write_text(json.dumps(rows,indent=2)+'\n')
    (attempt/'format-and-status-deltas.json').write_text(json.dumps(deltas,indent=2)+'\n')
    assert not git('diff','--name-only','-z')
    assert not git('ls-files','--others','--exclude-standard','-z')
    staged = set(git('diff','--cached','--name-only','-z').decode().rstrip('\0').split('\0'))
    assert staged == set(inputs['ownedSourcePaths']) and len(staged)==50
    index = index_map(git('ls-files','--stage','-z'))
    assert set(index)=={r['path'] for r in rows}
    for row in rows:
        assert index[row['path']]==('100755' if row['mode']&0o111 else '100644',row['actualGitOid'])
    for row in inputs['protectedRetainedRows']+[inputs['acceptedMigrationReadme'],inputs['protectedUnrelatedLedger']]+inputs['protectedImmutableRetainedPublication']:
        file_bind(row)
    for row in inputs['incomingRows']:
        data=(root/row['path']).read_bytes()
        assert len(data)==row['bytes'] and sha(data)==row['sha256']
    assert sha((root/'package.json').read_bytes())==inputs['currentPackage']['sha256']
    assert sha((root/'pnpm-lock.yaml').read_bytes())==inputs['currentLock']['sha256']
    original_result=json.loads(Path('/private/tmp/splotch-resume-01a111b0/neutral-host/source-unit/current-inputs-preparation-v2/attempt-01/result.json').read_bytes())
    record['currentInputFormattingDisposition'] = []
    for row in original_result['currentInputs']['outputs']:
        data=(root/row['path']).read_bytes()
        byte_equal = len(data)==row['bytes'] and sha(data)==row['sha256']
        if not byte_equal:
            assert row['path']=='docs/migration/evidence/native-topology-05/script-inventory.json'
            original=Path('/Users/kylemit/Code/Splotch/logs/migration-resumption-01a111b0/neutral-host/current-inputs-qualified-v2-01/generated-inputs')/row['path']
            original_bytes=original.read_bytes()
            assert len(original_bytes)==row['bytes'] and sha(original_bytes)==row['sha256']
            assert json.loads(data)==json.loads(original_bytes), 'Formatter changed complete current inventory values'
        record['currentInputFormattingDisposition'].append({'path':row['path'],'oldBytes':row['bytes'],'oldSha256':row['sha256'],'currentBytes':len(data),'currentSha256':sha(data),'rawByteEqual':byte_equal,'completeJsonValueEqual':True,'oldReceiptRelabeledNewRawScope':False})
    record['installedPreserved'] = installed_preserved('current')
    original_stashes=Path('/private/tmp/splotch-resume-01a111b0/neutral-host/source-unit/composition-cf0-01/stashes.txt').read_text().splitlines()
    stack=git('stash','list','--format=%H').decode().splitlines()
    assert all(line.split()[0] in stack for line in original_stashes)
    for owned in ['024d0433e9d25be3d5078a6dd0fce56c7e561b8d','f52c8fc2bba4d5541efeb4695b2491638fd65658']:
        assert owned in stack and git('cat-file','-t',owned).decode().strip()=='commit'
    second, ignored=actual_sources(expected,{r['path']:r for r in rows})
    assert second==rows
    record['afterMetadata']=metadata('after')
    assert {k:r['sha256'] for k,r in record['beforeMetadata'].items()}=={k:r['sha256'] for k,r in record['afterMetadata'].items()}
    record.update({'state':'read-only-source-postqualification-passed','actual50StagedNoUnstagedUntracked':True,'allStagedBlobsMatchFilesystem':True,'sourceRows':len(rows),'nonOwnedSourceEqual':True,'formatAndStatusDeltaCount':len(deltas),'protectedIncomingLedgersPublicationEqual':True,'rootManifestAndLockByteEqual':True,'threeCompleteCurrentInputObjectsValueEqual':True,'previousStashMembersPreserved':True,'originalPreparationRecorderReclassifiedAsPass':False,'originalShortGitAddExitOrArgvInferred':False,'sourceGateOrHostAccepted':False})
except BaseException as error:
    record['state']='failed'
    record['failure']={'type':type(error).__name__,'message':str(error)}
    raise
finally:
    record['finishedAtUtc']=now()
    record['elapsedSeconds']=time.monotonic()-STARTED
    record['wholeDeadlinePassed']=record['elapsedSeconds']<=WHOLE_SECONDS
    (attempt/'result.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({'state':record['state'],'path':str(attempt/'result.json'),'pid':os.getpid(),'pgid':os.getpgrp(),'elapsedSeconds':record['elapsedSeconds']}))
    assert record['state']=='read-only-source-postqualification-passed' and record['wholeDeadlinePassed']
