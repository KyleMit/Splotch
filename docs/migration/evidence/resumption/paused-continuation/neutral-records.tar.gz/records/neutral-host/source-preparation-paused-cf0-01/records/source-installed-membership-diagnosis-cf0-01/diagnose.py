import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import time

STARTED = time.monotonic()
WHOLE_SECONDS = 60
BASE = Path(__file__).parent
ATTEMPT = BASE / 'attempt-01'
assert not ATTEMPT.exists()
ATTEMPT.mkdir()
if os.getpgrp() != os.getpid():
    os.setsid()
ROOT = Path('/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch')
WITNESS = Path('/private/tmp/splotch-resume-01a111b0/neutral-host/source-unit/current-inputs-preparation-v2/attempt-01/after-installed.json')
SOURCE = Path('/private/tmp/splotch-resume-01a111b0/neutral-host/source-unit/source-postqualification-cf0-01/attempt-01/current-source.json')
RESULT = {'scope': 'Read-only complete installed membership difference; no cache exclusion, product/source qualification, or source/graph mutation', 'state': 'starting', 'pid': os.getpid(), 'pgid': os.getpgrp(), 'startedAtUtc': datetime.datetime.now(datetime.UTC).isoformat()}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def alarm(_signal, _frame):
    raise TimeoutError('Membership diagnosis whole deadline')

signal.signal(signal.SIGALRM, alarm)
signal.setitimer(signal.ITIMER_REAL, 50)

def ps_identity():
    raw = subprocess.run(['/bin/ps', '-ww', '-p', str(os.getpid()), '-o', 'pid=,ppid=,pgid=,lstart=,args='], capture_output=True, check=True, timeout=5).stdout
    fields = raw.decode().split(None, 8)
    assert len(fields) == 9
    return {'pid': int(fields[0]), 'ppid': int(fields[1]), 'pgid': int(fields[2]), 'birth': ' '.join(fields[3:8]), 'argv': fields[8].strip()}

def source_equal():
    raw = SOURCE.read_bytes()
    assert sha(raw) == 'dc3a99ccf2374398dcece0deaf99ebbcbc93dbad1943f66a9d4b02096b32cc89'
    rows = json.loads(raw)
    for row in rows:
        path = ROOT / row['path']
        actual = path.lstat()
        data = path.read_bytes()
        assert path.is_file() and not path.is_symlink()
        assert stat.S_IMODE(actual.st_mode) == row['mode'] and len(data) == row['bytes'] and sha(data) == row['sha256'], 'Source changed: ' + row['path']
    return len(rows)

def metadata(label):
    rows = {}
    for name, argv in [('head', ['rev-parse', 'HEAD']), ('index', ['ls-files', '--stage', '-z']), ('membership', ['ls-files', '-z']), ('status', ['status', '--porcelain=v1', '-z', '--untracked-files=all']), ('staged', ['diff', '--cached', '--binary', '--no-ext-diff']), ('unstaged', ['diff', '--binary', '--no-ext-diff'])]:
        raw = subprocess.run(['/usr/bin/git', '--no-optional-locks', *argv], cwd=ROOT, capture_output=True, check=True, timeout=5).stdout
        path = ATTEMPT / (label + '-' + name + '.bin')
        path.write_bytes(raw)
        rows[name] = {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}
    return rows

def membership():
    raw = WITNESS.read_bytes()
    assert sha(raw) == '75fd8d9e944bd473e66fd56bb01a1196432699bb565731a49f9f38648562a610'
    contexts = []
    for context in json.loads(raw)['contexts']:
        directory = ROOT / context['relativePath']
        if not context['present']:
            assert not directory.exists() and not directory.is_symlink()
            contexts.append({'relativePath': context['relativePath'], 'present': False})
            continue
        info = directory.lstat()
        assert str(info.st_dev) == context['rootIdentity']['device'] and str(info.st_ino) == context['rootIdentity']['inode'] and not directory.is_symlink()
        actual_files, actual_dirs = set(), {'.'}
        for current, names, files in os.walk(directory, followlinks=False):
            for name in names.copy():
                path = Path(current) / name
                relative = str(path.relative_to(directory))
                if path.is_symlink():
                    actual_files.add(relative)
                    names.remove(name)
                else:
                    actual_dirs.add(relative)
            for name in files:
                actual_files.add(str((Path(current) / name).relative_to(directory)))
        old_files = {row['path'] for row in context['files']}
        old_dirs = {row['path'] for row in context['directories']}
        old_changed = []
        for row in context['files']:
            path = directory / row['path']
            if row['path'] not in actual_files:
                continue
            actual = path.lstat()
            data = os.readlink(path).encode() if path.is_symlink() else path.read_bytes()
            if stat.S_IMODE(actual.st_mode) != row['mode'] or len(data) != row['bytes'] or sha(data) != row['sha256']:
                old_changed.append(row['path'])
        additions = []
        for relative in sorted(actual_files - old_files):
            path = directory / relative
            actual = path.lstat()
            data = os.readlink(path).encode() if path.is_symlink() else path.read_bytes()
            additions.append({'path': relative, 'kind': 'symlink' if path.is_symlink() else 'file', 'mode': stat.S_IMODE(actual.st_mode), 'bytes': len(data), 'sha256': sha(data), 'inode': str(actual.st_ino), 'device': str(actual.st_dev), 'mtimeNs': actual.st_mtime_ns})
        contexts.append({'relativePath': context['relativePath'], 'present': True, 'rootIdentity': context['rootIdentity'], 'oldFileRows': len(old_files), 'actualFileRows': len(actual_files), 'oldDirectoryRows': len(old_dirs), 'actualDirectoryRows': len(actual_dirs), 'addedFiles': additions, 'removedFiles': sorted(old_files - actual_files), 'changedOldFiles': old_changed, 'addedDirectories': [{'path': p, 'mode': stat.S_IMODE((directory / p).lstat().st_mode)} for p in sorted(actual_dirs - old_dirs)], 'removedDirectories': sorted(old_dirs - actual_dirs)})
    return contexts

try:
    RESULT['identity'] = ps_identity()
    assert RESULT['identity']['pgid'] == os.getpid() and RESULT['identity']['argv'].endswith(' -B ' + str(Path(__file__).resolve()))
    RESULT['sourceRowsBefore'] = source_equal()
    RESULT['beforeMetadata'] = metadata('before')
    RESULT['contexts'] = membership()
    RESULT['sourceRowsAfter'] = source_equal()
    RESULT['afterMetadata'] = metadata('after')
    assert {k: r['sha256'] for k, r in RESULT['beforeMetadata'].items()} == {k: r['sha256'] for k, r in RESULT['afterMetadata'].items()}
    RESULT['state'] = 'read-only-membership-difference-recorded'
    RESULT['sourceAndSemanticGitInputsUnchanged'] = True
    RESULT['oldFailureReclassifiedOrGraphAccepted'] = False
except BaseException as error:
    RESULT['state'] = 'failed'
    RESULT['failure'] = {'type': type(error).__name__, 'message': str(error)}
    raise
finally:
    RESULT['finishedAtUtc'] = datetime.datetime.now(datetime.UTC).isoformat()
    RESULT['elapsedSeconds'] = time.monotonic() - STARTED
    RESULT['wholeDeadlinePassed'] = RESULT['elapsedSeconds'] <= WHOLE_SECONDS
    (ATTEMPT / 'result.json').write_text(json.dumps(RESULT, indent=2) + '\n')
    print(json.dumps({'state': RESULT['state'], 'result': str(ATTEMPT / 'result.json'), 'pid': os.getpid(), 'pgid': os.getpgrp(), 'elapsedSeconds': RESULT['elapsedSeconds']}))
    assert RESULT['state'] == 'read-only-membership-difference-recorded' and RESULT['wholeDeadlinePassed']
