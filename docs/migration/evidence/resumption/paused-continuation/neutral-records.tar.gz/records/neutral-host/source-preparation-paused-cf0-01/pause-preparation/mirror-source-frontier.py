import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
import time

STARTED = time.monotonic()


def timeout(_signal, _frame):
    raise TimeoutError('Finite paused source-frontier mirror whole 120-second deadline')


signal.signal(signal.SIGALRM, timeout)
signal.setitimer(signal.ITIMER_REAL, 120)
if os.getpgrp() != os.getpid():
    os.setsid()
selection_path = Path(sys.argv[1]).resolve(strict=True)
selection_bytes = selection_path.read_bytes()
selection = json.loads(selection_bytes)
assert selection['wholeDeadlineSeconds'] == 120
destination = Path(selection['destinationRoot'])
output = Path(__file__).parent / 'mirror-result.json'
assert not output.exists()
record = {'scope': selection['scope'], 'selectionSha256': hashlib.sha256(selection_bytes).hexdigest(),
          'startedAtUtc': datetime.datetime.now(datetime.UTC).isoformat(), 'pid': os.getpid(), 'pgid': os.getpgrp(), 'state': 'starting'}


def qualify_source(row):
    path = Path(row['source'])
    assert path.is_file() and not path.is_symlink() and path.resolve(strict=True) == path
    info = path.stat()
    data = path.read_bytes()
    assert stat.S_IMODE(info.st_mode) == row['mode']
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    return info, data


try:
    assert sys.version_info[:3] == (3, 14, 6)
    raw = subprocess.run(['/bin/ps', '-ww', '-axo', 'pid=,ppid=,pgid=,lstart=,args='], capture_output=True, check=True, timeout=5).stdout
    for line in raw.decode().splitlines():
        fields = line.split(None, 8)
        if len(fields) == 9 and int(fields[0]) == os.getpid():
            record['identity'] = {'pid': int(fields[0]), 'ppid': int(fields[1]), 'pgid': int(fields[2]), 'birth': ' '.join(fields[3:8]), 'argv': fields[8]}
    assert record['identity']['pgid'] == os.getpid()
    assert record['identity']['argv'].endswith(' -B ' + str(Path(__file__).resolve()) + ' ' + str(selection_path))
    assert not destination.exists() and not destination.is_symlink()
    assert destination.parent.resolve(strict=True) == destination.parent
    names = {row['destinationRelative'] for row in selection['rows']}
    assert len(names) == len(selection['rows'])
    for row in selection['rows']:
        relative = Path(row['destinationRelative'])
        assert not relative.is_absolute() and '..' not in relative.parts
        qualify_source(row)
    destination.mkdir()
    copied = []
    for row in selection['rows']:
        source_identity, data = qualify_source(row)
        target = destination / row['destinationRelative']
        target.parent.mkdir(parents=True, exist_ok=True)
        assert target.parent.resolve(strict=True) == target.parent
        with target.open('xb') as stream:
            stream.write(data)
        target.chmod(row['mode'])
        info = target.stat()
        actual = target.read_bytes()
        assert (info.st_dev, info.st_ino) != (source_identity.st_dev, source_identity.st_ino)
        assert info.st_nlink == 1 and stat.S_IMODE(info.st_mode) == row['mode']
        assert len(actual) == row['bytes'] and hashlib.sha256(actual).hexdigest() == row['sha256']
        qualify_source(row)
        copied.append({**row, 'destination': str(target), 'sourceIdentity': {'device': source_identity.st_dev, 'inode': source_identity.st_ino},
                       'destinationIdentity': {'device': info.st_dev, 'inode': info.st_ino}, 'independentInode': True, 'sourceAndDestinationEqual': True})
    actual_names = {str(path.relative_to(destination)) for path in destination.rglob('*') if path.is_file()}
    assert actual_names == names
    for row in selection['rows']:
        qualify_source(row)
    record['rows'] = copied
    record['copiedBytes'] = sum(row['bytes'] for row in copied)
    assert record['copiedBytes'] == selection['totalBytes']
    record['state'] = 'paused-source-frontier-mirror-qualified'
except BaseException as error:
    record['state'] = 'failed'
    record['failure'] = {'name': type(error).__name__, 'message': str(error)}
    raise
finally:
    record['finishedAtUtc'] = datetime.datetime.now(datetime.UTC).isoformat()
    record['elapsedSeconds'] = time.monotonic() - STARTED
    record['wholeDeadlinePassed'] = record['elapsedSeconds'] <= 120
    with output.open('x') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
    assert record['state'] == 'paused-source-frontier-mirror-qualified' and record['wholeDeadlinePassed']
    print(json.dumps({'path': str(output), 'pid': record['pid'], 'pgid': record['pgid'], 'rows': len(record['rows']), 'bytes': record['copiedBytes'], 'elapsedSeconds': record['elapsedSeconds']}))
