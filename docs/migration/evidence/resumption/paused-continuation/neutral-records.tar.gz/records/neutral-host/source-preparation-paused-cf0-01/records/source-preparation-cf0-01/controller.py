import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
import time

STARTED = time.monotonic()
WHOLE_SECONDS = 180
FINAL_SECONDS = 15
active = None
attempt = Path(__file__).parent / 'attempt-01'
assert not attempt.exists()
attempt.mkdir()
if os.getpgrp() != os.getpid():
    os.setsid()
record = {'owner': 'retained_control', 'state': 'starting', 'startedAtUtc': datetime.datetime.now(datetime.UTC).isoformat(), 'pid': os.getpid(), 'pgid': os.getpgrp(), 'children': [], 'scope': 'Exact selected source status/format/staging preparation only; no tests/check/lint/install/build/browser/rival'}
inputs_path = Path(__file__).parent / 'inputs.json'
inputs_bytes = inputs_path.read_bytes()
assert hashlib.sha256(inputs_bytes).hexdigest() == '1be594a6a0e94ae6b52c67fecdaa1f5d7e8abed1d3cf4526015091f7be21910f'
inputs = json.loads(inputs_bytes)
root = Path(inputs['worktree'])
record['inputsSha256'] = hashlib.sha256(inputs_bytes).hexdigest()


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def remaining():
    return max(0.001, STARTED + WHOLE_SECONDS - time.monotonic())


def alarm(_signum, _frame):
    raise TimeoutError('Selected source-preparation whole deadline')


signal.signal(signal.SIGALRM, alarm)
signal.setitimer(signal.ITIMER_REAL, WHOLE_SECONDS - FINAL_SECONDS)


def ps_rows():
    data = subprocess.run(['/bin/ps', '-ww', '-axo', 'pid=,ppid=,pgid=,lstart=,args='], capture_output=True, check=True, timeout=min(5, remaining())).stdout
    rows = []
    for line in data.decode().splitlines():
        fields = line.split(None, 8)
        if len(fields) == 9:
            rows.append({'pid': int(fields[0]), 'ppid': int(fields[1]), 'pgid': int(fields[2]), 'birth': ' '.join(fields[3:8]), 'argv': fields[8]})
    return rows


def identity(pid):
    return next((row for row in ps_rows() if row['pid'] == pid), None)


def git(*args):
    return subprocess.run(['/usr/bin/git', '--no-optional-locks', *args], cwd=root, capture_output=True, check=True, timeout=min(10, remaining())).stdout


def file_bind(row):
    path = Path(row['path'])
    assert path.is_file() and not path.is_symlink() and path.resolve(strict=True) == path
    data = path.read_bytes()
    assert stat.S_IMODE(path.lstat().st_mode) == row['mode'] and len(data) == row['bytes'] and sha(data) == row['sha256'], 'Changed frozen input: ' + str(path)


def source_rows(expected):
    rows = []
    for old in expected:
        path = root / old['path']
        assert path.is_file() and not path.is_symlink()
        data = path.read_bytes()
        row = {'path': old['path'], 'mode': stat.S_IMODE(path.lstat().st_mode), 'bytes': len(data), 'sha256': sha(data)}
        assert all(row[k] == old[k] for k in row), 'Source byte/mode drift: ' + old['path']
        rows.append(row)
    return rows


def metadata(label):
    result = {}
    for name, args in [('head', ['rev-parse', 'HEAD']), ('tree', ['rev-parse', 'HEAD^{tree}']), ('branch', ['branch', '--show-current']), ('index', ['ls-files', '--stage', '-z']), ('membership', ['ls-files', '-z']), ('status', ['status', '--porcelain=v1', '-z', '--untracked-files=all']), ('staged-diff', ['diff', '--cached', '--binary', '--no-ext-diff']), ('unstaged-diff', ['diff', '--binary', '--no-ext-diff'])]:
        data = git(*args)
        path = attempt / (label + '-' + name + '.bin')
        path.write_bytes(data)
        result[name] = {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}
    return result


def index_map(data):
    result = {}
    for raw in data.split(b'\0'):
        if raw:
            header, path = raw.split(b'\t', 1)
            mode, oid, stage = header.split()
            assert stage == b'0'
            result[path.decode()] = (mode.decode(), oid.decode())
    return result


def installed_preserved(label):
    witness_path = Path('/private/tmp/splotch-resume-01a111b0/neutral-host/source-unit/current-inputs-preparation-v2/attempt-01/after-installed.json')
    data = witness_path.read_bytes()
    assert sha(data) == '75fd8d9e944bd473e66fd56bb01a1196432699bb565731a49f9f38648562a610'
    witness = json.loads(data)
    observations = []
    for context in witness['contexts']:
        directory = root / context['relativePath']
        if not context['present']:
            assert not directory.exists() and not directory.is_symlink()
            observations.append({'relativePath': context['relativePath'], 'present': False})
            continue
        info = directory.lstat()
        assert not directory.is_symlink() and str(info.st_dev) == context['rootIdentity']['device'] and str(info.st_ino) == context['rootIdentity']['inode']
        for row in context['files']:
            path = directory / row['path']
            actual = path.lstat()
            assert stat.S_IMODE(actual.st_mode) == row['mode'] and actual.st_size == row['bytes']
            if row['kind'] == 'symlink':
                assert path.is_symlink() and os.readlink(path) == row['link']
                assert os.path.relpath(path.resolve(strict=True), directory) == row['target']
                raw = os.readlink(path).encode()
            else:
                assert path.is_file() and not path.is_symlink()
                raw = path.read_bytes()
            assert sha(raw) == row['sha256'], 'Installed byte drift: ' + str(path)
        expected_files = {row['path'] for row in context['files']}
        expected_dirs = {row['path'] for row in context['directories']}
        actual_files, actual_dirs = set(), {'.'}
        for current, names, files in os.walk(directory, followlinks=False):
            for name in names.copy():
                path = Path(current) / name
                relative = str(path.relative_to(directory))
                if path.is_symlink():
                    actual_files.add(relative)
                    names.remove(name)
                else:
                    actual_dirs.add(relative)
            for name in files:
                actual_files.add(str((Path(current) / name).relative_to(directory)))
        assert actual_files == expected_files and actual_dirs == expected_dirs
        for row in context['directories']:
            path = directory if row['path'] == '.' else directory / row['path']
            assert path.is_dir() and not path.is_symlink() and stat.S_IMODE(path.lstat().st_mode) == row['mode']
        observations.append({'relativePath': context['relativePath'], 'present': True, 'rootIdentity': context['rootIdentity'], 'fileRowsRequalified': len(expected_files), 'directoryRowsRequalified': len(expected_dirs), 'completeMembershipEqual': True, 'baselineInventorySha256': context['inventorySha256']})
    receipt = {'scope': 'Byte/mode/link/membership equality with prior maintained full witness only; no new manager or relaxed graph acceptance', 'baselinePath': str(witness_path), 'baselineSha256': sha(data), 'contexts': observations}
    (attempt / (label + '-installed-preservation.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    return receipt


def current_proof(item):
    live = identity(item['pid'])
    assert live and live == item['identity'] and live['ppid'] == os.getpid() and live['pgid'] == live['pid'], 'No current owned identity; decline signal'
    return live


def release_active():
    global active
    if active is None:
        return
    child, item = active
    if child.poll() is None:
        proof = current_proof(item)
        item['signals'].append({'signal': 'SIGTERM', 'at': now(), 'proof': proof})
        os.killpg(child.pid, signal.SIGTERM)
        try:
            child.wait(timeout=min(5, remaining()))
        except subprocess.TimeoutExpired:
            proof = current_proof(item)
            item['signals'].append({'signal': 'SIGKILL', 'at': now(), 'proof': proof})
            os.killpg(child.pid, signal.SIGKILL)
            child.wait(timeout=min(5, remaining()))
    item['releaseObservedAtUtc'] = now()
    item['remainingGroupRows'] = [row for row in ps_rows() if row['pgid'] == child.pid]
    assert not item['remainingGroupRows'], 'Unresolved owned Git group'
    active = None


def run_child(label, argv, seconds=30):
    global active
    item = {'label': label, 'argv': argv, 'startedAtUtc': now(), 'signals': [], 'cwd': str(root)}
    record['children'].append(item)
    stdout_path, stderr_path = attempt / (label + '.stdout.log.txt'), attempt / (label + '.stderr.log.txt')
    with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
        child = subprocess.Popen(argv, cwd=root, env=environment, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, start_new_session=True)
        item['pid'] = child.pid
        item['identity'] = identity(child.pid)
        item['fullLiveArgvObserved'] = bool(item['identity'] and item['identity']['argv'] not in ['(git)', '(node)'])
        active = (child, item)
        assert item['fullLiveArgvObserved'], 'Source-preparation full live argv unavailable; setup refusal'
        assert item['identity']['ppid'] == os.getpid() and item['identity']['pgid'] == child.pid
        item['exitCode'] = child.wait(timeout=min(seconds, remaining() - FINAL_SECONDS))
    for name, path in [('stdout', stdout_path), ('stderr', stderr_path)]:
        raw = path.read_bytes()
        item[name] = {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}
    item['finishedAtUtc'] = now()
    release_active()
    assert item['exitCode'] == 0, 'Actual selected preparation child failed: ' + label


try:
    record['identity'] = identity(os.getpid())
    assert record['identity']['pgid'] == os.getpid() and record['identity']['argv'].endswith(' -B ' + str(Path(__file__).resolve()))
    expected_source = json.loads(Path(inputs['sourceBefore']).read_bytes())
    before_rows = source_rows(expected_source)
    (attempt / 'before-source.json').write_text(json.dumps(before_rows, indent=2) + '\n')
    for row in inputs['ownedSourceRows'] + inputs['protectedRetainedRows'] + [inputs['acceptedMigrationReadme'], inputs['protectedUnrelatedLedger']] + inputs['protectedImmutableRetainedPublication']:
        file_bind(row)
    for row in inputs['actualOwners']:
        path = Path(row['path'])
        assert str(path.resolve(strict=True)) == row['realPath']
        data = path.read_bytes()
        assert len(data) == row['bytes'] and sha(data) == row['sha256'] and stat.S_IMODE(path.stat().st_mode) == row['mode']
    record['beforeInstalled'] = installed_preserved('before')
    record['beforeMetadata'] = metadata('before')
    assert git('rev-parse', 'HEAD').decode().strip() == inputs['head']
    for name, row in inputs['metadata'].items():
        if name in record['beforeMetadata']:
            assert record['beforeMetadata'][name]['sha256'] == row['sha256']
    environment = {key: os.environ[key] for key in ['HOME', 'USER', 'LOGNAME', 'LANG', 'LC_ALL', 'TMPDIR'] if key in os.environ}
    environment.update({'PATH': str(Path(inputs['node']).parent) + ':/usr/bin:/bin:/usr/sbin:/sbin', 'CI': 'true', 'NODE_DISABLE_COMPILE_CACHE': '1', 'COREPACK_ENABLE_NETWORK': '0'})
    run_child('registered-info', [inputs['node'], inputs['npmCli'], 'run', 'info'])
    proposal = Path(inputs['unitDocProposal']).read_bytes()
    assert sha(proposal) == inputs['unitDocProposalSha256']
    (root / 'docs/migration/NEUTRAL-HOST.md').write_bytes(proposal)
    run_child('selected-prettier', [inputs['node'], str(root / 'node_modules/prettier/bin/prettier.cjs'), '--write', *inputs['formatPaths']], 60)
    run_child('selected-dprint', [inputs['node'], inputs['npmCli'], 'run', 'format:md', '--', 'docs/migration/NEUTRAL-HOST.md'], 60)
    initial_package = inputs['currentPackage']['sha256']
    actual_package = sha((root / 'package.json').read_bytes())
    record['rootManifestRawByteChangedByFormatting'] = actual_package != initial_package
    if actual_package != initial_package:
        run_child('actual-input-generator-after-format', [inputs['node'], str(root / 'tools/migration/gen-topology-proof-inputs.mjs')])
    assert sha((root / 'pnpm-lock.yaml').read_bytes()) == inputs['currentLock']['sha256']
    run_child('stage-exact-owned50', ['/usr/bin/git', '-c', 'core.hooksPath=/dev/null', 'add', '--', *inputs['ownedSourcePaths']])
    assert not git('diff', '--name-only', '-z')
    assert not git('ls-files', '--others', '--exclude-standard', '-z')
    assert set(git('diff', '--cached', '--name-only', '-z').decode().rstrip('\0').split('\0')) == set(inputs['ownedSourcePaths'])
    after_rows, changes = [], []
    for old in expected_source:
        path = root / old['path']
        assert path.is_file() and not path.is_symlink()
        data = path.read_bytes()
        current = {'path': old['path'], 'mode': stat.S_IMODE(path.lstat().st_mode), 'bytes': len(data), 'sha256': sha(data)}
        assert current['mode'] == old['mode']
        before = {k: old[k] for k in current}
        if current != before:
            assert old['path'] in inputs['ownedSourcePaths'], 'Unexpected source change: ' + old['path']
            changes.append({'path': old['path'], 'before': before, 'after': current, 'disposition': 'explicit-unit-status-amendment' if old['path'] == 'docs/migration/NEUTRAL-HOST.md' else 'existing-selected-formatter'})
        after_rows.append(current)
    assert set(git('ls-files', '-z').decode().rstrip('\0').split('\0')) == {r['path'] for r in after_rows}
    index = index_map(git('ls-files', '--stage', '-z'))
    for row in after_rows:
        data = (root / row['path']).read_bytes()
        actual_oid = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert index[row['path']] == ('100755' if row['mode'] & 0o111 else '100644', actual_oid)
    (attempt / 'after-source.json').write_text(json.dumps(after_rows, indent=2) + '\n')
    (attempt / 'format-and-status-deltas.json').write_text(json.dumps(changes, indent=2) + '\n')
    for row in inputs['protectedRetainedRows'] + [inputs['acceptedMigrationReadme'], inputs['protectedUnrelatedLedger']] + inputs['protectedImmutableRetainedPublication']:
        file_bind(row)
    for row in inputs['incomingRows']:
        data = (root / row['path']).read_bytes()
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
    record['afterInstalled'] = installed_preserved('after')
    assert record['afterInstalled'] == record['beforeInstalled']
    record['afterMetadata'] = metadata('after')
    record['actualOwnedPaths'] = inputs['ownedSourcePaths']
    record['all50StagedNoUnstagedUntracked'] = True
    record['currentSourceRows'] = len(after_rows)
    record['formatAndStatusChanges'] = changes
    record['lockManagerBytesUnchanged'] = True
    record['protectedAndIncomingOwnersUnchanged'] = True
    record['completeInstalledPhysicalRowsEqual'] = True
    record['sourceHead'] = git('rev-parse', 'HEAD').decode().strip()
    record['state'] = 'selected-source-preparation-qualified'
except BaseException as error:
    record['state'] = 'failed'
    record['failure'] = {'type': type(error).__name__, 'message': str(error)}
    try:
        release_active()
    except BaseException as cleanup:
        record['unresolvedOwnership'] = {'type': type(cleanup).__name__, 'message': str(cleanup)}
    raise
finally:
    signal.setitimer(signal.ITIMER_REAL, min(FINAL_SECONDS, remaining()))
    record['finishedAtUtc'] = now()
    record['elapsedSeconds'] = time.monotonic() - STARTED
    record['wholeDeadlinePassed'] = record['elapsedSeconds'] <= WHOLE_SECONDS
    record['activeOwnedChildRemaining'] = active is not None
    (attempt / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'state': record['state'], 'path': str(attempt / 'result.json'), 'pid': os.getpid(), 'pgid': os.getpgrp(), 'elapsedSeconds': record['elapsedSeconds']}))
    assert record['state'] == 'selected-source-preparation-qualified' and record['wholeDeadlinePassed'] and active is None
