import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { readWebHostArtifact } from '/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch/tools/migration/lib/web-host-artifact.mjs';
const root = '/private/tmp/splotch-neutral-resume-670_yiah/release-cost-artifacts-02/splotch-web-host-PvYSWi';
const inputsBytes = readFileSync(root + '/inputs.json');
const resultBytes = readFileSync(root + '/result.json');
let refusal;
try { readWebHostArtifact(root); } catch (error) { refusal = error.message; }
assert.equal(refusal, 'Only a completed, source-bound structural build artifact can be checked/served');
assert.ok(inputsBytes.equals(readFileSync(root + '/inputs.json')));
assert.ok(resultBytes.equals(readFileSync(root + '/result.json')));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
console.log(JSON.stringify({ scope: 'Actual strict failed-artifact reader; incomplete neutral input freeze is preserved, no serving, cost measurement or acceptance', refusal, inputsSha256: sha(inputsBytes), resultSha256: sha(resultBytes), publicBytesUnchanged: true }));
