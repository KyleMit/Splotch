import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync, spawnSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const worktree = '/private/tmp/splotch-f1-ff900-20261008/Splotch';
const output = '/private/tmp/splotch-f1-ff900-20261008/evidence';
const TIMEOUT_MS = 180_000;
const git = (...args) => execFileSync('git', args, { cwd: worktree });
const digest = (bytes) => createHash('sha256').update(bytes).digest('hex');
const historical = JSON.parse(readFileSync(join(worktree, 'docs/migration/evidence/import-boundary-current-base-cf0/controls/source-inputs.json.txt')));
const files = Object.fromEntries(Object.keys(historical.files).map((path) => [path, digest(readFileSync(join(worktree, path)))]));
const index = digest(git('ls-files', '--stage', '-z'));
const toolFiles = git('ls-files', 'tools').toString().split('\n').filter((path) => path.endsWith('.mjs'));
const source = { preparationHead: git('rev-parse', 'HEAD').toString().trim(), acceptedBase: git('rev-parse', 'MERGE_HEAD').toString().trim(), files, semanticIndexSha256: index, trackedToolFiles: { count: toolFiles.length, sha256: digest(toolFiles.join('\n') + '\n') } };
writeFileSync(join(output, 'source-inputs.json.txt'), JSON.stringify(source, null, 2) + '\n');
function verify() {
  for (const [path, sha256] of Object.entries(files)) assert.equal(digest(readFileSync(join(worktree, path))), sha256, path);
  assert.equal(digest(git('ls-files', '--stage', '-z')), index);
  assert.equal(git('diff', '--name-only').length, 0);
}
const commands = [
  ['scoped', ['run', 'test:tools', '--', 'tools/migration/tests/candidate-imports.test.mjs', 'tools/migration/tests/candidate-configs.test.mjs', 'tools/migration/tests/ownership.test.mjs', 'tools/migration/tests/production-closure.test.mjs', 'tools/migration/tests/forge-mitigation.test.mjs', 'tools/tests/tool-specifier-resolution.test.mjs']],
  ...['check', 'lint', 'format:check', 'check:migration:native-topology', 'check:doc-refs'].map((script) => [script.replaceAll(':', '-'), ['run', script]]),
];
const records = [];
for (const [label, args] of commands) {
  verify();
  const startedAt = new Date().toISOString();
  const result = spawnSync('npm', args, { cwd: worktree, timeout: TIMEOUT_MS, encoding: 'utf8', maxBuffer: 32 * 1024 * 1024, env: { ...process.env, DPRINT_CACHE_DIR: join(output, 'dprint-cache') } });
  const log = `${label}.log.txt`;
  writeFileSync(join(output, log), (result.stdout ?? '') + (result.stderr ?? ''));
  let invariantError = null;
  try { verify(); } catch (error) { invariantError = String(error); }
  const record = { command: ['npm', ...args], startedAt, finishedAt: new Date().toISOString(), exit: result.status, signal: result.signal, error: result.error?.message ?? null, invariantError, log };
  records.push(record);
  writeFileSync(join(output, 'source-gates.json.txt'), JSON.stringify({ source, records }, null, 2) + '\n');
  console.log(JSON.stringify(record));
  if (record.exit !== 0 || record.signal || record.error || invariantError) process.exit(1);
}
verify();
