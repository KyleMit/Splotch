import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync, writeFileSync, mkdirSync, readdirSync, statSync, realpathSync } from 'node:fs';
import { basename, dirname, join, relative } from 'node:path';
import { pathToFileURL } from 'node:url';
const unit = '/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch';
const root = '/private/tmp/splotch-resume-01a111b0/retained/sw-diagnosis';
const artifactRoot = '/private/tmp/splotch-resume-01a111b0/retained/public-calls/release/splotch-web-host-zWQlPc';
const { freezeSource, assertSourceUnchanged, sourceGit, sha256 } = await import(pathToFileURL(join(unit, 'tools/migration/lib/web-host-source.mjs')));
const { assertFinalInputBindings } = await import(pathToFileURL(join(unit, 'tools/migration/lib/web-host-inputs.mjs')));
const { fileInventory } = await import(pathToFileURL(join(unit, 'tools/migration/lib/web-host-files.mjs')));
const { compareProductBytes } = await import(pathToFileURL(join(unit, 'tools/migration/lib/web-host-comparison.mjs')));
const { copiedBuildEnvironment } = await import(pathToFileURL(join(unit, 'tools/migration/lib/web-host-build.mjs')));
const inputsBytes = readFileSync(join(artifactRoot, 'inputs.json'));
const inputs = JSON.parse(inputsBytes);
const marker = JSON.parse(readFileSync(join(artifactRoot, '.splotch-web-host.json')));
const owned = { root: artifactRoot, token: marker.token };
const options = { babelPresetEnvTargets: ['chrome >= 56'], inlineWorkboxRuntime: false, mode: 'production', sourcemap: false };
const report = { started: new Date().toISOString(), caller: process.argv, execPath: process.execPath, node: process.version, artifactRoot, sourceSha: inputs.snapshot.sha, sourceTree: sourceGit(unit, ['rev-parse', 'HEAD^{tree}']).trim(), inputsSha256: sha256(inputsBytes), options, optionOwners: ['web/vite.config.ts', 'node_modules/vite-plugin-pwa/dist/index.js', 'node_modules/workbox-build/build/schema/GenerateSWOptions.json', 'node_modules/workbox-build/build/lib/bundle.js'], steps: [], classification: 'bounded causal diagnostic, not product acceptance', limits: ['Workbox generated-set equivalence only', 'no deployed offline/update runtime claim', 'no output-normalization allowance changed', 'no source graph/cache or release-mode change'] };
const snapshot = freezeSource({ root: unit, topologySha: inputs.snapshot.topologySha, topologyLockSha256: inputs.snapshot.topologyLockSha256, provisional: false });
assert.equal(snapshot.sha, '3a92d297bc2c48f7a372e89cbe764bd498adcb9f');
writeFileSync(join(root, 'source-before.json'), JSON.stringify({ ...snapshot, tree: report.sourceTree }, null, 2) + '\n', { flag: 'wx' });
await assertFinalInputBindings(owned, inputs.bindings);
const roles = {};
const envBefore = { ...process.env };
const cwdBefore = process.cwd();
const restoredInstalledRows = fileInventory(join(unit, 'node_modules'));
writeFileSync(join(root, 'replacement-installed-before.json'), JSON.stringify(restoredInstalledRows) + '\n', { flag: 'wx' });
function moduleIdentity(copy) {
 const owner = join(copy, 'node_modules/workbox-build/build/lib/bundle.js');
 const req = createRequire(owner);
 const paths = [owner, join(copy, 'node_modules/workbox-build/build/lib/write-sw-using-default-template.js'), join(copy, 'node_modules/workbox-build/build/schema/GenerateSWOptions.json'), join(copy, 'node_modules/vite-plugin-pwa/dist/index.js'), join(copy, 'web/vite.config.ts')];
 for (const name of ['@rollup/plugin-babel', '@rollup/plugin-node-resolve', 'rollup', '@rollup/plugin-terser', '@trickfilm400/rollup-plugin-off-main-thread', '@babel/preset-env', '@rollup/plugin-replace', 'tempy', 'fs-extra', 'upath']) paths.push(req.resolve(name));
 const terser = createRequire(req.resolve('@rollup/plugin-terser')).resolve('terser');
 paths.push(terser, join(dirname(terser), '../lib/scope.js'));
 return paths.map(path => ({ path, realPath: realpathSync(path), bytes: statSync(path).size, sha256: sha256(readFileSync(path)) }));
}
for (const role of ['reference', 'control']) {
 const copy = join(artifactRoot, role);
 const raw = readFileSync(join(root, role + '-raw-sw.js.txt'), 'utf8');
 const urls = [...new Set(raw.match(/\/\?app-shell-build=[a-f0-9-]{36}/g))];
 assert.equal(urls.length, 1);
 const nonceCount = raw.split(urls[0]).length - 1;
 assert.equal(nonceCount, 3);
 const client = join(copy, 'web/.svelte-kit/output/client');
 const generated = readdirSync(client).filter(name => name === 'sw.js' || /^workbox-[a-f0-9]+\.js(?:\.map)?$/.test(name) || name === 'sw.js.map').sort();
 assert.deepEqual(generated, ['sw.js', 'workbox-10e0918b.js']);
 roles[role] = { copy, raw, shellUrl: urls[0], nonceCount, generated, modules: moduleIdentity(copy), original: Object.fromEntries(generated.map(name => [name, sha256(readFileSync(join(client, name)))])), cleanupImport: sha256(readFileSync(join(client, 'sw-page-cache-cleanup-09c341cd.js'))) };
}
assert.equal(roles.reference.cleanupImport, roles.control.cleanupImport);
report.restoredInstalledModules = moduleIdentity(unit);
for (const role of Object.values(roles)) {
 assert.deepEqual(report.restoredInstalledModules.map(entry => [entry.bytes, entry.sha256]), role.modules.map(entry => [entry.bytes, entry.sha256]));
}
report.restoredInstalledInventory = { count: restoredInstalledRows.length, sha256: sha256(JSON.stringify(restoredInstalledRows)), evidence: 'replacement-installed-before.json' };
const rawNormalized = role => role.raw.replaceAll(role.copy + '/', '<owned-copy>/').replaceAll(role.shellUrl, '<recorded-app-shell>');
assert.equal(rawNormalized(roles.reference), rawNormalized(roles.control));
report.roles = Object.fromEntries(Object.entries(roles).map(([role, value]) => [role, { copy: value.copy, shellUrl: value.shellUrl, nonceCount: value.nonceCount, originalFiles: value.original, modules: value.modules, rawSha256: sha256(value.raw), normalizedRawSha256: sha256(rawNormalized(value)), cleanupImportSha256: value.cleanupImport }]));
writeFileSync(join(root, 'invocation-before.json'), JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
async function run(label, role, raw) {
 const target = join(root, label);
 mkdirSync(target, { recursive: false });
 const env = copiedBuildEnvironment(owned, role.copy, 'release', inputs.pinned.env);
 process.chdir(role.copy);
 for (const name of Object.keys(process.env)) delete process.env[name];
 Object.assign(process.env, env, { NODE_ENV: 'production' });
 const { bundle } = createRequire(join(role.copy, 'package.json'))(join(role.copy, 'node_modules/workbox-build/build/lib/bundle.js'));
 const started = new Date().toISOString();
 const files = await bundle({ ...options, swDest: join(role.copy, 'web/.svelte-kit/output/client/sw.js'), unbundledCode: raw });
 const emitted = files.map(file => basename(file.name)).sort();
 assert.deepEqual(emitted, role.generated);
 const rows = [];
 for (const file of files) {
  const path = join(target, basename(file.name));
  writeFileSync(path, file.contents, { flag: 'wx' });
  rows.push({ name: basename(file.name), originalDest: file.name, bytes: readFileSync(path).length, sha256: sha256(readFileSync(path)) });
 }
 const row = { label, ownerRole: role === roles.reference ? 'reference' : 'control', started, finished: new Date().toISOString(), sourceRawSha256: sha256(raw), resolvedOwner: join(role.copy, 'node_modules/workbox-build/build/lib/bundle.js'), swDest: join(role.copy, 'web/.svelte-kit/output/client/sw.js'), environment: Object.fromEntries(Object.entries(env).filter(([key]) => !['HOME','USER','LOGNAME','PATH'].includes(key))), environmentSha256: sha256(JSON.stringify(env)), emitted: rows.sort((a,b) => a.name.localeCompare(b.name)), outputRoot: target };
 report.steps.push(row);
 return row;
}
function assertOriginal(step, role) {
 for (const file of step.emitted) assert.equal(file.sha256, role.original[file.name], step.label + ':' + file.name);
}
function actualCompare(left, right, leftUrl, rightUrl) {
 return compareProductBytes({ referenceRoot: left.outputRoot, controlRoot: right.outputRoot, reference: { appShellUrl: leftUrl, outputs: { '.': fileInventory(left.outputRoot) } }, control: { appShellUrl: rightUrl, outputs: { '.': fileInventory(right.outputRoot) } } });
}
try {
 const ref = await run('reference-reproduced', roles.reference, roles.reference.raw);
 assertOriginal(ref, roles.reference);
 const control = await run('control-reproduced', roles.control, roles.control.raw);
 assertOriginal(control, roles.control);
 report.originalProductComparison = { expected: 'reject the recorded unexplained generated bytes' };
 assert.throws(() => actualCompare(ref, control, roles.reference.shellUrl, roles.control.shellUrl), error => { report.originalProductComparison.message = error.message; return error.message === 'Unexplained retained-control product bytes differ: ./sw.js'; });
 const substituted = roles.control.raw.replaceAll(roles.control.shellUrl, roles.reference.shellUrl);
 assert.equal(substituted.split(roles.control.shellUrl).length - 1, 0);
 assert.equal(substituted.split(roles.reference.shellUrl).length - 1, 3);
 assert.equal(substituted.replaceAll(roles.control.copy + '/', '<owned-copy>/'), roles.reference.raw.replaceAll(roles.reference.copy + '/', '<owned-copy>/'));
 const nonce = await run('control-nonce-only', roles.control, substituted);
 assertOriginal(nonce, roles.reference);
 report.nonceOnlyPositive = actualCompare(ref, nonce, roles.reference.shellUrl, roles.reference.shellUrl);
 const oldHandler = 'if (canonicalResponse) return canonicalResponse;';
 const newHandler = 'if (canonicalResponse) return new Response("retained-control-reject", { status: 418 });';
 assert.equal(substituted.split(oldHandler).length - 1, 1);
 const mutated = substituted.replace(oldHandler, newHandler);
 assert.equal(mutated.split('retained-control-reject').length - 1, 1);
 const negative = await run('control-handler-reject', roles.control, mutated);
 const generatedWorker = readFileSync(join(negative.outputRoot, 'sw.js'), 'utf8');
 assert(generatedWorker.includes('retained-control-reject'));
 assert(/status:418/.test(generatedWorker));
 report.handlerMutation = { before: oldHandler, after: newHandler, sourceOccurrences: 1, emittedSentinelRetained: true, emittedStatusRetained: true };
 assert.throws(() => actualCompare(ref, negative, roles.reference.shellUrl, roles.reference.shellUrl), error => { report.handlerMutation.rejection = error.message; return error.message === 'Unexplained retained-control product bytes differ: ./sw.js'; });
 report.restoredPositive = actualCompare(ref, nonce, roles.reference.shellUrl, roles.reference.shellUrl);
 report.status = 'diagnostic-passed';
} catch (error) {
 report.status = 'diagnostic-failed';
 report.error = { name: error.name, message: error.message, stack: error.stack };
 process.exitCode = 1;
} finally {
 for (const name of Object.keys(process.env)) delete process.env[name];
 Object.assign(process.env, envBefore);
 process.chdir(cwdBefore);
 assertSourceUnchanged(snapshot);
 await assertFinalInputBindings(owned, inputs.bindings);
 for (const role of Object.values(roles)) assert.deepEqual(moduleIdentity(role.copy), role.modules);
 assert.deepEqual(moduleIdentity(unit), report.restoredInstalledModules);
 const restoredInstalledAfter = fileInventory(join(unit, 'node_modules'));
 assert.deepEqual(restoredInstalledAfter, restoredInstalledRows);
 report.restoredInstalledAfterSha256 = sha256(JSON.stringify(restoredInstalledAfter));
 const after = freezeSource({ root: unit, topologySha: snapshot.topologySha, topologyLockSha256: snapshot.topologyLockSha256, provisional: false });
 assert.deepEqual(after, snapshot);
 report.sourceUnchanged = true;
 report.installedRolesUnchanged = true;
 report.finished = new Date().toISOString();
 report.sourceBeforeSha256 = sha256(readFileSync(join(root, 'source-before.json')));
 writeFileSync(join(root, 'source-after.json'), JSON.stringify({ ...after, tree: sourceGit(unit, ['rev-parse','HEAD^{tree}']).trim() }, null, 2) + '\n', { flag: 'wx' });
 report.sourceAfterSha256 = sha256(readFileSync(join(root, 'source-after.json')));
 writeFileSync(join(root, 'diagnostic.json'), JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
 console.log(JSON.stringify({ status: report.status, sourceSha: report.sourceSha, steps: report.steps.map(s => ({label:s.label, files:s.emitted})), handlerMutation: report.handlerMutation, error: report.error, sourceUnchanged: report.sourceUnchanged }));
}
