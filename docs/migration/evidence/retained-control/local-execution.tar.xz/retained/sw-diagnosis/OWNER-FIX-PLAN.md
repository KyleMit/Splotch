# Service-worker nonce owner repair plan

This is a proposal for independent plan challenge, not implementation or retained-unit acceptance.

The source-bound public release build at 3a92d297bc2c48f7a372e89cbe764bd498adcb9f (tree db24062b33250e879b7696fcff1c5646029e0d68) correctly rejected differing service-worker bytes. The actual shipping PWA owner uses a fresh app-shell UUID for each build. Workbox's installed production Rollup/Terser pipeline receives that UUID inside three string literals; its character-frequency mangling can change other emitted identifiers. The existing comparator's exact recorded-URL replacement cannot erase those induced identifier differences.

The bounded causal replay is in diagnostic.json. Both original complete generated sets were reproduced byte-for-byte by their own frozen installed Workbox owners, production options and original role imports. Replacing only the control's three recorded UUID occurrences emitted the complete reference generated set exactly. A real canonical-cache handler mutation retained its sentinel and status in minified output and failed the actual unchanged product-byte comparator for the intended sw.js reason. Restoring the exact positive emitted set passed. Complete pre/post source and installed-input witnesses remain equal. This proves this recorded discrepancy's nonce cause; it does not establish deployed offline/update acceptance.

Recommended ordinary implementation: give the actual shipping app-shell nonce owner a strict optional frozen build input, analogous to existing build metadata. Keep randomUUID() as the ordinary unpinned default. Mint one fresh nonce per owned artifact through that actual copied owner and pass it to both copies through their bounded environment. Pinning must happen before real production generation/minification. Keep the complete output comparator, emitted inventory, mode/kind, version, startup/lazy measurement, host-source and graph guards intact.

Exact proposed write boundaries:

- New build-only web/appShellBuildNonce.ts and colocated build-owner test (test placement follows existing web/buildVersion.test.ts owner convention): export one environment-key constant and a validated build nonce function. An absent pin derives a fresh UUID; a present malformed/noncanonical UUID fails loudly. The test injection seam is explicitly for tests. A caller must not silently replace malformed supplied input.
- web/vite.config.ts: call that build-only nonce owner instead of importing/calling randomUUID directly. Preserve appShellPrecacheUrl, manifest transform and fallback consumers, all cache/update policy and shipping production minification. No runtime UI dependency.
- tools/migration/lib/web-host-metadata.mjs: compose actual copied nonce-owner input into the existing frozen build-input record, retaining appVersion/buildTime semantics. Record the nonce and strict environment ownership alongside the already pinned metadata; validation must reject missing/mismatched/extra environment ownership. Prefer a separate named appShellNonce field, not pretending nonce is an appVersion/buildTime field.
- tools/migration/build-web-host.mjs and existing scoped tests only as actual caller/receipt shape requires. Both released reference and retained wrapper get the same fresh artifact nonce. Later independent release/mechanism artifacts derive separate fresh nonces.
- tools/migration/lib/web-host-evidence.mjs and existing tests: assert both actually emitted app-shell URLs equal the recorded pin through the actual appShellPrecacheUrl owner before accepting complete bytes. The unchanged compareProductBytes remains the product comparison owner.
- Existing migration READMEs/evidence note only for final causal disposition, current gates and provenance. Root owns CAMPAIGN.md.

Compose docs-only accepted integration e7413bf92066fcf45967cf04241a513fd48d49ff before this implementation and final-source freeze. The immutable 3a92 replay receipt keeps its scope. Preserve the unexpected failed public call, with subsequent six calls never run. Do not overwrite its capsule.

Alternatives assessed:

- Expanding output normalization to arbitrary alpha-renamed code would weaken the complete emitted-byte contract and could hide semantic differences. Reject for this focused repair.
- Disabling minification, changing Workbox/Terser mangle behavior or patching installed dependencies changes the released build under test. Reject as a control acceptance fix.
- Retrying complete builds until a lucky UUID character distribution happens to match is not causal evidence. Reject.
- Replacing shipping uniqueness with a version/content-derived stable nonce changes the app-shell freshness policy. A strict optional paired-build input preserves the ordinary per-build random default with less policy scope.
- Monkeypatching node:crypto or rewriting copied shipping config broadens the control's authority and bypasses the released-system owner. Reject.

Acceptance and rejecting controls:

- Actual nonce owner: unpinned derivation remains unique per requested build; valid pin exact; malformed, wrong UUID version/variant, empty, extra/mismatched owned environment values reject. Native/service-worker-disabled behavior follows existing actual owner scope without creating a new platform branch.
- Actual copied invocation/receipt controls: pin is minted once per artifact and inherited by both real production builds; emitted URLs match it; missing or altered recorded nonce is rejected. Guard fixtures prove those failures, and restored positives pass.
- Existing full exact comparison still rejects the actual handler mutation; retain its executed receipt without broadening normalization.
- Format/check/lint and affected/full applicable tools/Browserless gates run with source snapshots immediately before and after; final-head hosted CI covers shipping E2E and release smoke. Reuse 3a92's completed source-bound hosted nonruntime gates only as exact historical scope.
- Seven final committed-source public calls run serially under an explicit exclusive host lease, new capsule, final source HEAD/tree/clean inventory/lock before and after. Browser output identity and distinct repeat witnesses remain mandatory.
- Independent executed-result challenge precedes repair acceptance; original PR2702 Claude conversation b5bb0824-3f7a-4ad7-9e05-4e8e9af77333 round two (one used, two remaining) must continue under the restored actual cwd key, with no fresh/reset substitute. Parent decides separate focused source-owner review/integration if required; this proposal does not consume or adopt that ledger.

Resource and evidence limits: this repair establishes paired released build reproducibility modulo the already approved generated-input ownership, not deployment PWA runtime acceptance, app latency, physical calibration or an architecture winner. The failed public artifact's complete installed graph lives in inputs.json; the restored installed inventory is replacement-installed-before.json. Disposable physical node_modules copies may retire only after source, installed identities, receipts and review provenance are preserved and their obligations transfer. No entire dependency-cache replication is needed in durable evidence.

