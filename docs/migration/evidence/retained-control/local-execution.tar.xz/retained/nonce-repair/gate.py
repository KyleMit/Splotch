import datetime,hashlib,json,os,signal,socket,subprocess,sys,time
from pathlib import Path
ROOT=Path('/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch')
BASE=Path('/private/tmp/splotch-resume-01a111b0/retained/nonce-repair')
label=sys.argv[1]
argv=sys.argv[2:]
GATE_DEADLINE_SECONDS=600
TERMINATION_GRACE_SECONDS=10
port=int(os.environ['SMOKE_PORT']) if 'SMOKE_PORT' in os.environ else None
def port_available():
 if port is None: return None
 with socket.socket() as listener:
  listener.bind(('127.0.0.1',port))
 return True
port_before=port_available()
out=BASE/label
out.mkdir()
def snapshot(name):
 p=out/(name+'.json')
 args=['node',str(BASE/'snapshot.mjs'),str(ROOT),str(p)]
 if not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True): args.append('committed')
 subprocess.run(args,check=True,cwd=ROOT)
 return json.loads(p.read_text())
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
before=snapshot('source-before')
record={'owner':'retained_control','label':label,'controllerPid':os.getpid(),'command':argv,'started':now(),'sourceHead':before['snapshot']['sha'],'sourceTree':before['headTree'],'stagedTree':before['stagedTree'],'provisional':before['snapshot']['provisional'],'deadlineSeconds':GATE_DEADLINE_SECONDS,'port':port,'portAvailableBefore':port_before,'releaseCondition':'owned group gone and explicit port bindable after completion/failure'}
print(json.dumps(record),flush=True)
start=time.monotonic()
with (out/'output.log.txt').open('w') as log:
 child=subprocess.Popen(argv,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 record['childPid']=child.pid
 record['groupPid']=child.pid
 record['processStartIdentity']=subprocess.check_output(['ps','-o','pid=,ppid=,pgid=,lstart=,command=','-p',str(child.pid)],text=True).strip()
 (out/'invocation.json').write_text(json.dumps(record,indent=2)+'\n')
 try:
  record['exitCode']=child.wait(timeout=GATE_DEADLINE_SECONDS)
  record['timedOut']=False
 except subprocess.TimeoutExpired:
  record['timedOut']=True
  os.killpg(child.pid,signal.SIGTERM)
  try: record['exitCode']=child.wait(timeout=TERMINATION_GRACE_SECONDS)
  except subprocess.TimeoutExpired:
   os.killpg(child.pid,signal.SIGKILL)
   record['exitCode']=child.wait()
record['elapsedSeconds']=time.monotonic()-start
record['finished']=now()
after=snapshot('source-after')
processes=subprocess.check_output(['ps','-axo','pid=,ppid=,pgid=,lstart=,command='],text=True)
record['ownedGroupRemaining']=[line for line in processes.splitlines() if len(line.split())>2 and line.split()[2]==str(child.pid)]
record['portAvailableAfter']=port_available()
record['sourceUnchanged']= all(before[k]==after[k] for k in ['snapshot','headTree','stagedTree','node','installedLockSha256'])
record['outputBytes']=(out/'output.log.txt').stat().st_size
record['outputSha256']=hashlib.sha256((out/'output.log.txt').read_bytes()).hexdigest()
(out/'invocation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
sys.exit(record['exitCode'] if record['sourceUnchanged'] and not record['ownedGroupRemaining'] and not record['timedOut'] else 98)
