from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import sys
import tarfile
import time

ROOT = Path('/private/tmp/splotch-resume-01a111b0/retained')
OUT = ROOT / 'public-evidence'
SOURCE = Path('/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch')
DEADLINE_SECONDS = 600
started = time.monotonic()
OUT.mkdir(exist_ok=True)

def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def source_identity():
    def git(*args):
        return subprocess.check_output(['git', '-C', str(SOURCE), *args], text=True).strip()
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'porcelain': git('status', '--porcelain=v1')}

selected = set()
def add_file(path):
    if path.is_symlink() or not path.is_file():
        raise RuntimeError('Evidence member must be a regular non-symlink file: ' + str(path))
    selected.add(path)

def add_tree(path):
    for member in path.rglob('*'):
        if member.is_symlink():
            raise RuntimeError('Unexpected evidence symlink: ' + str(member))
        if member.is_file():
            add_file(member)

def artifact(path):
    for member in path.iterdir():
        if member.is_file():
            add_file(member)
    for name in ('controls', 'browser-results', 'browser-report'):
        if (path / name).exists():
            add_tree(path / name)

for name in ('public-calls-final', 'public-calls'):
    for member in (ROOT / name).iterdir():
        if member.is_file():
            add_file(member)
artifact(ROOT / 'public-calls-final/release/splotch-web-host-00Wgl6')
artifact(ROOT / 'public-calls-final/mechanism/splotch-web-host-CKf8UD')
artifact(ROOT / 'public-calls/release/splotch-web-host-zWQlPc')
add_tree(ROOT / 'sw-diagnosis')
for member in (ROOT / 'nonce-repair').iterdir():
    if member.is_dir():
        add_tree(member)
for name in ('failure-dispositions.json', 'gate.py', 'snapshot.mjs', 'reviewed-97b493.patch', 'preparation-setup-error.json', 'pre-commit-source.json'):
    add_file(ROOT / 'nonce-repair' / name)
for name in ('run-public-calls-final.py', 'installed-graph-final.mjs', 'replacement-qualification.json', 'pre-round2-source.json', 'public-calls-release.json', 'original-findings-disposition.md', 'original-round2-prompt.md'):
    add_file(ROOT / name)
add_tree(ROOT / 'final-base')
add_file(Path(__file__))

before = source_identity()
if before['porcelain']:
    raise RuntimeError('Compression source binding must be clean committed source')
rows = [{'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size, 'mode': p.stat().st_mode & 0o7777, 'sha256': digest(p)} for p in sorted(selected)]
manifest = {'createdAt': stamp(), 'sourceAtPackaging': before, 'files': rows, 'excluded': ['physical source/dependency copies', 'runtime caches', 'emitted product byte copies except bounded causal Workbox replay outputs', 'authentication state and raw conversations'], 'rawBytes': sum(r['bytes'] for r in rows), 'format': 'standard tar.xz, LZMA preset 9, 64 MiB dictionary; original file bytes and modes preserved'}
(OUT / 'local-execution-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
manifest_path = OUT / 'local-execution-manifest.json'
rows_with_manifest = rows + [{'path': str(manifest_path.relative_to(ROOT)), 'bytes': manifest_path.stat().st_size, 'mode': manifest_path.stat().st_mode & 0o7777, 'sha256': digest(manifest_path)}]
archive = OUT / 'local-execution.tar.xz'
lease = {'owner': 'retained_control', 'pid': os.getpid(), 'command': [sys.executable, str(Path(__file__))], 'processStartIdentity': subprocess.check_output(['ps', '-p', str(os.getpid()), '-o', 'pid=,ppid=,pgid=,lstart=,args='], text=True).strip(), 'started': stamp(), 'deadlineSeconds': DEADLINE_SECONDS, 'sourceBefore': before, 'selectedFiles': len(rows_with_manifest), 'rawBytes': manifest['rawBytes'], 'state': 'compressing'}
(OUT / 'compression-lease.json').write_text(json.dumps(lease, indent=2) + '\n')
print(json.dumps(lease), flush=True)

def timeout(signum, frame):
    raise TimeoutError('Owned compression exceeded its 600-second deadline')

signal.signal(signal.SIGALRM, timeout)
signal.alarm(DEADLINE_SECONDS)
try:
    with tarfile.open(archive, 'w:xz', preset=9, format=tarfile.PAX_FORMAT) as tar:
        for row in rows_with_manifest:
            path = ROOT / row['path']
            if path.stat().st_size != row['bytes'] or digest(path) != row['sha256']:
                raise RuntimeError('Selected evidence changed before compression: ' + row['path'])
            info = tarfile.TarInfo('retained/' + row['path'])
            info.size = row['bytes']
            info.mode = row['mode']
            info.mtime = 0
            with path.open('rb') as f:
                tar.addfile(info, f)
    expected = {'retained/' + row['path']: row for row in rows_with_manifest}
    seen = set()
    with tarfile.open(archive, 'r:xz') as tar:
        for member in tar:
            name = member.name
            if not member.isfile() or name in seen or name.startswith('/') or '..' in Path(name).parts or name not in expected:
                raise RuntimeError('Unsafe or unexpected decoded evidence member: ' + name)
            row = expected[name]
            h = hashlib.sha256()
            with tar.extractfile(member) as f:
                for block in iter(lambda: f.read(1024 * 1024), b''):
                    h.update(block)
            if member.size != row['bytes'] or member.mode != row['mode'] or h.hexdigest() != row['sha256']:
                raise RuntimeError('Decoded evidence differs: ' + name)
            seen.add(name)
    if seen != set(expected):
        raise RuntimeError('Incomplete decoded evidence member inventory')
    for row in rows_with_manifest:
        if digest(ROOT / row['path']) != row['sha256']:
            raise RuntimeError('Evidence source changed during compression: ' + row['path'])
    after = source_identity()
    if before != after:
        raise RuntimeError('Checkout changed during compression')
    lease.update({'state': 'verified-complete', 'finished': stamp(), 'elapsedSeconds': time.monotonic() - started, 'sourceAfter': after, 'sourceUnchanged': True, 'decodedMembers': len(seen), 'archiveBytes': archive.stat().st_size, 'archiveSha256': digest(archive), 'manifestSha256': digest(manifest_path), 'ownedChildren': []})
except BaseException as error:
    lease.update({'state': 'failed', 'finished': stamp(), 'elapsedSeconds': time.monotonic() - started, 'error': repr(error), 'archiveBytes': archive.stat().st_size if archive.exists() else None, 'ownedChildren': []})
    raise
finally:
    signal.alarm(0)
    (OUT / 'compression-lease.json').write_text(json.dumps(lease, indent=2) + '\n')
    print(json.dumps(lease), flush=True)
