import datetime,hashlib,json,os,signal,socket,subprocess,sys,time
from pathlib import Path
ROOT=Path('/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch')
R=Path('/private/tmp/splotch-resume-01a111b0/retained/node-floor')
OUT=R/('full-'+sys.argv[1]);OUT.mkdir()
NODE='/Users/kylemit/.nvm/versions/node/v24.16.0/bin/node'
HEAD='5434e9d7ddd33ad1d2afdc7b8906aca24a8c8118'
TREE='2c64a3869e9c1faf7df1e9adbfc01d9713f8215a'
LOCK='705b57623e37d509826f4b6aa42b00d4957d7dd295165d462523b075e42a9f92'
START=time.monotonic();DEADLINE=START+600
PORT=int(os.environ['SMOKE_PORT'])
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(body):return hashlib.sha256(body).hexdigest()
def identity(pid):return subprocess.run(['ps','-p',str(pid),'-o','pid=,ppid=,pgid=,lstart=,command='],capture_output=True,text=True).stdout.strip()
def groups(pid):
 output=subprocess.run(['ps','-axo','pid=,ppid=,pgid=,lstart=,command='],capture_output=True,text=True,check=True).stdout
 return [line.strip() for line in output.splitlines() if len(line.split(None,3))>=3 and line.split(None,3)[2]==str(pid)]
def port_free():
 with socket.socket() as listener:listener.bind(('127.0.0.1',PORT))
 return True
record={'owner':'retained_control','label':sys.argv[1],'controllerPid':os.getpid(),'controllerStartIdentity':identity(os.getpid()),'controllerSha256':sha(Path(__file__).read_bytes()),'sourceHead':HEAD,'sourceTree':TREE,'port':PORT,'started':now(),'wholeDeadlineSeconds':600,'children':[],'status':'running'}
def save(): (OUT/'invocation.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,argv,maximum=600):
 row={'label':label,'command':list(map(str,argv)),'started':now()};start=time.monotonic()
 with (OUT/(label+'.log.txt')).open('wb') as log:
  child=subprocess.Popen(row['command'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  row.update(pid=child.pid,groupPid=child.pid,processStartIdentity=identity(child.pid));record['children'].append(row);save();print(json.dumps({'event':'child-start','label':label,'pid':child.pid}),flush=True)
  try:child.wait(timeout=min(maximum,max(0.01,DEADLINE-time.monotonic())));row['timedOut']=False
  except subprocess.TimeoutExpired:
   row['timedOut']=True;os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=10)
 row.update(exitCode=child.returncode,elapsedSeconds=time.monotonic()-start,finished=now(),ownedGroupRemaining=groups(child.pid),outputSha256=sha((OUT/(label+'.log.txt')).read_bytes()),outputBytes=(OUT/(label+'.log.txt')).stat().st_size);save()
 if row['timedOut'] or row['ownedGroupRemaining']:raise RuntimeError('Owned child failed deadline/release '+label)
 return child.returncode
def bind_source(label):
 output=OUT/(label+'.json')
 if run(label,[NODE,R.parent/'nonce-repair/snapshot.mjs',ROOT,output,'committed'],60):raise RuntimeError('Source binder failed '+label)
 value=json.loads(output.read_text())
 if value['snapshot']['sha']!=HEAD or value['headTree']!=TREE or value['stagedTree']!=TREE or value['snapshot']['provisional']:raise RuntimeError('Source differs from frozen committed head')
 return value
def bind_graph(label):
 output=OUT/(label+'.json')
 if run(label,[NODE,R.parent/'installed-graph-final.mjs',ROOT,output,LOCK],60):raise RuntimeError('Installed binder failed '+label)
 return json.loads(output.read_text())
save()
before=installed_before=None
try:
 record['portAvailableImmediatelyBefore']=port_free();save()
 before=bind_source('source-before');installed_before=bind_graph('installed-before')
 record['gateExitCode']=run('gate',['npm','run',sys.argv[2]])
 record['status']='gate-passed' if record['gateExitCode']==0 else 'gate-failed'
except BaseException as error:record.update(status='failed-setup-provenance-or-release',errorType=type(error).__name__,error=str(error))
finally:
 try:
  after=bind_source('source-after');installed_after=bind_graph('installed-after')
  record['sourceUnchanged']=before is not None and all(before[k]==after[k] for k in ['snapshot','headTree','stagedTree','node','installedLockSha256'])
  record['installedUnchanged']=installed_before is not None and all(installed_before[k]==installed_after[k] for k in ['root','node','lockSha256','owners','inventorySha256','rows'])
  record['portAvailableAfter']=port_free()
 except BaseException as error:record.update(status='failed-final-binding',finalErrorType=type(error).__name__,finalError=str(error))
 record.update(finished=now(),elapsedSeconds=time.monotonic()-START,ownedGroupsRemaining={str(c['pid']):groups(c['pid']) for c in record['children']})
 if not record.get('sourceUnchanged') or not record.get('installedUnchanged') or not record.get('portAvailableAfter') or any(record['ownedGroupsRemaining'].values()):record['status']='failed-provenance-or-release'
 save();print(json.dumps({k:record.get(k) for k in ['status','gateExitCode','elapsedSeconds','sourceUnchanged','installedUnchanged','portAvailableAfter','error','finalError']}),flush=True)
if record['status']!='gate-passed':raise SystemExit(1)
