import { readFileSync, writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
const [sourceRoot, artifactRoot, output] = process.argv.slice(2);
const { readWebHostArtifact } = await import(pathToFileURL(sourceRoot + '/tools/migration/lib/web-host-artifact.mjs'));
const { sha256 } = await import(pathToFileURL(sourceRoot + '/tools/migration/lib/web-host-source.mjs'));
const { owned, inputs, result } = readWebHostArtifact(artifactRoot);
writeFileSync(output, JSON.stringify({observed:new Date().toISOString(),ownerSha256:sha256(readFileSync(sourceRoot + '/tools/migration/lib/web-host-artifact.mjs')),root:owned.root,sourceSha:inputs.snapshot.sha,inputsSha256:sha256(readFileSync(artifactRoot + '/inputs.json')),resultSha256:sha256(readFileSync(artifactRoot + '/result.json')),roleOutputCounts:Object.fromEntries(Object.entries(result.evidence).map(([role,record])=>[role,Object.fromEntries(Object.entries(record.outputs).map(([path,rows])=>[path,rows.length]))])),appShellNonce:inputs.pinned.appShellNonce},null,2)+'\n');
