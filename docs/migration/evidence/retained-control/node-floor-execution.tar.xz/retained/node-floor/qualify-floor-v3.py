import datetime, hashlib, json, os, pathlib, posixpath, shutil, signal, stat, subprocess, tarfile, time, urllib.request

ROOT = pathlib.Path('/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch')
RECORDS = pathlib.Path('/private/tmp/splotch-resume-01a111b0/retained/node-floor/attempt-3')
NODE = '/Users/kylemit/.nvm/versions/node/v24.16.0/bin/node'
FLOOR_NAME = 'node-v22.13.0-darwin-arm64'
FLOOR_SHA = '71b0893ef6a55295994f38002fada15c9a76a3cedeb36745fde0403741d183c6'
BASE = 'f14966ee98563e3c569fbcb90beea6d9c684614a'
CURRENT = '81f84eebaf71c3d178186137d9c2bb07f7e85209'
LOCK = '705b57623e37d509826f4b6aa42b00d4957d7dd295165d462523b075e42a9f92'
RELEASE = pathlib.Path('/private/tmp/splotch-resume-01a111b0/retained/public-calls-final/release/splotch-web-host-00Wgl6')
SNAPSHOT = RECORDS.parent.parent / 'nonce-repair/snapshot.mjs'
GRAPH = RECORDS.parent.parent / 'installed-graph-final.mjs'
started = time.monotonic()
whole_start = datetime.datetime.fromisoformat(json.loads((RECORDS.parent/'qualification-lease.json').read_text())['started'])
deadline = started + 600 - (datetime.datetime.now(datetime.timezone.utc)-whole_start).total_seconds()
lease = {'owner':'retained_control','controllerPid':os.getpid(),'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'deadlineSeconds':600,'wholeUnitStarted':whole_start.isoformat(),'controllerSha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'source':CURRENT,'base':BASE,'ports':[],'children':[],'status':'running','claims':['Exact declared-floor PWA CLI loading and real precache validation only','Historical real release output reuse is not a new-source build','Full corrected postbuild condition remains pending fresh corrected-source outputs']}

def sha(data): return hashlib.sha256(data).hexdigest()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name, value): (RECORDS/name).write_text(json.dumps(value,indent=2)+'\n')
def remaining(maximum):
    left=deadline-time.monotonic()
    if left <= 0: raise TimeoutError('Whole floor-qualification deadline expired')
    return min(left,maximum)
def process_identity(pid):
    p=subprocess.run(['ps','-p',str(pid),'-o','pid=,ppid=,pgid=,lstart=,command='],capture_output=True,text=True)
    return p.stdout.strip()
def group_members(pgid):
    p=subprocess.run(['ps','-axo','pid=,ppid=,pgid=,lstart=,command='],capture_output=True,text=True,check=True)
    return [line.strip() for line in p.stdout.splitlines() if len(line.split(None,3))>=3 and line.split(None,3)[2]==str(pgid)]
def run(label, command, cwd=ROOT, env=None, seconds=60, expected=0, stderr_contains=(), stdout_contains=()):
    row={'label':label,'command':list(map(str,command)),'cwd':str(cwd),'started':now(),'deadlineSeconds':seconds,'expectedExitCode':expected,'expectedStderr':list(stderr_contains),'expectedStdout':list(stdout_contains)}
    begin=time.monotonic()
    with (RECORDS/(label+'.stdout.txt')).open('wb') as out, (RECORDS/(label+'.stderr.txt')).open('wb') as err:
        child=subprocess.Popen(row['command'],cwd=cwd,env=env,stdout=out,stderr=err,start_new_session=True)
        row.update(pid=child.pid,groupPid=child.pid,startIdentity=process_identity(child.pid))
        lease['children'].append(row);save('qualification-lease.json',lease)
        try: child.wait(timeout=remaining(seconds));row['timedOut']=False
        except subprocess.TimeoutExpired:
            row['timedOut']=True
            os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=5)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
        row.update(exitCode=child.returncode,elapsedSeconds=time.monotonic()-begin,finished=now(),remainingGroup=group_members(child.pid))
    stdout=(RECORDS/(label+'.stdout.txt')).read_bytes();stderr=(RECORDS/(label+'.stderr.txt')).read_bytes()
    row.update(stdoutSha256=sha(stdout),stderrSha256=sha(stderr),stdoutBytes=len(stdout),stderrBytes=len(stderr))
    row['predicatePassed']=not row['timedOut'] and child.returncode==expected and not row['remainingGroup'] and all(text.encode() in stderr for text in stderr_contains) and all(text.encode() in stdout for text in stdout_contains)
    save('qualification-lease.json',lease)
    if not row['predicatePassed']:raise RuntimeError('Wrong result/setup or ownership failure in '+label)
    return stdout
def inventory(root):
    rows=[]
    for directory,dirs,files in os.walk(root,followlinks=False):
        for name in dirs[:]:
            if (pathlib.Path(directory)/name).is_symlink():files.append(name);dirs.remove(name)
        for name in files:
            path=pathlib.Path(directory)/name;s=path.lstat();link=os.readlink(path) if path.is_symlink() else None
            if not stat.S_ISREG(s.st_mode) and link is None:raise RuntimeError('Unsafe physical entry '+str(path))
            rows.append({'path':path.relative_to(root).as_posix(),'bytes':s.st_size,'kind':'symlink' if link is not None else 'file','mode':s.st_mode & 0o777,'target':os.path.relpath(path.resolve(),root.resolve()) if link is not None else None,'sha256':sha(link.encode() if link is not None else path.read_bytes()),'link':link})
    return sorted(rows,key=lambda r:r['path'])
def safe_extract(archive, destination, label, expected_top=None):
    if destination.exists():raise RuntimeError('Extraction root already exists '+str(destination))
    begin=time.monotonic();rows=[];seen=set();folded=set()
    with tarfile.open(archive,'r:*') as tar:
        members=tar.getmembers()
        for m in members:
            remaining(120)
            name=m.name.rstrip('/')
            if name.startswith('/') or '\\' in name or any(p in ('','..','.') for p in name.split('/')):raise RuntimeError('Unsafe archive path '+name)
            if name in seen or name.casefold() in folded:raise RuntimeError('Duplicate/case-colliding archive path '+name)
            seen.add(name);folded.add(name.casefold())
            if expected_top and name.split('/')[0]!=expected_top:raise RuntimeError('Wrong archive top '+name)
            if not (m.isdir() or m.isfile() or m.issym() or m.islnk()):raise RuntimeError('Unsupported archive kind '+name)
            target=None
            if m.issym() or m.islnk():
                if m.linkname.startswith('/') or '\\' in m.linkname:raise RuntimeError('Unsafe archive link '+name)
                target=posixpath.normpath(posixpath.join(posixpath.dirname(name),m.linkname) if m.issym() else m.linkname)
                if target.startswith('../') or target=='..' or (expected_top and target.split('/')[0]!=expected_top):raise RuntimeError('Escaping archive link '+name)
            if m.mode & ~0o777:raise RuntimeError('Unsafe archive mode '+name)
            body=tar.extractfile(m).read() if m.isfile() else None
            rows.append({'path':name,'kind':'directory' if m.isdir() else 'file' if m.isfile() else 'symlink' if m.issym() else 'hardlink','mode':m.mode,'bytes':m.size,'link':m.linkname if target is not None else None,'resolvedTarget':target,'sha256':sha(body) if body is not None else None})
        save(label+'-archive-members.json',{'archiveSha256':sha(archive.read_bytes()),'memberCount':len(rows),'rows':rows})
        for row in rows:
            if row['resolvedTarget'] is not None and row['resolvedTarget'] not in seen:raise RuntimeError('Missing archive link target '+row['path'])
        destination.mkdir()
        for m in members:
            path=destination/m.name.rstrip('/')
            for parent in path.parents:
                if parent==destination:break
                if parent.is_symlink():raise RuntimeError('Archive parent is a symlink '+str(parent))
            path.parent.mkdir(parents=True,exist_ok=True)
            if m.isdir():path.mkdir(exist_ok=True);path.chmod(m.mode)
            elif m.isfile():
                with tar.extractfile(m) as source, path.open('xb') as out:shutil.copyfileobj(source,out)
                path.chmod(m.mode)
            elif m.issym():path.symlink_to(m.linkname)
        for m in members:
            if m.islnk():os.link(destination/m.linkname,destination/m.name)
    physical=inventory(destination)
    for row in rows:
        path=destination/row['path']
        if row['kind']=='file' and (sha(path.read_bytes())!=row['sha256'] or (path.stat().st_mode & 0o777)!=row['mode']):raise RuntimeError('Decoded archive mismatch '+row['path'])
        if row['kind']=='symlink' and os.readlink(path)!=row['link']:raise RuntimeError('Decoded archive link mismatch '+row['path'])
    save(label+'-decoded-inventory.json',{'observed':now(),'elapsedSeconds':time.monotonic()-begin,'rows':physical})
    if time.monotonic()-begin>120:raise TimeoutError('Extraction deadline exceeded '+label)
    return physical
def download(name,url):
    begin=time.monotonic();path=RECORDS/name
    if path.exists():raise RuntimeError('Download destination already exists '+str(path))
    with urllib.request.urlopen(url,timeout=remaining(120)) as response,path.open('xb') as out:
        headers=dict(response.headers);status=response.status
        while data:=response.read(1024*1024):
            if time.monotonic()-begin>120:raise TimeoutError('Transfer deadline exceeded')
            out.write(data)
    body=path.read_bytes();expected=headers.get('Content-Length')
    if status!=200 or (expected is not None and len(body)!=int(expected)):raise RuntimeError('Incomplete archive transfer')
    row={'name':name,'url':url,'observed':now(),'status':status,'contentLength':expected,'bytes':len(body),'sha256':sha(body),'elapsedSeconds':time.monotonic()-begin,'headers':headers}
    save(name+'.transfer.json',row);return path

lease['controllerStartIdentity']=process_identity(os.getpid());save('qualification-lease.json',lease)
try:
    run('source-before',[NODE,SNAPSHOT,ROOT,RECORDS/'source-before.json'])
    run('installed-before',[NODE,GRAPH,ROOT,RECORDS/'installed-before.json',LOCK])
    run('released-artifact-before',[NODE,'--disable-warning=ExperimentalWarning',RECORDS/'read-release.mjs',ROOT,RELEASE,RECORDS/'released-artifact-before.json'],seconds=120)
    prior=RECORDS.parent/'attempt-2'
    sums=prior/'SHASUMS256.txt';archive=prior/(FLOOR_NAME+'.tar.xz')
    exact=[line for line in sums.read_text().splitlines() if line.split()[-1]==FLOOR_NAME+'.tar.xz']
    if exact!=[FLOOR_SHA+'  '+FLOOR_NAME+'.tar.xz'] or sha(archive.read_bytes())!=FLOOR_SHA:raise RuntimeError('Qualified runtime archive input changed')
    actual_runtime=inventory(prior/'toolchain')
    if actual_runtime!=json.loads((prior/'node-decoded-inventory.json').read_text())['rows']:raise RuntimeError('Qualified decoded runtime input changed')
    save('runtime-reuse.json',{'observed':now(),'qualifiedPrior':'../attempt-2','archiveSha256':FLOOR_SHA,'SHASUMS256Sha256':sha(sums.read_bytes()),'decodedRuntimeRows':len(actual_runtime),'decodedRuntimeExact':True,'publisherArchiveNotRedownloaded':True})
    floor=prior/'toolchain'/FLOOR_NAME;binary=floor/'bin/node'
    env={k:os.environ[k] for k in ['PATH','HOME','USER','LOGNAME','LANG','LC_ALL','TZ','SYSTEMROOT'] if k in os.environ}
    env['PATH']=str(floor/'bin')+':'+env.get('PATH','')
    run('floor-version',[binary,'--version'],env=env,stdout_contains=['v22.13.0'])
    run('floor-arch',[binary,'-p','process.arch'],env=env,stdout_contains=['arm64'])
    npm_package=floor/'lib/node_modules/npm/package.json';npm=json.loads(npm_package.read_text())
    save('qualified-runtime.json',{'observed':now(),'officialArchiveSha256':FLOOR_SHA,'binary':str(binary),'binarySha256':sha(binary.read_bytes()),'binaryMode':binary.stat().st_mode & 0o777,'architecture':'arm64','version':'v22.13.0','npmPackageSha256':sha(npm_package.read_bytes()),'npmVersion':npm['version'],'npmCliSha256':sha((floor/'lib/node_modules/npm/bin/npm-cli.js').read_bytes()),'noGlobalInstall':True})
    result=json.loads((RELEASE/'result.json').read_text());original=RELEASE/'reference'
    before_product=inventory(original/'web/.svelte-kit/output')
    if before_product!=result['evidence']['reference']['outputs']['web/.svelte-kit/output']:raise RuntimeError('Real released Kit output mismatch')
    save('original-kit-before.json',before_product)
    source_static=inventory(original/'web/static/coloring');save('original-coloring.json',source_static)
    probes={}
    for label,revision in [('baseline',BASE),('current',CURRENT)]:
        source_archive=RECORDS/(label+'-source.tar')
        run(label+'-git-archive',['git','-c','tar.umask=0022','archive','--format=tar','--output='+str(source_archive),revision],seconds=120)
        dest=RECORDS/('probe-'+label);source_rows=safe_extract(source_archive,dest,label+'-source')
        if inventory(dest/'web/static/coloring')!=source_static:raise RuntimeError('Static coloring source differs '+label)
        shutil.copytree(original/'web/.svelte-kit/output',dest/'web/.svelte-kit/output',copy_function=shutil.copy2)
        if inventory(dest/'web/.svelte-kit/output')!=before_product:raise RuntimeError('Copied real release output differs '+label)
        save(label+'-probe-before.json',inventory(dest));probes[label]=dest
    run('baseline-unflagged',[binary,'tools/check-pwa-precache.mjs'],cwd=probes['baseline'],env=env,stdout_contains=['[pwa-precache]'])
    run('current-unflagged-reject',[binary,'tools/check-pwa-precache.mjs'],cwd=probes['current'],env=env,expected=1,stderr_contains=['ERR_UNKNOWN_FILE_EXTENSION','web/appShellBuildNonce.ts'])
    flags=['--experimental-strip-types','--disable-warning=ExperimentalWarning']
    run('current-explicit-flags-positive',[binary,*flags,'tools/check-pwa-precache.mjs'],cwd=probes['current'],env=env,stdout_contains=['[pwa-precache]'])
    pinned={**env,'SPLOTCH_PINNED_APP_SHELL_NONCE':'c6c9b58b-211e-4e3b-8ab9-4ab1a9958886'}
    run('current-shipping-ambient-pin-reject',[binary,*flags,'tools/check-pwa-precache.mjs'],cwd=probes['current'],env=pinned,expected=1,stderr_contains=['App-shell nonce pin requires its complete owned paired-control context'])
    run('current-shipping-restored-positive',[binary,*flags,'tools/check-pwa-precache.mjs'],cwd=probes['current'],env=env,stdout_contains=['[pwa-precache]'])
    for label,dest in probes.items():
        after=inventory(dest);save(label+'-probe-after.json',after)
        if after!=json.loads((RECORDS/(label+'-probe-before.json')).read_text()):raise RuntimeError('Probe source/output changed '+label)
    after_product=inventory(original/'web/.svelte-kit/output');save('original-kit-after.json',after_product)
    if after_product!=before_product:raise RuntimeError('Historical actual output changed')
    run('released-artifact-after',[NODE,'--disable-warning=ExperimentalWarning',RECORDS/'read-release.mjs',ROOT,RELEASE,RECORDS/'released-artifact-after.json'],seconds=120)
    run('source-after',[NODE,SNAPSHOT,ROOT,RECORDS/'source-after.json'])
    run('installed-after',[NODE,GRAPH,ROOT,RECORDS/'installed-after.json',LOCK])
    sb=json.loads((RECORDS/'source-before.json').read_text());sa=json.loads((RECORDS/'source-after.json').read_text())
    for key in ['headTree','stagedTree','installedLockSha256','snapshot']:
        if sa[key]!=sb[key]:raise RuntimeError('Actual source changed during floor qualification '+key)
    gb=json.loads((RECORDS/'installed-before.json').read_text());ga=json.loads((RECORDS/'installed-after.json').read_text())
    if ga['rows']!=gb['rows'] or ga['inventorySha256']!=gb['inventorySha256']:raise RuntimeError('Borrowed installed graph changed')
    lease.update(status='qualified',sourceUnchanged=True,installedGraphUnchanged=True,originalProductUnchanged=True,probeSourceOutputUnchanged=True)
except BaseException as error:
    lease.update(status='failed',errorType=type(error).__name__,error=str(error))
finally:
    lease.update(finished=now(),elapsedSeconds=time.monotonic()-started,remainingOwnedGroups={str(r['groupPid']):group_members(r['groupPid']) for r in lease['children']})
    save('qualification-lease.json',lease)
    print(json.dumps({'status':lease['status'],'elapsedSeconds':lease['elapsedSeconds'],'children':len(lease['children']),'error':lease.get('error'),'remainingOwnedGroups':{k:len(v) for k,v in lease['remainingOwnedGroups'].items()}}),flush=True)
if lease['status']!='qualified':raise SystemExit(1)
