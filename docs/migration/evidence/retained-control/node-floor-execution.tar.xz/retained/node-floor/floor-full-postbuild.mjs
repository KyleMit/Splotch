import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
const [worktree, artifactRoot, floorNode, npmCli, outputRoot] = process.argv.slice(2);
const { readWebHostArtifact } = await import(pathToFileURL(join(worktree, 'tools/migration/lib/web-host-artifact.mjs')));
const { copiedBuildEnvironment, runCopiedChild } = await import(pathToFileURL(join(worktree, 'tools/migration/lib/web-host-build.mjs')));
const { fileInventory } = await import(pathToFileURL(join(worktree, 'tools/migration/lib/web-host-files.mjs')));
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const before = readWebHostArtifact(artifactRoot);
if (before.inputs.snapshot.sha !== '5434e9d7ddd33ad1d2afdc7b8906aca24a8c8118' || before.artifact !== 'release')
  throw new Error('Floor condition requires the fresh corrected-source release artifact');
const reference = before.inputs.copies.reference;
const script = JSON.parse(readFileSync(join(reference, 'package.json'), 'utf8')).scripts.postbuild;
if (script.split(' && ').filter((step) => step === 'node --experimental-strip-types --disable-warning=ExperimentalWarning tools/check-pwa-precache.mjs').length !== 1)
  throw new Error('Fresh actual postbuild does not contain the exact reviewer prescription');
if (sha(readFileSync(floorNode)) !== '5c79f8e198fd2456ea6660aaa6be218f9f44747f2306c7d0f5f97b087b2f2dfc' ||
    sha(readFileSync(npmCli)) !== '8e5f6f3429f8cdbe693cdc29904e9d5a7b127a494bd15c804bd54c7403bfcbe7')
  throw new Error('Qualified actual floor Node/npm bytes changed');
if (existsSync(join(reference, 'node_modules/.bin/node')))
  throw new Error('Copied lifecycle bin would shadow the qualified floor Node');
const env = copiedBuildEnvironment(before.owned, reference, before.artifact, before.inputs.pinned.env);
env.PATH = `${dirname(floorNode)}:${env.PATH ?? ''}`;
const version = spawnSync('node', ['--version'], { cwd: reference, env, encoding: 'utf8' });
if (version.status !== 0 || version.stdout.trim() !== 'v22.13.0')
  throw new Error('Actual postbuild child PATH does not select Node22.13.0');
const runtimeRoot = join(dirname(dirname(floorNode)), '..');
const runtimeBefore = fileInventory(runtimeRoot);
const record = {
  started: new Date().toISOString(),
  node: process.version,
  processExecPath: process.execPath,
  childPathVersion: version.stdout.trim(),
  floorNode,
  floorNodeSha256: sha(readFileSync(floorNode)),
  npmCli,
  npmCliSha256: sha(readFileSync(npmCli)),
  sourceSha: before.inputs.snapshot.sha,
  reference,
  actualPostbuild: script,
  inputsSha256: sha(readFileSync(join(artifactRoot, 'inputs.json'))),
  resultSha256: sha(readFileSync(join(artifactRoot, 'result.json'))),
  markerSha256: sha(readFileSync(join(artifactRoot, '.splotch-web-host.json'))),
  childEnvKeys: Object.keys(env).sort(),
  pinnedEnvKeySet: Object.keys(before.inputs.pinned.env).sort(),
  pinnedNonce: before.inputs.pinned.appShellNonce,
  runtimeBefore,
  status: 'running',
  claimLimit: 'Actual corrected release postbuild on declared Node floor; no deployed PWA/offline, RN/React, architecture or physical performance claim',
};
const write = () => writeFileSync(join(outputRoot, 'condition.json'), JSON.stringify(record, null, 2) + '\n');
write();
try {
  record.child = await runCopiedChild({ owned: before.owned, copyRoot: reference, env, label: 'floor-full-postbuild', command: floorNode, args: [npmCli, 'run', 'postbuild'] });
  record.status = 'postbuild-passed';
} catch (error) {
  record.status = 'postbuild-failed';
  record.error = error.message;
  record.child = error.childRecord ?? null;
} finally {
  try {
    const after = readWebHostArtifact(artifactRoot);
    record.artifactReadbackUnchanged =
      record.inputsSha256 === sha(readFileSync(join(artifactRoot, 'inputs.json'))) &&
      record.resultSha256 === sha(readFileSync(join(artifactRoot, 'result.json'))) &&
      record.markerSha256 === sha(readFileSync(join(artifactRoot, '.splotch-web-host.json'))) &&
      after.inputs.snapshot.sha === record.sourceSha &&
      after.inputs.pinned.appShellNonce === record.pinnedNonce;
    record.runtimeAfter = fileInventory(runtimeRoot);
    record.runtimeUnchanged = JSON.stringify(record.runtimeBefore) === JSON.stringify(record.runtimeAfter);
    if (!record.artifactReadbackUnchanged || !record.runtimeUnchanged)
      record.status = 'failed-final-bindings';
  } catch (error) {
    record.status = 'failed-artifact-readback';
    record.finalError = error.message;
  }
  record.finished = new Date().toISOString();
  write();
}
console.log(JSON.stringify({status:record.status,sourceSha:record.sourceSha,node:record.node,artifactReadbackUnchanged:record.artifactReadbackUnchanged,runtimeUnchanged:record.runtimeUnchanged}));
if (record.status !== 'postbuild-passed') process.exitCode = 1;
