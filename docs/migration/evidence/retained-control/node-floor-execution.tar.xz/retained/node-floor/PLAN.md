# Exact retained postbuild condition

Original final review is published at
https://github.com/KyleMit/Splotch/pull/2702#pullrequestreview-5432590230.
Its complete findings are at
`/private/tmp/splotch-resume-01a111b0/retained/claude-round3-findings.json`.
Actual original conversation b5bb0824-3f7a-4ad7-9e05-4e8e9af77333 genuinely resumed for
round three at source 81f84eebaf71c3d178186137d9c2bb07f7e85209/base
f14966ee98563e3c569fbcb90beea6d9c684614a. All three rounds are spent; none is reset.
The current source is not accepted.

The exact recorded conditional wording is:

> With that flag added, and a re-run of the touched postbuild path, I see no remaining
> reason to withhold acceptance of this retained-control scope.

The review prescribes
`node --experimental-strip-types --disable-warning=ExperimentalWarning tools/check-pwa-precache.mjs`,
matching adjacent existing invocations. It confirms all original six and all three round-two
corrections on source 81; it reports one blocking Node-floor defect and zero unverified claims.
Fulfillment is an executed condition of that completed review, not another independent review
of a changed head. Parent retains the final interpretation and integration decision.

## Fixed source boundary

Change only the PWA command inside `package.json`'s existing `postbuild` chain. Add one narrow
cross-file script guard to the existing PWA test file, which has space below its maintained
cap; leave the 551-line workflow-hygiene file alone. The guard reads the actual package
postbuild command and requires both flags before the actual PWA entry. Exercise removal and
restoration on an owned disposable source copy. No nonce owner, output comparison, budgets,
toolchain floor, package/lock dependencies or import structure changes.

Commit this bounded source correction before composing accepted docs-only
794448fbf76276b76a910c167b5c2e0c4e1ea538. Verify the incoming actual diff contains only the
accepted documentation/evidence obligations, then merge without replacing stale whole files
or folding a dirty index into the merge. Format and qualify the actual resulting source,
index, environment and guard inputs before broad execution.

## Consequential floor probe

Uncertainty: whether the actual shipping postbuild entry and its new TS import graph execute
on the declared Node 22.13 floor with the exact prescribed command. Released owner:
`package.json` postbuild plus `tools/check-pwa-precache.mjs`; runtime owner is official
Node 22.13.0. Expected positive: the former baseline checker executes against real retained
release outputs; the corrected actual PWA command and full corrected postbuild chain pass on
Node 22.13.0. Intended rejecting behavior: source 81's unflagged entry fails for
`ERR_UNKNOWN_FILE_EXTENSION` naming `web/appShellBuildNonce.ts`, before any precache operation.
The same outputs must pass when the explicit flags are restored. A missing worker, invalid
marker, absent dependency or setup refusal is not this negative control.

Node 22.13.0 is absent from installed nvm versions (20.20.2,22.23.2,24.16.0); the host is arm64.
Qualify the official isolated archive from
https://nodejs.org/download/release/v22.13.0/node-v22.13.0-darwin-arm64.tar.xz
against the exact publisher SHASUMS256 entry
71b0893ef6a55295994f38002fada15c9a76a3cedeb36745fde0403741d183c6.
Preserve the complete SHASUMS256 response from the same official release. Verify complete
bytes/digest and a safe member inventory before owned extraction, including internal-only
link targets; execute no installer or package lifecycle. Record the extracted actual Node
binary hash, `--version`, architecture and bundled npm identity. No global nvm/profile/cache
changes or dependency installation. Official documentation requires the flag at 22.13 and
records default stripping from 22.18. A 22.23 strip-disabled proxy remains supporting evidence,
not the declared-floor identity.

Keep original source 81 and released 85 inputs immutable. In an owned floor records/probe root,
materialize exact baseline f149 checker/source inputs with complete source manifests and
reuse the real already-qualified release output bytes only after their full inventory binds.
Run the actual baseline PWA entry at the declared floor with ordinary unpinned environment;
run source 81's actual entry without the flag against the same frozen generated data; then
the exact corrected entry with its prescribed flags. Capture full command, Node hash/version,
source/output pre/post identities, exit/stdout/stderr and intended reason. Product data is
reused only where relevant output/static inputs remain byte-identical; the baseline is not
relabeled as a build of new source.

After fresh corrected-source seven calls, run the entire actual `npm run postbuild` once on
the new completed release reference copy using qualified Node 22.13/npm and the existing
`copiedBuildEnvironment` owner. Its recorded metadata/nonce and full owned context remain
intact; prepend the qualified floor bin only in the child PATH. Existing artifact readback
must validate complete source/support/installed/output identities before and after. The
prescribed script and real output must pass. Also retain the actual shipping ambient-pin
reject/restored positive and original owner controls. No new build is needed solely for that
postbuild invocation, because the fresh seven-call release outputs already bind to new source.

Archive/floor preparation is bounded to owned records/processes, no port, at most 120 seconds
per transfer/extraction and 60 seconds per guard invocation. The actual full postbuild chain
gets120 seconds. Report readiness and obtain the parent's concrete qualification slot before
materializing or executing the floor binary; this plan does not consume another review round.

## Fresh gates and claims

The package/script change invalidates complete source/Git-metadata inputs. Historical nonce
diagnosis and source 81/85/22e receipts keep their original scope. Freeze corrected composed
source and run affected scoped/static gates, then request serialized full Quality and full
Browserless leases (600 seconds each, explicit unused SMOKE_PORT=5300). After positive gates,
push the clean corrected source and request seven distinct public calls under the named 2100s
cumulative controller, complete source/index and installed-graph witnesses, fresh explicit
ports, actual owned handles and verified release. Run the floor postbuild and capture its
condition separately. Obtain fresh final-head CI and complete structured logs/artifact ZIP
exports with actual tested-merge/tree/source/installed graph identities.

Only the exact recorded predicate can be claimed fulfilled after those results exist.
Original round 3 remains a blocking review of 81 with an explicit condition; it is not silently
converted into an unconditional review of a later head. Parent decides acceptance from its
exact condition and executable evidence. No fourth, fresh, reset or alternative reviewer is
invoked. Any new defect, scope growth, wrong-reason negative, stale input or unavailable
minimum runtime halts dependent acceptance and is reported before broad repair.

Scope remains retained Svelte control eligibility: no React recovery, RN runtime, architecture
selection, deployed PWA update/offline behavior, full product or physical performance claim.
