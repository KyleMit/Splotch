import datetime, hashlib, json, os, pathlib, shutil, signal, subprocess, time
ROOT=pathlib.Path('/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch')
R=pathlib.Path('/private/tmp/splotch-resume-01a111b0/retained/node-floor/scoped-static')
R.mkdir()
NODE='/Users/kylemit/.nvm/versions/node/v24.16.0/bin/node'
BASE=R.parent.parent
SNAPSHOT=BASE/'nonce-repair/snapshot.mjs'
GRAPH=BASE/'installed-graph-final.mjs'
LOCK='705b57623e37d509826f4b6aa42b00d4957d7dd295165d462523b075e42a9f92'
NAME='enables type stripping for the shipping postbuild PWA checker'
COMMAND='node --experimental-strip-types --disable-warning=ExperimentalWarning tools/check-pwa-precache.mjs'
begin=time.monotonic();deadline=begin+600
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(body):return hashlib.sha256(body).hexdigest()
def ps():return subprocess.run(['ps','-axo','pid=,ppid=,pgid=,lstart=,command='],text=True,capture_output=True,check=True).stdout.splitlines()
def group(pid):return [x.strip() for x in ps() if len(x.split(None,3))>=3 and x.split(None,3)[2]==str(pid)]
lease={'owner':'retained_control','started':now(),'controllerPid':os.getpid(),'controllerStartIdentity':subprocess.run(['ps','-p',str(os.getpid()),'-o','pid=,ppid=,pgid=,lstart=,command='],text=True,capture_output=True).stdout.strip(),'controllerSha256':sha(pathlib.Path(__file__).read_bytes()),'wholeDeadlineSeconds':600,'ports':[],'sourceSha':'81f84eebaf71c3d178186137d9c2bb07f7e85209','sourceState':'Provisional exact2-file reviewer-prescribed flag+guard correction','children':[],'status':'running'}
def save(): (R/'lease.json').write_text(json.dumps(lease,indent=2)+'\n')
def run(label,command,seconds=120,cwd=ROOT,expected=0):
 row={'label':label,'command':list(map(str,command)),'cwd':str(cwd),'started':now(),'deadlineSeconds':seconds,'expectedExitCode':expected};start=time.monotonic()
 with (R/(label+'.stdout.txt')).open('wb') as out,(R/(label+'.stderr.txt')).open('wb') as err:
  child=subprocess.Popen(row['command'],cwd=cwd,stdout=out,stderr=err,start_new_session=True);row.update(pid=child.pid,groupPid=child.pid,startIdentity=subprocess.run(['ps','-p',str(child.pid),'-o','pid=,ppid=,pgid=,lstart=,command='],capture_output=True,text=True).stdout.strip());lease['children'].append(row);save()
  try:child.wait(timeout=min(seconds,max(0.01,deadline-time.monotonic())));row['timedOut']=False
  except subprocess.TimeoutExpired:
   row['timedOut']=True;os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
 row.update(exitCode=child.returncode,elapsedSeconds=time.monotonic()-start,finished=now(),remainingGroup=group(child.pid),stdoutSha256=sha((R/(label+'.stdout.txt')).read_bytes()),stderrSha256=sha((R/(label+'.stderr.txt')).read_bytes()))
 row['predicatePassed']=child.returncode==expected and not row['timedOut'] and not row['remainingGroup'];save()
 if not row['predicatePassed']:raise RuntimeError('Wrong result/setup in '+label)
 return row
def guard(label,expected):
 output=R/(label+'.report.json');fixture=R/'fixture'
 row=run(label,[NODE,ROOT/'node_modules/vitest/vitest.mjs','run','--config',R/'fixture-vitest.config.mjs','--testNamePattern',NAME,'--reporter=json','--outputFile='+str(output)],seconds=60,cwd=fixture,expected=expected)
 result=json.loads(output.read_text());assertions=[x for test in result['testResults'] for x in test['assertionResults'] if x['fullName']==NAME]
 if len(assertions)!=1 or assertions[0]['status']!=('passed' if expected==0 else 'failed') or result['numFailedTests']!=expected:raise RuntimeError('Guard failed for an unintended reason '+label)
 if expected and not any('expected' in x and 'tools/check-pwa-precache.mjs' in x for x in assertions[0]['failureMessages']):raise RuntimeError('Missing exact postbuild drift assertion '+label)
 row['assertionFullName']=assertions[0]['fullName'];row['assertionStatus']=assertions[0]['status'];row['actualPackageSha256']=sha((fixture/'package.json').read_bytes());row['reportSha256']=sha(output.read_bytes());save()

save()
try:
 run('source-before',[NODE,SNAPSHOT,ROOT,R/'source-before.json'],seconds=60)
 run('installed-before',[NODE,GRAPH,ROOT,R/'installed-before.json',LOCK],seconds=60)
 (R/'installed-before.complete').write_text(now()+'\n');print('INSTALLED_GRAPH_BEFORE_COMPLETE',flush=True)
 run('format-scoped',[ROOT/'node_modules/.bin/prettier','--write','package.json','tools/tests/check-pwa-precache.test.mjs'],seconds=60)
 fixture=R/'fixture';shutil.copytree(R.parent/'attempt-3/probe-current',fixture,ignore=shutil.ignore_patterns('.svelte-kit'))
 for path in ['package.json','tools/tests/check-pwa-precache.test.mjs']:shutil.copy2(ROOT/path,fixture/path)
 (fixture/'node_modules').symlink_to(ROOT/'node_modules',target_is_directory=True)
 (R/'fixture-vitest.config.mjs').write_text("export default { root: "+json.dumps(str(fixture/'tools'))+", cacheDir: "+json.dumps(str(R/'vite-cache'))+", test: { environment:'node', include:['tests/check-pwa-precache.test.mjs'], fileParallelism:false, maxWorkers:1, pool:'forks', cache:false } };\n")
 package=fixture/'package.json';positive=package.read_bytes();assert positive.count(COMMAND.encode())==1
 guard('guard-positive',0)
 rejected=positive.replace(COMMAND.encode(),COMMAND.replace('--experimental-strip-types ','',1).encode());package.write_bytes(rejected)
 guard('guard-strip-flag-reject',1)
 package.write_bytes(positive);guard('guard-restored-positive',0)
 (R/'guard-mutation.json').write_text(json.dumps({'base':'81f84eebaf71c3d178186137d9c2bb07f7e85209','positivePackageSha256':sha(positive),'negativePackageSha256':sha(rejected),'mutation':'Remove only --experimental-strip-types from actual PWA postbuild step; other bytes unchanged','testSourceSha256':sha((fixture/'tools/tests/check-pwa-precache.test.mjs').read_bytes()),'restoredPackageExact':package.read_bytes()==positive},indent=2)+'\n')
 run('check',['npm','run','check'],seconds=240)
 run('lint',['npm','run','lint'],seconds=240)
 run('source-after',[NODE,SNAPSHOT,ROOT,R/'source-after.json'],seconds=60)
 while not (R/'native-provision-released').exists():
  if time.monotonic()>=deadline:raise TimeoutError('Awaiting explicit native provisioning release before installed post-witness')
  time.sleep(0.25)
 run('installed-after',[NODE,GRAPH,ROOT,R/'installed-after.json',LOCK],seconds=60)
 before=json.loads((R/'source-before.json').read_text());after=json.loads((R/'source-after.json').read_text())
 for key in ['headTree','stagedTree','installedLockSha256','snapshot']:
  if before[key]!=after[key]:raise RuntimeError('Source/index changed during scoped qualification '+key)
 gb=json.loads((R/'installed-before.json').read_text());ga=json.loads((R/'installed-after.json').read_text());assert gb['rows']==ga['rows'] and gb['inventorySha256']==ga['inventorySha256']
 lease.update(status='qualified',sourceIndexUnchanged=True,installedGraphUnchanged=True)
except BaseException as error:lease.update(status='failed',errorType=type(error).__name__,error=str(error))
finally:
 lease.update(finished=now(),elapsedSeconds=time.monotonic()-begin,remainingOwnedGroups={str(c['pid']):group(c['pid']) for c in lease['children']});save();print(json.dumps({'status':lease['status'],'elapsedSeconds':lease['elapsedSeconds'],'error':lease.get('error'),'children':len(lease['children'])}),flush=True)
if lease['status']!='qualified':raise SystemExit(1)
