import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import time

WORKTREE = Path('/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch')
EVIDENCE = Path('/private/tmp/splotch-resume-01a111b0/retained/public-calls-node-floor')
TOPOLOGY = 'dc08a90abc67b53124146bf288c80de0f9ffd1dd'
LOCK = '705b57623e37d509826f4b6aa42b00d4957d7dd295165d462523b075e42a9f92'
PUBLIC_CALLS_DEADLINE_SECONDS = 35 * 60
TERMINATION_GRACE_SECONDS = 10
TOTAL_BEGIN = time.monotonic()
SOURCE_BINDER = Path('/private/tmp/splotch-resume-01a111b0/retained/nonce-repair/snapshot.mjs')
INSTALLED_BINDER = Path('/private/tmp/splotch-resume-01a111b0/retained/installed-graph-final.mjs')
INSTALLED_BINDER_SHA = hashlib.sha256(INSTALLED_BINDER.read_bytes()).hexdigest()
CONTROLLER_PATH = Path(__file__)
CONTROLLER_SHA = hashlib.sha256(CONTROLLER_PATH.read_bytes()).hexdigest()
SOURCE_BINDER_SHA = hashlib.sha256(SOURCE_BINDER.read_bytes()).hexdigest()
REGISTRY = '/Users/kylemit/Library/Caches/ms-playwright'


def command(argv):
    return subprocess.check_output(argv, cwd=WORKTREE, text=True).strip()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(name, value):
    (EVIDENCE / name).write_text(json.dumps(value, indent=2) + '\n')


def timestamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def witness(artifact_root):
    rows = []
    for parent in ('browser-results', 'browser-report'):
        for path in sorted((artifact_root / parent).rglob('*')):
            if path.is_file():
                stat = path.stat()
                rows.append({'path': str(path.relative_to(artifact_root)),
                             'sha256': digest(path), 'bytes': stat.st_size,
                             'mode': stat.st_mode & 0o777})
    return rows


def source_binding(label):
    path = EVIDENCE / (label + '.json')
    subprocess.run(['node', str(SOURCE_BINDER), str(WORKTREE), str(path), 'committed'], check=True, cwd=WORKTREE)
    return json.loads(path.read_text())


def installed_binding(label):
    path = EVIDENCE / (label + '.json')
    subprocess.run(['node', str(INSTALLED_BINDER), str(WORKTREE), str(path), LOCK], check=True, cwd=WORKTREE)
    return json.loads(path.read_text())


def same_installed(before, after):
    return all(before[key] == after[key] for key in ('root', 'node', 'lockSha256', 'owners', 'inventorySha256', 'rows'))


def same_inputs(before, after):
    return all(before[key] == after[key] for key in ('snapshot', 'headTree', 'stagedTree', 'node', 'installedLockSha256'))


def group_members(group):
    output = subprocess.check_output(['ps', '-axo', 'pid=,ppid=,pgid=,lstart=,command='], text=True)
    return [line for line in output.splitlines() if len(line.split()) > 2 and line.split()[2] == str(group)]


def bind_port(port):
    if port is None:
        return None
    try:
        with socket.socket() as listener:
            listener.bind(('127.0.0.1', port))
        return True
    except OSError:
        return False


EVIDENCE.mkdir()
initial_binding = source_binding('source-before')
initial_installed = installed_binding('installed-before')
source_sha = command(['git', 'rev-parse', 'HEAD'])
if source_sha != '5434e9d7ddd33ad1d2afdc7b8906aca24a8c8118':
    raise RuntimeError('Source differs from the declared clean composed floor-correction head')
if command(['git', 'status', '--porcelain']):
    raise RuntimeError('Public acceptance requires clean committed source')
for path in ('pnpm-lock.yaml', 'node_modules/.pnpm/lock.yaml'):
    if digest(WORKTREE / path) != LOCK:
        raise RuntimeError(f'Frozen lock mismatch: {path}')

record = {'owner': 'retained_control', 'controllerPid': os.getpid(),
          'sourceSha': source_sha, 'sourceTree': initial_binding['headTree'], 'topologySha': TOPOLOGY,
          'controllerSha256': CONTROLLER_SHA, 'sourceBinderSha256': SOURCE_BINDER_SHA, 'installedBinderSha256': INSTALLED_BINDER_SHA,
          'deadlineSeconds': PUBLIC_CALLS_DEADLINE_SECONDS,
          'lockSha256': LOCK, 'topologyLockSha256': LOCK,
          'installedLockSha256': LOCK, 'browserRegistry': REGISTRY,
          'node': command(['node', '--version']), 'started': timestamp(),
          'controllerStartIdentity': command(['ps', '-o', 'pid=,ppid=,pgid=,lstart=,command=', '-p', str(os.getpid())]),
          'calls': [], 'artifacts': {}, 'status': 'running'}
write_json('calls.json', record)
print(json.dumps({'event': 'start', 'sourceSha': source_sha,
                  'controllerPid': os.getpid()}), flush=True)


def run_call(label, argv, port=None):
    path = EVIDENCE / f'{label}.log.txt'
    before = source_binding(f'{label}-source-before')
    installed_before = installed_binding(f'{label}-installed-before')
    port_before = bind_port(port)
    if port_before is False:
        raise RuntimeError(f'Explicit port {port} is occupied before {label}; no foreign cleanup authorized')
    started = timestamp()
    begin = time.monotonic()
    timed_out = False
    with path.open('w') as log:
        child = subprocess.Popen(argv, cwd=WORKTREE, stdout=log,
                                 stderr=subprocess.STDOUT, start_new_session=True)
        identity = command(['ps', '-o', 'pid=,ppid=,pgid=,lstart=,command=', '-p', str(child.pid)])
        write_json('active-lease.json', {'owner': 'retained_control',
                   'controllerPid': os.getpid(), 'childPid': child.pid, 'groupPid': child.pid,
                   'processStartIdentity': identity, 'command': argv,
                   'label': label, 'port': port, 'portAvailableBefore': port_before,
                   'deadlineSeconds': PUBLIC_CALLS_DEADLINE_SECONDS,
                   'releaseCondition': 'owned caller/copied groups gone and explicit port bindable'})
        print(json.dumps({'event': 'call-start', 'label': label,
                          'childPid': child.pid, 'port': port}), flush=True)
        try:
            remaining = PUBLIC_CALLS_DEADLINE_SECONDS - (time.monotonic() - TOTAL_BEGIN)
            exit_code = child.wait(timeout=max(1, remaining))
        except (subprocess.TimeoutExpired, KeyboardInterrupt):
            timed_out = True
            os.killpg(child.pid, signal.SIGTERM)
            try:
                exit_code = child.wait(timeout=TERMINATION_GRACE_SECONDS)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                exit_code = child.wait()
    after = None
    installed_after = None
    source_error = None
    try:
        after = source_binding(f'{label}-source-after')
        installed_after = installed_binding(f'{label}-installed-after')
    except BaseException as error:
        source_error = f'{type(error).__name__}: {error}'
    row = {'label': label, 'command': argv, 'childPid': child.pid, 'groupPid': child.pid,
           'processStartIdentity': identity, 'port': port, 'started': started,
           'elapsedSeconds': time.monotonic() - begin,
           'exitCode': exit_code, 'timedOut': timed_out,
           'sourceUnchanged': after is not None and same_inputs(before, after),
           'sourceBindingError': source_error,
           'installedUnchanged': installed_after is not None and same_installed(installed_before, installed_after),
           'portAvailableBefore': port_before, 'portAvailableAfter': bind_port(port),
           'ownedGroupRemaining': group_members(child.pid),
           'sourceBeforeSha256': digest(EVIDENCE / f'{label}-source-before.json'),
           'sourceAfterSha256': digest(EVIDENCE / f'{label}-source-after.json') if after is not None else None,
           'log': str(path), 'logSha256': digest(path)}
    record['calls'].append(row)
    write_json('calls.json', record)
    print(json.dumps({'event': 'call-complete', **row}), flush=True)
    if exit_code or timed_out or not row['sourceUnchanged'] or not row['installedUnchanged'] or row['ownedGroupRemaining'] or row['portAvailableAfter'] is False:
        raise RuntimeError(f'Public call failed: {label} exit {exit_code}; full provenance in calls.json')
    return path


try:
    for artifact in ('release', 'mechanism'):
        parent = EVIDENCE / artifact
        parent.mkdir()
        build_log = run_call(f'{artifact}-build', [
            'npm', '--silent', 'run', 'migration:web-host:build', '--',
            f'--topology-sha={TOPOLOGY}', f'--topology-lock-sha256={LOCK}',
            f'--artifact={artifact}', f'--output-parent={parent}'])
        markers = [line.removeprefix('Owned web-host artifact: ')
                   for line in build_log.read_text().splitlines()
                   if line.startswith('Owned web-host artifact: ')]
        if len(markers) != 1:
            raise RuntimeError(f'Successful build has {len(markers)} root markers')
        artifact_root = Path(markers[0])
        if artifact_root.parent.resolve() != parent.resolve():
            raise RuntimeError('Builder root escaped its owned artifact parent')
        record['artifacts'][artifact] = str(artifact_root)
        write_json('calls.json', record)
        run_call(f'{artifact}-check', [
            'npm', 'run', 'migration:web-host:check', '--',
            f'--artifact-root={artifact_root}'])
        first_witness = None
        count = 2 if artifact == 'mechanism' else 1
        for invocation in range(1, count + 1):
            port = int(command(['npm', '--silent', 'run', 'show:free-port']))
            run_call(f'{artifact}-browser-{invocation}', [
                'npm', 'run', 'migration:web-host:test', '--',
                f'--artifact-root={artifact_root}', f'--port={port}',
                f'--browser-registry={REGISTRY}'], port)
            with socket.socket() as check:
                check.bind(('127.0.0.1', port))
            if artifact == 'mechanism' and invocation == 1:
                first_witness = witness(artifact_root)
                write_json('first-browser-witness.json', first_witness)
            elif artifact == 'mechanism':
                after = {row['path']: row for row in witness(artifact_root)}
                if not first_witness or any(after.get(row['path']) != row
                                            for row in first_witness):
                    raise RuntimeError('First invocation evidence changed after repeat')
                write_json('first-browser-witness-after-repeat.json',
                           {'unchanged': True, 'rows': first_witness})
    if command(['git', 'rev-parse', 'HEAD']) != source_sha:
        raise RuntimeError('Borrowed source head changed')
    if command(['git', 'status', '--porcelain']):
        raise RuntimeError('Borrowed source became dirty')
    record['status'] = 'completed-public-calls'
except BaseException as error:
    record['status'] = 'failed'
    record['error'] = f'{type(error).__name__}: {error}'
    raise
finally:
    final_binding = None
    final_installed = None
    try:
        final_binding = source_binding('source-after')
        final_installed = installed_binding('installed-after')
    except BaseException as error:
        record['finalSourceBindingError'] = f'{type(error).__name__}: {error}'
    record['sourceUnchanged'] = final_binding is not None and same_inputs(initial_binding, final_binding)
    record['installedUnchanged'] = final_installed is not None and same_installed(initial_installed, final_installed)
    record['installedBinderUnchanged'] = digest(INSTALLED_BINDER) == INSTALLED_BINDER_SHA
    record['sourceBinderUnchanged'] = digest(SOURCE_BINDER) == SOURCE_BINDER_SHA
    record['controllerUnchanged'] = digest(CONTROLLER_PATH) == CONTROLLER_SHA
    record['ownedGroupsRemaining'] = []
    group_ids = {row['groupPid'] for row in record['calls']}
    artifact_roots = set(record['artifacts'].values())
    for artifact in ('release', 'mechanism'):
        artifact_roots.update(str(path) for path in (EVIDENCE / artifact).glob('splotch-web-host-*') if path.is_dir())
    for artifact_root in artifact_roots:
        artifact_root = Path(artifact_root)
        result_path = artifact_root / 'result.json'
        if result_path.exists():
            result = json.loads(result_path.read_text())
            group_ids.update(child['termination']['groupPid'] for child in result.get('children', []) if child.get('termination', {}).get('groupPid'))
        for receipt in (artifact_root / 'controls').glob('*.json'):
            child = json.loads(receipt.read_text())
            if child.get('termination', {}).get('groupPid'):
                group_ids.add(child['termination']['groupPid'])
    for group in sorted(group_ids):
        record['ownedGroupsRemaining'].extend(group_members(group))
    record['portsAvailableAfter'] = {str(port): bind_port(port) for port in sorted({row['port'] for row in record['calls'] if row['port'] is not None})}
    if not record['sourceUnchanged'] or not record['sourceBinderUnchanged'] or not record['installedUnchanged'] or not record['installedBinderUnchanged'] or not record['controllerUnchanged'] or record['ownedGroupsRemaining'] or not all(record['portsAvailableAfter'].values()):
        record['status'] = 'failed-provenance-or-release'
    record['finished'] = timestamp()
    record['totalElapsedSeconds'] = time.monotonic() - TOTAL_BEGIN
    record['summedCallElapsedSeconds'] = sum(row['elapsedSeconds'] for row in record['calls'])
    write_json('calls.json', record)
    write_json('active-lease.json', {'owner': 'retained_control',
               'controllerPid': os.getpid(), 'state': record['status'],
               'released': timestamp() if not record['ownedGroupsRemaining'] else None,
               'ownedGroupsRemaining': record['ownedGroupsRemaining']})

if record['status'] != 'completed-public-calls':
    raise RuntimeError(record['status'])
