from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import sys
import tarfile
import time

ROOT = Path('/private/tmp/splotch-resume-01a111b0/retained')
OUT = ROOT / 'public-floor-evidence'
SOURCE = Path('/Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch')
DEADLINE_SECONDS = 600
started = time.monotonic()
OUT.mkdir(exist_ok=True)

def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def source_identity():
    def git(*args):
        return subprocess.check_output(['git', '-C', str(SOURCE), *args], text=True).strip()
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'porcelain': git('status', '--porcelain=v1')}

archive = OUT / 'node-floor-execution.tar.xz'
lease_path = OUT / 'compression-lease.json'
if archive.exists() or lease_path.exists():
    raise RuntimeError('Actual compression archive/lease must be absent; prior owned attempts require separate output roots')
lease = {'owner': 'retained_control', 'pid': os.getpid(), 'command': [sys.executable, str(Path(__file__))], 'processStartIdentity': subprocess.check_output(['ps', '-p', str(os.getpid()), '-o', 'pid=,ppid=,pgid=,lstart=,args='], text=True).strip(), 'started': stamp(), 'deadlineSeconds': DEADLINE_SECONDS, 'state': 'preparing', 'archiveAbsentBefore': True, 'preparedManifestSha256': digest(OUT / 'node-floor-execution-manifest.json'), 'ownedChildren': []}
lease_path.write_text(json.dumps(lease, indent=2) + '\n')
def timeout(signum, frame):
    raise TimeoutError('Owned complete packaging invocation exceeded its 600-second deadline')
signal.signal(signal.SIGALRM, timeout)
signal.setitimer(signal.ITIMER_REAL, max(0.01, DEADLINE_SECONDS - (time.monotonic() - started)))
try:
    selected = set()
    def add_file(path):
        if path.is_symlink() or not path.is_file():
            raise RuntimeError('Evidence member must be a regular non-symlink file: ' + str(path))
        selected.add(path)

    def add_tree(path):
        for member in path.rglob('*'):
            if member.is_symlink():
                raise RuntimeError('Unexpected evidence symlink: ' + str(member))
            if member.is_file():
                add_file(member)

    def artifact(path):
        for member in path.iterdir():
            if member.is_file():
                add_file(member)
        for name in ('controls', 'browser-results', 'browser-report'):
            if (path / name).exists():
                add_tree(path / name)

    floor = ROOT / 'node-floor'
    for member in floor.iterdir():
        if member.is_file():
            add_file(member)
    for name in ('attempt-2', 'attempt-3', 'scoped-static', 'scoped-static-2', 'scoped-static-3', 'full-quality', 'full-browserless', 'full-postbuild'):
        for member in (floor / name).iterdir():
            if member.is_file() and not member.name.endswith('-source.tar') and member.name != 'node-v22.13.0-darwin-arm64.tar.xz':
                add_file(member)
    for member in (ROOT / 'public-calls-node-floor').iterdir():
        if member.is_file():
            add_file(member)
    artifact(ROOT / 'public-calls-node-floor/release/splotch-web-host-dvnCLi')
    artifact(ROOT / 'public-calls-node-floor/mechanism/splotch-web-host-lxAIXl')
    for member in ROOT.glob('claude-round3*'):
        if member.is_file() and member.suffix in ('.json', '.txt', '.log'):
            add_file(member)
    for member in ROOT.glob('original-round3*.md'):
        add_file(member)
    add_file(ROOT / 'installed-graph-final.mjs')
    add_file(ROOT / 'nonce-repair/snapshot.mjs')
    add_file(Path(__file__))

    before = source_identity()
    if before['porcelain']:
        raise RuntimeError('Compression source binding must be clean committed source')
    rows = [{'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size, 'mode': p.stat().st_mode & 0o7777, 'sha256': digest(p)} for p in sorted(selected)]
    manifest = {'createdAt': stamp(), 'sourceAtPackaging': before, 'files': rows, 'excluded': ['physical source/dependency copies', 'runtime caches', 'emitted product byte copies', 'authentication state and raw conversations', 'published official Node vendor archive bytes (durably local; public URL/digest/member/decoded inventory retained)', 'recoverable Git source archive bytes (exact commit and complete member/decoded inventories retained)'], 'rawBytes': sum(r['bytes'] for r in rows), 'format': 'standard tar.xz, LZMA preset 9, 64 MiB dictionary; original file bytes and modes preserved'}
    (OUT / 'node-floor-execution-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    manifest_path = OUT / 'node-floor-execution-manifest.json'
    rows_with_manifest = rows + [{'path': str(manifest_path.relative_to(ROOT)), 'bytes': manifest_path.stat().st_size, 'mode': manifest_path.stat().st_mode & 0o7777, 'sha256': digest(manifest_path)}]
    lease.update({'sourceBefore': before, 'selectedFiles': len(rows_with_manifest), 'rawBytes': manifest['rawBytes'], 'state': 'compressing'})
    (OUT / 'compression-lease.json').write_text(json.dumps(lease, indent=2) + '\n')
    print(json.dumps(lease), flush=True)

    with tarfile.open(archive, 'x:xz', preset=9, format=tarfile.PAX_FORMAT) as tar:
        for row in rows_with_manifest:
            path = ROOT / row['path']
            if path.stat().st_size != row['bytes'] or digest(path) != row['sha256']:
                raise RuntimeError('Selected evidence changed before compression: ' + row['path'])
            info = tarfile.TarInfo('retained/' + row['path'])
            info.size = row['bytes']
            info.mode = row['mode']
            info.mtime = 0
            with path.open('rb') as f:
                tar.addfile(info, f)
    expected = {'retained/' + row['path']: row for row in rows_with_manifest}
    seen = set()
    with tarfile.open(archive, 'r:xz') as tar:
        for member in tar:
            name = member.name
            if not member.isfile() or name in seen or name.startswith('/') or '..' in Path(name).parts or name not in expected:
                raise RuntimeError('Unsafe or unexpected decoded evidence member: ' + name)
            row = expected[name]
            h = hashlib.sha256()
            with tar.extractfile(member) as f:
                for block in iter(lambda: f.read(1024 * 1024), b''):
                    h.update(block)
            if member.size != row['bytes'] or member.mode != row['mode'] or h.hexdigest() != row['sha256']:
                raise RuntimeError('Decoded evidence differs: ' + name)
            seen.add(name)
    if seen != set(expected):
        raise RuntimeError('Incomplete decoded evidence member inventory')
    for row in rows_with_manifest:
        if digest(ROOT / row['path']) != row['sha256']:
            raise RuntimeError('Evidence source changed during compression: ' + row['path'])
    after = source_identity()
    if before != after:
        raise RuntimeError('Checkout changed during compression')
    lease.update({'state': 'verified-complete', 'finished': stamp(), 'elapsedSeconds': time.monotonic() - started, 'sourceAfter': after, 'sourceUnchanged': True, 'decodedMembers': len(seen), 'archiveBytes': archive.stat().st_size, 'archiveSha256': digest(archive), 'manifestSha256': digest(manifest_path), 'ownedChildren': []})

except BaseException as error:
    lease.update({'state': 'failed', 'finished': stamp(), 'elapsedSeconds': time.monotonic() - started, 'error': repr(error), 'archiveBytes': archive.stat().st_size if archive.exists() else None, 'ownedChildren': []})
    (OUT / 'compression-failure.json').write_text(json.dumps(lease, indent=2) + '\n')
    raise
finally:
    signal.setitimer(signal.ITIMER_REAL, 0)
    lease.update({'finished': stamp(), 'elapsedSeconds': time.monotonic() - started})
    lease_path.write_text(json.dumps(lease, indent=2) + '\n')
    print(json.dumps(lease), flush=True)
