Continue the original retained-control PR2702 review in this exact original conversation,
b5bb0824-3f7a-4ad7-9e05-4e8e9af77333. This is substantive round three of the three-round
budget: original round one plus genuinely resumed round two were used, and this is the one
remaining final executed-source review. A fresh fallback, reset, fourth round or alternate
conversation is not successful continuation. Preserve review provenance. Use leave-pr-review
and post verified findings through the established native handler; do not mutate source.

PR: https://github.com/KyleMit/Splotch/pull/2702
Actual cwd: /Users/kylemit/.codex/worktrees/migration-retained-controls/Splotch
Frozen clean head: 81f84eebaf71c3d178186137d9c2bb07f7e85209
Frozen tree: 957779386684564e864da7a9d79c0ed4ea9b32e3
Accepted integration base: f14966ee98563e3c569fbcb90beea6d9c684614a
Actual final CI checkout: 22e43b1e2448eca0876836d2ed4d455585df2d1e
Actual CI checkout tree: 957779386684564e864da7a9d79c0ed4ea9b32e3
Actual CI parents: accepted f14966ee98563e3c569fbcb90beea6d9c684614a and frozen
81f84eebaf71c3d178186137d9c2bb07f7e85209. Tree equality is established; Git-derived
metadata identities are separately recorded and must not be equated.

Read the complete final disposition before judging acceptance:
/private/tmp/splotch-resume-01a111b0/retained/final-round3-disposition.md
Read the complete final-head CI/export manifest:
/private/tmp/splotch-resume-01a111b0/retained/ci-final-81/final-head-evidence.json
Those files and the complete underlying receipts are mirrored durably under
/Users/kylemit/Code/Splotch/logs/migration-resumption-01a111b0/retained.
The actual frozen source contains the focused implementation, documentation and complete
technical packet at docs/migration/evidence/retained-control/README.md, local-controls.json,
local-execution.tar.xz, local-execution-manifest.json.txt, compression-lease.json.txt and
compression-release.json.txt. Verify size/digest/safe members before any owned extraction;
never overlay source or automatically execute archived scripts. The packet preserves full
graphs/logs/source bindings and controls, not physical dependency caches or raw conversations.

Your actual round-two findings and publication remain unchanged:
/private/tmp/splotch-resume-01a111b0/retained/nonce-repair/original-round2/findings.json
https://github.com/KyleMit/Splotch/pull/2702#pullrequestreview-5431123113
Round two confirmed the original six dispositions and the causal nonce diagnosis, and required
three precise corrections before implementation. Review the final implementation of all three:

1. Fully owned nonce pin and actual marker context; loud refusal outside owned copies, including
   the actual ordinary shipping postbuild/PWA owner. Unpinned reads remain fresh/read-only,
   and separate evaluations produce unique values. Actual owner tests prove owned positives,
   foreign/missing/altered marker or context refusals, restored positives, ordinary shipping
   positive/refusal/restoration and unpinned independent evaluations.
2. No nonce URL normalization. Actual direct byte comparison rejects a differently pinned
   worker for the intended product-byte reason and accepts restoration. Both complete local
   and final CI released/mechanism inventories compare all 3,095 emitted files with zero
   normalizations; the only retained allowance is the explicit owned-copy absolute prefix.
3. Exactly metadata+nonce environment keys, one pre-build mint from the actual copied owner,
   strict canonical UUID and recorded/emitted URL equality in every later artifact caller.
   Actual tampered-record/environment/digest readback fails while the worker stays unchanged,
   restoration passes, and the browser child environment does not carry the pin.

Confirm the original six fixes remain valid on final executed source: owner-pinned Kit
metadata without time normalization; actual detached-preview cleanup requiring successful
artifact preflight and real launch; a genuine positive hydration hold plus same input canvas
and visible ink adoption; owned SIGINT/SIGTERM/forced escalation cleanup with unrelated
survivor; unique repeated invocation paths preserving the first evidence bytes; and kind/mode
checking before equal digest short-circuit. Challenge plausible false passes and false
rejections. Agreement alone is not evidence; tie every empirical conclusion to actual owner,
source/input identity, positive behavior, intended rejecting reason and restored control.

Actual final local runtime source is clean 85c8c926829602e07ab508e9ec150593aa890f21,
tree 100e345bb2a2cb8871ea830c26202d86019fb1bc. Current 81 changes only accepted documentation
composition plus six retained evidence/status paths; production/build/checker/package/lock
inputs match 85 exactly. Source-bound Quality 15 and Browserless 5 stages passed there. All seven
distinct public calls then passed under a named 35-minute cumulative wall deadline, actual
906.006821 seconds. Complete source/index and the 64,872-row installed graph were equal
around every call and overall. Original groups were absent and port 5300 rebindable after
each call. First mechanism screenshot/report/last-run bytes/modes/hashes stayed equal after
the second UUID. Source 85 output bytes are preserved locally and durably.

Actual final-head hosted CI is complete and green: Tests 37502660124, native compile 37502659937,
ADR 37502659689;23 registered checks18 success, 5 skipped. All 18 successful job logs are complete native
decoded strings, 4,218,129 UTF-8bytes, with actual checkout 22e attribution. Retained job 112403699090
completed 17:20:25→17:42:12UTC: 1,307s total, 1,216s seven-call step, 69s setup, 22s remaining stages.
This validates the named 2,100s allowance as harness cost, not app latency.

The complete retained ZIPs were qualified against exact GitHub size/digest and every safe
regular member; both uploaded artifacts have 7,569 full source rows exactly matching 81 and
complete 64,708-row Linux installed graphs for each role. Local macOS graphs are distinct.
Release artifact 11430624724 is 15,050,138bytes, SHA256
36ebf761824133212fec4251eb408f423241077dd5c4c4cd66ea0e693b5d461c.
Mechanism artifact 11431033811 is 15,451,159bytes, SHA256
1a4aae4b3c08517924ad204c1fbe1848d891fd2e5b2dca7fb6df850e49711ea2.
Their full parsed inputs, results, complete build/browser logs, safe-member manifests,
separate HTML reports and PNGs are at ci-final-81/installed-release and installed-mechanism.
Uploaded ZIPs contain complete output hash inventories and executed comparator evidence;
they do not contain every emitted hosted product byte. Do not infer missing bytes from UI
log snippets or relabel old 3a92/85/be receipts as final 81 CI.

Preserved unintended failures are not rejecting controls: the initial clean 3a92 nonce byte
failure, generated-type setup, maintained fixture cap/import-boundary/stale preview failures,
and the evidence sampler's inherited 1 MiB binary-diff ENOBUFS before any guard. No cap, exclusion,
output equivalence or startup/lazy budget was weakened. Corrected actual fixture tests require
preflight and launch. Formatted bounded docs were committed and the unchanged sampler then
qualified the affected guards on clean 81. Old initial broad gates without at-execution full
source identity remain owner-attested exploratory, superseded by exact final CI for acceptance.
Original worktree disappearance, exact replacement and frozen installed identity requalification
are recorded; its cause is unknown. Original copies/PIDs do not authorize cleanup.

Review requests are read-only/scoped. Source stays frozen. The parent may own a separate tools
lease; ask the broker before any full suite/build/browser/native/performance run. Do not run
unrelated full suites, re-install dependencies, mutate source, change review ledgers, normalize
unintended failures or reset budgets. Bounded native-owner tests/source/evidence checks may be
requested through the established command broker with actual expected observation and reason.

The decision is whether this retained Svelte control unit is independently accepted and eligible
for integration. Explicitly state any material unresolved finding or input/provenance limit.
The unit does not prove a React host/recovery, RN runtime, architecture selection, deployed PWA
update/offline behavior, full product completion or physical comparative performance. Shipping
Capacitor compile cannot prove RN. Accept only this actual retained scope if all findings and
controls are resolved with current evidence; otherwise leave dependent acceptance halted.
