# Shared Java21 qualification

The three final finite stages exited0 and have accepted complete receipts: held-download
acquisition, publisher authentication with complete installed-payload association, and
actual JVM/JDK tooling identity. The installed trusted Java home is
`/Library/Java/JavaVirtualMachines/temurin-21.jdk/Contents/Home`.

Exact source owners are inert `.txt` files. No source in this packet should be executed.
`qualified-java21.json` binds the final source hashes and result receipts. The unchanged
profile retains historical preparation statements; actual completion is recorded in the
final stage receipts and qualified result. `running.json` is a historical start receipt;
`complete.json` is the final status. Every earlier failed and accepted attempt remains
separate and retains its original producer status.

The official tar signature passed, a parsed RSA-value-only byte alteration was rejected,
and the original signature passed again. The same held archive file descriptor covered
authentication, all550 archive members and final digest readback. The installed member
set, types and all459 regular file bytes/digests/modes match. Installed directory context
and archive directory context are explicitly recorded; no extraction or chmod occurred.

Actual Java21 properties, all69 module names/versions, Apple code-signature integrity,
built-in jimage image-header read, actual qualified Java17 rejection and restoredJava21
passed. Observed libnio/libjimage JNI paths apply only to jimage. JVM library-tag
observations are partial JNI loads, not the complete OS loaded-image graph. Ordinary
keytool/Gradle/native SDK inputs, compiled closure, app installation and device work
remain separate L0 gates. This qualification does not accept held F1 or N1 work.

Trust relies on the declared official Adoptium key authority and authenticated download
channels, exact frozen artifact bytes, the previously qualified sqv/OpenSSL route and
trusted host/no concurrent same-user mutation. Homebrew bottle metadata is a bootstrap
for the verifier route, not an independent upstream or reproducible-binary attestation.
Signature policy used the recorded actual UTC; signer liveness at signing time does not
claim fresh revocation knowledge or present-day key validity. See the exact claim limits
in the profile and final qualified result. No signing, DYLD or runtime security policy
was weakened.

Raw200MB archive, installed JVMs, inherited verifier/SDK/signing/private-host material
and signed CDN redirect channels remain host-local. Exact required-input mappings,
bytes and hashes plus availability limits are in `input-availability-map.json`. These
omissions mean this packet alone cannot independently reproduce the qualification. No
physical device identifiers, credentials or redirect authorization tokens are included.

The manifest lists every packaged file except the manifest itself, preserves the
source-to-package byte mapping, and is verified against complete actual membership.
The consumer must verify its selected Java path and establish its own effective
environment and isolated temporary-directory ownership.
