import argparse
import collections
import copy
import datetime
import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys

BASE = 'f14966ee98563e3c569fbcb90beea6d9c684614a'
TAGS = ['v1.0.0', 'v1.0.1', 'v1.1.0', 'v1.2.0', 'v1.3.0', 'v1.4.0', 'v1.5.0', 'v1.6.0']
INPUT_NAMES = ['live-tags-native-complete.json', 'live-tag-association.json', 'live-release-inventory.json', 'supported-artifact-qualification.json']
OWNER_PATTERN = re.compile(r'localStorage|sessionStorage|STORAGE_KEYS|Preferences|SecureStorage|indexedDB|openDB\(|(?:read|write)(?:Bool|String|Int|Number)\(|removeKey\(|hydrateDurableStorage|installationId|@capacitor/device|splotch[-_]|gemini-api-key|managed-access-code')
SIGNALS = {
    'held_picture_database': r'splotch-unsaved-pictures',
    'held_picture_hint': r'unsavedPicturesHeld|splotch-unsaved-pictures-held',
    'pending_durable_removals': r'splotch-pending-durable-removals',
    'vault_absence_marker': r'vaultAbsent|vault-absen|vault-absence|secureVaultEmpty|splotch-secure-empty',
    'coloring_marker': r'[\'\"]\.installed[\'\"]',
    'android_unique_work': r'splotch-coloring-pack[\'\"]',
    'ios_persisted_job': r'jobs/current\.json',
    'ios_background_session': r'coloring-packs|URLSessionConfiguration\.background|sessionIdentifier',
    'identity': r'installationId|@capacitor/device|Device\.getId|splotch-free-generation-v1|identifierForVendor|ANDROID_ID',
    'credential_namespace': r'gemini-api-key|managed-access-code|splotch-ai-access-token|splotch-ai-user-api-key',
    'storage_namespace': r'[\'\"]splotch-[^\'\"]+[\'\"]',
    'pack_directory': r'getNoBackupFilesDir|versionDirectory|bookDirectory|rootDirectory|deleteOldVersions|deleteOld',
}
EXPECTED = {
    'storage': ['src/lib/storage.js', 'src/lib/storage.ts', 'web/src/lib/storage.ts'],
    'secure': ['src/lib/secureStorage.js', 'src/lib/secureStorage.ts', 'web/src/lib/secureStorage.ts'],
    'settings': ['src/lib/state/settings.svelte.js', 'src/lib/state/settings.svelte.ts', 'web/src/lib/state/settings.svelte.ts'],
    'stroke_width': ['src/lib/state/strokeWidth.svelte.js', 'src/lib/state/strokeWidth.svelte.ts', 'web/src/lib/state/strokeWidth.svelte.ts'],
    'central_keys': ['src/lib/storageKeys.ts', 'web/src/lib/storageKeys.ts'],
    'held_pictures': ['src/lib/drawing/unsavedPictureStore.ts', 'web/src/lib/drawing/unsavedPictureStore.ts'],
    'held_state': ['src/lib/state/saveFailure.svelte.ts', 'web/src/lib/state/saveFailure.svelte.ts'],
    'android_pack_storage': ['android/app/src/main/java/art/splotch/app/ColoringPackStorage.java'],
    'android_pack_plugin': ['android/app/src/main/java/art/splotch/app/ColoringPacksPlugin.java'],
    'ios_pack_plugin': ['ios/App/App/ColoringPacksPlugin.swift'],
    'ios_native_lock': ['ios/App/App.xcodeproj/project.xcworkspace/xcshareddata/swiftpm/Package.resolved'],
}

def require(condition, code, message):
    if not condition:
        raise RuntimeError(f'{code}: {message}')

def git(repo, *args):
    result = subprocess.run(['git', *args], cwd=repo, capture_output=True)
    require(result.returncode == 0, 'GIT_READ_FAILED', f'{args}: {result.stderr.decode(errors="replace")}')
    return result.stdout

def digest(data):
    return hashlib.sha256(data).hexdigest()

def tree(repo, commit):
    result = {}
    for item in git(repo, 'ls-tree', '-rz', '--full-tree', commit).split(b'\0'):
        if not item:
            continue
        meta, path = item.split(b'\t', 1)
        mode, kind, oid = meta.decode().split()
        if kind == 'blob':
            result[path.decode()] = {'mode': mode, 'gitBlob': oid}
    return result

def blob_batch(repo, entries):
    oids = list(dict.fromkeys(row['gitBlob'] for row in entries.values()))
    result = git(repo, 'cat-file', '--batch') if not oids else subprocess.run(
        ['git', 'cat-file', '--batch'], cwd=repo,
        input=('\n'.join(oids) + '\n').encode(), capture_output=True, check=True).stdout
    offset = 0
    blobs = {}
    for oid in oids:
        end = result.index(b'\n', offset)
        actual_oid, kind, size = result[offset:end].decode().split()
        require(actual_oid == oid and kind == 'blob', 'BLOB_IDENTITY', oid)
        size = int(size)
        offset = end + 1
        blobs[oid] = result[offset:offset + size]
        offset += size
        require(result[offset:offset + 1] == b'\n', 'BLOB_BOUNDARY', oid)
        offset += 1
    return blobs

def production_text(path):
    if re.search(r'\.(test|spec)\.|/__tests__/', path):
        return False
    return ((path.startswith(('src/', 'web/src/')) and path.endswith(('.js', '.ts', '.tsx', '.svelte')))
            or (path.startswith(('android/app/src/main/', 'ios/App/App/')) and path.endswith(('.java', '.kt', '.swift'))))

def explicit_category(path):
    if path in ['package.json', 'package-lock.json', 'pnpm-lock.yaml', 'capacitor.config.json', '.npmrc']:
        return 'package-lock-identity'
    if path.startswith('patches/') and path.endswith('.patch'):
        return 'dependency-patch'
    if path.startswith('android/') and (path.endswith(('.gradle', '.properties')) or path in ['android/gradlew', 'android/gradle/wrapper/gradle-wrapper.jar']):
        return 'android-build-identity'
    if path.startswith('android/app/src/main/') and path.endswith(('.java', '.kt', 'AndroidManifest.xml')):
        return 'android-native-owner'
    if path.startswith('ios/') and (path.endswith(('.swift', '.plist', '.entitlements', '.pbxproj', 'Package.resolved', '.xcconfig')) or pathlib.PurePosixPath(path).name in ['Podfile', 'Podfile.lock']):
        return 'ios-native-owner-lock'
    if path.endswith('strip-native-assets.mjs'):
        return 'native-build-source-association'
    if path.startswith(('src/lib/platform/', 'web/src/lib/platform/', 'src/lib/coloringPacks/', 'web/src/lib/coloringPacks/')) and production_text(path):
        return 'platform-pack-contract'
    if path in ['src/lib/platform.js', 'src/lib/platform.ts', 'web/src/lib/platform.ts']:
        return 'platform-identity'
    return None

def identify(repo, row, supplied_commit=None):
    ref = row['ref']
    expected = row['localCommit']
    actual_object = git(repo, 'rev-parse', '--verify', ref).decode().strip()
    actual_commit = git(repo, 'rev-parse', '--verify', ref + '^{commit}').decode().strip()
    require(row['sameRefObject'] and actual_object == row['liveObject']['sha'] == row['localObject'], 'TAG_OBJECT_MISMATCH', ref)
    require(actual_commit == expected, 'TAG_COMMIT_MISMATCH', ref)
    source = supplied_commit or actual_commit
    require(source == expected, 'SOURCE_COMMIT_MISMATCH', f'{ref}: expected {expected}, supplied {source}')
    return source

def verify_freeze(root, records):
    expected = {f'sources/{tag}/{row["path"]}': row for tag, rows in records.items() for row in rows}
    actual = {str(p.relative_to(root)) for p in (root / 'sources').rglob('*') if p.is_file()}
    require(actual == set(expected), 'SELECTED_OWNER_SET_MISMATCH', json.dumps({'missing': sorted(set(expected) - actual), 'extra': sorted(actual - set(expected))}))
    for path, row in expected.items():
        p = root / path
        require(not p.is_symlink() and p.is_file(), 'FROZEN_TYPE_MISMATCH', path)
        data = p.read_bytes()
        require(len(data) == row['bytes'] and digest(data) == row['sha256'], 'FROZEN_BYTES_MISMATCH', path)
        wanted = 0o755 if row['mode'] == '100755' else 0o644
        require(p.stat().st_mode & 0o777 == wanted, 'FROZEN_MODE_MISMATCH', path)
        require(hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == row['gitBlob'], 'FROZEN_GIT_BLOB_MISMATCH', path)
    return {'result': 'pass', 'selectedFiles': len(expected), 'totalBytes': sum(x['bytes'] for x in expected.values())}

def mismatch_paths(a, b, prefix=''):
    if type(a) is not type(b):
        return [prefix]
    if isinstance(a, dict):
        result = []
        for key in sorted(set(a) | set(b)):
            path = f'{prefix}/{key}'
            if key not in a or key not in b:
                result.append(path)
            else:
                result += mismatch_paths(a[key], b[key], path)
        return result
    if isinstance(a, list):
        return [] if a == b else [prefix]
    return [] if a == b else [prefix]

def normalized_json(data, lock):
    value = json.loads(data)
    del value['version']
    if lock:
        del value['packages']['']['version']
    return value

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', required=True)
    parser.add_argument('--inputs', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    repo, inputs, output = map(pathlib.Path, [args.repo, args.inputs, args.output])
    require(output.is_dir(), 'OUTPUT_MISSING', str(output))
    require(not (output / 'sources').exists(), 'OUTPUT_NOT_NEW', str(output / 'sources'))
    associations = json.loads((inputs / 'live-tag-association.json').read_text())
    require([row['ref'].removeprefix('refs/tags/') for row in associations] == TAGS, 'FINITE_TAG_SET', 'Eight ordered release tags required')
    input_manifest = []
    (output / 'inputs').mkdir(exist_ok=True)
    for name in INPUT_NAMES:
        data = (inputs / name).read_bytes()
        (output / 'inputs' / name).write_bytes(data)
        input_manifest.append({'path': name, 'bytes': len(data), 'sha256': digest(data)})
    selected_by_tag, manifests, signals = {}, [], {}
    original_bytes = {}
    source_before = {'head': git(repo, 'rev-parse', 'HEAD').decode().strip(), 'status': git(repo, 'status', '--porcelain=v1').decode()}
    require(source_before['head'] == BASE, 'PARENT_BASE_MISMATCH', source_before['head'])
    for association in associations:
        commit = identify(repo, association)
        tag = association['ref'].removeprefix('refs/tags/')
        entries = tree(repo, commit)
        readable = {p: row for p, row in entries.items() if production_text(p) or explicit_category(p)}
        blobs = blob_batch(repo, readable)
        source_rows, selected_rows, tag_signals = [], [], {name: [] for name in SIGNALS}
        for path, identity in sorted(readable.items()):
            data = blobs[identity['gitBlob']]
            row = {'path': path, **identity, 'bytes': len(data), 'sha256': digest(data)}
            text = data.decode(errors='replace')
            category = explicit_category(path)
            if production_text(path):
                source_rows.append(row)
                for name, expression in SIGNALS.items():
                    pattern = re.compile(expression)
                    for number, line in enumerate(text.splitlines(), 1):
                        if pattern.search(line):
                            tag_signals[name].append({'path': path, 'line': number, 'text': line.strip()})
                if OWNER_PATTERN.search(text):
                    category = category or 'persistence-key-consumer'
            if not category:
                continue
            require(identity['mode'] in ['100644', '100755'], 'SELECTED_MODE', path)
            row['category'] = category
            target = output / 'sources' / tag / path
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as file:
                file.write(data)
            target.chmod(0o755 if identity['mode'] == '100755' else 0o644)
            selected_rows.append(row)
            original_bytes[(tag, path)] = data
        lib_root = 'src/lib' if any(p.startswith('src/lib/') for p in entries) else 'web/src/lib'
        required = [f'{lib_root}/storage.' + ('js' if tag.startswith('v1.0.') else 'ts'),
                    f'{lib_root}/secureStorage.' + ('js' if tag.startswith('v1.0.') else 'ts')]
        for path in required:
            require(path in {r['path'] for r in selected_rows}, 'REQUIRED_STORAGE_OWNER', f'{tag}:{path}')
        selected_by_tag[tag] = selected_rows
        signals[tag] = tag_signals
        manifests.append({'tag': tag, 'tagObject': association['localObject'], 'commit': commit,
                          'tree': git(repo, 'rev-parse', commit + '^{tree}').decode().strip(), 'libRoot': lib_root,
                          'selection': selected_rows, 'searchedProductionSources': source_rows,
                          'expectedRolePaths': {role: {'present': [p for p in paths if p in entries], 'absent': [p for p in paths if p not in entries]} for role, paths in EXPECTED.items()}})
    positive = verify_freeze(output, selected_by_tag)
    controls = []
    try:
        identify(repo, associations[0], associations[2]['localCommit'])
        raise RuntimeError('WRONG_SOURCE_ACCEPTED')
    except RuntimeError as error:
        require(str(error).startswith('SOURCE_COMMIT_MISMATCH:'), 'WRONG_REJECTION_REASON', str(error))
        controls.append({'name': 'wrong-tag-source', 'intendedMutation': {'tag': TAGS[0], 'suppliedCommit': associations[2]['localCommit']}, 'result': 'expected-rejection', 'reason': str(error)})
    missing = output / 'sources' / TAGS[0] / 'src/lib/storage.js'
    held = output / 'controls-missing-owner.storage.js'
    os.replace(missing, held)
    try:
        try:
            verify_freeze(output, selected_by_tag)
            raise RuntimeError('MISSING_OWNER_ACCEPTED')
        except RuntimeError as error:
            require(str(error).startswith('SELECTED_OWNER_SET_MISMATCH:') and 'src/lib/storage.js' in str(error), 'WRONG_REJECTION_REASON', str(error))
            controls.append({'name': 'missing-selected-storage-owner', 'intendedMutation': str(missing.relative_to(output)), 'result': 'expected-rejection', 'reason': str(error)})
    finally:
        os.replace(held, missing)
    restored = verify_freeze(output, selected_by_tag)
    controls.append({'name': 'restored-positive', **restored})
    left, right = TAGS[:2]
    old_paths = set(r['path'] for r in selected_by_tag[left]) | set(r['path'] for r in selected_by_tag[right])
    collapse = {'left': left, 'right': right, 'rawComparisons': [], 'semanticComparisons': [], 'excludedJsonMetadataOnly': {'package.json': ['/version'], 'package-lock.json': ['/version', '/packages//version']}}
    for path in sorted(old_paths):
        a, b = original_bytes.get((left, path)), original_bytes.get((right, path))
        collapse['rawComparisons'].append({'path': path, 'leftSha256': digest(a) if a is not None else None, 'rightSha256': digest(b) if b is not None else None, 'sameBytes': a == b, 'leftMode': next((r['mode'] for r in selected_by_tag[left] if r['path'] == path), None), 'rightMode': next((r['mode'] for r in selected_by_tag[right] if r['path'] == path), None)})
        if a is not None and b is not None and path in ['package.json', 'package-lock.json']:
            aa, bb = normalized_json(a, path == 'package-lock.json'), normalized_json(b, path == 'package-lock.json')
            collapse['semanticComparisons'].append({'path': path, 'sameAfterOnlyDeclaredExclusions': aa == bb, 'remainingMismatchJsonPointers': mismatch_paths(aa, bb)})
    core_paths = ['src/lib/storage.js', 'src/lib/secureStorage.js', 'src/lib/state/settings.svelte.js', 'src/lib/state/strokeWidth.svelte.js', 'src/lib/platform.js', 'capacitor.config.json', 'android/app/src/main/AndroidManifest.xml', 'android/app/src/main/java/art/splotch/app/MainActivity.java']
    collapse['persistentCoreByteAndModeEquivalent'] = all(next(r for r in collapse['rawComparisons'] if r['path'] == p)['sameBytes'] and next(r for r in collapse['rawComparisons'] if r['path'] == p)['leftMode'] == next(r for r in collapse['rawComparisons'] if r['path'] == p)['rightMode'] for p in core_paths)
    collapse['resolvedPackageLockEquivalentExceptRootVersion'] = next(r for r in collapse['semanticComparisons'] if r['path'] == 'package-lock.json')['sameAfterOnlyDeclaredExclusions']
    collapse['fullSelectedSourceEquivalent'] = all(r['sameBytes'] and r['leftMode'] == r['rightMode'] for r in collapse['rawComparisons'])
    source_after = {'head': git(repo, 'rev-parse', 'HEAD').decode().strip(), 'status': git(repo, 'status', '--porcelain=v1').decode()}
    require(source_after == source_before, 'SOURCE_MUTATED', json.dumps({'before': source_before, 'after': source_after}))
    receipt = {'schemaVersion': 1, 'observedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'producerSha256': digest(pathlib.Path(__file__).read_bytes()), 'parentBase': BASE, 'inputs': input_manifest,
               'sourceBefore': source_before, 'sourceAfter': source_after, 'tags': manifests,
               'selectionRules': {'productionScope': 'All non-test .js/.ts/.tsx/.svelte under each actual src or web/src; all production .java/.kt/.swift under native app sources', 'contentPattern': OWNER_PATTERN.pattern, 'explicit': 'Root package/lock/.npmrc/Capconfig; dependency patches; Android Gradle/properties/wrapper; native production source/manifest; iOS Swift/plist/entitlements/project/SPM/Pod lock; actual strip-native-assets script; actual platform/coloringPacks production directories'},
               'positive': positive, 'controls': controls,
               'claimLimits': ['Tagged Git source only; selected blobs do not prove installed artifact source association', 'No installed dependency tree/plugin source acquired, native dependency resolution, signing/channel, effective runtime WebView origin, installation or upgrade execution', 'Absence signals cover enumerated production source paths and declared literal patterns; runtime aliases or external plugin data are outside that claim', 'No dependency or native source was executed']}
    for name, value in [('manifest.json', receipt), ('semantic-signals.json', signals), ('oldest-collapse.json', collapse)]:
        (output / name).write_text(json.dumps(value, indent=2) + '\n')
    print(json.dumps({'result': 'pass', 'tags': len(manifests), 'selectedFiles': positive['selectedFiles'], 'selectedBytes': positive['totalBytes'], 'controls': controls, 'oldestPersistentCoreEquivalent': collapse['persistentCoreByteAndModeEquivalent'], 'oldestLockGraphEquivalent': collapse['resolvedPackageLockEquivalentExceptRootVersion'], 'oldestFullSelectedSourceEquivalent': collapse['fullSelectedSourceEquivalent']}, indent=2))

if __name__ == '__main__':
    main()
