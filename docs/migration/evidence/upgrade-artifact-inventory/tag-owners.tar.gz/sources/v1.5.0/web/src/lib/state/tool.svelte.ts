import { STORAGE_KEYS, readString, writeString, onDurableRestore } from '../storage';
import type { CommonIconName } from '../components/iconTypes';

// The active brush, a single four-way axis picked from the Actions Panel's
// Brush Menu:
//   pen    — solid ink, no texture (the default).
//   crayon — textured wax with color mixing (ADR-0065).
//   magic  — reveals colors where the child paints (ADR-0043): the active
//            coloring page's colored fill when one is applied, otherwise a
//            random rainbow, so it works on any canvas.
//   eraser — removes pixels; shares the stroke-width setting at a multiplier.
// Pen and crayon are the "ink brushes": both lay down the active palette color.
export type BrushType = 'pen' | 'crayon' | 'magic' | 'eraser';
export type OptionalBrushType = Exclude<BrushType, 'pen'>;

// Fields are readonly, not just the array slots: BRUSH_TYPES is derived from
// this list once at module load, so a mutable `brush` would let a consumer
// reintroduce the very drift deriving it removed.
export interface BrushOption {
  readonly brush: BrushType;
  readonly icon: CommonIconName;
  readonly label: string;
  readonly id: string;
}

// The Brush Menu's entries, in presentation order — the icon/label/id metadata
// the Brush Button trigger (its stacked faces) and the Brush Menu popover both
// render. The eraser keeps its long-standing #eraserButton id (and the magic
// brush #magicBrushButton) from their days as top-level buttons — the
// data-off-eraser CSS driven by Settings and the E2E suite address them by id.
//
// Each icon name is `brush-` + its BrushType, but it stays spelled out as a
// literal rather than derived from the brush: icon-orphans.test.ts counts an
// icon as referenced only where a quoted string literal of its name appears in
// non-test source, so building the name with a template literal would stop
// these from vouching for their own SVGs. The pairing this spells out twice is
// held instead by a drift guard in tool.svelte.test.ts.
export const BRUSH_OPTIONS: readonly BrushOption[] = [
  { brush: 'pen', icon: 'brush-pen', label: 'Pen', id: 'penBrushButton' },
  { brush: 'crayon', icon: 'brush-crayon', label: 'Crayon', id: 'crayonBrushButton' },
  { brush: 'magic', icon: 'brush-magic', label: 'Magic brush', id: 'magicBrushButton' },
  { brush: 'eraser', icon: 'brush-eraser', label: 'Eraser', id: 'eraserButton' },
];

// Derived from the Brush Menu's entries, so the two lists can't drift apart.
export const BRUSH_TYPES: readonly BrushType[] = BRUSH_OPTIONS.map((o) => o.brush);
export const OPTIONAL_BRUSH_TYPES: readonly OptionalBrushType[] = BRUSH_TYPES.filter(
  (brush): brush is OptionalBrushType => brush !== 'pen'
);

const DEFAULT_BRUSH: BrushType = 'pen';

function isBrushType(raw: string): raw is BrushType {
  return (BRUSH_TYPES as readonly string[]).includes(raw);
}

export function isInkBrush(brush: BrushType): brush is 'pen' | 'crayon' {
  return brush === 'pen' || brush === 'crayon';
}

// The eraser is deliberately excluded from persistence: a fresh launch always
// opens on a blank page, and waking up holding an eraser would strand the
// child with a tool that does nothing there (the same reasoning as
// resetToolAfterClear). Selecting the eraser therefore never overwrites the
// stored choice, and a stored value is never restored as the eraser.
function readBrush(fallback: BrushType): BrushType {
  const raw = readString(STORAGE_KEYS.brushType, fallback);
  return isBrushType(raw) && raw !== 'eraser' ? raw : fallback;
}

export const toolState = $state({
  brush: readBrush(DEFAULT_BRUSH),
});

// The last ink brush the child held — where a color pick or a canvas clear
// lands them when it pulls them out of the eraser or magic brush (picking a
// color means "draw with this", so it must resume a brush that uses color).
// Runtime-only: across a relaunch it's rebuilt from the persisted brush,
// falling back to the pen when the stored choice was the magic brush.
let inkBrush: 'pen' | 'crayon' = isInkBrush(toolState.brush) ? toolState.brush : 'pen';

export function selectBrush(brush: BrushType) {
  toolState.brush = brush;
  if (isInkBrush(brush)) inkBrush = brush;
  if (brush !== 'eraser') writeString(STORAGE_KEYS.brushType, brush);
}

// Resume drawing with the active color: the last-used pen/crayon. Called by
// the palette when a color is picked while the eraser or magic brush is held.
export function selectInkBrush() {
  selectBrush(inkBrush);
}

export function fallBackFromBrush(brush: OptionalBrushType) {
  if (brush === 'crayon' && inkBrush === 'crayon') inkBrush = 'pen';
  if (toolState.brush === brush) selectInkBrush();
}

// Flip between the ink brush and the eraser. Shared by the Brush Menu's eraser
// entry-toggle semantics and the Apple Pencil double-tap bridge
// (web/src/lib/plugins/pencilEraser.ts). Leaving the eraser always lands on
// the last ink brush (never the magic brush).
export function toggleEraser() {
  if (toolState.brush === 'eraser') selectInkBrush();
  else selectBrush('eraser');
}

// After the canvas is cleared, an active eraser would strand the child holding
// a non-drawing tool on a blank page — switch back to the last ink brush,
// which also restores the last-used color for free (the eraser never touches
// colors.activeColor). The magic brush survives the clear: it draws on a fresh
// page too, and the engine re-locks a new magic sheet during clearCanvas()
// while the brush stays selected.
export function resetToolAfterClear() {
  if (toolState.brush === 'eraser') selectInkBrush();
}

// Re-read the persisted brush into the live store after the durable storage
// layer recovers values evicted by the native WebView (see storage.ts).
export function reloadBrushType() {
  toolState.brush = readBrush(toolState.brush);
  if (isInkBrush(toolState.brush)) inkBrush = toolState.brush;
}

onDurableRestore(reloadBrushType);
