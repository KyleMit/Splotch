import datetime
import hashlib
import importlib.util
import json
import pathlib
import shutil

SOURCE = pathlib.Path(__file__).resolve().parent
TARGET = pathlib.Path('/Users/kylemit/Code/Splotch/logs/migration-resumption-01a111b0/continuity-intake/tag-owners')
module_spec = importlib.util.spec_from_file_location('tag_inventory', SOURCE / 'inventory.py')
module = importlib.util.module_from_spec(module_spec)
module_spec.loader.exec_module(module)
manifest = json.loads((SOURCE / 'manifest.json').read_text())
module.verify_freeze(SOURCE, {row['tag']: row['selection'] for row in manifest['tags']})
assert not TARGET.exists(), 'Refuse to overlay existing durable records'
file_manifest = json.loads((SOURCE / 'file-manifest.json').read_text())
source_files = [path for path in SOURCE.rglob('*') if path.is_file()]
assert all(not path.is_symlink() for path in source_files)
shutil.copytree(SOURCE, TARGET, copy_function=shutil.copy2)
verified = []
for original in sorted(source_files):
    relative = original.relative_to(SOURCE)
    copied = TARGET / relative
    assert copied.is_file() and not copied.is_symlink()
    assert copied.read_bytes() == original.read_bytes()
    assert copied.stat().st_mode & 0o777 == original.stat().st_mode & 0o777
    before, after = original.stat(), copied.stat()
    assert (before.st_dev, before.st_ino) != (after.st_dev, after.st_ino)
    verified.append({'path': str(relative), 'bytes': before.st_size, 'sha256': module.digest(original.read_bytes()), 'mode': oct(before.st_mode & 0o777), 'scratchDevice': before.st_dev, 'scratchInode': before.st_ino, 'durableDevice': after.st_dev, 'durableInode': after.st_ino})
assert {row['path'] for row in verified} == {row['path'] for row in file_manifest['files']} | {'file-manifest.json'}
durable_positive = module.verify_freeze(TARGET, {row['tag']: row['selection'] for row in manifest['tags']})
receipt = {'observedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'sourceRoot': str(SOURCE), 'durableRoot': str(TARGET), 'fileManifestSha256': module.digest((SOURCE / 'file-manifest.json').read_bytes()), 'sourceManifestSha256': module.digest((SOURCE / 'manifest.json').read_bytes()), 'producerSha256': module.digest(pathlib.Path(__file__).read_bytes()), 'copiedFileCount': len(verified), 'allBytesAndModesIdentical': True, 'allInodesIndependent': True, 'allFrozenTagBlobsVerifiedAtDurableRoot': durable_positive, 'files': verified, 'claimLimits': ['Host-local owned evidence mirror; no remote publication or Git tracking is implied', 'Copy receipt is an envelope created after the file-manifest and is not part of that manifest']}
for root in [SOURCE, TARGET]:
    (root / 'durable-copy.json').write_text(json.dumps(receipt, indent=2) + '\n')
assert (SOURCE / 'durable-copy.json').read_bytes() == (TARGET / 'durable-copy.json').read_bytes()
assert (SOURCE / 'durable-copy.json').stat().st_ino != (TARGET / 'durable-copy.json').stat().st_ino
print(json.dumps({key: value for key, value in receipt.items() if key != 'files'}, indent=2))
