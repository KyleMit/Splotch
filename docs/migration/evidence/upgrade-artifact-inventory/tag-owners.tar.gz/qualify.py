import datetime
import hashlib
import importlib.util
import json
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent
module_spec = importlib.util.spec_from_file_location('tag_inventory', ROOT / 'inventory.py')
module = importlib.util.module_from_spec(module_spec)
module_spec.loader.exec_module(module)
manifest = json.loads((ROOT / 'manifest.json').read_text())
records = {row['tag']: row['selection'] for row in manifest['tags']}
inputs = ROOT / 'inputs'
associations = json.loads((inputs / 'live-tag-association.json').read_text())
native = json.loads((inputs / 'live-tags-native-complete.json').read_text())
live_tags = json.loads(native['structuredContent']['content'])
assert len(live_tags) == len(associations) == 8
by_ref = {row['ref']: row for row in live_tags}
for row in associations:
    assert by_ref[row['ref']]['object'] == row['liveObject']
releases = json.loads((inputs / 'live-release-inventory.json').read_text())
qualification = json.loads((inputs / 'supported-artifact-qualification.json').read_text())
assert qualification['inputs']['releaseInventorySha256'] == module.digest((inputs / 'live-release-inventory.json').read_bytes())
assert qualification['inputs']['liveTagAssociationSha256'] == module.digest((inputs / 'live-tag-association.json').read_bytes())
qualified_tags = {row['tag']: row for row in qualification['results']}
assert set(qualified_tags) == {row['tag'] for row in releases['rows']} == set(records)
checked_assets = []
for release in releases['rows']:
    qualified = qualified_tags[release['tag']]
    assert qualified['taggedCommit'] == next(row['localCommit'] for row in associations if row['ref'] == 'refs/tags/' + release['tag'])
    assert len(release['assets']) == len(qualified['assets'])
    for asset in release['assets']:
        read = next(row for row in qualified['assets'] if row['assetId'] == asset['id'])
        assert read['name'] == asset['name'] and read['bytes'] == asset['bytes']
        assert 'sha256:' + read['sha256'] == asset['digest']
        checked_assets.append({'tag': release['tag'], 'assetId': asset['id'], 'name': asset['name'], 'bytes': asset['bytes'], 'sha256': read['sha256'], 'actualEmbeddedVersion': read['actualEmbeddedVersion'], 'versionMatchesTag': read['releaseTagMatchesEmbeddedVersion']})
original_path = ROOT / 'sources/v1.0.0/src/lib/storage.js'
original_bytes = original_path.read_bytes()
substitute_path = ROOT / 'sources/v1.1.0/src/lib/storage.ts'
substitute_bytes = substitute_path.read_bytes()
assert original_bytes != substitute_bytes
original_path.write_bytes(substitute_bytes)
try:
    try:
        module.verify_freeze(ROOT, records)
        raise RuntimeError('WRONG_SOURCE_BYTES_ACCEPTED')
    except RuntimeError as error:
        assert str(error).startswith('FROZEN_BYTES_MISMATCH: sources/v1.0.0/src/lib/storage.js')
        rejection = str(error)
finally:
    original_path.write_bytes(original_bytes)
restored = module.verify_freeze(ROOT, records)
receipt = {'observedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'producerSha256': module.digest(pathlib.Path(__file__).read_bytes()), 'inputLinks': {'eightNativeTagObjectsMatchAssociations': True, 'eightQualificationCommitsMatchAssociations': True, 'qualificationInputHashesMatchFrozenInputs': True, 'tenAssetMetadataRowsMatchQualification': len(checked_assets) == 10}, 'checkedPublishedAssetMetadata': checked_assets, 'wrongSourceBytesControl': {'target': str(original_path.relative_to(ROOT)), 'substitute': str(substitute_path.relative_to(ROOT)), 'beforeSha256': module.digest(original_bytes), 'substituteSha256': module.digest(substitute_bytes), 'result': 'expected-rejection', 'reason': rejection}, 'restoredPositive': restored, 'claimLimits': ['This links existing complete metadata and binary qualification receipts; it does not reread or execute binaries, query signing or prove compiled-source association', 'Artifact tag/version mismatches remain real historical mismatches, separate from intended inventory controls']}
(ROOT / 'metadata-and-source-controls.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'result': 'pass', 'inputLinks': receipt['inputLinks'], 'wrongSourceBytesControl': receipt['wrongSourceBytesControl'], 'restoredPositive': restored}, indent=2))
