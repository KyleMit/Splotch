import importlib.util
import json
import pathlib
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent
module_spec = importlib.util.spec_from_file_location('tag_inventory', ROOT / 'inventory.py')
module = importlib.util.module_from_spec(module_spec)
module_spec.loader.exec_module(module)
manifest = json.loads((ROOT / 'manifest.json').read_text())
rows = []
native_packages = ['@aparajita/capacitor-secure-storage', '@capacitor/core', '@capacitor/android', '@capacitor/ios', '@capacitor/preferences', '@capacitor/device']
for record in manifest['tags']:
    base = ROOT / 'sources' / record['tag']
    config = json.loads((base / 'capacitor.config.json').read_text())
    files = subprocess.run(['git', 'ls-tree', '-r', '--name-only', record['commit']], cwd='/Users/kylemit/Code/Splotch', capture_output=True, check=True).stdout.decode().splitlines()
    lock = base / 'package-lock.json'
    if lock.exists():
        parsed = json.loads(lock.read_text())
        packages = []
        for name in native_packages:
            package = parsed['packages'].get('node_modules/' + name)
            if package is not None:
                packages.append({'name': name, 'version': package['version'], 'integrity': package.get('integrity'), 'resolved': package.get('resolved')})
        lock_info = {'path': 'package-lock.json', 'lockfileVersion': parsed['lockfileVersion'], 'nativePackages': packages}
    else:
        lines = (base / 'pnpm-lock.yaml').read_text().splitlines()
        anchors = []
        for number, line in enumerate(lines, 1):
            if any("'" + name + "':" in line or "'" + name + '@' in line for name in native_packages):
                anchors.append({'line': number, 'text': '\n'.join(lines[number - 1:min(number + 4, len(lines))])})
        lock_info = {'path': 'pnpm-lock.yaml', 'nativePackageLiteralAnchors': anchors, 'yamlParsed': False}
    spm = base / 'ios/App/App.xcodeproj/project.xcworkspace/xcshareddata/swiftpm/Package.resolved'
    rows.append({'tag': record['tag'], 'commit': record['commit'], 'capacitorDeclaration': config, 'packageLock': lock_info, 'iosNativeLock': json.loads(spm.read_text()) if spm.exists() else None, 'androidCommittedGradleLockfiles': [path for path in files if path.startswith('android/') and (path.endswith('.lockfile') or 'dependency-locks/' in path)], 'iosCommittedPodLocks': [path for path in files if path.startswith('ios/') and path.endswith('Podfile.lock')]})
receipt = {'producerSha256': module.digest(pathlib.Path(__file__).read_bytes()), 'rows': rows, 'claimLimits': ['Lockfile blobs pin source declarations. No installed package bytes, Gradle resolved graph, SPM checkout, plugin implementation, compiled source or effective runtime origin was verified.', 'Native plugin key/prefix/access defaults cannot be proven from app setter text and package version alone.', 'pnpm records preserve exact source and literal package anchors; no YAML semantics were inferred with an unvalidated parser.']}
(ROOT / 'identity-and-locks.json').write_text(json.dumps(receipt, indent=2) + '\n')
(ROOT / 'search-predicates.json').write_text(json.dumps({'producerSha256': manifest['producerSha256'], 'literalSignals': module.SIGNALS, 'roleCandidatePaths': module.EXPECTED, 'productionScope': manifest['selectionRules']['productionScope'], 'searchedSet': 'manifest.json tags[].searchedProductionSources'}, indent=2) + '\n')
print(json.dumps({'result': 'pass', 'tags': len(rows), 'producerSha256': receipt['producerSha256'], 'applicationIds': {row['tag']: row['capacitorDeclaration']['appId'] for row in rows}, 'committedGradleLockCounts': {row['tag']: len(row['androidCommittedGradleLockfiles']) for row in rows}}, indent=2))
