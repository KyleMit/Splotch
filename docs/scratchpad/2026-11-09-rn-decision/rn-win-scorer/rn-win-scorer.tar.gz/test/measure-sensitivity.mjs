#!/usr/bin/env node
// How much does the pre-registered trail time move per millisecond of true ink latency?
// Applies the rules to exact kinematics (no video) for a range of flick profiles.
import { makeProfile } from "./gen-synthetic.mjs";
import {
  FRAME_MS,
  VISIBLE_GAP_MM,
  ARRIVAL_GAP_MM,
  MIN_FAST_SPEED_MM_PER_MS,
  N_FAST_FRAMES,
  slopeAt,
  findStop,
  trailFromCandidates,
} from "../bin/lib/rules.mjs";

const R_MM = 7.5; // contact centre to the finger's trailing side
const CAP_MM = 0.77; // half the Size 3 ink width
const RESTS_MS = [110, 0];

function minJerk(D, T) {
  return {
    arc: (t) => {
      if (t <= 0) return 0;
      if (t >= T) return D;
      const s = t / T;
      return D * (10 * s ** 3 - 15 * s ** 4 + 6 * s ** 5);
    },
    total: T,
  };
}

function measure(prof, lagMs, REST_MS) {
  const n0 = -Math.ceil(REST_MS / FRAME_MS);
  const n1 = Math.ceil((prof.total + 400) / FRAME_MS);
  const edge = {};
  const tip = {};
  for (let n = n0; n <= n1; n++) {
    const t = n * FRAME_MS;
    edge[n] = prof.arc(t) - R_MM;
    tip[n] = t - lagMs >= -REST_MS ? prof.arc(t - lagMs) + CAP_MM : null;
  }
  const ns = Object.keys(edge)
    .map(Number)
    .sort((a, b) => a - b);
  const speed = {};
  for (const n of ns) {
    const s = slopeAt(edge, n);
    speed[n] = s === null ? null : s / FRAME_MS;
  }
  let nPeak = ns[0];
  for (const n of ns) if ((speed[n] ?? 0) > (speed[nPeak] ?? 0)) nPeak = n;
  const arr = [];
  for (const n of ns) arr[n - n0] = edge[n];
  const stopIdx = findStop(arr, nPeak - n0, arr.length);
  const nStop = stopIdx === null ? null : stopIdx + n0;
  const cands = [];
  for (const n of ns) {
    if (nStop !== null && n >= nStop) continue;
    if (tip[n] === null) continue;
    const g = edge[n] - tip[n];
    if (
      g < VISIBLE_GAP_MM ||
      speed[n] === null ||
      speed[n] < MIN_FAST_SPEED_MM_PER_MS
    )
      continue;
    cands.push({ n, gap: g, speed: speed[n] });
  }
  let arrival = null;
  for (const n of ns) {
    if (n <= nPeak || tip[n] === null) continue;
    const g = edge[n] - tip[n];
    if (g <= ARRIVAL_GAP_MM) {
      const gp = edge[n - 1] - tip[n - 1];
      arrival = (n - 1 + (gp - ARRIVAL_GAP_MM) / (gp - g) - nStop) * FRAME_MS;
      break;
    }
  }
  return {
    trail:
      cands.length >= N_FAST_FRAMES ? trailFromCandidates(cands).median : null,
    arrival,
    peak: speed[nPeak],
  };
}

const profiles = [
  [
    "cosine ramps, 100 mm, 1.2 m/s, accel 50 / decel 80 ms (the synthetic clips)",
    makeProfile(100, 1.2, 50, 80),
  ],
  [
    "cosine ramps, 100 mm, 0.9 m/s, accel 60 / decel 100 ms",
    makeProfile(100, 0.9, 60, 100),
  ],
  [
    "cosine ramps, 130 mm, 1.4 m/s, accel 40 / decel 60 ms (long cruise)",
    makeProfile(130, 1.4, 40, 60),
  ],
  ["minimum-jerk bell, 100 mm in 150 ms (peak 1.25 m/s)", minJerk(100, 150)],
  ["minimum-jerk bell, 100 mm in 200 ms (peak 0.94 m/s)", minJerk(100, 200)],
  ["minimum-jerk bell, 130 mm in 160 ms (peak 1.52 m/s)", minJerk(130, 160)],
];
const lags = [20, 30, 40, 50, 60, 70, 80];
const rows = [];
for (const rest of RESTS_MS) {
  console.log(`\ntrail / arrival (ms) under the pre-registered rules; contact offset ${R_MM} mm; finger rests ${rest} ms before flicking`);
  console.log(`profile${' '.repeat(70)}${lags.map((l) => `L=${l}`.padStart(12)).join('')}   dTrail/dL 30→55  dArrival/dL 30→55`);
  for (const [name, prof] of profiles) {
    const cells = lags.map((L) => measure(prof, L, rest));
    const a = measure(prof, 30, rest);
    const b = measure(prof, 55, rest);
    const slopeT = a.trail !== null && b.trail !== null ? (b.trail - a.trail) / 25 : null;
    const slopeA = (b.arrival - a.arrival) / 25;
    rows.push({ restMs: rest, name, cells: lags.map((L, i) => ({ lag: L, trail: cells[i].trail, arrival: cells[i].arrival })), slopeTrail: slopeT, slopeArrival: slopeA });
    console.log(
      `${name.padEnd(77)}${cells.map((c) => `${c.trail === null ? '–' : c.trail.toFixed(1)}/${c.arrival === null ? '–' : c.arrival.toFixed(1)}`.padStart(12)).join('')}   ${slopeT === null ? '   –' : slopeT.toFixed(2).padStart(10)}  ${slopeA.toFixed(2).padStart(10)}`,
    );
  }
}
// Shift lag (amendments 2 and 3) on the same kinematics: nominal and with e moved ±2 mm.
import * as RR from '../bin/lib/rules.mjs';
function measureShift(prof, lagMs, restMs, eShift) {
  const n0 = -Math.ceil(restMs / FRAME_MS);
  const n1 = Math.ceil((prof.total + 400) / FRAME_MS);
  const edgeAt = (t) => prof.arc(t) - R_MM;
  const edge = {};
  for (let n = n0; n <= n1; n++) edge[n] = edgeAt(n * FRAME_MS);
  const stopT = prof.total;
  const holdEdge = edgeAt(stopT + 1);
  const edgeRest = edgeAt(0);
  const e = R_MM + CAP_MM + eShift;
  const invert = (target) => {
    let lo = 0;
    let hi = stopT;
    for (let it = 0; it < 60; it++) {
      const mid = (lo + hi) / 2;
      if (edgeAt(mid) < target) lo = mid;
      else hi = mid;
    }
    return (lo + hi) / 2;
  };
  const cands = [];
  for (let n = n0; n <= n1; n++) {
    const t = n * FRAME_MS;
    if (t - lagMs < -restMs) continue;
    const sp = RR.slopeAt(edge, n);
    const speed = sp === null ? null : sp / FRAME_MS;
    if (speed === null || speed < RR.SHIFT_MIN_SPEED_MM_PER_MS) continue;
    const tipF = prof.arc(t - lagMs) + CAP_MM;
    if (edge[n] - tipF < RR.SHIFT_MIN_APART_MM) continue;
    const target = tipF - e;
    if (target <= edgeRest + RR.SHIFT_CENSOR_MM || target >= holdEdge - RR.SHIFT_CENSOR_MM) continue;
    cands.push({ speed, lag: t - invert(target) });
  }
  return cands.length >= N_FAST_FRAMES ? { value: RR.shiftFromCandidates(cands).median, n: cands.length } : { value: null, n: cands.length };
}
const f1 = (v) => (v === null ? '   –' : v.toFixed(1).padStart(5));
console.log('\nshift lag (ms) under amendments 2 and 3, nominal / e+2 mm / e−2 mm (valid frames); contact 7.5 mm behind the trailing side');
for (const rest of RESTS_MS) {
  console.log(`finger rests ${rest} ms before flicking`);
  console.log(`profile${' '.repeat(70)}      L=30 (n)             L=42 (n)             L=55 (n)      diff 55−30 nominal / e+2 / e−2`);
  for (const [name, prof] of profiles) {
    const cells = [30, 42, 55].map((L) => [0, 2, -2].map((d) => measureShift(prof, L, rest, d)));
    const diff = (k) => (cells[2][k].value === null || cells[0][k].value === null ? null : cells[2][k].value - cells[0][k].value);
    rows.push({ restMs: rest, name, shift: cells.map((c, i) => ({ lag: [30, 42, 55][i], nominal: c[0].value, ePlus2: c[1].value, eMinus2: c[2].value, frames: c[0].n })) });
    console.log(`${name.padEnd(77)}${cells.map((c) => `${f1(c[0].value)}/${f1(c[1].value)}/${f1(c[2].value)} (${c[0].n})`.padStart(21)).join('')}      ${f1(diff(0))} / ${f1(diff(1))} / ${f1(diff(2))}`);
  }
}
// Amendment 4: the matched moment must also be at ≥ 0.5 m/s; a stroke whose tip is visible 2 mm clear in fewer
// than 10 fast frames is scored below floor (the delay at which it would just show).
function measureShift4(prof, lagMs, restMs, eShift) {
  const n0 = -Math.ceil(restMs / FRAME_MS);
  const n1 = Math.ceil((prof.total + 400) / FRAME_MS);
  const edgeAt = (t) => prof.arc(t) - R_MM;
  const edge = {};
  for (let n = n0; n <= n1; n++) edge[n] = edgeAt(n * FRAME_MS);
  const holdEdge = edgeAt(prof.total + 1);
  const edgeRest = edgeAt(0);
  const e = R_MM + CAP_MM + eShift;
  const invert = (target) => {
    let lo = 0;
    let hi = prof.total;
    for (let it = 0; it < 60; it++) {
      const mid = (lo + hi) / 2;
      if (edgeAt(mid) < target) lo = mid;
      else hi = mid;
    }
    return (lo + hi) / 2;
  };
  const speedAtT = (tc) => {
    const ser = [];
    for (let j = -4; j <= 4; j++) ser[j + 4] = edgeAt(tc + j * FRAME_MS);
    return RR.slopeAt(ser, 4) / FRAME_MS;
  };
  const ok = (target) => !(target <= edgeRest + RR.SHIFT_CENSOR_MM || target >= holdEdge - RR.SHIFT_CENSOR_MM);
  const vis = [];
  const flo = [];
  let visibleClear = 0;
  for (let n = n0; n <= n1; n++) {
    const t = n * FRAME_MS;
    const sp = RR.slopeAt(edge, n);
    const speed = sp === null ? null : sp / FRAME_MS;
    if (speed === null || speed < RR.SHIFT_MIN_SPEED_MM_PER_MS) continue;
    const fTarget = edge[n] - RR.SHIFT_MIN_APART_MM - e;
    if (ok(fTarget)) {
      const tp = invert(fTarget);
      if (speedAtT(tp) >= RR.SHIFT_MIN_MATCHED_SPEED_MM_PER_MS) flo.push({ speed, lag: t - tp });
    }
    if (t - lagMs < -restMs) continue;
    const tipF = prof.arc(t - lagMs) + CAP_MM;
    if (edge[n] - tipF < RR.SHIFT_MIN_APART_MM) continue;
    visibleClear++;
    const target = tipF - e;
    if (!ok(target)) continue;
    const tp = invert(target);
    if (speedAtT(tp) < RR.SHIFT_MIN_MATCHED_SPEED_MM_PER_MS) continue;
    vis.push({ speed, lag: t - tp });
  }
  if (vis.length >= N_FAST_FRAMES) return { value: RR.shiftFromCandidates(vis).median, n: vis.length, mode: 'visible' };
  if (visibleClear < N_FAST_FRAMES && flo.length >= N_FAST_FRAMES) return { value: RR.shiftFromCandidates(flo).median, n: flo.length, mode: 'floor' };
  return { value: null, n: vis.length, mode: null };
}
const profiles4 = [
  ...profiles,
  ['cosine ramps, 140 mm, 1.2 m/s, accel 50 / decel 80 ms (amendment-4 synthetic swipes)', makeProfile(140, 1.2, 50, 80)],
  ['minimum-jerk bell, 140 mm in 200 ms (peak 1.31 m/s)', minJerk(140, 200)],
];
const pairs4 = [[30, 55], [30, 42], [15, 40], [5, 40]];
const g = (r) => (r.value === null ? '   –  ' : `${r.value.toFixed(1).padStart(5)}${r.mode === 'floor' ? 'F' : ' '}`);
console.log('\nAMENDMENT 4: shift lag with the matched moment also ≥ 0.5 m/s, and below floor (F) when the tip is hidden');
console.log('differences slower − faster arm (ms): nominal / e+2 mm / e−2 mm; "–" = fewer than 10 valid frames in an arm');
for (const rest of RESTS_MS) {
  console.log(`finger rests ${rest} ms before flicking`);
  console.log(`profile${' '.repeat(80)}${pairs4.map(([a, b]) => `${b} v ${a} (true ${b - a})`.padEnd(26)).join('')}`);
  for (const [name, prof] of profiles4) {
    const cells = pairs4.map(([a, b]) => [0, 2, -2].map((d) => {
      const fa = measureShift4(prof, a, rest, d);
      const fb = measureShift4(prof, b, rest, d);
      return { fa, fb, diff: fa.value === null || fb.value === null ? null : fb.value - fa.value };
    }));
    rows.push({ amendment: 4, restMs: rest, name, pairs: pairs4.map(([a, b], i) => ({ fast: a, slow: b, nominal: cells[i][0].diff, ePlus2: cells[i][1].diff, eMinus2: cells[i][2].diff, fastMode: cells[i][0].fa.mode, fastValue: cells[i][0].fa.value, slowFrames: cells[i][0].fb.n })) });
    const f1 = (v) => (v === null ? '  –  ' : v.toFixed(1).padStart(5));
    console.log(`${name.padEnd(87)}${cells.map((c) => `${f1(c[0].diff)}/${f1(c[1].diff)}/${f1(c[2].diff)}${c[0].fa.mode === 'floor' ? ' F' : '  '}`.padEnd(26)).join('')}`);
  }
}
console.log('F = the faster arm scores below floor (an upper bound), so the difference is a lower bound.');
console.log('\nper-arm values (ms) under amendment 4, finger rests 110 ms: lag → nominal(valid frames)');
for (const [name, prof] of profiles4) console.log(`${name.padEnd(87)}${[5, 15, 30, 40, 42, 55].map((L) => { const r = measureShift4(prof, L, 110, 0); return `${L}: ${g(r)}(${r.n})`; }).join('  ')}`);
if (process.argv[2]) {
  const { writeFileSync } = await import("node:fs");
  writeFileSync(process.argv[2], JSON.stringify(rows, null, 2));
}
