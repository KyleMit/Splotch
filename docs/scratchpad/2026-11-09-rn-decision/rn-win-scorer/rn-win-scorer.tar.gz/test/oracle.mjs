// The pre-registered measure applied to the generator's exact geometry (no image processing).
import {
  FRAME_MS,
  VISIBLE_GAP_MM,
  ARRIVAL_GAP_MM,
  MIN_FAST_SPEED_MM_PER_MS,
  N_FAST_FRAMES,
  slopeAt,
  findStop,
  trailFromCandidates,
  median,
  SHIFT_MIN_SPEED_MM_PER_MS,
  SHIFT_MIN_APART_MM,
  LEAD_VISIBLE_MM,
  SHIFT_CENSOR_MM,
  E_VARIANT_MM,
  shiftFromCandidates,
  SHIFT_MIN_MATCHED_SPEED_MM_PER_MS,
} from "../bin/lib/rules.mjs";

export function oracleForStroke(
  st,
  tipLog,
  { penWidthMm, trailingOffset, leadingOffset, cfg },
) {
  const planted = {
    lagMs: cfg.lagMs,
    jitterMs: cfg.jitterMs,
    displayHz: cfg.displayHz,
    shortMm: st.short,
    gapMm: st.gap,
    missing: st.missing,
    offframe: st.offframe,
    overshootMm: st.overshoot,
    contactLeadMm: cfg.contactLeadMm ?? null,
  };
  const nSwipe = Math.ceil(st.tSwipe / FRAME_MS);
  const nLift = Math.floor(st.tLift / FRAME_MS);
  const edge = [];
  const contact = [];
  const tipFront = [];
  const rCache = new Map();
  for (const { n, tipArc } of tipLog) {
    const t = n * FRAME_MS;
    if (t < st.tTouch || t >= st.tLift) continue;
    const a = st.prof.arc(t - st.tSwipe);
    const key = a.toFixed(3);
    if (!rCache.has(key)) rCache.set(key, trailingOffset(st, a));
    contact[n] = a;
    edge[n] = a - rCache.get(key);
    tipFront[n] = tipArc >= 0 ? tipArc + penWidthMm / 2 : null;
  }
  const frames = Object.keys(edge).map(Number);
  const speed = [];
  for (const n of frames) {
    const s = slopeAt(edge, n);
    speed[n] = s === null ? null : s / FRAME_MS;
  }
  let nPeak = nSwipe;
  for (const n of frames)
    if (n < nLift && (speed[n] ?? 0) > (speed[nPeak] ?? 0)) nPeak = n;
  const nStop = findStop(edge, nPeak, nLift);
  const gap = (n) =>
    tipFront[n] === null || tipFront[n] === undefined
      ? null
      : edge[n] - tipFront[n];
  const cands = [];
  for (const n of frames) {
    if (nStop !== null && n >= nStop) continue;
    const g = gap(n);
    if (g === null || g < VISIBLE_GAP_MM) continue;
    if (speed[n] === null || speed[n] < MIN_FAST_SPEED_MM_PER_MS) continue;
    cands.push({ n, gap: g, speed: speed[n] });
  }
  const trail =
    cands.length >= N_FAST_FRAMES ? trailFromCandidates(cands) : null;
  let arrivalMs = null;
  for (const n of frames) {
    if (n <= nPeak) continue;
    const g = gap(n);
    const gPrev = gap(n - 1);
    if (g !== null && g <= ARRIVAL_GAP_MM) {
      const frac =
        gPrev !== null && gPrev > ARRIVAL_GAP_MM
          ? (gPrev - ARRIVAL_GAP_MM) / (gPrev - g)
          : 1;
      const nA = n - 1 + frac;
      arrivalMs = nStop === null ? null : (nA - nStop) * FRAME_MS;
      break;
    }
  }
  const holdEdge =
    nStop === null
      ? null
      : median(frames.filter((n) => n >= nStop).map((n) => edge[n]));
  const finalTip = Math.max(...tipLog.map((x) => x.tipArc));
  const rAtPeak = contact[nPeak] - edge[nPeak];
  return {
    num: st.num,
    planted,
    timesMs: {
      touch: st.tTouch,
      swipe: st.tSwipe,
      stop: st.tStop,
      lift: st.tLift,
    },
    frames: { swipe: nSwipe, peak: nPeak, stop: nStop, lift: nLift },
    peakSpeedMmPerMs: speed[nPeak],
    trailingOffsetMm: rAtPeak,
    expectedTrailApproxMs: cfg.lagMs - rAtPeak / speed[nPeak],
    oracle: {
      shift: st.missing ? null : shiftOracle(st, tipLog, { penWidthMm, trailingOffset, leadingOffset }),
      trailMs: trail ? trail.median : null,
      trailFrames: trail ? trail.chosen.map((c) => c.n) : [],
      nVisibleFast: cands.length,
      arrivalMs,
      endpointBeyondEdgeMm:
        finalTip >= 0 && holdEdge !== null
          ? finalTip + penWidthMm / 2 - holdEdge
          : null,
    },
  };
}

/**
 * Shift lag (apparent tracking delay) on exact geometry under amendments 2 and 3: frames at ≥ 0.5 m/s with the
 * ink tip visible (behind the trailing edge by ≥ 2 mm, or beyond the leading edge by ≥ 1 mm), censored within
 * 1 mm of the rest points, time since (or until) the exact trailing edge stood at (tip − e); 10 fastest, median.
 */
export function shiftOracle(
  st,
  tipLog,
  { penWidthMm, trailingOffset, leadingOffset },
) {
  const cap = penWidthMm / 2;
  const grid = [];
  for (let s = 0; s <= st.D + 1e-9; s += 2)
    grid.push([s, trailingOffset(st, s), leadingOffset(st, s)]);
  if (grid[grid.length - 1][0] < st.D)
    grid.push([st.D, trailingOffset(st, st.D), leadingOffset(st, st.D)]);
  const interp = (s, col) => {
    const k = Math.min(grid.length - 2, Math.max(0, Math.floor(s / 2)));
    const [s0, ,] = grid[k];
    const s1 = grid[k + 1][0];
    const f = s1 > s0 ? (s - s0) / (s1 - s0) : 0;
    return grid[k][col] + (grid[k + 1][col] - grid[k][col]) * f;
  };
  const arcAt = (t) => st.prof.arc(Math.min(t, st.tLift) - st.tSwipe);
  const edgeAt = (t) => {
    const a = arcAt(t);
    return a - interp(a, 1);
  };
  const frontAt = (t) => {
    const a = arcAt(t);
    return a + interp(a, 2);
  };
  const edgeRest = edgeAt(st.tSwipe);
  const holdEdge = edgeAt(st.tStop + 1);
  const finalTip = Math.max(...tipLog.map((x) => x.tipArc)) + cap;
  const e = finalTip - holdEdge;
  const edge = [];
  const rows = [];
  for (const { n, tipArc } of tipLog) {
    const t = n * FRAME_MS;
    if (t < st.tTouch || t >= st.tLift) continue;
    edge[n] = edgeAt(t);
    rows.push({ n, t, tipF: tipArc >= 0 ? tipArc + cap : null });
  }
  const invert = (target) => {
    let lo = st.tSwipe;
    let hi = st.tStop;
    for (let it = 0; it < 60; it++) {
      const mid = (lo + hi) / 2;
      if (edgeAt(mid) < target) lo = mid;
      else hi = mid;
    }
    return (lo + hi) / 2;
  };
  // Finger speed at a continuous time: the same ±4-frame least-squares slope the rules use, on exact positions.
  const speedAtT = (tc) => {
    const ser = [];
    for (let j = -4; j <= 4; j++) ser[j + 4] = edgeAt(tc + j * FRAME_MS);
    const sp = slopeAt(ser, 4);
    return sp === null ? null : sp / FRAME_MS;
  };
  const censored = (target) => target <= edgeRest + SHIFT_CENSOR_MM || target >= holdEdge - SHIFT_CENSOR_MM;
  const run = (eUse) => {
    const cands = [];
    let visibleClear = 0;
    for (const { n, t, tipF } of rows) {
      const sp = slopeAt(edge, n);
      const speed = sp === null ? null : sp / FRAME_MS;
      if (speed === null || speed < SHIFT_MIN_SPEED_MM_PER_MS || tipF === null) continue;
      let kind = null;
      if (edge[n] - tipF >= SHIFT_MIN_APART_MM) kind = "behind";
      else if (tipF - frontAt(t) >= LEAD_VISIBLE_MM && tipF - edge[n] >= SHIFT_MIN_APART_MM) kind = "ahead";
      if (!kind) continue;
      visibleClear++;
      const target = tipF - eUse;
      if (censored(target)) continue;
      const tp = invert(target);
      if (speedAtT(tp) < SHIFT_MIN_MATCHED_SPEED_MM_PER_MS) continue;
      cands.push({ n, speed, kind, lag: t - tp });
    }
    return { cands, visibleClear };
  };
  // Below floor (amendment 4): the delay at which a tip 2 mm clear behind the trailing edge would just show.
  const floor = (eUse) => {
    const cands = [];
    for (const { n, t } of rows) {
      const sp = slopeAt(edge, n);
      const speed = sp === null ? null : sp / FRAME_MS;
      if (speed === null || speed < SHIFT_MIN_SPEED_MM_PER_MS) continue;
      const target = edge[n] - SHIFT_MIN_APART_MM - eUse;
      if (censored(target)) continue;
      const tp = invert(target);
      if (speedAtT(tp) < SHIFT_MIN_MATCHED_SPEED_MM_PER_MS) continue;
      cands.push({ n, speed, kind: "floor", lag: t - tp });
    }
    return cands;
  };
  const pick = (cands) => (cands.length >= N_FAST_FRAMES ? shiftFromCandidates(cands) : null);
  const first = run(e);
  const mode = first.cands.length >= N_FAST_FRAMES ? "visible" : first.visibleClear < N_FAST_FRAMES && floor(e).length >= N_FAST_FRAMES ? "floor" : null;
  const value = (eUse) => (mode === "floor" ? pick(floor(eUse)) : mode === "visible" ? pick(run(eUse).cands) : null);
  const nominal = value(e);
  const plus = value(e + E_VARIANT_MM);
  const minus = value(e - E_VARIANT_MM);
  const tails = tipLog.map((x) => x.tailArc).filter((v) => v !== null && v !== undefined);
  return {
    shiftLagMs: nominal ? nominal.median : null,
    shiftLagEPlus2Ms: plus ? plus.median : null,
    shiftLagEMinus2Ms: minus ? minus.median : null,
    belowFloor: mode === "floor",
    nShiftFrames: first.cands.length,
    visibleClear: first.visibleClear,
    tipAheadFrames: nominal ? nominal.chosen.filter((c) => c.kind === "ahead").length : 0,
    eMm: e,
    overshootMm: tails.length ? Math.max(...tails) + cap - finalTip : 0,
  };
}
