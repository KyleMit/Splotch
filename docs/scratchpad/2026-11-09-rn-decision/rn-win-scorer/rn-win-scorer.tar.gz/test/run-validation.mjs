#!/usr/bin/env node
// Score every synthetic clip and check shift lag (amendments 2 and 3) against the exact-geometry oracle, the
// planted lags and the planted failures; then run compare-blocks end to end on the win and tie block sets.
// usage: node test/run-validation.mjs [--reuse] [--jobs 4]
import {
  readdirSync,
  readFileSync,
  writeFileSync,
  existsSync,
  mkdirSync,
  symlinkSync,
  rmSync,
} from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { spawn, spawnSync } from "node:child_process";
import { median, quantile, FRAME_MS } from "../bin/lib/rules.mjs";

const here = dirname(fileURLToPath(import.meta.url));
const bin = join(here, "..", "bin");
const clipsDir = join(here, "clips");
const resultsDir = join(here, "results");
const blocksDir = join(here, "blocks");
const reuse = process.argv.includes("--reuse");
const jobsArg = process.argv.indexOf("--jobs");
const JOBS = jobsArg > 0 ? Number(process.argv[jobsArg + 1]) : 4;
/** Pass criteria from the coordinator's brief. */
const CLIP_TOL_MS = 4;
/** Amendment 4: below-floor strokes count as scorable. */
const SCORABLE = new Set(["ok", "below_floor"]);
/** The coordinator's expected Part 1 verdicts for the amendment-4 block sets (reported, never tuned toward). */
const EXPECTED = { "long-30v55": "RN wins Part 1", "long-30v42": "Tie: no win established", "long-15v40": "RN wins Part 1", "long-5v40": "RN wins Part 1", "long-ship30v55": "Shipping wins Part 1" };
const DIFF_TOL_MS = 5;

const truths = readdirSync(clipsDir)
  .filter((f) => f.endsWith(".truth.json"))
  .map((f) => JSON.parse(readFileSync(join(clipsDir, f), "utf8")));
const blockTruths = truths.filter((t) => t.config.block);
const plainTruths = truths.filter((t) => !t.config.block);

function run(cmd, args) {
  return new Promise((res, rej) => {
    const p = spawn(cmd, args, { stdio: ["ignore", "pipe", "pipe"] });
    let out = "";
    let err = "";
    p.stdout.on("data", (d) => (out += d));
    p.stderr.on("data", (d) => (err += d));
    p.on("close", (code) =>
      code === 0
        ? res(out)
        : rej(new Error(`${cmd} ${args.join(" ")}: ${err || out}`)),
    );
  });
}
async function pool(items, fn) {
  const q = [...items];
  await Promise.all(
    Array.from({ length: JOBS }, async () => {
      while (q.length) await fn(q.shift());
    }),
  );
}

// 1. Score the plain clips (raw-chrome through crop-clip --corners first).
await pool(plainTruths, async (t) => {
  const out = join(resultsDir, t.clip);
  if (reuse && existsSync(join(out, "strokes.json"))) return;
  let clip = join(clipsDir, `${t.clip}.mp4`);
  if (t.config.raw) {
    const c = t.drawingAreaCornersPx;
    const corners = [c.tl, c.tr, c.br, c.bl]
      .map((p) => p.map((v) => Math.round(v)).join(","))
      .join(",");
    mkdirSync(join(clipsDir, "cropped"), { recursive: true });
    await run(join(bin, "crop-clip"), [
      clip,
      "--id",
      t.clip,
      "--corners",
      corners,
      "--corners-mm",
      `${t.config.areaMm.join(",")}`,
      "--ppm",
      String(t.config.ppm),
      "--brush",
      t.config.brush,
      "--outdir",
      join(clipsDir, "cropped"),
    ]);
    clip = join(clipsDir, "cropped", `${t.clip}.mp4`);
  }
  mkdirSync(out, { recursive: true });
  await run(join(bin, "score-clip"), [clip, "--out", out, "--quiet"]);
});

// 2. Score the block sets with score-all (one folder per set) and write their keys.
const sets = [...new Set(blockTruths.map((t) => t.config.block.set))];
for (const set of sets) {
  const dir = join(blocksDir, set);
  mkdirSync(dir, { recursive: true });
  const key = [];
  for (const t of blockTruths.filter((x) => x.config.block.set === set)) {
    for (const ext of ["mp4", "json"]) {
      const dst = join(dir, `${t.clip}.${ext}`);
      if (!existsSync(dst))
        symlinkSync(join(clipsDir, `${t.clip}.${ext}`), dst);
    }
    const b = t.config.block;
    key.push({
      id: t.clip,
      app: b.app === "rn" ? "rn" : "shipping",
      brush: b.brush,
      block: b.block,
    });
  }
  writeFileSync(
    join(dir, "key.jsonl"),
    key.map((k) => JSON.stringify(k)).join("\n") + "\n",
  );
  if (!(reuse && existsSync(join(dir, "table.json"))))
    await run(join(bin, "score-all"), [
      dir,
      "--jobs",
      String(JOBS),
      "--no-debug",
      "--json",
      join(dir, "table.json"),
    ]).catch((e) => {
      throw e;
    });
}

// 3. Compare every stroke with the oracle.
const strokesFor = (t) => {
  if (t.config.block)
    return JSON.parse(
      readFileSync(
        join(blocksDir, t.config.block.set, "scores", t.clip, "strokes.json"),
        "utf8",
      ),
    );
  return JSON.parse(
    readFileSync(join(resultsDir, t.clip, "strokes.json"), "utf8"),
  );
};
const report = [];
for (const t of truths) {
  const strokes = strokesFor(t);
  const rows = t.strokes.map((ts) => {
    const p = ts.planted;
    const match = p.missing
      ? strokes.find(
          (s) =>
            s.frames?.hold !== undefined &&
            Math.abs(s.frames.hold - ts.timesMs.stop / FRAME_MS) < 60,
        )
      : strokes.find(
          (s) =>
            s.frames?.firstInk !== undefined &&
            Math.abs(s.frames.firstInk - ts.frames.swipe) < 30,
        );
    const planted = p.missing
      ? "missing"
      : p.shortMm
        ? "short"
        : p.gapMm
          ? "gap"
          : p.overshootMm
            ? "overshoot"
            : p.offframe
              ? "offframe"
              : null;
    const os = ts.oracle.shift;
    const oracleScorable = !!os && os.shiftLagMs !== null;
    const expectStatus =
      planted === "offframe"
        ? "unscorable"
        : planted
          ? "fidelity_failure"
          : oracleScorable
            ? os.belowFloor
              ? "below_floor"
              : "ok"
            : "unscorable";
    return {
      stroke: ts.num,
      planted,
      expectStatus,
      gotStatus: match?.status ?? "not detected",
      rules: match?.exclusionRules ?? [],
      reasons: match?.reasons ?? [],
      oracleShiftMs: os?.shiftLagMs ?? null,
      oracleFrames: os?.nShiftFrames ?? null,
      shiftMs: match?.shiftLagMs ?? null,
      frames: match?.nShiftFrames ?? null,
      errMs:
        match?.shiftLagMs !== undefined &&
        os?.shiftLagMs !== null &&
        os?.shiftLagMs !== undefined
          ? +(match.shiftLagMs - os.shiftLagMs).toFixed(2)
          : null,
      oraclePlus: os?.shiftLagEPlus2Ms ?? null,
      oracleMinus: os?.shiftLagEMinus2Ms ?? null,
      plus: match?.shiftLagEPlus2Ms ?? null,
      minus: match?.shiftLagEMinus2Ms ?? null,
      oracleE: os ? +os.eMm.toFixed(2) : null,
      e: match?.eMm ?? null,
      se: match?.shiftLagSeMs ?? null,
      unc: match?.shiftLagUncMs ?? null,
      overshootMm: match?.overshootMm ?? null,
      oracleOvershootMm: os?.overshootMm ?? null,
    };
  });
  const okRows = rows.filter((r) => SCORABLE.has(r.expectStatus) && SCORABLE.has(r.gotStatus));
  const quant = t.config.displayHz ? 500 / t.config.displayHz : 0;
  report.push({
    clip: t.clip,
    brush: t.config.brush,
    plantedLagMs: t.config.lagMs,
    effectiveLagMs: t.config.lagMs + quant,
    oracleMedianMs: median(
      rows
        .filter((r) => SCORABLE.has(r.expectStatus) && r.oracleShiftMs !== null)
        .map((r) => r.oracleShiftMs),
    ),
    scorerMedianMs: median(okRows.map((r) => r.shiftMs)),
    scorable: rows.filter((r) => SCORABLE.has(r.gotStatus)).length,
    belowFloor: rows.filter((r) => r.gotStatus === "below_floor").length,
    oracleScorable: rows.filter((r) => SCORABLE.has(r.expectStatus)).length,
    oracleBelowFloor: rows.filter((r) => r.expectStatus === "below_floor").length,
    plantedOk: rows
      .filter((r) => r.planted)
      .every((r) => r.gotStatus === r.expectStatus),
    falseFlags: rows.filter((r) => !r.planted && SCORABLE.has(r.expectStatus) && r.gotStatus !== r.expectStatus),
    missedScorable: rows.filter((r) => !r.planted && r.expectStatus === "unscorable" && SCORABLE.has(r.gotStatus)),
    rows,
  });
}

// 4. compare-blocks end to end, plus a second scorer that agrees and one that disagrees.
const compare = {};
for (const set of sets) {
  const dir = join(blocksDir, set);
  const table = join(dir, "table.json");
  const keyFile = join(dir, "key.jsonl");
  const out = spawnSync(
    join(bin, "compare-blocks"),
    [
      table,
      keyFile,
      "--allow-uncommitted",
      "--json",
      join(dir, "verdict.json"),
    ],
    { encoding: "utf8" },
  );
  const first = JSON.parse(readFileSync(table, "utf8"));
  // An agreeing re-score: ambiguous strokes plus a fixed quarter of the rest, re-read within ±0.5 ms.
  const agree = {
    clips: first.clips.map((c) => ({
      id: c.id,
      strokes: c.strokes
        .filter((s, i) => s.ambiguous || i % 4 === 0)
        .map((s, i) => ({
          stroke: s.stroke,
          shiftLagMs:
            s.shiftLagMs === undefined
              ? undefined
              : s.shiftLagMs + (i % 2 ? 0.5 : -0.5),
        })),
    })),
  };
  // A disagreeing re-score: every RN stroke in pen block 1 re-read 8 ms slower.
  const keyRows = readFileSync(keyFile, "utf8")
    .trim()
    .split("\n")
    .map((l) => JSON.parse(l));
  const rnPen1 = keyRows.find(
    (k) => k.app === "rn" && k.brush === "pen" && k.block === 1,
  ).id;
  const disagree = {
    clips: first.clips
      .filter((c) => c.id === rnPen1)
      .map((c) => ({
        id: c.id,
        strokes: c.strokes
          .filter((s) => s.status === "ok")
          .map((s) => ({ stroke: s.stroke, shiftLagMs: s.shiftLagMs + 8 })),
      })),
  };
  writeFileSync(join(dir, "second-agree.json"), JSON.stringify(agree, null, 2));
  writeFileSync(
    join(dir, "second-disagree.json"),
    JSON.stringify(disagree, null, 2),
  );
  const withSecond = (f) =>
    spawnSync(
      join(bin, "compare-blocks"),
      [table, keyFile, "--allow-uncommitted", "--second", join(dir, f)],
      { encoding: "utf8" },
    ).stdout;
  compare[set] = {
    text: out.stdout + out.stderr,
    verdict: JSON.parse(readFileSync(join(dir, "verdict.json"), "utf8")),
    agree: withSecond("second-agree.json"),
    disagree: withSecond("second-disagree.json"),
  };
  writeFileSync(
    join(dir, "compare.txt"),
    compare[set].text +
      "\n--- with an agreeing second scorer ---\n" +
      compare[set].agree +
      "\n--- with a disagreeing second scorer ---\n" +
      compare[set].disagree,
  );
}
// Oracle view of each block (what perfect measurement would give under the same rules).
const oracleBlocks = {};
for (const set of sets) {
  oracleBlocks[set] = [];
  for (const brush of ["pen", "crayon"])
    for (const block of [1, 2]) {
      const arm = (app) =>
        blockTruths.find(
          (t) =>
            t.config.block.set === set &&
            t.config.block.brush === brush &&
            t.config.block.block === block &&
            t.config.block.app === app,
        );
      const med = (t, k) =>
        median(
          t.strokes
            .map((s) => s.oracle.shift?.[k])
            .filter((v) => v !== null && v !== undefined),
        );
      const rn = arm("rn");
      const sh = arm("ship");
      oracleBlocks[set].push({
        brush,
        block,
        diff: med(sh, "shiftLagMs") - med(rn, "shiftLagMs"),
        diffEPlus2: med(sh, "shiftLagEPlus2Ms") - med(rn, "shiftLagEPlus2Ms"),
        diffEMinus2:
          med(sh, "shiftLagEMinus2Ms") - med(rn, "shiftLagEMinus2Ms"),
      });
    }
}

// 5. Criteria.
const by = Object.fromEntries(report.map((r) => [r.clip, r]));
const cleanClips = report.filter(
  (r) =>
    r.rows.every((x) => !x.planted) && !r.clip.startsWith("predict-centred"),
);
const allErr = report.flatMap((r) =>
  r.rows
    .filter((x) => x.errMs !== null && SCORABLE.has(x.expectStatus))
    .map((x) => x.errMs),
);
const pairs = [
  ["clean-pen-lag30", "clean-pen-lag55"],
  ["clean-crayon-lag30", "clean-crayon-lag55"],
].filter(([a, b]) => by[a] && by[b]);
const criteria = {
  clipMedianWithin4msOfOracle: cleanClips.map((r) => ({
    clip: r.clip,
    oracle: r.oracleMedianMs,
    scorer: r.scorerMedianMs,
    err: r.scorerMedianMs - r.oracleMedianMs,
    pass: Math.abs(r.scorerMedianMs - r.oracleMedianMs) <= CLIP_TOL_MS,
  })),
  difference30vs55: pairs.map(([a, b]) => ({
    pair: `${b} − ${a}`,
    planted: 25,
    oracle: by[b].oracleMedianMs - by[a].oracleMedianMs,
    scorer: by[b].scorerMedianMs - by[a].scorerMedianMs,
    pass:
      Math.abs(by[b].scorerMedianMs - by[a].scorerMedianMs - 25) <= DIFF_TOL_MS,
  })),
  plantedFailuresFlagged: report
    .filter((r) => r.rows.some((x) => x.planted))
    .map((r) => ({
      clip: r.clip,
      pass: r.plantedOk,
      rows: r.rows
        .filter((x) => x.planted)
        .map(
          (x) =>
            `S${x.stroke} ${x.planted} → ${x.gotStatus} [${x.rules.join(",")}]`,
        ),
    })),
  noFalseFlags: report.map((r) => ({
    clip: r.clip,
    falseFlags: r.falseFlags.map(
      (x) =>
        `S${x.stroke} ${x.gotStatus} [${x.reasons.join("; ")}] (oracle frames ${x.oracleFrames}, scorer ${x.frames})`,
    ),
    scoredWhereOracleCannot: r.missedScorable.map((x) => `S${x.stroke}`),
  })),
  predictingNegative: by["predict-front-lead5"]
    ? {
        scorer: by["predict-front-lead5"].scorerMedianMs,
        oracle: by["predict-front-lead5"].oracleMedianMs,
        planted: -5,
        pass:
          by["predict-front-lead5"].scorerMedianMs < 0 &&
          Math.abs(by["predict-front-lead5"].scorerMedianMs + 5) <= CLIP_TOL_MS,
      }
    : null,
  hiddenLeadBelowFloor: ["predict-centred-lead5", "predict-centred-lead5-long"].filter((c) => by[c]).map((c) => ({
    clip: c,
    belowFloor: by[c].belowFloor,
    strokes: by[c].rows.length,
    values: by[c].rows.map((x) => x.shiftMs),
    oracle: by[c].rows.map((x) => x.oracleShiftMs),
    pass: by[c].rows.every((x) => x.gotStatus === "below_floor"),
  })),
  perStrokeErrorMs: {
    n: allErr.length,
    median: median(allErr),
    p05: quantile(allErr, 0.05),
    p95: quantile(allErr, 0.95),
    min: Math.min(...allErr),
    max: Math.max(...allErr),
  },
  uncertaintyCoverage: (() => {
    const rows = report.flatMap((r) =>
      r.rows.filter(
        (x) => x.errMs !== null && SCORABLE.has(x.expectStatus) && x.unc !== null,
      ),
    );
    const bias = median(rows.map((x) => x.errMs));
    return {
      n: rows.length,
      bias,
      within2Unc: rows.filter((x) => Math.abs(x.errMs - bias) <= 2 * x.unc)
        .length,
      medianUnc: median(rows.map((x) => x.unc)),
    };
  })(),
  compareBlocks: Object.fromEntries(
    sets.map((s) => [
      s,
      {
        overall: compare[s].verdict.overall,
        expected: EXPECTED[s] ?? null,
        asExpected: EXPECTED[s] ? compare[s].verdict.overall === EXPECTED[s] : null,
        blocks: compare[s].verdict.blocks.map((b) => ({
          block: b.label,
          diff: b.diff,
          ci: b.ci,
          diffEPlus2: b.diffEPlus2,
          diffEMinus2: b.diffEMinus2,
          speedRatio: b.speedRatio,
          scorable: [b.rn?.n, b.shipping?.n],
          belowFloor: [b.rn?.belowFloor, b.shipping?.belowFloor],
          decision: b.finalDecision,
          reasons: b.reasons,
        })),
        oracle: oracleBlocks[s],
        agreeingSecond: /changes no block/.test(compare[s].agree),
        disagreeingSecondChanges: /CHANGES at least one/.test(
          compare[s].disagree,
        ),
        verdictWithDisagreeingSecond: (compare[s].disagree.match(
          /PART 1 VERDICT: (.*)/,
        ) || [])[1],
      },
    ]),
  ),
};
writeFileSync(
  join(resultsDir, "validation.json"),
  JSON.stringify({ criteria, report }, null, 2),
);

const f = (v, d = 1) =>
  v === null || v === undefined || !Number.isFinite(v)
    ? "–"
    : Number(v).toFixed(d);
const pad = (v, n) => String(v).padStart(n);
console.log("SHIFT LAG (primary, amendments 2–4) — scorer vs exact-geometry oracle and planted lag; BF = below-floor strokes");
console.log(
  "clip                        brush   planted(eff)  oracle  scorer   err   max|stroke err|  scorable/oracle  planted failures",
);
for (const r of report) {
  const maxErr = Math.max(
    0,
    ...r.rows
      .filter((x) => x.errMs !== null && SCORABLE.has(x.expectStatus))
      .map((x) => Math.abs(x.errMs)),
  );
  const planted = r.rows.some((x) => x.planted)
    ? r.plantedOk
      ? "all flagged"
      : "MISSED"
    : "–";
  console.log(
    `${r.clip.padEnd(27)} ${r.brush.padEnd(6)} ${pad(`${r.plantedLagMs}(${f(r.effectiveLagMs)})`, 12)} ${pad(f(r.oracleMedianMs), 7)} ${pad(f(r.scorerMedianMs), 7)} ${pad(f(r.scorerMedianMs - r.oracleMedianMs, 2), 6)} ${pad(f(maxErr, 2), 10)}       ${pad(`${r.scorable}/${r.oracleScorable}`, 8)}${r.belowFloor || r.oracleBelowFloor ? ` BF ${r.belowFloor}/${r.oracleBelowFloor}` : ""}         ${planted}`,
  );
}
console.log("\n30 → 55 ms differences (planted 25):");
for (const d of criteria.difference30vs55)
  console.log(
    `  ${d.pair}: oracle ${f(d.oracle, 2)}, scorer ${f(d.scorer, 2)} ${d.pass ? "PASS" : "FAIL"}`,
  );
console.log(
  `\nper-stroke error vs oracle (ms): n ${allErr.length}, median ${f(criteria.perStrokeErrorMs.median, 2)}, 5–95% ${f(criteria.perStrokeErrorMs.p05, 2)} to ${f(criteria.perStrokeErrorMs.p95, 2)}, range ${f(criteria.perStrokeErrorMs.min, 2)} to ${f(criteria.perStrokeErrorMs.max, 2)}`,
);
const cov = criteria.uncertaintyCoverage;
console.log(
  `uncertainty: ${cov.within2Unc}/${cov.n} strokes within bias ± 2 × shift_lag_unc_ms (median unc ${f(cov.medianUnc, 2)} ms, bias ${f(cov.bias, 2)} ms)`,
);
console.log("\nplanted failures:");
for (const c of criteria.plantedFailuresFlagged)
  console.log(
    `  ${c.clip}: ${c.pass ? "all flagged" : "MISSED"} — ${c.rows.join("; ")}`,
  );
console.log("false flags / disagreements with the oracle on scorability:");
let anyFalse = false;
for (const c of criteria.noFalseFlags)
  if (c.falseFlags.length || c.scoredWhereOracleCannot.length) {
    anyFalse = true;
    console.log(
      `  ${c.clip}: ${[...c.falseFlags, ...c.scoredWhereOracleCannot.map((s) => `${s} scored though the oracle has < 10 valid frames`)].join("; ")}`,
    );
  }
if (!anyFalse) console.log("  none");
if (criteria.predictingNegative)
  console.log(
    `\npredicting arm (ink leads 5 ms, contact 2 mm inside the leading edge): scorer ${f(criteria.predictingNegative.scorer, 2)} ms, oracle ${f(criteria.predictingNegative.oracle, 2)} ms — ${criteria.predictingNegative.pass ? "negative, unclamped: PASS" : "FAIL"}`,
  );
for (const h of criteria.hiddenLeadBelowFloor)
  console.log(`hidden 5 ms lead, centred contact (${h.clip}): ${h.belowFloor}/${h.strokes} below floor, upper bounds ${h.values.map((v) => f(v)).join(" ")} ms (oracle ${h.oracle.map((v) => f(v)).join(" ")}) — ${h.pass ? "below floor, not unscorable, not a measured delay: PASS" : "FAIL"}`);
console.log("\ne ± 2 mm variants (clip medians, ms):");
for (const r of report.filter((x) => x.scorable > 0)) {
  const ok = r.rows.filter((x) => SCORABLE.has(x.gotStatus));
  console.log(
    `  ${r.clip.padEnd(27)} nominal ${pad(f(r.scorerMedianMs), 6)}  e+2 ${pad(f(median(ok.map((x) => x.plus).filter(Number.isFinite))), 6)} (oracle ${f(median(r.rows.map((x) => x.oraclePlus).filter(Number.isFinite)))})  e−2 ${pad(f(median(ok.map((x) => x.minus).filter(Number.isFinite))), 6)} (oracle ${f(median(r.rows.map((x) => x.oracleMinus).filter(Number.isFinite)))})`,
  );
}
for (const set of sets) {
  const c = criteria.compareBlocks[set];
  const lagsOf = (app) =>
    blockTruths.find(
      (t) => t.config.block.set === set && t.config.block.app === app,
    ).config.lagMs;
  console.log(
    `\ncompare-blocks, ${set} set (RN ${lagsOf("rn")} ms vs shipping ${lagsOf("ship")} ms; true shipping − RN ${lagsOf("ship") - lagsOf("rn")} ms): ${c.overall}${c.expected ? (c.asExpected ? `  [expected: ${c.expected} — AS EXPECTED]` : `  [expected: ${c.expected} — NOT AS EXPECTED]`) : "  [pre-amendment-4 swipes, reported only]"}`,
  );
  for (const b of c.blocks)
    console.log(
      `  ${b.block}: diff ${f(b.diff)} [${f(b.ci[0])}, ${f(b.ci[1])}], e+2 ${f(b.diffEPlus2)}, e−2 ${f(b.diffEMinus2)}, speed ratio ${f(b.speedRatio, 2)}, scorable RN/sh ${b.scorable.join("/")} (below floor ${b.belowFloor.join("/")}) → ${b.decision}${b.reasons.length ? ` (${b.reasons.join("; ")})` : ""}`,
    );
  console.log(
    `  oracle (perfect measurement, same rules): ${c.oracle.map((o) => `${o.brush} ${o.block}: ${f(o.diff)} / e+2 ${f(o.diffEPlus2)} / e−2 ${f(o.diffEMinus2)}`).join("; ")}`,
  );
  console.log(
    `  agreeing second scorer: ${c.agreeingSecond ? "changes no block's decision" : "CHANGED a decision"}; disagreeing second scorer (+8 ms on RN pen 1): ${c.disagreeingSecondChanges ? "reported as changing a block's decision" : "no change reported"} → ${c.verdictWithDisagreeingSecond}`,
  );
}
