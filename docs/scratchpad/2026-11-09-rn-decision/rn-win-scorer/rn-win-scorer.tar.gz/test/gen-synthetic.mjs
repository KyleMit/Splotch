#!/usr/bin/env node
// Synthetic 240 fps "flick and freeze" clips with a known ink lag, plus an exact-geometry oracle.
// usage: node gen-synthetic.mjs <outdir> <clip-name|all> [--list]
import { spawn } from "node:child_process";
import { writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { FFMPEG, FPS } from "../bin/lib/video.mjs";
import { oracleForStroke } from "./oracle.mjs";

const PPM = 4.0; // px per mm of the synthetic drawing area (≈ a 1080p landscape capture of a portrait 12.9" iPad)
const AREA_MM = [180, 230];
const FRAME_MS = 1000 / FPS;
const PEN_WIDTH_MM = 8 * (262.9 / 1366); // Size 3 = 8 pt on a 1366-pt-tall 262.9 mm screen
const INK_RGB = [168, 112, 220];
const PAPER_RGB = [245, 241, 233];
const SKIN_RGB = [220, 168, 142];
const FINGER_HALF_WIDTH_MM = 7.5; // 15 x 20 mm fingertip ellipse
const FINGER_HALF_LENGTH_MM = 10;
const BODY_RADIUS_MM = 7.8;
const SHADOW_OFFSET_MM = [1.5, 2.5];
const SHADOW_DARKEN = 0.12;
const EXPOSURE_MS = 2.5;
const BLUR_SAMPLES = 5;
const NOISE_SIGMA = 2.0;
/** Overshoot plant: a predicted tail this long past the stop, shown for OVERSHOOT_SHOW_MS after the ink reaches the stop. */
const OVERSHOOT_MM = 6;
const OVERSHOOT_SHOW_MS = 200;

const BASE = {
  brush: "pen",
  lagMs: 30,
  jitterMs: 0,
  displayHz: 0,
  seed: 11,
  tilt: 0,
  shakePx: 0,
  shadow: true,
  plants: {},
};
export const CLIPS = {
  "clean-pen-lag30": { ...BASE, lagMs: 30 },
  "clean-pen-lag55": { ...BASE, lagMs: 55 },
  "clean-crayon-lag30": { ...BASE, brush: "crayon", lagMs: 30, seed: 23 },
  "clean-crayon-lag55": { ...BASE, brush: "crayon", lagMs: 55, seed: 23 },
  "jitter-pen-lag40": {
    ...BASE,
    lagMs: 40,
    jitterMs: 4,
    displayHz: 120,
    seed: 31,
  },
  "disp60-crayon-lag45": {
    ...BASE,
    brush: "crayon",
    lagMs: 45,
    displayHz: 60,
    seed: 37,
  },
  "fid-short8": {
    ...BASE,
    lagMs: 30,
    seed: 41,
    plants: { short: [1, 2, 3, 4, 5, 6, 7, 8] },
  },
  "fid-mixed": {
    ...BASE,
    lagMs: 30,
    seed: 43,
    plants: { short: [2, 5], gap: [7], missing: [4] },
  },
  "offframe-pen-lag30": {
    ...BASE,
    lagMs: 30,
    seed: 47,
    plants: { offframe: [3, 6] },
  },
  "shake-tilt-pen-lag40": {
    ...BASE,
    lagMs: 40,
    seed: 53,
    tilt: 0.05,
    shakePx: 3,
    displayHz: 120,
  },
  "raw-chrome-pen-lag35": { ...BASE, lagMs: 35, seed: 59, raw: true },
  // Prediction: the ink leads the contact point by 5 ms. Seen from above, a lead shows only where the ink passes
  // the finger's leading edge, so this fixture's contact sits 2 mm inside that edge (finger rolled into the swipe).
  "predict-front-lead5": { ...BASE, lagMs: -5, contactLeadMm: 2, speedRange: [1.1, 1.5], seed: 61 },
  // The same lead under a centred contact (7.5 mm inside the leading edge): the leading ink stays hidden.
  "predict-centred-lead5": { ...BASE, lagMs: -5, speedRange: [1.1, 1.5], seed: 61 },
  // (f) The centred-contact lead on amendment-4 swipes: hidden, so it must score below floor.
  "predict-centred-lead5-long": { ...BASE, lagMs: -5, speedRange: [1.1, 1.5], strokeLenRange: [130, 150], seed: 61 },
  // A 6 mm predicted tail past the stop that retracts after 200 ms, on strokes 1, 3, 5, 7.
  "overshoot6-front-lag30": { ...BASE, lagMs: 30, contactLeadMm: 2, seed: 67, plants: { overshoot: [1, 3, 5, 7] } },
};
// Four-block sets for compare-blocks: RN truly 25 ms (win, winlow) or 12 ms (tie) faster than shipping.
// winlow: the same 25 ms advantage at lower absolute delays, where the e ± 2 mm variants stay symmetric.
/** One owner flicking consistently: peak speeds within 1.1–1.3 m/s, so the 25% speed-match rule never trips by chance. */
const BLOCK_SPEED_RANGE = [1.1, 1.3];
const BLOCK_SETS = { win: { rn: 30, ship: 55 }, tie: { rn: 30, ship: 42 }, winlow: { rn: 15, ship: 40 } };
/** Amendment 4 swipes: 130–150 mm, centred on the page. */
const LONG_SWIPE_MM = [130, 150];
// Amendment 4 sets on long swipes: (a) 30 v 55, (b) 30 v 42, (c) 15 v 40, (d) 5 v 40 (RN's tip mostly hidden),
// (e) the mirror, shipping 30 v RN 55.
const LONG_BLOCK_SETS = {
  "long-30v55": { rn: 30, ship: 55 },
  "long-30v42": { rn: 30, ship: 42 },
  "long-15v40": { rn: 15, ship: 40 },
  "long-5v40": { rn: 5, ship: 40 },
  "long-ship30v55": { rn: 55, ship: 30 },
};
let blockSeed = 101;
const blockSets = [...Object.entries(BLOCK_SETS).map(([k, v]) => [k, v, {}]), ...Object.entries(LONG_BLOCK_SETS).map(([k, v]) => [k, v, { strokeLenRange: LONG_SWIPE_MM }])];
for (const [set, lags, extra] of blockSets)
  for (const brush of ['pen', 'crayon'])
    for (const block of [1, 2])
      for (const app of ['rn', 'ship'])
        CLIPS[`blk${set}-${brush}${block}-${app}`] = { ...BASE, ...extra, brush, lagMs: lags[app], speedRange: BLOCK_SPEED_RANGE, seed: blockSeed++, block: { set, brush, block, app } };

function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const lerp = (a, b, s) => a + (b - a) * s;
const clamp = (x, lo, hi) => (x < lo ? lo : x > hi ? hi : x);

function gaussFactory(rand) {
  return () => {
    let u = 0;
    let v = 0;
    while (u === 0) u = rand();
    while (v === 0) v = rand();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  };
}

function valueNoise(w, h, cellPx, rand) {
  const gw = Math.ceil(w / cellPx) + 2;
  const gh = Math.ceil(h / cellPx) + 2;
  const grid = new Float32Array(gw * gh).map(() => rand() * 2 - 1);
  const out = new Float32Array(w * h);
  for (let y = 0; y < h; y++) {
    const gy = y / cellPx;
    const y0 = Math.floor(gy);
    const fy = gy - y0;
    const sy = fy * fy * (3 - 2 * fy);
    for (let x = 0; x < w; x++) {
      const gx = x / cellPx;
      const x0 = Math.floor(gx);
      const fx = gx - x0;
      const sx = fx * fx * (3 - 2 * fx);
      const a = grid[y0 * gw + x0];
      const b = grid[y0 * gw + x0 + 1];
      const c = grid[(y0 + 1) * gw + x0];
      const d = grid[(y0 + 1) * gw + x0 + 1];
      out[y * w + x] = lerp(lerp(a, b, sx), lerp(c, d, sx), sy);
    }
  }
  return out;
}

/** Cosine-ramp flick: accelerate over ta, cruise, decelerate over td; returns arc(ms) in mm. */
export function makeProfile(D, vp, ta, td) {
  let cruise = (D - (vp * (ta + td)) / 2) / vp;
  if (cruise < 0) {
    vp = D / ((ta + td) / 2);
    cruise = 0;
  }
  const total = ta + cruise + td;
  const arc = (tau) => {
    if (tau <= 0) return 0;
    if (tau < ta)
      return (vp / 2) * (tau - (ta / Math.PI) * Math.sin((Math.PI * tau) / ta));
    if (tau < ta + cruise) return (vp * ta) / 2 + vp * (tau - ta);
    if (tau < total) {
      const t2 = tau - ta - cruise;
      return (
        (vp * ta) / 2 +
        vp * cruise +
        (vp / 2) * (t2 + (td / Math.PI) * Math.sin((Math.PI * t2) / td))
      );
    }
    return D;
  };
  return { arc, total, vp, cruise };
}

function buildStrokes(cfg, rand) {
  const strokes = [];
  const T_APPROACH = 220;
  const T_REST = 110;
  const T_HOLD = 1000;
  const T_LIFT = 160;
  const T_AWAY = 220;
  let t0 = 300;
  for (let k = 0; k < 8; k++) {
    const num = k + 1;
    const leftToRight = k % 2 === 0;
    const y = 22 + 26 * k;
    const [dLo, dHi] = cfg.strokeLenRange ?? [95, 105];
    const D = dLo + rand() * (dHi - dLo);
    const angle = ((rand() * 2 - 1) * 5 * Math.PI) / 180;
    let x0 = leftToRight ? 40 : 140;
    if (cfg.strokeLenRange) x0 = AREA_MM[0] / 2 + (leftToRight ? -D / 2 : D / 2);
    let D2 = D;
    if (cfg.plants.offframe?.includes(num)) {
      x0 = leftToRight ? 85 : 95;
      D2 = leftToRight ? AREA_MM[0] - 3 - x0 : x0 - 3;
    }
    const dir = leftToRight
      ? [Math.cos(angle), Math.sin(angle)]
      : [-Math.cos(angle), -Math.sin(angle)];
    const nrm = [-dir[1], dir[0]];
    const sag = (rand() * 2 - 1) * 2;
    const [vLo, vHi] = cfg.speedRange ?? [0.9, 1.4];
    const vp = vLo + rand() * (vHi - vLo);
    const ta = 40 + rand() * 20;
    const td = 60 + rand() * 40;
    const prof = makeProfile(D2, vp, ta, td);
    const bodyAngle = ((rand() * 2 - 1) * 15 * Math.PI) / 180;
    const bodyDir = [Math.sin(bodyAngle), Math.cos(bodyAngle)];
    const tTouch = t0 + T_APPROACH;
    const tSwipe = tTouch + T_REST;
    const tStop = tSwipe + prof.total;
    const tLift = tStop + T_HOLD;
    const tEnd = tLift + T_LIFT + T_AWAY;
    const p0 = [x0, y];
    const point = (s) => {
      const u = s / D2;
      const off = sag * 4 * u * (1 - u);
      return [
        p0[0] + dir[0] * s + nrm[0] * off,
        p0[1] + dir[1] * s + nrm[1] * off,
      ];
    };
    const tangent = (s) => {
      const u = s / D2;
      const dOff = (sag * 4 * (1 - 2 * u)) / D2;
      const tx = dir[0] + nrm[0] * dOff;
      const ty = dir[1] + nrm[1] * dOff;
      const m = Math.hypot(tx, ty);
      return [tx / m, ty / m];
    };
    strokes.push({
      num,
      D: D2,
      p0,
      point,
      tangent,
      prof,
      bodyDir,
      tApproach: t0,
      tTouch,
      tSwipe,
      tStop,
      tLift,
      tEnd,
      short: cfg.plants.short?.includes(num) ? 8 : 0,
      gap: cfg.plants.gap?.includes(num) ? [40, 46] : null,
      missing: !!cfg.plants.missing?.includes(num),
      offframe: !!cfg.plants.offframe?.includes(num),
      overshoot: cfg.plants.overshoot?.includes(num) ? OVERSHOOT_MM : 0,
      anchorBack: cfg.contactLeadMm === undefined ? 0 : FINGER_HALF_WIDTH_MM - cfg.contactLeadMm,
      jitterPhase: rand(),
      displayPhase: rand(),
    });
    t0 = tEnd;
  }
  return { strokes, durationMs: t0 + 500 };
}

/** Hand anchor (fingertip centre) at time t for stroke st, or null when the hand is out of view. */
function handAt(st, t) {
  const far = 110;
  if (t < st.tApproach || t >= st.tEnd) return null;
  if (t < st.tTouch) {
    const s = (t - st.tApproach) / (st.tTouch - st.tApproach);
    const e = 1 - (1 - s) * (1 - s);
    const p = anchorAt(st, 0);
    return [
      p[0] + st.bodyDir[0] * far * (1 - e),
      p[1] + st.bodyDir[1] * far * (1 - e),
    ];
  }
  if (t < st.tLift) return anchorAt(st, st.prof.arc(t - st.tSwipe));
  const s = Math.min(1, (t - st.tLift) / (st.tEnd - st.tLift));
  const e = s * s;
  const p = anchorAt(st, st.D);
  return [p[0] + st.bodyDir[0] * far * e, p[1] + st.bodyDir[1] * far * e];
}

/** Fingertip centre for contact at arc s: the contact sits anchorBack mm ahead of the centre along the travel. */
function anchorAt(st, s) {
  const c = st.point(s);
  if (!st.anchorBack) return c;
  const tg = st.tangent(s);
  return [c[0] - tg[0] * st.anchorBack, c[1] - tg[1] * st.anchorBack];
}

/** Signed distance (mm) from point to the hand silhouette anchored at h. */
function handSd(px, py, h, bodyDir) {
  const dx = px - h[0];
  const dy = py - h[1];
  const across = dx * bodyDir[1] - dy * bodyDir[0];
  const along = dx * bodyDir[0] + dy * bodyDir[1];
  const ex = across / FINGER_HALF_WIDTH_MM;
  const ey = along / FINGER_HALF_LENGTH_MM;
  const rho = Math.sqrt(ex * ex + ey * ey);
  let sdE;
  if (rho < 1e-6) sdE = -FINGER_HALF_WIDTH_MM;
  else {
    const gx = across / (FINGER_HALF_WIDTH_MM * FINGER_HALF_WIDTH_MM);
    const gy = along / (FINGER_HALF_LENGTH_MM * FINGER_HALF_LENGTH_MM);
    const g = Math.sqrt(gx * gx + gy * gy) / rho;
    sdE = (rho - 1) / g;
  }
  const segStart = 6;
  const segEnd = 320;
  const tAlong = clamp(along, segStart, segEnd);
  const sdC = Math.hypot(across, along - tAlong) - BODY_RADIUS_MM;
  return { sd: Math.min(sdE, sdC), across };
}

/** Distance behind the contact point, along the stroke tangent, to the hand's trailing edge. */
export function trailingOffset(st, s) {
  return edgeOffset(st, s, -1);
}

/** Distance ahead of the contact point, along the stroke tangent, to the hand's leading edge. */
export function leadingOffset(st, s) {
  return edgeOffset(st, s, 1);
}

function edgeOffset(st, s, sign) {
  const c = st.point(s);
  const h = anchorAt(st, s);
  const tg = st.tangent(s);
  for (let d = 0; d < 40; d += 0.005) {
    const { sd } = handSd(c[0] + sign * tg[0] * d, c[1] + sign * tg[1] * d, h, st.bodyDir);
    if (sd > 0) return d;
  }
  return 40;
}

function inkColorFor(brush) {
  return brush === "crayon"
    ? INK_RGB.map((v, i) => v + (PAPER_RGB[i] - v) * 0.08)
    : INK_RGB;
}

export function inkTipArc(cfg, st, tMs, prevArc) {
  if (st.missing) return -1;
  let tq = tMs;
  if (cfg.displayHz) {
    const period = 1000 / cfg.displayHz;
    const phase = st.displayPhase * period;
    tq = Math.floor((tMs - phase) / period) * period + phase;
  }
  let lag = cfg.lagMs;
  if (cfg.jitterMs) {
    const frame = Math.round(tMs / FRAME_MS);
    const h = Math.sin(frame * 12.9898 + st.jitterPhase * 78.233) * 43758.5453;
    lag += (h - Math.floor(h) - 0.5) * 2 * cfg.jitterMs;
  }
  const tInk = tq - lag;
  if (tInk < st.tTouch || tMs < st.tTouch) return prevArc;
  let s = st.prof.arc(Math.min(tInk, st.tLift) - st.tSwipe);
  if (st.short) s = Math.min(s, st.D - st.short);
  return Math.max(prevArc, s);
}

function homography(cfg, sceneW, sceneH) {
  // scene px -> output px
  if (cfg.raw) {
    const ang = (1.5 * Math.PI) / 180;
    const sc = 0.97;
    const c = Math.cos(ang) * sc;
    const s = Math.sin(ang) * sc;
    const outW = 2 * Math.round((sceneW * 1.08 + 40) / 2);
    const outH = 2 * Math.round((sceneH * 1.04 + 40) / 2);
    const tx = outW / 2 - (c * sceneW) / 2 + (s * sceneH) / 2;
    const ty = outH / 2 - (s * sceneW) / 2 - (c * sceneH) / 2;
    const k = 0.00004;
    return { H: [c, -s, tx, s, c, ty, 0, k, 1], outW, outH };
  }
  if (cfg.tilt) {
    const cy = sceneH / 2;
    const p = cfg.tilt / sceneH;
    // y' = (y - cy)/(1 + p (y - cy)) + cy about the centre; x likewise
    const cx = sceneW / 2;
    const H = [1, 0, 0, 0, 1, 0, 0, p, 1];
    const T = [1, 0, -cx, 0, 1, -cy, 0, 0, 1];
    const Ti = [1, 0, cx, 0, 1, cy, 0, 0, 1];
    return { H: mul3(Ti, mul3(H, T)), outW: sceneW, outH: sceneH };
  }
  return { H: null, outW: sceneW, outH: sceneH };
}
function mul3(a, b) {
  const r = new Array(9).fill(0);
  for (let i = 0; i < 3; i++)
    for (let j = 0; j < 3; j++)
      for (let k = 0; k < 3; k++) r[i * 3 + j] += a[i * 3 + k] * b[k * 3 + j];
  return r;
}
function inv3(m) {
  const [a, b, c, d, e, f, g, h, i] = m;
  const A = e * i - f * h;
  const B = -(d * i - f * g);
  const C = d * h - e * g;
  const det = a * A + b * B + c * C;
  return [
    A,
    -(b * i - c * h),
    b * f - c * e,
    B,
    a * i - c * g,
    -(a * f - c * d),
    C,
    -(a * h - b * g),
    a * e - b * d,
  ].map((v) => v / det);
}
export function applyH(H, x, y) {
  const w = H[6] * x + H[7] * y + H[8];
  return [(H[0] * x + H[1] * y + H[2]) / w, (H[3] * x + H[4] * y + H[5]) / w];
}

export async function generate(name, outDir, opts = {}) {
  const cfg = CLIPS[name];
  if (!cfg) throw new Error(`unknown clip ${name}`);
  const rand = mulberry32(cfg.seed);
  const gauss = gaussFactory(mulberry32(cfg.seed * 7 + 1));
  const { strokes, durationMs } = buildStrokes(cfg, rand);
  const nFrames = Math.round((durationMs / 1000) * FPS);

  // Scene raster: drawing area, padded with app chrome for the raw clip.
  const padTop = cfg.raw ? Math.round(30 * PPM) : 0;
  const pad = cfg.raw ? Math.round(10 * PPM) : 0;
  const areaW = Math.round(AREA_MM[0] * PPM);
  const areaH = Math.round(AREA_MM[1] * PPM);
  const sceneW = areaW + 2 * pad;
  const sceneH = areaH + 2 * pad + padTop;
  const ox = pad;
  const oy = pad + padTop;
  if (opts.truthOnly) {
    const cam = homography(cfg, sceneW, sceneH);
    return finishTruth({ name, outDir, cfg, strokes, tipLog: simulateTipLog(cfg, strokes, nFrames), nFrames, cam, ox, oy, areaW, areaH });
  }
  const N = sceneW * sceneH;
  const paper = new Float32Array(N * 3);
  const lowN = valueNoise(sceneW, sceneH, 10 * PPM, rand);
  const grainRand = mulberry32(cfg.seed + 99);
  for (let i = 0; i < N; i++) {
    const f = 1 + 0.012 * lowN[i] + 0.008 * (grainRand() * 2 - 1);
    for (let c = 0; c < 3; c++) paper[i * 3 + c] = PAPER_RGB[c] * f;
  }
  if (cfg.raw) {
    for (let y = 0; y < sceneH; y++)
      for (let x = 0; x < sceneW; x++) {
        const inArea = x >= ox && x < ox + areaW && y >= oy && y < oy + areaH;
        if (inArea) continue;
        const i = y * sceneW + x;
        const inScreen =
          x >= pad && x < sceneW - pad && y >= pad && y < sceneH - pad;
        let col = [18, 18, 20];
        if (inScreen) {
          col = [236, 228, 250];
          const bx = Math.floor((x - pad) / (22 * PPM));
          const cxp = (bx + 0.5) * 22 * PPM + pad;
          const cyp = pad + padTop / 2;
          if (Math.hypot(x - cxp, y - cyp) < 8 * PPM)
            col = [
              [230, 90, 90],
              [90, 160, 230],
              [120, 200, 120],
              [171, 113, 225],
            ][bx % 4];
        }
        paper[i * 3] = col[0];
        paper[i * 3 + 1] = col[1];
        paper[i * 3 + 2] = col[2];
      }
  }
  const base = Float32Array.from(paper);
  const ink = new Float32Array(N);
  const inkRGB = inkColorFor(cfg.brush);
  const crayonTex =
    cfg.brush === "crayon"
      ? valueNoise(sceneW, sceneH, 0.35 * PPM, mulberry32(cfg.seed + 5))
      : null;
  const inkAlpha = cfg.brush === "crayon" ? 0.92 : 1;
  const halfW = (PEN_WIDTH_MM / 2) * PPM;

  const stamp = (sx, sy) => {
    const x0 = Math.max(0, Math.floor(sx - halfW - 1));
    const x1 = Math.min(sceneW - 1, Math.ceil(sx + halfW + 1));
    const y0 = Math.max(0, Math.floor(sy - halfW - 1));
    const y1 = Math.min(sceneH - 1, Math.ceil(sy + halfW + 1));
    for (let y = y0; y <= y1; y++)
      for (let x = x0; x <= x1; x++) {
        if (x < ox || x >= ox + areaW || y < oy || y >= oy + areaH) continue;
        const d = Math.hypot(x + 0.5 - sx, y + 0.5 - sy);
        let cov = clamp(halfW - d + 0.5, 0, 1) * inkAlpha;
        if (crayonTex)
          cov *= clamp((crayonTex[y * sceneW + x] + 0.55) / 0.9, 0.12, 1);
        const i = y * sceneW + x;
        if (cov > ink[i]) {
          ink[i] = cov;
          for (let c = 0; c < 3; c++)
            base[i * 3 + c] = paper[i * 3 + c] * (1 - cov) + inkRGB[c] * cov;
        }
      }
  };
  const drawInk = (st, fromArc, toArc) => {
    const start = fromArc < 0 ? 0 : fromArc;
    for (let s = start; s <= toArc + 1e-9; s += 0.1) {
      if (st.gap && s >= st.gap[0] && s <= st.gap[1]) continue;
      const p = st.point(Math.min(s, toArc));
      stamp(ox + p[0] * PPM, oy + p[1] * PPM);
    }
  };
  // Overshoot plant: a temporary predicted tail past the stop, composited per frame while it is shown.
  const tails = strokes.map((st) => {
    if (!st.overshoot) return null;
    const cov = new Map();
    const p = st.point(st.D);
    const tg = st.tangent(st.D);
    for (let d = 0; d <= st.overshoot + 1e-9; d += 0.1) {
      const sx = ox + (p[0] + tg[0] * d) * PPM;
      const sy = oy + (p[1] + tg[1] * d) * PPM;
      for (let y = Math.max(0, Math.floor(sy - halfW - 1)); y <= Math.min(sceneH - 1, Math.ceil(sy + halfW + 1)); y++)
        for (let x = Math.max(0, Math.floor(sx - halfW - 1)); x <= Math.min(sceneW - 1, Math.ceil(sx + halfW + 1)); x++) {
          let c = clamp(halfW - Math.hypot(x + 0.5 - sx, y + 0.5 - sy) + 0.5, 0, 1) * inkAlpha;
          if (crayonTex) c *= clamp((crayonTex[y * sceneW + x] + 0.55) / 0.9, 0.12, 1);
          const i = y * sceneW + x;
          if (c > (cov.get(i) ?? 0)) cov.set(i, c);
        }
    }
    return { cov, shownFrom: null };
  });

  const cam = homography(cfg, sceneW, sceneH);
  const Hinv = cam.H ? inv3(cam.H) : null;
  const outW = cam.outW;
  const outH = cam.outH;
  const frameF = new Float32Array(N * 3);
  const out = Buffer.alloc(outW * outH * 3);
  const noiseBank = Array.from({ length: 5 }, () =>
    Int8Array.from({ length: outW * outH * 3 + 7 }, () =>
      clamp(Math.round(gauss() * NOISE_SIGMA), -127, 127),
    ),
  );

  mkdirSync(outDir, { recursive: true });
  const file = join(outDir, `${name}.mp4`);
  const ff = spawn(
    FFMPEG,
    [
      "-v",
      "error",
      "-y",
      "-f",
      "rawvideo",
      "-pix_fmt",
      "rgb24",
      "-s",
      `${outW}x${outH}`,
      "-r",
      String(FPS),
      "-i",
      "-",
      "-c:v",
      "libx264",
      "-preset",
      "veryfast",
      "-crf",
      "17",
      "-pix_fmt",
      "yuv420p",
      "-g",
      "240",
      file,
    ],
    { stdio: ["pipe", "inherit", "inherit"] },
  );
  const write = (buf) =>
    new Promise((res) => {
      if (ff.stdin.write(buf)) res();
      else ff.stdin.once("drain", res);
    });

  const inkArc = strokes.map(() => -1);
  const tipLog = strokes.map(() => []);
  const shake = (n) => {
    if (!cfg.shakePx) return [0, 0];
    const t = n / FPS;
    const a = cfg.shakePx;
    return [
      0.75 * a * Math.sin(2 * Math.PI * 6.3 * t + 0.4) +
        0.2 * a * Math.sin(2 * Math.PI * 17.1 * t) +
        0.1 * a * gauss(),
      0.6 * a * Math.sin(2 * Math.PI * 4.7 * t + 1.9) +
        0.2 * a * Math.sin(2 * Math.PI * 13.3 * t + 0.3) +
        0.1 * a * gauss(),
    ];
  };
  const shakes = [];

  for (let n = 0; n < nFrames; n++) {
    const tMs = n * FRAME_MS;
    for (let k = 0; k < strokes.length; k++) {
      const st = strokes[k];
      if (tMs < st.tTouch || st.missing) continue;
      const next = inkTipArc(cfg, st, tMs, inkArc[k]);
      if (next > inkArc[k] || (inkArc[k] < 0 && next >= 0)) {
        drawInk(st, inkArc[k] < 0 ? -1 : inkArc[k], next);
        inkArc[k] = next;
      }
      const tail = tails[k];
      if (tail && tail.shownFrom === null && inkArc[k] >= st.D - 1e-6) tail.shownFrom = tMs;
      const tailOn = !!tail && tail.shownFrom !== null && tMs < tail.shownFrom + OVERSHOOT_SHOW_MS;
      if (tMs <= st.tEnd + 50) tipLog[k].push({ n, tipArc: inkArc[k], tailArc: tailOn ? st.D + st.overshoot : null });
    }
    frameF.set(base);
    for (const tail of tails) {
      if (!tail || tail.shownFrom === null || tMs >= tail.shownFrom + OVERSHOOT_SHOW_MS) continue;
      for (const [i, c] of tail.cov) {
        const m = Math.max(ink[i], c);
        for (let ch = 0; ch < 3; ch++) frameF[i * 3 + ch] = paper[i * 3 + ch] * (1 - m) + inkRGB[ch] * m;
      }
    }
    const active = strokes.find((st) => tMs >= st.tApproach && tMs < st.tEnd);
    if (active) renderHand(frameF, active, tMs, cfg, sceneW, sceneH, ox, oy);
    const sh = shake(n);
    shakes.push(sh);
    const noise = noiseBank[n % noiseBank.length];
    const noff = (n * 7919) % 7;
    if (!Hinv && !sh[0] && !sh[1]) {
      for (let i = 0; i < outW * outH * 3; i++)
        out[i] = clamp(Math.round(frameF[i] + noise[i + noff]), 0, 255);
    } else {
      warp(frameF, sceneW, sceneH, out, outW, outH, Hinv, sh, noise, noff);
    }
    await write(Buffer.from(out));
  }
  ff.stdin.end();
  await new Promise((res, rej) =>
    ff.on("close", (c) =>
      c === 0 ? res() : rej(new Error(`ffmpeg exit ${c}`)),
    ),
  );

  return finishTruth({ name, outDir, cfg, strokes, tipLog, nFrames, cam, ox, oy, areaW, areaH });
}

/** Oracle truth and (for cropped-style clips) the scorer sidecar. */
function finishTruth({ name, outDir, cfg, strokes, tipLog, nFrames, cam, ox, oy, areaW, areaH }) {
  const outW = cam.outW;
  const outH = cam.outH;
  const truth = {
    clip: name,
    config: {
      ...cfg,
      ppm: PPM,
      areaMm: AREA_MM,
      penWidthMm: PEN_WIDTH_MM,
      exposureMs: EXPOSURE_MS,
    },
    nFrames,
    strokes: strokes.map((st, k) =>
      oracleForStroke(st, tipLog[k], {
        penWidthMm: PEN_WIDTH_MM,
        trailingOffset,
        leadingOffset,
        cfg,
      }),
    ),
  };
  if (cfg.raw) {
    const corners = [
      [ox, oy],
      [ox + areaW, oy],
      [ox + areaW, oy + areaH],
      [ox, oy + areaH],
    ].map(([x, y]) => applyH(cam.H, x, y).map((v) => +v.toFixed(2)));
    truth.drawingAreaCornersPx = {
      tl: corners[0],
      tr: corners[1],
      br: corners[2],
      bl: corners[3],
    };
  } else {
    writeFileSync(
      join(outDir, `${name}.json`),
      JSON.stringify(
        {
          id: name,
          brush: cfg.brush,
          px_per_mm: PPM,
          fps: FPS,
          width: outW,
          height: outH,
          source: "synthetic",
        },
        null,
        2,
      ),
    );
  }
  writeFileSync(
    join(outDir, `${name}.truth.json`),
    JSON.stringify(truth, null, 2),
  );
  return truth;
}

/** The ink-tip timeline the render loop produces, without rendering (same inkTipArc and tail logic). */
function simulateTipLog(cfg, strokes, nFrames) {
  const inkArc = strokes.map(() => -1);
  const tipLog = strokes.map(() => []);
  const tails = strokes.map((st) => (st.overshoot ? { shownFrom: null } : null));
  for (let n = 0; n < nFrames; n++) {
    const tMs = n * FRAME_MS;
    for (let k = 0; k < strokes.length; k++) {
      const st = strokes[k];
      if (tMs < st.tTouch || st.missing) continue;
      const next = inkTipArc(cfg, st, tMs, inkArc[k]);
      if (next > inkArc[k] || (inkArc[k] < 0 && next >= 0)) inkArc[k] = next;
      const tail = tails[k];
      if (tail && tail.shownFrom === null && inkArc[k] >= st.D - 1e-6) tail.shownFrom = tMs;
      const tailOn = !!tail && tail.shownFrom !== null && tMs < tail.shownFrom + OVERSHOOT_SHOW_MS;
      if (tMs <= st.tEnd + 50) tipLog[k].push({ n, tipArc: inkArc[k], tailArc: tailOn ? st.D + st.overshoot : null });
    }
  }
  return tipLog;
}

function renderHand(frameF, st, tMs, cfg, W, H, ox, oy) {
  const hs = [];
  for (let j = 0; j < BLUR_SAMPLES; j++) {
    const tj = tMs + (j / (BLUR_SAMPLES - 1) - 0.5) * EXPOSURE_MS;
    const h = handAt(st, tj);
    if (h) hs.push(h);
  }
  if (!hs.length) return;
  const hc = handAt(st, tMs) || hs[Math.floor(hs.length / 2)];
  let blurMm = 0;
  for (const h of hs)
    blurMm = Math.max(blurMm, Math.hypot(h[0] - hc[0], h[1] - hc[1]));
  const bd = st.bodyDir;
  const xs = hs.map((h) => h[0]);
  const ys = hs.map((h) => h[1]);
  const reach = 320;
  const minX = Math.min(...xs, ...xs.map((x) => x + bd[0] * reach)) - 12;
  const maxX = Math.max(...xs, ...xs.map((x) => x + bd[0] * reach)) + 12;
  const minY = Math.min(...ys) - 14;
  const maxY = Math.max(...ys, ...ys.map((y) => y + bd[1] * reach)) + 12;
  const px0 = Math.max(0, Math.floor(ox + minX * PPM));
  const px1 = Math.min(W - 1, Math.ceil(ox + maxX * PPM));
  const py0 = Math.max(0, Math.floor(oy + minY * PPM));
  const py1 = Math.min(H - 1, Math.ceil(oy + maxY * PPM));
  const pxMm = 1 / PPM;
  const shadowSoft = 1.0;
  for (let py = py0; py <= py1; py++) {
    const my = (py + 0.5 - oy) / PPM;
    for (let px = px0; px <= px1; px++) {
      const mx = (px + 0.5 - ox) / PPM;
      const centre = handSd(mx, my, hc, bd);
      let cov;
      if (centre.sd > blurMm + pxMm) cov = 0;
      else if (centre.sd < -blurMm - pxMm) cov = 1;
      else {
        cov = 0;
        for (const h of hs)
          cov += clamp(0.5 - handSd(mx, my, h, bd).sd / pxMm, 0, 1);
        cov /= hs.length;
      }
      let shadow = 0;
      if (cfg.shadow) {
        const s = handSd(
          mx - SHADOW_OFFSET_MM[0],
          my - SHADOW_OFFSET_MM[1],
          hc,
          bd,
        ).sd;
        shadow = clamp(0.5 - s / (2 * shadowSoft), 0, 1) * SHADOW_DARKEN;
      }
      if (cov <= 0 && shadow <= 0) continue;
      const i = (py * W + px) * 3;
      const shade =
        0.8 + 0.2 * Math.sqrt(Math.max(0, 1 - (centre.across / 8) ** 2));
      for (let c = 0; c < 3; c++) {
        const under = frameF[i + c] * (1 - shadow);
        frameF[i + c] = under * (1 - cov) + SKIN_RGB[c] * shade * cov;
      }
    }
  }
}

function warp(src, sw, sh, out, ow, oh, Hinv, shk, noise, noff) {
  for (let y = 0; y < oh; y++) {
    for (let x = 0; x < ow; x++) {
      const X = x + 0.5 - shk[0];
      const Y = y + 0.5 - shk[1];
      let sx = X;
      let sy = Y;
      if (Hinv) [sx, sy] = applyH(Hinv, X, Y);
      sx -= 0.5;
      sy -= 0.5;
      const o = (y * ow + x) * 3;
      const x0 = Math.floor(sx);
      const y0 = Math.floor(sy);
      if (x0 < 0 || y0 < 0 || x0 >= sw - 1 || y0 >= sh - 1) {
        out[o] = 40 + noise[o + noff];
        out[o + 1] = 38 + noise[o + 1 + noff];
        out[o + 2] = 36 + noise[o + 2 + noff];
        continue;
      }
      const fx = sx - x0;
      const fy = sy - y0;
      const i00 = (y0 * sw + x0) * 3;
      const i10 = i00 + 3;
      const i01 = i00 + sw * 3;
      const i11 = i01 + 3;
      for (let c = 0; c < 3; c++) {
        const v =
          (src[i00 + c] * (1 - fx) + src[i10 + c] * fx) * (1 - fy) +
          (src[i01 + c] * (1 - fx) + src[i11 + c] * fx) * fy;
        out[o + c] = clamp(Math.round(v + noise[o + c + noff]), 0, 255);
      }
    }
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const truthOnly = process.argv.includes("--truth-only");
  const [outDir, which] = process.argv.slice(2).filter((a) => a !== "--truth-only");
  if (!outDir || !which) {
    console.error(
      `usage: gen-synthetic.mjs <outdir> <${Object.keys(CLIPS).join("|")}|all>`,
    );
    process.exit(2);
  }
  const names = which === "all" ? Object.keys(CLIPS) : which.split(",");
  for (const name of names) {
    const t0 = Date.now();
    const truth = await generate(name, outDir, { truthOnly });
    console.log(
      `${name}: ${truth.nFrames} frames in ${((Date.now() - t0) / 1000).toFixed(1)} s`,
    );
  }
}
