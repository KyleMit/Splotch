# rn-win: slow-motion ink-lag scorer

Scores the iPad "flick and freeze" clips for Part 1 of
`docs/scratchpad/2026-11-09-rn-decision/rn-win-test.md` as amended (amendments 2–4, commits
1881333e2 and a4314c956). The primary measure is **shift lag** (apparent tracking delay); trail time
and arrival time are reported only. The tools use Node and ffmpeg only; `sharp` comes from the
repo's `node_modules` and is used only for PNG output. Nothing is installed. `MANIFEST.sha256`
fingerprints the frozen scorer, generator and reports (`shasum -a 256 -c MANIFEST.sha256` from this
folder).

```
bin/probe-clip      ingest check: refuse anything that is not a uniform 240 fps capture
bin/crop-clip       gridded stills to choose the crop; crop + rectify + blind-label; writes the scorer sidecar
bin/score-clip      score one blinded clip (JSON, CSV, summary, debug overlays)
bin/score-all       score a folder of blinded clips; print one table; --json writes the scores table
bin/compare-blocks  after the scores are committed: open the key, compute per-block differences and the verdict
bin/lib/            rules.mjs (the pre-registered constants and rules), score.mjs, overlay.mjs, video.mjs
test/               synthetic generator + oracle, validation runner, sensitivity analysis, results
```

## Running it on the real clips

The shell is zsh. `RW` is this folder.

```zsh
RW=/private/tmp/claude-501/-Users-kylemit-Code-Splotch--claude-worktrees-splotch-status-planning-f08c4b/190a1992-bb0a-40b4-94f5-7fa92fcd16b7/scratchpad/campaign/rn-win
cd $RW && shasum -a 256 -c MANIFEST.sha256            # the scorer is the frozen one
IN=<folder holding the AirDropped .MOV originals>
OUT=$RW/real; mkdir -p $OUT/stills $OUT/blind

# 1. Ingest check (exit 0 = accepted, 1 = refused). Refused clips must be re-sent as originals.
for f in $IN/*.MOV; do $RW/bin/probe-clip $f --json $OUT/stills/${f:t:r}.probe.json || echo "REFUSED $f"; done

# 2. Choose the crop: a pixel-grid still, then the four screen corners (TL, TR, BR, BL), which also writes a
#    rectified still with a 10 mm grid for picking the drawing area in mm.
$RW/bin/crop-clip $IN/IMG_0001.MOV --still --out $OUT/stills/IMG_0001.grid.png
$RW/bin/crop-clip $IN/IMG_0001.MOV --still --corners X0,Y0,X1,Y1,X2,Y2,X3,Y3 --area-mm X,Y,W,H --out $OUT/stills/IMG_0001.grid.png

# 3. Crop, rectify and blind every clip with ONE --area-mm. Keep crop-key.jsonl away from the scorer.
$RW/bin/crop-clip $IN/IMG_0001.MOV --id K1 --corners X0,Y0,X1,Y1,X2,Y2,X3,Y3 --area-mm X,Y,W,H \
  --brush pen --outdir $OUT/blind --key $OUT/crop-key.jsonl

# 4. Score everything, audit the first clip's debug images by eye, then COMMIT table.json.
$RW/bin/score-all $OUT/blind --jobs 2 --json $OUT/table.json

# 5. Only after table.json is committed: write the unmasking key and run the comparison.
#    key.jsonl: one line per clip, {"id":"K1","app":"rn","brush":"pen","block":1} (app rn | shipping).
$RW/bin/compare-blocks <committed path>/table.json <key.jsonl> [--second <committed second-scorer table>]
```

`compare-blocks` refuses a scores table that is not tracked and unmodified in its git repository
(`--allow-uncommitted` exists only for the synthetic tests) and prints the commit it read.

The second scorer's table uses the same format as `table.json`. It may hold only the re-scored
strokes (`{"clips":[{"id":"K1","strokes":[{"stroke":3,"status":"ok","shiftLagMs":41.2, ...}]}]}`);
those replace the first scorer's strokes of the same number.

Audit before trusting a number. Open `scores/<id>/debug/segmentation.png`, which shows the ink each
stroke claimed. Open `sNN-series.png`, which plots tip and trailing edge against time with the
scored frames circled. Open the marked frames `sNN-fNNNNN-<tag>.png`; each label gives that frame's
shift lag and tip kind (behind the finger or ahead of it).

## The measure as implemented (amendments 2–4)

**Shift lag (primary).** For each frame, it is the time since the fingertip's trailing edge stood at
(ink tip − e). For ink leading the finger, it is the time until the edge stands there, a negative
value that is never clamped. e is the stroke's settled ink end beyond the trailing edge at the hold.

* **Frames that count:**
  * The fingertip moves at ≥ 0.5 m/s (least-squares slope of the edge over ±4 frames).
  * **Amendment 4:** the finger was also moving at ≥ 0.5 m/s at the matched moment t′. The speed
    there is interpolated between the neighbouring frames' slopes.
  * The ink tip and the trailing edge are both visible and at least 2 mm apart, which is the
    visibility floor and is now a rule. The tip is visible either way:
    * behind the finger: the walk along the ink ends on paper, at least 1 mm short of the trailing
      edge;
    * ahead of the finger: ink resumes within 1.5 mm past the finger's leading edge and shows at
      least 1 mm of itself.
  * **Censoring, now a rule:** a frame whose target (tip − e) lies within 1 mm of where the finger
    rested before the flick, or held after it, is dropped.
  * The crossing time is linear between frames, and the edge must move at least 0.05 mm in that
    frame.
* **Per stroke:** the median over the 10 fastest such frames.
* **Below floor (amendment 4).** This applies only when all of these hold:
  * the stroke has fewer than 10 valid frames;
  * its tip was visible 2 mm clear in fewer than 10 fast frames;
  * its ink is complete after the lift (no fidelity failure, no border, a stop, lift and settled
    view).

  Then it is scored `below_floor`. Its value is the median, over its 10 fastest frames that obey the
  same speed, matched-moment and censoring rules, of the delay at which a tip 2 mm clear behind the
  edge would just have shown. That is an upper bound. The stroke counts as scorable, and the count
  is reported per clip. If the tip was visible clear in 10 or more fast frames but too few were
  usable (censored, for example with a long delay), the stroke stays **unscorable**, not below
  floor. A floor value there would understate a long delay.
* **e** is read from the final settled ink (the per-mm median over the last half of the settled
  window, after any retraction) against the median hold edge. It is reported per stroke as `e_mm`.
* **e ± 2 mm variants.** The whole rule, matched-moment condition included, is re-run with every
  stroke's e moved by +2 and by −2 mm. Below-floor strokes re-run the floor value. A stroke with
  fewer than 10 valid frames under a variant has no value for it.
* **Exclusions, by rule only**, reported per clip in `summary.json` (`exclusions`) and in
  score-all's table:
  * Strokes:
    * `fewFrames`, `border` (fingertip within 2 mm of the frame edge), `noStop`, `noLift`,
      `noSettled`;
    * fidelity failures `short` (e < 2.5 mm), `shortRelative` (more than 4 mm below the clip's 75th
      percentile), `gap`, `missing` and `overshoot`.
  * Fast frames: `tipHidden`, `tooClose`, `border`, `noEdge`, `censoredStart`, `censoredStop`,
    `noCrossing`, `slowMatched`.
* **Overshoot.** The farthest ink seen in any frame (the 3rd-largest frame, against noise) more than
  4 mm past the final settled end is a fidelity failure: ink that overshot the hold point and
  retracted.
* **Uncertainty.** `shift_lag_unc_ms` combines, in quadrature, the frame SE (1.25 × sd / √10) and a
  0.5 mm e measurement uncertainty propagated through the e ± 2 mm slope.

**Reported only, with no veto.**

* Arrival time.
* Trail time.
* Peak speed per stroke.

**compare-blocks** applies the line as written in the note, for each brush and block (one clip per
arm). Scorable means `ok` or `below_floor`; below-floor counts are printed per clip.

* the median shift lag over each clip's scorable strokes;
* the difference, shipping minus RN;
* a 95% percentile bootstrap interval: strokes resampled within each clip, 10,000 resamples, seed
  20261111 + block index;
* the speed match: the median peak speeds' max/min ≤ 1.25;
* at least 5 scorable strokes per clip, nominally and under each e variant;
* the e ± 2 mm differences;
* with `--second`: the merged re-score's difference, and whether it changes the block's decision.

A block goes to RN only if all of these hold:

* the difference is ≥ 20 ms and its interval lies above 0;
* both e variants give ≥ 20 ms;
* the speeds match, each clip has at least 5 scorable strokes, and the re-score keeps it ≥ 20.

Shipping takes a block by the mirror line. RN wins Part 1 only with all four blocks; shipping
likewise; anything else is a tie.

## Validation (synthetic positive controls)

`test/gen-synthetic.mjs` draws 240 fps clips frame by frame in Node and pipes them to x264 (CRF 17).
The frames show:

* textured paper with sensor noise at 4 px/mm;
* a 15 × 20 mm fingertip plus a finger body, with 2.5 ms motion blur and a shadow;
* cosine-ramp flicks, 1 s holds and lifts;
* Purple Size 3 ink following the contact point with a planted delay.

Swipes come in two lengths: about 100 mm (the original fixtures) and **130–150 mm** (amendment 4,
the `long-*` sets and `predict-centred-lead5-long`). The **oracle** (`test/oracle.mjs`) applies the
same amended rules to the exact geometry, so the scorer error is pure measurement error.
`node test/run-validation.mjs` reproduces everything: `test/results/validation.txt`, plus
`test/blocks/<set>/compare.txt` for each block set.

Existing clips were not re-rendered. Their oracle truth was recomputed with `--truth-only`, which
reproduced the previously rendered truth files byte for byte before the rule change. The earlier
fixtures stay byte-identical to their first render.

**Shift lag against the oracle** (79 clips, 570 scored strokes):

|                                    |                                                                                                  |
| ---------------------------------- | ------------------------------------------------------------------------------------------------ |
| Per-stroke error                   | median +0.34 ms, 5–95% −0.17 to +0.62, range −0.42 to +1.17                                      |
| Coverage                           | 567/570 within bias ± 2 × `shift_lag_unc_ms` (median 0.47 ms)                                    |
| Clip medians                       | +0.17 to +0.92 ms from the oracle (below-floor clips −0.25 to +0.06) (criterion ±4 ms: **pass**) |
| 30 → 55 ms difference (planted 25) | pen 24.99, crayon 25.07 (oracle 24.98 / 25.01): **pass**                                         |

Selected clips:

| clip                                                 | planted | oracle | scorer    | scorable                 |
| ---------------------------------------------------- | ------- | ------ | --------- | ------------------------ |
| jitter ±4 ms, 120 Hz                                 | 40      | 43.1   | 43.7      | 7/7                      |
| 60 Hz display                                        | 45      | 50.4   | 50.8      | 4/4                      |
| shake ±3 px + keystone                               | 40      | 43.4   | 44.3      | 7 (oracle 6)             |
| rotated chrome via `crop-clip --corners`             | 35      | 35.0   | 35.4      | 8/8                      |
| ink leads 5 ms, contact 2 mm inside the leading edge | −5      | −5.0   | **−4.75** | 8/8, negative, unclamped |

* **Planted failures.** All are flagged and none is ever below floor:
  * 8/8 `short`;
  * fid-mixed: `short` ×2, `gap`, `missing`;
  * off-frame `border` ×2;
  * overshoot 6 mm then retract: 4/4 `overshoot`; the other 4 strokes score 30.2–30.4 ms.
* **No false flags.** The only scorability disagreement with the oracle is one shake/tilt stroke the
  scorer kept and the oracle dropped.
* **Hidden lead (fixture f).** A 5 ms lead with the contact centred is hidden under the finger.
  * 8/8 below floor on 130–150 mm swipes, with upper bounds of 6.9–9.2 ms (oracle 7.0–9.4).
  * 8/8 below floor on 100 mm swipes too, 7.3–9.3 ms.
  * Never unscorable, and never reported as a measured positive delay.
* **Lighting drift.** ±3% brightness, ±8% contrast and ±6% R/B gamma move shift lag by −0.05 to
  +0.67 ms per stroke.
* **Crop and probe.** The rect crop changes values by at most ±0.04 ms. probe-clip results are
  unchanged.

**compare-blocks end to end.** There are 8 clips per set (one per arm, brush and block, independent
strokes, peak speeds 1.1–1.3 m/s) and 130–150 mm swipes. Below-floor counts are given per arm (RN /
shipping).

| set                | truth               | per-block difference (sh − RN) | e+2 mm         | e−2 mm         | below floor            | verdict                    |
| ------------------ | ------------------- | ------------------------------ | -------------- | -------------- | ---------------------- | -------------------------- |
| (a) long-30v55     | RN 30 / shipping 55 | 24.9, 25.0, 25.0, 25.0         | 24.9–25.1      | 24.7–24.9      | 0/0                    | **RN wins Part 1** ✓       |
| (b) long-30v42     | RN 30 / shipping 42 | 11.9–12.1                      | 11.9–12.1      | 11.7–12.0      | 0/0                    | **Tie** ✓                  |
| (c) long-15v40     | RN 15 / shipping 40 | 24.9–25.2                      | 25.1–25.2      | 24.6–24.9      | 0/0                    | **RN wins Part 1** ✓       |
| (d) long-5v40      | RN 5 / shipping 40  | 31.8–32.4                      | 31.8–32.5      | 31.5–32.1      | **8/0 in every block** | **RN wins Part 1** ✓       |
| (e) long-ship30v55 | shipping 30 / RN 55 | −25.0 to −24.9                 | −25.1 to −25.0 | −24.8 to −24.6 | 0/0                    | **Shipping wins Part 1** ✓ |

* The 95% intervals are 0.2–0.9 ms wide. Speed ratios are 1.00–1.08. Every block has 7–8 scorable
  strokes per arm.
* In (d), RN's strokes score below floor at about 8.1–8.6 ms, an upper bound. So the difference
  (about 32) understates the true 35, as the rule intends.
* The oracle gives the same per-block numbers within 0.7 ms.
* Second scorer:
  * An agreeing re-score (the ambiguous strokes plus every 4th, each ±0.5 ms) changes no decision.
  * Re-reading RN's pen-1 strokes 8 ms slower is reported as changing that block in (a) and (c),
    which turns their verdict to "no win". In (d) the margin survives it.

**What changed from amendment 3, on the old 100 mm swipes** (`test/blocks/{win,tie,winlow}`):

| set              | before (amendments 2–3)       | now (amendment 4)                                         |
| ---------------- | ----------------------------- | --------------------------------------------------------- |
| win, 30 vs 55    | tie: e−2 mm gave 16.6–18.9 ms | tie: shipping's 55 ms arm keeps only 0–2 scorable strokes |
| tie, 30 vs 42    | tie                           | tie                                                       |
| winlow, 15 vs 40 | RN wins                       | RN wins                                                   |

On 100 mm swipes, the matched-moment rule leaves too few frames for a 55 ms delay. The scorable
counts read 2, 2, 2, 0 for the slower arm, and the clean 55 ms clips keep 3 of 8 strokes. **The
130–150 mm swipes are needed, not optional.**

## Sensitivity: e ± 2 mm under amendment 4

The bottom of `test/results/sensitivity.txt` holds exact kinematics with the amended rules. It
covers the six earlier flick profiles plus two 140 mm profiles. The differences between arms are
nominal / e+2 mm / e−2 mm. Before amendment 4, the 55 v 30 e−2 values were 18.0–23.2.

| profile                              | 55 v 30 (true 25)             | 42 v 30 (12)   | 40 v 15 (25)   | 40 v 5 (35, RN below floor) |
| ------------------------------------ | ----------------------------- | -------------- | -------------- | --------------------------- |
| cosine 100 mm 1.2 m/s                | – / – / 25.0 (too few frames) | 12.0/12.0/12.0 | 25.0/25.0/24.7 | 31.4/31.4/31.1              |
| cosine 100 mm 0.9 m/s                | 25.0/25.0/25.0                | 12.0/12.0/12.0 | 25.0/25.0/24.9 | 28.6/28.6/28.4              |
| cosine 130 mm 1.4 m/s                | 25.0/25.0/24.9                | 12.0/12.0/11.9 | 25.0/25.0/24.7 | 32.7/32.7/32.4              |
| min-jerk 100 mm / 150 ms             | – / – / – (too few frames)    | 12.0/12.0/12.0 | 25.0/25.2/24.5 | 31.4/31.7/30.9              |
| min-jerk 100 mm / 200 ms             | 25.0/25.0/24.8                | 12.0/12.0/11.9 | 25.0/25.2/24.6 | 28.8/29.1/28.3              |
| min-jerk 130 mm / 160 ms             | 25.0/25.0/24.6                | 12.0/12.0/11.7 | 25.0/25.3/24.4 | 33.0/33.3/32.4              |
| cosine 140 mm 1.2 m/s (the fixtures) | 25.0/25.0/24.8                | 12.0/12.0/11.8 | 25.0/25.1/24.7 | 31.4/31.5/31.2              |
| min-jerk 140 mm / 200 ms             | 25.0/25.1/24.6                | 12.0/12.1/11.6 | 25.0/25.5/24.4 | 32.0/32.6/31.3              |

* With the matched moment also at ≥ 0.5 m/s, 2 mm of e moves a difference by at most 0.6 ms in
  either direction.
* The same holds with a touch-and-go start.
* A 55 ms arm keeps 16–17 valid frames per stroke on 140 mm swipes, against 8–9 on short fast 100 mm
  ones.

## Earlier findings (why amendments 2–4 exist)

* **Trail time compresses and saturates.** At the top of `sensitivity.txt`, trail time moves
  0.42–0.91 ms per ms of latency and goes flat past about 60 ms with a resting start. Shift lag
  replaced it (amendment 2).
* **Amendment 3's e ± 2 mm test was lopsided.** The slower arm's matched moment fell in the slow
  acceleration, so a true 25 ms read 16.6–18.9 ms under e − 2 mm. The matched-moment speed rule
  fixes it (amendment 4).

## Known limits

* **Not yet seen real footage.** The iPhone's noise, HEVC 10-bit / HLG, rolling shutter, and the
  iPad's refresh, glare, moiré and mini-LED behaviour are untested. The note requires the first real
  clip to be checked by eye against the debug images before anything is scored.
* **Short swipes cannot score long delays.** With the matched-moment rule, a delay around 55 ms
  needs roughly 100 ms of sustained fast motion. 100 mm flicks leave most such strokes unscorable,
  which is not below floor. Use 130–150 mm swipes.
* **Below floor is an upper bound.**
  * It is about (e + 2 mm) / v, roughly 7–11 ms at 1.0–1.5 m/s.
  * A hidden fast app is credited with that bound, never with a faster value.
  * A leading (predicting) app whose lead stays under the finger scores below floor the same way.
  * A lead shows as a negative value only when it passes the finger's leading edge.
* **Camera shake** enters shift lag directly, because t and t′ are different frames. ±3 px shake
  gave per-stroke errors up to about 1.2 ms. A propped camera should be steadier.
* **Systematic bias.** The scorer reads about +0.34 ms high against the oracle. It is the same in
  both arms. Below-floor values read about 0.2 ms low.
* **Occlusion, nail, lighting, crayon, perspective, resolution and layout:**
  * Swipe sideways to the finger.
  * Lock AE/AF.
  * Crayon is validated only on synthetic grain.
  * Use `--corners`.
  * At least 2 px/mm is required.
  * Strokes go on fresh paper, with the fingertip at least 15 mm from the crop edge.
  * Keep filming 0.5 s after the last lift.
* **Short-ink sensitivity.** A shortfall smaller than about 4 mm relative to the contact offset
  cannot be seen on camera.

## Filming notes to relay

* 240 fps Slo-mo, phone propped above, all four screen corners in view, AE/AF locked.
* Strokes are separate horizontal lines **130–150 mm long**, centred on the page, swiped fast and
  sideways to the finger.
* Use the same start habit in every clip.
* Hold dead still for at least 1 s, then lift and move the hand out of view.
* AirDrop › Options › All Photos Data.
